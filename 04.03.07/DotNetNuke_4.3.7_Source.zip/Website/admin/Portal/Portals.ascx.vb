'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2006
' by DotNetNuke Corporation
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports DotNetNuke.Entities.Modules.Actions

Namespace DotNetNuke.Modules.Admin.Portals

	''' -----------------------------------------------------------------------------
	''' <summary>
	''' The Portals PortalModuleBase is used to manage the portlas.
	''' </summary>
	''' <returns></returns>
	''' <remarks>
	''' </remarks>
	''' <history>
	''' 	[cnurse]	9/28/2004	Updated to reflect design changes for Help, 508 support
	'''                       and localisation
	''' </history>
	''' -----------------------------------------------------------------------------
	Partial  Class Portals

		Inherits Entities.Modules.PortalModuleBase
		Implements Entities.Modules.IActionable

#Region "Controls"


#End Region

#Region "Private Methods"

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' BindData fetches the data from the database and updates the controls
		''' </summary>
		''' <returns></returns>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	9/28/2004	Updated to reflect design changes for Help, 508 support
		'''                       and localisation
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub BindData()

			Dim objPortalController As New PortalController

			'Localize the Grid
			Services.Localization.Localization.LocalizeDataGrid(grdPortals, Me.LocalResourceFile)

			grdPortals.DataSource = objPortalController.GetPortals
			grdPortals.DataBind()

		End Sub

#End Region

#Region "Public Methods"

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' FormatExpiryDate formats the expiry date and filter out null-dates
		''' </summary>
		''' <returns></returns>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	9/28/2004	Updated to reflect design changes for Help, 508 support
		'''                       and localisation
		''' </history>
		''' -----------------------------------------------------------------------------
		Function FormatExpiryDate(ByVal DateTime As Date) As String
			Try
				If Not Null.IsNull(DateTime) Then
					FormatExpiryDate = DateTime.ToShortDateString
				End If
			Catch exc As Exception			 'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try
		End Function

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' FormatExpiryDate formats the format name as an <a> tag
		''' </summary>
		''' <returns></returns>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	9/28/2004	Updated to reflect design changes for Help, 508 support
		'''                       and localisation
		''' </history>
		''' -----------------------------------------------------------------------------
		Public Function FormatPortalAliases(ByVal PortalID As Integer) As String
			Try
				Dim objPortalAliasController As New PortalAliasController
				Dim arr As ArrayList = objPortalAliasController.GetPortalAliasArrayByPortalID(PortalID)
				Dim objPortalAliasInfo As PortalAliasInfo
				Dim str As New System.Text.StringBuilder
				Dim i As Integer
				For i = 0 To arr.Count - 1
					objPortalAliasInfo = CType(arr(i), PortalAliasInfo)
                    str.Append("<a href=""" + AddHTTP(objPortalAliasInfo.HTTPAlias) + """>" + objPortalAliasInfo.HTTPAlias + "</a>" + "<BR>")
				Next
				Return str.ToString

			Catch exc As Exception			 'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try
		End Function

		Public Function GetEditURL(ByVal PortalID As Integer) As String
			Dim objTabs As New TabController
            Dim objTab As Entities.Tabs.TabInfo = objTabs.GetTabByName("Site Settings", PortalSettings.PortalId, PortalSettings.AdminTabId)
            Return NavigateURL(objTab.TabID, "", "pid=" & PortalID.ToString)
		End Function
#End Region

#Region "Event Handlers"

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Page_Load runs when the control is loaded.
		''' </summary>
		''' <returns></returns>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	9/28/2004	Updated to reflect design changes for Help, 508 support
		'''                       and localisation
		'''     [VMasanas]  9/28/2004   Changed redirect to Access Denied
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
			Try

				' Verify that the current user has access to access this page
				If Not UserInfo.IsSuperUser Then
					Response.Redirect(NavigateURL("Access Denied"), True)
				End If

				BindData()

			Catch exc As Exception			 'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try

		End Sub

#End Region

#Region "Optional Interfaces"
		Public ReadOnly Property ModuleActions() As ModuleActionCollection Implements Entities.Modules.IActionable.ModuleActions
			Get
				Dim Actions As New ModuleActionCollection
				Actions.Add(GetNextActionID, Services.Localization.Localization.GetString(ModuleActionType.AddContent, LocalResourceFile), ModuleActionType.AddContent, "", "", EditUrl("Signup"), False, SecurityAccessLevel.Host, True, False)
				Return Actions
			End Get
		End Property
#End Region

#Region " Web Form Designer Generated Code "

		'This call is required by the Web Form Designer.
		<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

		End Sub

		Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
			'CODEGEN: This method call is required by the Web Form Designer
			'Do not modify it using the code editor.
			InitializeComponent()
		End Sub

#End Region

	End Class

End Namespace
