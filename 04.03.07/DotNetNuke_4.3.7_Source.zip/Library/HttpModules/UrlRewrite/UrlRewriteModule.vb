'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2006
' by DotNetNuke Corporation
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.IO
Imports System.Web
Imports System.Text.RegularExpressions
Imports DotNetNuke
Imports DotNetNuke.Entities.Portals
Imports DotNetNuke.Common

Namespace DotNetNuke.HttpModules

    Public Class UrlRewriteModule

        Implements IHttpModule

        Public ReadOnly Property ModuleName() As String
            Get
                Return "UrlRewriteModule"
            End Get
        End Property

        Public Sub Init(ByVal application As HttpApplication) Implements IHttpModule.Init

            AddHandler application.BeginRequest, AddressOf Me.OnBeginRequest

        End Sub


        Public Sub OnBeginRequest(ByVal s As Object, ByVal e As EventArgs)

            Dim app As HttpApplication = CType(s, HttpApplication)
            Dim Server As HttpServerUtility = app.Server
            Dim Request As HttpRequest = app.Request
            Dim Response As HttpResponse = app.Response
            Dim requestedPath As String = app.Request.Url.AbsoluteUri

            ' URL validation 
            ' check for ".." escape characters commonly used by hackers to traverse the folder tree on the server
            ' the application should always use the exact relative location of the resource it is requesting
            Dim strURL As String = Request.Url.AbsolutePath
            Dim strDoubleDecodeURL As String = Server.UrlDecode(Server.UrlDecode(Request.RawUrl))
            If strURL.IndexOf("..") <> -1 Or strDoubleDecodeURL.IndexOf("..") <> -1 Then
                Throw New HttpException(404, "Not Found")
            End If

            'fix for ASP.NET canonicalization issues http://support.microsoft.com/?kbid=887459
            If (Request.Path.IndexOf(Chr(92)) >= 0 Or System.IO.Path.GetFullPath(Request.PhysicalPath) <> Request.PhysicalPath) Then
                Throw New HttpException(404, "Not Found")
            End If

            'check if we are upgrading/installing
            If Request.Url.LocalPath.ToLower.EndsWith("install.aspx") Then
                Exit Sub
            End If

            ' save original url in context
            app.Context.Items.Add("UrlRewrite:OriginalUrl", app.Request.Url.AbsoluteUri)

            ' Friendly URLs are exposed externally using the following format
            ' http://www.domain.com/tabid/###/mid/###/ctl/xxx/default.aspx
            ' and processed internally using the following format
            ' http://www.domain.com/default.aspx?tabid=###&mid=###&ctl=xxx
            ' The system for accomplishing this is based on an extensible Regex rules definition stored in /SiteUrls.config
            Dim sendTo As String = ""

            ' save and remove the querystring as it gets added back on later
            ' path parameter specifications will take precedence over querystring parameters
            Dim strQueryString As String = ""
            If (app.Request.Url.Query <> "") Then
                strQueryString = Request.QueryString.ToString()
                requestedPath = requestedPath.Replace(app.Request.Url.Query, "")
            End If

            ' get url rewriting rules 
            Dim rules As Config.RewriterRuleCollection = Config.RewriterConfiguration.GetConfig().Rules

            ' iterate through list of rules
            Dim intMatch As Integer = -1
            For intRule As Integer = 0 To rules.Count - 1
                ' check for the existence of the LookFor value 
                Dim strLookFor As String = "^" & RewriterUtils.ResolveUrl(app.Context.Request.ApplicationPath, rules(intRule).LookFor) & "$"
                Dim objLookFor As Regex = New Regex(strLookFor, RegexOptions.IgnoreCase)
                ' if there is a match
                If (objLookFor.IsMatch(requestedPath)) Then
                    ' create a new URL using the SendTo regex value
                    sendTo = RewriterUtils.ResolveUrl(app.Context.Request.ApplicationPath, objLookFor.Replace(requestedPath, rules(intRule).SendTo))
                    ' obtain the RegEx match group which contains the parameters
                    Dim objMatch As Match = objLookFor.Match(requestedPath)
                    Dim strParameters As String = objMatch.Groups(2).Value
                    ' process the parameters
                    If (strParameters.Trim().Length > 0) Then
                        ' split the value into an array based on "/" ( ie. /tabid/##/ )
                        strParameters = strParameters.Replace("\", "/")
                        Dim arrParameters As String() = strParameters.Split("/"c)
                        Dim strParameterDelimiter As String
                        Dim strParameterName As String
                        Dim strParameterValue As String
                        ' icreate a well formed querystring based on the array of parameters
                        For intParameter As Integer = 1 To arrParameters.Length - 1
                            ' ignore the page name 
                            If arrParameters(intParameter).ToLower.IndexOf(".aspx") = -1 Then
                                ' get parameter name
                                strParameterName = arrParameters(intParameter).Trim()
                                If strParameterName.Length > 0 Then
                                    ' add parameter to SendTo if it does not exist already  
                                    If sendTo.ToLower.IndexOf("?" & strParameterName.ToLower) = -1 And sendTo.ToLower.IndexOf("&" & strParameterName.ToLower) = -1 Then
                                        ' get parameter delimiter
                                        If sendTo.IndexOf("?") <> -1 Then
                                            strParameterDelimiter = "&"
                                        Else
                                            strParameterDelimiter = "?"
                                        End If
                                        sendTo = sendTo & strParameterDelimiter & strParameterName
                                        ' get parameter value
                                        strParameterValue = ""
                                        If (intParameter < (arrParameters.Length - 1)) Then
                                            intParameter += 1
                                            If (arrParameters(intParameter).Trim <> "") Then
                                                strParameterValue = arrParameters(intParameter).Trim()
                                            End If
                                        End If
                                        ' add the parameter value
                                        If strParameterValue.Length > 0 Then
                                            sendTo = sendTo & "=" & strParameterValue
                                        End If
                                    End If
                                End If
                            End If
                        Next
                    End If
                    intMatch = intRule
                    Exit For ' exit as soon as it processes the first match
                End If
            Next

            ' add querystring parameters back to SendTo
            If strQueryString <> "" Then
                Dim arrParameters As String() = strQueryString.Split("&"c)
                Dim strParameterName As String
                ' iterate through the array of parameters
                For intParameter As Integer = 0 To arrParameters.Length - 1
                    ' get parameter name
                    strParameterName = arrParameters(intParameter)
                    If strParameterName.IndexOf("=") <> -1 Then
                        strParameterName = strParameterName.Substring(0, strParameterName.IndexOf("="))
                    End If
                    ' check if parameter already exists
                    If sendTo.ToLower.IndexOf("?" & strParameterName.ToLower) = -1 And sendTo.ToLower.IndexOf("&" & strParameterName.ToLower) = -1 Then
                        ' add parameter to SendTo value
                        If sendTo.IndexOf("?") <> -1 Then
                            sendTo = sendTo & "&" & arrParameters(intParameter)
                        Else
                            sendTo = sendTo & "?" & arrParameters(intParameter)
                        End If
                    End If
                Next
            End If

            ' if a match was found to the urlrewrite rules
            If intMatch <> -1 Then
                If rules(intMatch).SendTo.StartsWith("~") Then
                    ' rewrite the URL for internal processing
                    RewriterUtils.RewriteUrl(app.Context, sendTo)
                Else
                    ' it is not possible to rewrite the domain portion of the URL so redirect to the new URL
                    Response.Redirect(sendTo, True)
                End If
            End If

            ' *Note: from this point on we are dealing with a "standard" querystring ( ie. http://www.domain.com/default.aspx?tabid=## )

            Dim TabId As Integer = -1
            Dim PortalId As Integer = -1
            Dim DomainName As String = Nothing
            Dim PortalAlias As String = Nothing
            Dim objPortalAliasInfo As PortalAliasInfo

            ' get TabId from querystring ( this is mandatory for maintaining portal context for child portals )
            Try
                If Not (Request.QueryString("tabid") Is Nothing) Then
                    TabId = Int32.Parse(Request.QueryString("tabid"))
                End If
                ' get PortalId from querystring ( this is used for host menu options as well as child portal navigation )
                If Not (Request.QueryString("portalid") Is Nothing) Then
                    PortalId = Int32.Parse(Request.QueryString("portalid"))
                End If
            Catch ex As Exception
                'The tabId or PortalId are incorrectly formatted (potential DOS)
                Throw New HttpException(404, "Not Found")
            End Try

            ' alias parameter can be used to switch portals
            If Not (Request.QueryString("alias") Is Nothing) Then
                ' check if the alias is valid
                If Not PortalSettings.GetPortalAliasInfo(Request.QueryString("alias")) Is Nothing Then
                    ' check if the domain name contains the alias
                    If InStr(1, Request.QueryString("alias"), DomainName, CompareMethod.Text) = 0 Then
                        ' redirect to the url defined in the alias
                        Response.Redirect(GetPortalDomainName(Request.QueryString("alias"), Request), True)
                    Else ' the alias is the same as the current domain
                        PortalAlias = Request.QueryString("alias")
                    End If
                End If
            End If

            ' parse the Request URL into a Domain Name token 
            DomainName = GetDomainName(Request, True)

            ' PortalId identifies a portal when set
            If PortalAlias Is Nothing Then
                If PortalId <> -1 Then
                    PortalAlias = PortalSettings.GetPortalByID(PortalId, DomainName)
                End If
            End If

            ' TabId uniquely identifies a Portal
            If PortalAlias Is Nothing Then
                If TabId <> -1 Then
                    ' get the alias from the tabid, but only if it is for a tab in that domain
                    PortalAlias = PortalSettings.GetPortalByTab(TabId, DomainName)
                    If PortalAlias Is Nothing Or PortalAlias = "" Then
                        'if the TabId is not for the correct domain
                        'see if the correct domain can be found and redirect it 
                        objPortalAliasInfo = PortalSettings.GetPortalAliasInfo(DomainName)
                        If Not objPortalAliasInfo Is Nothing Then
                            If app.Request.Url.AbsoluteUri.ToLower.StartsWith("https://") Then
                                strURL = "https://" & objPortalAliasInfo.HTTPAlias.Replace("*.", "")
                            Else
                                strURL = "http://" & objPortalAliasInfo.HTTPAlias.Replace("*.", "")
                            End If
                            If strURL.ToLower.IndexOf(DomainName.ToLower()) = -1 Then
                                strURL += app.Request.Url.PathAndQuery
                            End If
                            Response.Redirect(strURL, True)
                        End If
                    End If
                End If
            End If

            ' else use the domain name
            If PortalAlias Is Nothing Or PortalAlias = "" Then
                PortalAlias = DomainName
            End If
            'using the DomainName above will find that alias that is the domainname portion of the Url
            'ie. dotnetnuke.com will be found even if zzz.dotnetnuke.com was entered on the Url
            objPortalAliasInfo = PortalSettings.GetPortalAliasInfo(PortalAlias)
            If Not objPortalAliasInfo Is Nothing Then
                PortalId = objPortalAliasInfo.PortalID
            End If

            ' if the portalid is not known
            If PortalId = -1 Then
                If Not Request.Url.LocalPath.ToLower.EndsWith(glbDefaultPage.ToLower) Then
                    ' allows requests for aspx pages in custom folder locations to be processed
                    Exit Sub
                Else
                    'the domain name was not found so try using the host portal's first alias
                    If Convert.ToString(HostSettings("HostPortalId")) <> "" Then
                        PortalId = Convert.ToInt32(HostSettings("HostPortalId"))
                        ' use the host portal
                        Dim objPortalAliasController As New PortalAliasController
                        Dim arrPortalAliases As ArrayList
                        arrPortalAliases = objPortalAliasController.GetPortalAliasArrayByPortalID(Integer.Parse(Convert.ToString(HostSettings("HostPortalId"))))
                        If arrPortalAliases.Count > 0 Then
                            'Get the first Alias
                            objPortalAliasInfo = CType(arrPortalAliases(0), PortalAliasInfo)
                            If app.Request.Url.AbsoluteUri.ToLower.StartsWith("https://") Then
                                strURL = "https://" & objPortalAliasInfo.HTTPAlias.Replace("*.", "")
                            Else
                                strURL = "http://" & objPortalAliasInfo.HTTPAlias.Replace("*.", "")
                            End If
                            If TabId <> -1 Then
                                strURL += app.Request.Url.Query()
                            End If
                            Response.Redirect(strURL, True)
                        End If
                    End If
                End If
            End If


            If PortalId <> -1 Then
                ' load the PortalSettings into current context
                Dim _portalSettings As PortalSettings = New PortalSettings(TabId, objPortalAliasInfo)
                app.Context.Items.Add("PortalSettings", _portalSettings)
            Else
                ' alias does not exist in database
                ' and all attempts to find another have failed
                'this should only happen if the HostPortal does not have any aliases
                Dim objStreamReader As StreamReader
                objStreamReader = File.OpenText(Server.MapPath("~/404.htm"))
                Dim strHTML As String = objStreamReader.ReadToEnd
                objStreamReader.Close()
                strHTML = Replace(strHTML, "[DOMAINNAME]", DomainName)
                Response.Write(strHTML)
                Response.End()
            End If

        End Sub

        Public Sub Dispose() Implements IHttpModule.Dispose
        End Sub

    End Class

End Namespace
