'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports AspNetSecurity = System.Web.Security

Imports DotNetNuke.Entities.Modules
Imports DotNetNuke.Services.Mail
Imports DotNetNuke.UI.Utilities

Namespace DotNetNuke.Modules.Admin.Users

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' The ManageUsers PortalModuleBase is used to manage Users
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[cnurse]	9/13/2004	Updated to reflect design changes for Help, 508 support
    '''                       and localisation
    '''     [cnurse]    2/21/2005   Updated to use new User UserControl
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Partial  Class ManageUsers
        Inherits DotNetNuke.Entities.Modules.PortalModuleBase

#Region "Controls"

        'User Details Area


        'tasks

        'Audit Area

        Protected WithEvents Dropdownlist1 As System.Web.UI.WebControls.DropDownList
        Protected WithEvents Dropdownlist2 As System.Web.UI.WebControls.DropDownList


#End Region

#Region "Private Members"

        Private Shadows UserId As Integer = -1

#End Region

#Region "Private Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' BindData binds the controls to the Data
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/13/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub BindData()

            userControl.ModuleId = ModuleId
            userControl.StartTabIndex = 1
            addressUser.ModuleId = ModuleId
            addressUser.StartTabIndex = 10

            'Populate the timezone combobox (look up timezone translations based on currently set culture)
            Services.Localization.Localization.LoadTimeZoneDropDownList(cboTimeZone, CType(Page, PageBase).PageCulture.Name, Convert.ToString(PortalSettings.TimeZoneOffset))
            Services.Localization.Localization.LoadCultureDropDownList(cboLocale, CultureDropDownTypes.NativeName, CType(Page, PageBase).PageCulture.Name)

            If UserId = -1 Then
                'If trying to add a SuperUser - check that user is a SuperUser
                If PortalSettings.ActiveTab.ParentId = PortalSettings.SuperTabId And Not Me.UserInfo.IsSuperUser Then
                    UI.Skins.Skin.AddModuleMessage(Me, Services.Localization.Localization.GetString("SuperUser", LocalResourceFile), UI.Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                    DisableForm()
                    Exit Sub
                End If
                userControl.ShowPassword = True
                chkAuthorized.Checked = True
                cmdDelete.Visible = False
                cmdManage.Visible = False
                pnlAudit.Visible = False
                PasswordManagementRow.Visible = False
            Else
                Dim objUsers As New UserController
                Dim objUser As UserInfo = objUsers.GetUser(PortalId, UserId)

                ' Read first row from database
                If Not objUser Is Nothing Then

                    'Check if User is a member of the Current Portal
                    If objUser.PortalID <> PortalId Then
                        UI.Skins.Skin.AddModuleMessage(Me, Services.Localization.Localization.GetString("InvalidUser", LocalResourceFile), UI.Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                        DisableForm()
                        Exit Sub
                    End If


                    'Check if User is a SuperUser and that the current User is a SuperUser
                    If objUser.IsSuperUser And Not Me.UserInfo.IsSuperUser Then
                        UI.Skins.Skin.AddModuleMessage(Me, Services.Localization.Localization.GetString("SuperUser", LocalResourceFile), UI.Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                        DisableForm()
                        Exit Sub
                    End If

                    If objUser.Membership.LockedOut Then
                        UI.Skins.Skin.AddModuleMessage(Me, Services.Localization.Localization.GetString("UserLockedOut", LocalResourceFile), UI.Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                        cmdUnlock.Visible = True
                    Else
                        cmdUnlock.Visible = False
                    End If

                    userControl.FirstName = objUser.Profile.FirstName
                    userControl.LastName = objUser.Profile.LastName
                    userControl.UserName = objUser.Membership.Username
                    userControl.Email = objUser.Membership.Email
                    userControl.IM = objUser.Profile.IM
                    userControl.Website = objUser.Profile.Website
                    chkAuthorized.Checked = objUser.Membership.Approved

                    If Not cboTimeZone.Items.FindByValue(objUser.Profile.TimeZone.ToString) Is Nothing Then
                        cboTimeZone.ClearSelection()
                        cboTimeZone.Items.FindByValue(objUser.Profile.TimeZone.ToString).Selected = True
                    End If
                    If Not cboLocale.Items.FindByValue(objUser.Profile.PreferredLocale.ToString) Is Nothing Then
                        cboLocale.ClearSelection()
                        cboLocale.Items.FindByValue(objUser.Profile.PreferredLocale.ToString).Selected = True
                    End If

                    addressUser.Unit = objUser.Profile.Unit
                    addressUser.Street = objUser.Profile.Street
                    addressUser.City = objUser.Profile.City
                    addressUser.Region = objUser.Profile.Region
                    addressUser.Country = objUser.Profile.Country
                    addressUser.Postal = objUser.Profile.PostalCode
                    addressUser.Telephone = objUser.Profile.Telephone
                    addressUser.Cell = objUser.Profile.Cell
                    addressUser.Fax = objUser.Profile.Fax

                    ' disable deletion or deactivation of the currently logged in account
                    If UserInfo.UserID = objUser.UserID Then
                        cmdDelete.Visible = False
                        chkAuthorized.Enabled = False
                    End If

                    ' super users can not be assigned to roles
                    If objUser.IsSuperUser Then
                        cmdManage.Visible = False
                    End If

                    ' Hide null-dates
                    If Not Null.IsNull(objUser.Membership.CreatedDate) Then
                        lblCreatedDate.Text = objUser.Membership.CreatedDate.ToString
                    End If
                    If Not Null.IsNull(objUser.Membership.LastLoginDate) Then
                        lblLastLoginDate.Text = objUser.Membership.LastLoginDate.ToString
                    End If
                Else
                    UI.Skins.Skin.AddModuleMessage(Me, Services.Localization.Localization.GetString("NoUser", LocalResourceFile), UI.Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                    DisableForm()
                End If
                userControl.ShowPassword = False
            End If

        End Sub

        Private Sub DisableForm()

            cmdUpdate.Visible = False
            cmdManage.Visible = False
            cmdDelete.Visible = False
            pnlAudit.Visible = False
            tblPreferences.Visible = False
            dshPreferences.Visible = False
            tblPassword.Visible = False
            dshPassword.Visible = False

        End Sub
#End Region

#Region "Event Handlers"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Page_Load runs when the control is loaded
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/13/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        '''     [VMasanas]  9/28/2004   Changed redirect to Access Denied
        '''		[dan.caron] 11/1/2004	Removed limitation where SuperUser could not access page
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try

                ' get userid
                If Not (Request.QueryString("userid") Is Nothing) Then
                    UserId = Int32.Parse(Request.QueryString("userid"))
                End If

                ' If this is the first visit to the page, bind the role data to the datalist
                If Page.IsPostBack = False Then
                    ClientAPI.AddButtonConfirm(cmdDelete, Services.Localization.Localization.GetString("DeleteItem"))
                    BindData()
                End If

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' cmdCancel_Click runs when the cancel Button is clicked
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/13/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
            Try
                Response.Redirect(NavigateURL(TabId, "", IIf(Request.QueryString("filter") <> "", "filter=" & Request.QueryString("filter"), "").ToString), True)

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' cmdDelete_Click runs when the delete Button is clicked
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/13/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdDelete.Click
            Try

                ' get user id from dropdownlist of users
                Dim objUsers As New UserController
                Dim intPortalID As Integer
                If PortalSettings.ActiveTab.ParentId = PortalSettings.SuperTabId Then
                    intPortalID = -1
                Else
                    intPortalID = PortalId
                End If
                objUsers.DeleteUser(intPortalID, UserId)

                Dim objEventLog As New Services.Log.EventLog.EventLogController
                objEventLog.AddLog("Username", userControl.UserName, PortalSettings, UserId, Services.Log.EventLog.EventLogController.EventLogType.USER_DELETED)
                Response.Redirect(NavigateURL(TabId, "", IIf(Request.QueryString("filter") <> "", "filter=" & Request.QueryString("filter"), "").ToString), True)

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' cmdManage_Click runs when the manage Users Button is clicked
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/13/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdManage_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdManage.Click
            Try
                Response.Redirect(NavigateURL(Me.TabId, "User Roles", "UserId=" & UserId), True)
            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' cmdUpdate_Click runs when the Update Button is clicked
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/13/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        '''     [vmasanas]  11/23/2004  Username cannot be changed
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdUpdate.Click
            Try
                ' Only attempt a save/update if all form fields on the page are valid
                If Page.IsValid = True Then

                    ' update the user record in the database
                    Dim objUsers As New UserController
                    Dim ObjUser As UserInfo

                    If UserId = -1 Then
                        ObjUser = New UserInfo
                        If PortalSettings.ActiveTab.ParentId = PortalSettings.SuperTabId Then
                            ObjUser.PortalID = -1
                            ObjUser.IsSuperUser = True
                        Else
                            ObjUser.PortalID = PortalId
                        End If
                        ObjUser.Membership.Username = userControl.UserName
                        ObjUser.Profile.FirstName = userControl.FirstName
                        ObjUser.Profile.LastName = userControl.LastName
                        ObjUser.Profile.Unit = addressUser.Unit
                        ObjUser.Profile.Street = addressUser.Street
                        ObjUser.Profile.City = addressUser.City
                        ObjUser.Profile.Region = addressUser.Region
                        ObjUser.Profile.PostalCode = addressUser.Postal
                        ObjUser.Profile.Country = addressUser.Country
                        ObjUser.Profile.Telephone = addressUser.Telephone
                        ObjUser.Membership.Email = userControl.Email
                        ObjUser.Membership.Approved = chkAuthorized.Checked
                        ObjUser.AffiliateID = Null.NullInteger
                        ObjUser.Profile.Cell = addressUser.Cell
                        ObjUser.Profile.Fax = addressUser.Fax
                        ObjUser.Profile.IM = userControl.IM
                        ObjUser.Profile.Website = userControl.Website
                        ObjUser.Profile.PreferredLocale = cboLocale.SelectedItem.Value
                        ObjUser.Profile.TimeZone = Convert.ToInt32(cboTimeZone.SelectedItem.Value)
                        ObjUser.Membership.Password = userControl.Password
                        UserId = objUsers.AddUser(ObjUser, True)
                        ObjUser.UserID = UserId

                        If UserId >= 0 Then
                            Dim objEventLog As New Services.Log.EventLog.EventLogController
                            objEventLog.AddLog(ObjUser, PortalSettings, UserId, UserControl.UserName, Services.Log.EventLog.EventLogController.EventLogType.USER_CREATED)
                            Mail.SendMail(PortalSettings.Email, UserControl.Email, "", _
                                Services.Localization.Localization.GetSystemMessage(ObjUser.Profile.PreferredLocale, PortalSettings, "EMAIL_USER_REGISTRATION_PUBLIC_SUBJECT", ObjUser), _
                                Services.Localization.Localization.GetSystemMessage(ObjUser.Profile.PreferredLocale, PortalSettings, "EMAIL_USER_REGISTRATION_PUBLIC_BODY", ObjUser), _
                                "", "", "", "", "", "")
                            Response.Redirect(NavigateURL(TabId, "", "filter=" & Left(UserControl.FirstName, 1)), True)
                        Else       ' registration error
                            Dim UserRegistrationStatus As AspNetSecurity.MembershipCreateStatus
                            UserRegistrationStatus = CType(UserId * -1, AspNetSecurity.MembershipCreateStatus)
                            Dim objUserController As New UserController
                            lblMessage.Text = objUserController.GetRegistrationStatus(UserRegistrationStatus)
                        End If
                    Else
                        ' if activating an account, send notification
                        ObjUser = objUsers.GetUser(PortalId, UserId)

                        If Not ObjUser Is Nothing Then
                            If chkAuthorized.Checked Then
                                If ObjUser.Membership.Approved <> chkAuthorized.Checked Then
                                    Mail.SendMail(PortalSettings.Email, userControl.Email, "", _
                                        Services.Localization.Localization.GetSystemMessage(ObjUser.Profile.PreferredLocale, PortalSettings, "EMAIL_USER_REGISTRATION_PUBLIC_SUBJECT", ObjUser), _
                                        Services.Localization.Localization.GetSystemMessage(ObjUser.Profile.PreferredLocale, PortalSettings, "EMAIL_USER_REGISTRATION_PUBLIC_BODY", ObjUser), _
                                        "", "", "", "", "", "")
                                End If
                            End If

                            'update the user
                            ObjUser.Profile.FirstName = userControl.FirstName
                            ObjUser.Profile.LastName = userControl.LastName
                            ObjUser.Profile.Unit = addressUser.Unit
                            ObjUser.Profile.Street = addressUser.Street
                            ObjUser.Profile.City = addressUser.City
                            ObjUser.Profile.Region = addressUser.Region
                            ObjUser.Profile.PostalCode = addressUser.Postal
                            ObjUser.Profile.Country = addressUser.Country
                            ObjUser.Profile.Telephone = addressUser.Telephone
                            ObjUser.Membership.Email = userControl.Email
                            ObjUser.Membership.Approved = chkAuthorized.Checked
                            ObjUser.Profile.Cell = addressUser.Cell
                            ObjUser.Profile.Fax = addressUser.Fax
                            ObjUser.Profile.IM = userControl.IM
                            ObjUser.Profile.Website = userControl.Website
                            ObjUser.Profile.PreferredLocale = cboLocale.SelectedItem.Value
                            ObjUser.Profile.TimeZone = Convert.ToInt32(cboTimeZone.SelectedItem.Value)
                            objUsers.UpdateUser(ObjUser)
                        End If

                        Response.Redirect(NavigateURL(TabId, "", IIf(Request.QueryString("filter") <> "", "filter=" & Request.QueryString("filter"), "").ToString), True)
                    End If
                End If
            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' cmdUnlock_Click runs when the Unlock Account Button is clicked
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdUnlock_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdUnlock.Click
            Try

                ' update the user record in the database
                Dim objUsers As New UserController
                Dim ObjUser As UserInfo

                ObjUser = objUsers.GetUser(PortalId, UserId)
                objUsers.UnlockUserAccount(ObjUser)

                Response.Redirect(NavigateURL(TabId, "", IIf(Request.QueryString("filter") <> "", "filter=" & Request.QueryString("filter"), "").ToString), True)

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' cmdUpdatePassword_Click runs when the Update Pasword Button is clicked
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	3/03/2005	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdUpdatePassword_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdUpdatePassword.Click
            If txtNewPassword.Text = "" Or txtNewConfirm.Text = "" Then
                MessageCell.Controls.Add(UI.Skins.Skin.GetModuleMessageControl("", DotNetNuke.Services.Localization.Localization.GetString("NewPassword", Me.LocalResourceFile), DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning))
                Exit Sub
            End If
            If txtNewPassword.Text <> txtNewConfirm.Text Then
                MessageCell.Controls.Add(UI.Skins.Skin.GetModuleMessageControl("", DotNetNuke.Services.Localization.Localization.GetString("PasswordMatchFailure", Me.LocalResourceFile), DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning))
                Exit Sub
            End If

            Dim objUserController As New UserController
            Dim objUser As UserInfo = objUserController.GetUser(PortalId, UserId)

            If objUserController.SetPassword(objUser, txtNewPassword.Text) Then
                'Success
                MessageCell.Controls.Add(UI.Skins.Skin.GetModuleMessageControl("", DotNetNuke.Services.Localization.Localization.GetString("PasswordChanged", Me.LocalResourceFile), DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.GreenSuccess))
            Else
                'Fail
                MessageCell.Controls.Add(UI.Skins.Skin.GetModuleMessageControl("", DotNetNuke.Services.Localization.Localization.GetString("PasswordResetFailed", Me.LocalResourceFile), DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning))
            End If
        End Sub

#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

    End Class

End Namespace