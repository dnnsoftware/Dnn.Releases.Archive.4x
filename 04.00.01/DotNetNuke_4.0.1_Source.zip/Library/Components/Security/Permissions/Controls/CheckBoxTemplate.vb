'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.Drawing
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.IO
Imports System.Collections
Imports System.Data


Namespace DotNetNuke.Security.Permissions.Controls


    Public Class CheckBoxTemplate : Implements ITemplate

        '---------------------------------------------------------------------------- 
        ' The internal storage for which DataField we are going to represent. 
        '---------------------------------------------------------------------------- 
        Private mDataField As String
        '---------------------------------------------------------------------------- 
        ' The internal storage for the AutoPostback flag. 
        '---------------------------------------------------------------------------- 
        Private mAutoPostBack As Boolean = False
        '---------------------------------------------------------------------------- 
        ' Internal storage for the readOnly flag. 
        '---------------------------------------------------------------------------- 
        Private mReadOnly As Boolean
        '---------------------------------------------------------------------------- 
        ' Internal storage for value mapping - bind checkbox to non-boolean fields 
        '---------------------------------------------------------------------------- 
        Private mTrueValue As String
        '---------------------------------------------------------------------------- 
        ' Our CheckChanged event 
        '---------------------------------------------------------------------------- 
        Public Event BoxCheckedChanged(ByVal gridIndex As Integer, ByVal checked As Boolean)

        '---------------------------------------------------------------------------- 
        ' The CheckBoxTemplate constructor 
        '---------------------------------------------------------------------------- 
        Public Sub New(ByVal editable As Boolean)
            mReadOnly = CType(IIf((editable = True), False, True), Boolean)
        End Sub

        Public Sub New(ByVal editable As Boolean, ByVal trueValue As String)
            mReadOnly = CType(IIf((editable = True), False, True), Boolean)
            mTrueValue = trueValue
        End Sub
        '---------------------------------------------------------------------------- 
        ' Instantiates the CheckBox that we wish to represent in this column. 
        '---------------------------------------------------------------------------- 
        Public Sub InstantiateIn(ByVal container As Control) Implements ITemplate.InstantiateIn
            Dim box As New CheckBox
            AddHandler box.DataBinding, AddressOf BindData
            box.AutoPostBack = AutoPostBack
            AddHandler box.CheckedChanged, AddressOf OnCheckChanged
            container.Controls.Add(box)
        End Sub 'InstantiateIn 

        '---------------------------------------------------------------------------- 
        ' This is a common handler for all the Checkboxes. 
        '---------------------------------------------------------------------------- 
        Public Sub OnCheckChanged(ByVal sender As Object, ByVal e As EventArgs)

            Dim box As CheckBox = CType(sender, CheckBox)
            Dim container As DataGridItem = CType(box.NamingContainer, DataGridItem)
            Dim gridIndex As Integer = container.ItemIndex

            RaiseEvent BoxCheckedChanged(gridIndex, box.Checked)

        End Sub

        '---------------------------------------------------------------------------- 
        ' Used to set the DataField that we wish to represent with this CheckBox. 
        '---------------------------------------------------------------------------- 
        Public Property DataField() As String
            Get
                Return mDataField
            End Get
            Set(ByVal Value As String)
                mDataField = Value
            End Set
        End Property

        '---------------------------------------------------------------------------- 
        ' Set the AutoPostBack flag. If this is true then each time a CheckBox is clicked 
        ' in the Column that contains this item then an event is raised on the server. 
        '---------------------------------------------------------------------------- 
        Public Property AutoPostBack() As Boolean
            Get
                Return mAutoPostBack
            End Get
            Set(ByVal Value As Boolean)
                mAutoPostBack = Value
            End Set
        End Property

        '---------------------------------------------------------------------------- 
        ' Handler for the DataBinding event where we bind the data for a specific row 
        ' to the CheckBox. 
        '---------------------------------------------------------------------------- 
        Private Sub BindData(ByVal sender As Object, ByVal e As EventArgs)

            Dim box As CheckBox = CType(sender, CheckBox)
            Dim container As DataGridItem = CType(box.NamingContainer, DataGridItem)

            box.Checked = False
            
            Dim data As String = (CType(container.DataItem, DataRowView))(mDataField).ToString
            If data.EndsWith("N") Then
                mReadOnly = True
            Else
                mReadOnly = False
            End If
            If data.StartsWith("True") Or data.EndsWith("N") Then
                box.Checked = True
            End If

            box.Enabled = Not mReadOnly
            box.ID = data
        End Sub

    End Class

End Namespace