'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports DotNetNuke.Entities.Modules
Imports DotNetNuke.Entities.Modules.Actions

Imports AspNetSecurity = System.Web.Security

Imports DotNetNuke.UI.Utilities

Namespace DotNetNuke.Modules.Admin.Users

	''' -----------------------------------------------------------------------------
	''' <summary>
	''' The Users PortalModuleBase is used to manage the Registered Users of a portal
	''' </summary>
	''' <returns></returns>
	''' <remarks>
	''' </remarks>
	''' <history>
	''' 	[cnurse]	9/10/2004	Updated to reflect design changes for Help, 508 support
	'''                       and localisation
	''' </history>
	''' -----------------------------------------------------------------------------


	Partial  Class UserAccounts

		Inherits Entities.Modules.PortalModuleBase
		Implements Entities.Modules.IActionable

#Region "Controls"


#End Region

#Region "Protected Members"

        Protected CurrentPage As Integer = -1
        Protected TotalPages As Integer = -1

#End Region

#Region "Private Members"

        Dim strFilter As String

#End Region

#Region "Private Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' BindData gets the users from the Database and binds them to the DataGrid
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/10/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub BindData()
            BindData(Nothing, Nothing)
        End Sub

        Private Sub BindData(ByVal SearchText As String, ByVal SearchField As String)
            Dim OriginalApplicationName As String = Common.Globals.GetApplicationName
            Try
                CreateLetterSearch()

                'Choose which Date Column to display
                If rblDisplayDate.SelectedItem.Value = "C" Then
                    grdUsers.Columns(6).Visible = True
                    grdUsers.Columns(7).Visible = False
                Else
                    grdUsers.Columns(6).Visible = False
                    grdUsers.Columns(7).Visible = True
                End If

                'Localize the Headers
                Services.Localization.Localization.LocalizeDataGrid(grdUsers, Me.LocalResourceFile)

                ' Get the list of registered users from the database
                Dim PageSize As Integer = Convert.ToInt32(ddlRecordsPerPage.SelectedItem.Value)
                Dim TotalRecords As Integer
                Dim colMembers As AspNetSecurity.MembershipUserCollection
                Dim colMembersUsers As AspNetSecurity.MembershipUser
                Dim colMembersUsersUnauthenticated As New AspNetSecurity.MembershipUserCollection

                Select Case SearchText
                    Case Services.Localization.Localization.GetString("All")
                        strFilter = ""
                    Case Services.Localization.Localization.GetString("Unauthorized")
                        strFilter = ""
                    Case Else
                        strFilter = SearchText
                End Select

                If PortalSettings.ActiveTab.ParentId = PortalSettings.SuperTabId AndAlso UserInfo.IsSuperUser Then
                    Common.Globals.SetApplicationName(Common.Globals.glbSuperUserAppName)
                Else
                    Common.Globals.SetApplicationName(PortalId)
                End If

                If strFilter = "" Then
                    
                    If SearchText = Services.Localization.Localization.GetString("Unauthorized") Then
                        'filter out the approved users
                        colMembers = AspNetSecurity.Membership.GetAllUsers
                        For Each colMembersUsers In colMembers
                            If colMembersUsers.IsApproved = False Or colMembersUsers.LastLoginDate = Null.NullDate Then
                                colMembersUsersUnauthenticated.Add(colMembersUsers)
                            End If
                        Next

                        ' Hide 'Records per Page' and pagingcontrol while diplaying UnAuthorized members, since they are not used here
                        Label5.Visible = False
                        ddlRecordsPerPage.Visible = False
                        ctlPagingControl.Visible = False

                    Else
                        colMembers = AspNetSecurity.Membership.GetAllUsers(CurrentPage - 1, PageSize, TotalRecords)
                    End If
                Else
                    If SearchField = "email" Then
                        colMembers = AspNetSecurity.Membership.FindUsersByEmail(strFilter, CurrentPage - 1, PageSize, TotalRecords)
                    Else
                        colMembers = AspNetSecurity.Membership.FindUsersByName(strFilter + "%", CurrentPage - 1, PageSize, TotalRecords)
                    End If
                End If
                If SearchText = Services.Localization.Localization.GetString("Unauthorized") Then
                    grdUsers.DataSource = ConvertMembershipToUserInfo(PortalId, colMembersUsersUnauthenticated)
                Else
                    grdUsers.DataSource = ConvertMembershipToUserInfo(PortalId, colMembers)
                End If

                grdUsers.DataBind()

                ctlPagingControl.TotalRecords = TotalRecords
                ctlPagingControl.PageSize = PageSize
                ctlPagingControl.CurrentPage = CurrentPage
                Dim strQuerystring As String
                If ddlRecordsPerPage.SelectedIndex <> 0 Then
                    strQuerystring = "PageRecords=" + ddlRecordsPerPage.SelectedValue
                End If
                If strFilter <> "" Then
                    strQuerystring += "&filter=" + strFilter
                End If
                ctlPagingControl.QuerystringParams = strQuerystring
                ctlPagingControl.TabID = TabId
            Finally
                'Reset the Application Name
                Common.Globals.SetApplicationName(OriginalApplicationName)
            End Try
        End Sub

        Private Function ConvertMembershipToUserInfo(ByVal PortalID As Integer, ByVal colMembers As AspNetSecurity.MembershipUserCollection) As ArrayList
            Dim e As Exception
            Dim objMember As AspNetSecurity.MembershipUser
            Dim objUserController As New UserController
            Dim arrUsers As New ArrayList
            Dim UsersSynchronized As Boolean = False
            For Each objMember In colMembers
                Dim objUserInfo As New UserInfo
                Try
                    objUserInfo = objUserController.FillUserInfo(PortalID, objMember.UserName)
                Catch exc As Exception
                    If Not UsersSynchronized Then
                        objUserController.SynchronizeUsers(PortalID)
                        objUserInfo = objUserController.FillUserInfo(PortalID, objMember.UserName)
                        UsersSynchronized = True
                    End If
                    e = exc
                End Try
                arrUsers.Add(objUserInfo)
            Next
            If UsersSynchronized Then
                LogException(e)
            End If
            Return arrUsers
        End Function

        Private Sub CreateLetterSearch()

            Dim strAlphabet As String() = {"A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", Services.Localization.Localization.GetString("All"), Services.Localization.Localization.GetString("Unauthorized")}
            rptLetterSearch.DataSource = strAlphabet
            rptLetterSearch.DataBind()

        End Sub


#End Region

#Region "Public Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' DisplayAddress correctly formats an Address
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/10/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function DisplayAddress(ByVal Unit As Object, ByVal Street As Object, ByVal City As Object, ByVal Region As Object, ByVal Country As Object, ByVal PostalCode As Object) As String
            Try
                DisplayAddress = FormatAddress(Unit, Street, City, Region, Country, PostalCode)

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' DisplayEmail correctly formats an Email Address
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/10/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function DisplayEmail(ByVal Email As String) As String
            Try
                DisplayEmail = HtmlUtils.FormatEmail(Email)

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' DisplayDate correctly formats the Date
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/10/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function DisplayDate(ByVal UserDate As Date) As String
            Try
                If Not Null.IsNull(UserDate) Then
                    DisplayDate = UserDate.ToString
                Else
                    DisplayDate = ""
                End If

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' FormatURL correctly formats the Url for the Edit User Link
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/10/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Protected Function FormatURL(ByVal strKeyName As String, ByVal strKeyValue As String) As String
            Try
                If strFilter <> "" Then
                    FormatURL = EditUrl(strKeyName, strKeyValue, "", "filter=" & strFilter)
                Else
                    FormatURL = EditUrl(strKeyName, strKeyValue)
                End If
            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' FilterURL correctly formats the Url for filter by first letter and paging
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/10/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Protected Function FilterURL(ByVal Filter As String, ByVal CurrentPage As String) As String

            If Filter <> "" Then
                If CurrentPage <> "" Then
                    Return Common.Globals.NavigateURL(TabId, "", "filter=" & Filter, "currentpage=" & CurrentPage, "PageRecords=" & ddlRecordsPerPage.SelectedValue)
                Else
                    Return Common.Globals.NavigateURL(TabId, "", "filter=" & Filter, "PageRecords=" & ddlRecordsPerPage.SelectedValue)
                End If
            Else
                If CurrentPage <> "" Then
                    Return Common.Globals.NavigateURL(TabId, "", "currentpage=" & CurrentPage, "PageRecords=" & ddlRecordsPerPage.SelectedValue)
                Else
                    Return Common.Globals.NavigateURL(TabId, "",  "PageRecords=" & ddlRecordsPerPage.SelectedValue)
                End If
            End If

        End Function

#End Region

#Region "Event Handlers"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Page_Load runs when the control is loaded
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/10/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try

                If Not Request.QueryString("CurrentPage") Is Nothing Then
                    CurrentPage = CType(Request.QueryString("CurrentPage"), Integer)
                Else
                    CurrentPage = 1
                End If

                If Not Request.QueryString("filter") Is Nothing Then
                    strFilter = Request.QueryString("filter")
                Else
                    strFilter = ""
                End If

                If Not Page.IsPostBack Then

                    ClientAPI.AddButtonConfirm(cmdDelete, Services.Localization.Localization.GetString("DeleteItems"))

                    If Not Request.QueryString("PageRecords") Is Nothing Then
                        ddlRecordsPerPage.SelectedValue = Request.QueryString("PageRecords")
                    End If

                    rblDisplayDate.SelectedIndex = 0
                    BindData(strFilter, "username")

                End If
            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' grdUsers_ItemCommand runs when a command button in the grid is clicked.
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/10/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub grdUsers_ItemCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles grdUsers.ItemCommand
            Try
                If e.CommandName = "filter" Then
                    strFilter = Convert.ToString(e.CommandArgument)
                    CurrentPage = 1
                    txtSearch.Text = ""
                    BindData(strFilter, "username")
                End If

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' cmdDelete_Click runs when the Delete Unauthorized Users button is clicked.
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/10/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdDelete_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDelete.Click
            Try
                Dim objUser As New UserController

                objUser.DeleteUsers(PortalId)

                BindData()

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' ddlRecordsPerPage_SelectedIndexChanged runs when the user selects a new
        ''' Records Per Page value from the dropdown.
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[dancaron]	10/28/2004	Intial Version
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub ddlRecordsPerPage_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ddlRecordsPerPage.SelectedIndexChanged
            CurrentPage = 1
            BindData()
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' btnSearch_Click runs when the user searches for accounts by username or email
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[dancaron]	10/28/2004	Intial Version
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub btnSearch_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnSearch.Click
            CurrentPage = 1
            BindData(txtSearch.Text, ddlSearchType.SelectedItem.Value)
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' rblDisplayDate_SelectedIndexChanged runs when the user selects a different Date
        ''' Type to display
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	11/29/2004	Intial Version
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub rblDisplayDate_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rblDisplayDate.SelectedIndexChanged

            BindData()

        End Sub

#End Region

#Region "Optional Interfaces"
        Public ReadOnly Property ModuleActions() As ModuleActionCollection Implements Entities.Modules.IActionable.ModuleActions
            Get
                Dim Actions As New ModuleActionCollection
                Actions.Add(GetNextActionID, Services.Localization.Localization.GetString(ModuleActionType.AddContent, LocalResourceFile), ModuleActionType.AddContent, "", "", EditUrl(), False, SecurityAccessLevel.Admin, True, False)
                Return Actions
            End Get
        End Property
#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

    End Class

End Namespace
