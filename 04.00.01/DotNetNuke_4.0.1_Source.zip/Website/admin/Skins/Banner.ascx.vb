'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports DotNetNuke.Services.Vendors

Namespace DotNetNuke.UI.Skins.Controls
    ''' -----------------------------------------------------------------------------
    ''' <summary></summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    ''' <history>
    ''' 	[cniknet]	10/15/2004	Replaced public members with properties and removed
    '''                             brackets from property names
    ''' </history>
    ''' -----------------------------------------------------------------------------

    Partial  Class Banner

        Inherits UI.Skins.SkinObjectBase

        ' private members
        Private _groupName As String
        Private _bannerTypeId As String

        Const MyFileName As String = "Banner.ascx"

        ' protected controls

#Region "Public Members"
        Public Property GroupName() As String
            Get
                Return _groupName
            End Get
            Set(ByVal Value As String)
                _groupName = Value
            End Set
        End Property

        Public Property BannerTypeId() As String
            Get
                Return _bannerTypeID
            End Get
            Set(ByVal Value As String)
                _bannerTypeID = Value
            End Set
        End Property
#End Region

#Region "Event Handlers"
        '*******************************************************
        '
        ' The Page_Load server event handler on this page is used
        ' to populate the role information for the page
        '
        '*******************************************************

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            ' public attributes
            If BannerTypeId = "" Then
                BannerTypeId = "1" ' banner
            End If

            If PortalSettings.BannerAdvertising <> 0 Then
                Dim intPortalId As Integer
                If PortalSettings.BannerAdvertising = 1 Then
                    intPortalId = PortalSettings.PortalId ' portal
                Else
                    intPortalId = Null.NullInteger ' host
                End If

                ' get banner using the GroupName
                Dim objBanners As New BannerController
                Dim arrBanners As ArrayList = objBanners.LoadBanners(intPortalId, Null.NullInteger, Integer.Parse(BannerTypeId), GroupName, 1)

                Dim objBanner As BannerInfo
                If arrBanners.Count = 0 Then
                    ' add default banner if none found
                    objBanner = New BannerInfo
                    objBanner.BannerId = -1
                    objBanner.ImageFile = Common.Globals.ApplicationPath & "/images/banner.gif"
                    objBanner.URL = glbAppUrl
                    objBanner.BannerName = Services.Localization.Localization.GetString("Banner", Services.Localization.Localization.GetResourceFile(Me, MyFileName))
                    arrBanners.Add(objBanner)
                Else
                    objBanner = CType(arrBanners(0), BannerInfo)
                End If

                lblBanner.Text = objBanners.FormatBanner(objBanner.VendorId, objBanner.BannerId, objBanner.BannerTypeId, objBanner.BannerName, objBanner.ImageFile, objBanner.Description, objBanner.URL, objBanner.Width, objBanner.Height, CType(IIf(PortalSettings.BannerAdvertising = 1, "L", "G"), String), PortalSettings.HomeDirectory)
            Else
                lblBanner.Visible = False
            End If

        End Sub
#End Region

#Region " Web Form Designer Generated Code "


        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

    End Class

End Namespace
