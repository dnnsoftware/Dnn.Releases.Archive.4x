'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Namespace DotNetNuke.Entities.Users

	Public Class UserMembership
		Private _Password As String
		Private _Email As String
		Private _Username As String
        Private _LastLoginDate As Date
        Private _LastLockoutDate As Date
		Private _CreatedDate As Date
		Private _Approved As Boolean
		Private _LockedOut As Boolean
        Private _ObjectHydrated As Boolean

        Public Sub New()

        End Sub

        Public Property Password() As String
            Get
                Return _Password
            End Get
            Set(ByVal Value As String)
                _Password = Value
                If Not ObjectHydrated Then
                    ObjectHydrated = True
                End If
            End Set
        End Property

        Public Property Email() As String
            Get
                Return _Email
            End Get
            Set(ByVal Value As String)
                _Email = Value
                If Not ObjectHydrated Then
                    ObjectHydrated = True
                End If
            End Set
        End Property

        Public Property Username() As String
            Get
                Return _Username
            End Get
            Set(ByVal Value As String)
                _Username = Value
                If Not ObjectHydrated Then
                    ObjectHydrated = True
                End If
            End Set
        End Property

        Public Property LastLoginDate() As Date
            Get
                Return _LastLoginDate
            End Get
            Set(ByVal Value As Date)
                _LastLoginDate = Value
                If Not ObjectHydrated Then
                    ObjectHydrated = True
                End If
            End Set
        End Property

        Public Property LastLockoutDate() As Date
            Get
                Return _LastLockoutDate
            End Get
            Set(ByVal Value As Date)
                _LastLockoutDate = Value
                If Not ObjectHydrated Then
                    ObjectHydrated = True
                End If
            End Set
        End Property

        Public Property CreatedDate() As Date
            Get
                Return _CreatedDate
            End Get
            Set(ByVal Value As Date)
                _CreatedDate = Value
                If Not ObjectHydrated Then
                    ObjectHydrated = True
                End If
            End Set
        End Property

        Public Property Approved() As Boolean
            Get
                Return _Approved
            End Get
            Set(ByVal Value As Boolean)
                _Approved = Value
                If Not ObjectHydrated Then
                    ObjectHydrated = True
                End If
            End Set
        End Property

        Public Property LockedOut() As Boolean
            Get
                Return _LockedOut
            End Get
            Set(ByVal Value As Boolean)
                _LockedOut = Value
                If Not ObjectHydrated Then
                    ObjectHydrated = True
                End If
            End Set
        End Property

        Public Property ObjectHydrated() As Boolean
            Get
                Return _ObjectHydrated
            End Get
            Set(ByVal Value As Boolean)
                _ObjectHydrated = Value
                If Not ObjectHydrated Then
                    _ObjectHydrated = True
                End If
            End Set
        End Property

    End Class





End Namespace
