'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.Drawing
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.IO
Imports System.Collections
Imports System.Data


Namespace DotNetNuke.Security.Permissions.Controls


    Public Class CheckBoxColumn : Inherits System.Web.UI.WebControls.TemplateColumn

        '---------------------------------------------------------------------------- 
        ' Internal storage of the CheckBoxTemplate that is to be used for the view state. 
        '---------------------------------------------------------------------------- 
        Private mViewItem As CheckBoxTemplate

        '---------------------------------------------------------------------------- 
        ' Internal storage of the CheckBoxTemplate that is to be used for the edit state. 
        '---------------------------------------------------------------------------- 
        Private mEditItem As CheckBoxTemplate

        '---------------------------------------------------------------------------- 
        ' Initialise our CheckBoxColumn. 
        '---------------------------------------------------------------------------- 
        Public Sub New()


            mViewItem = New CheckBoxTemplate(True)
            MyClass.ItemTemplate = mViewItem

            ' let the edit check box be editable 
            mEditItem = New CheckBoxTemplate(True)
            AddHandler mViewItem.BoxCheckedChanged, AddressOf OnEditCheckedChanged
            MyClass.EditItemTemplate = mEditItem
            MyClass.ItemStyle.HorizontalAlign = HorizontalAlign.Center

        End Sub

        '---------------------------------------------------------------------------- 
        ' Initialise our CheckBoxColumn with an optional ImmediatePostback capability. 
        ' If true then each change of state of the CheckBox item 
        ' will cause an event to be fired immediately on the server. 
        '---------------------------------------------------------------------------- 
        Public Sub New(ByVal ImmediatePostback As Boolean, Optional ByVal trueValue As String = "true")

            ' set the view one as readonly 
            mViewItem = New CheckBoxTemplate(ImmediatePostback, trueValue)
            AddHandler mViewItem.BoxCheckedChanged, AddressOf OnViewCheckedChanged
            MyClass.ItemTemplate = mViewItem

            ' let the edit check box be editable 
            mEditItem = New CheckBoxTemplate(Not ImmediatePostback, trueValue)
            AddHandler mEditItem.BoxCheckedChanged, AddressOf OnEditCheckedChanged
            MyClass.EditItemTemplate = mEditItem
            MyClass.ItemStyle.HorizontalAlign = HorizontalAlign.Center
            AutoPostBack = ImmediatePostback

        End Sub


        '---------------------------------------------------------------------------- 
        ' If true then then each click on a CheckBox will cause an event to be fired on the server. 
        '---------------------------------------------------------------------------- 
        Public Property AutoPostBack() As Boolean
            Get
                Return mViewItem.AutoPostBack
            End Get
            Set(ByVal Value As Boolean)
                mViewItem.AutoPostBack = Value
                mEditItem.AutoPostBack = Value
            End Set
        End Property

        Public Event ViewCheckedChanged(ByVal gridIndex As Integer, ByVal checked As Boolean)
        Public Event EditCheckedChanged(ByVal gridIndex As Integer, ByVal checked As Boolean)

        Public Sub OnEditCheckedChanged(ByVal gridIndex As Integer, ByVal checked As Boolean)

            RaiseEvent EditCheckedChanged(gridIndex, checked)

        End Sub

        Public Sub OnViewCheckedChanged(ByVal gridIndex As Integer, ByVal checked As Boolean)

            RaiseEvent ViewCheckedChanged(gridIndex, checked)

        End Sub

        '---------------------------------------------------------------------------- 
        ' The DataField that we wish our control to bind to. 
        '---------------------------------------------------------------------------- 
        Public Property DataField() As String
            Get
                Return mViewItem.DataField
            End Get
            Set(ByVal Value As String)
                mViewItem.DataField = Value
                mEditItem.DataField = Value
            End Set
        End Property

    End Class

  
End Namespace