'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.Configuration
Imports System.Data
Imports System.Globalization
Imports System.IO

Namespace DotNetNuke.Services.FileSystem
    ''' -----------------------------------------------------------------------------
    ''' Project	 : DotNetNuke
    ''' Class	 : FileController
    ''' 
    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' Business Class that provides access to the Database for the functions within the calling classes
    ''' Instantiates the instance of the DataProvider and returns the object, if any
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[DYNST]	2/1/2004	Created
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Public Class FileController

        Public Function GetFiles(ByVal PortalId As Integer, ByVal Folder As String) As IDataReader

            Return DataProvider.Instance().GetFiles(PortalId, Folder)

        End Function

        Public Function GetFilesByFolder(ByVal PortalId As Integer, ByVal Folder As String) As ArrayList

            Return CBO.FillCollection(DataProvider.Instance().GetFiles(PortalId, Folder), GetType(FileInfo))

        End Function

        Public Function GetFile(ByVal FilePath As String, ByVal PortalId As Integer) As FileInfo

            Return GetFile(Path.GetFileName(FilePath), PortalId, FilePath.Replace(Path.GetFileName(FilePath), ""))

        End Function

        Public Function GetFile(ByVal FileName As String, ByVal PortalId As Integer, ByVal Folder As String) As FileInfo

            Return CType(CBO.FillObject(DataProvider.Instance().GetFile(FileName, PortalId, Folder), GetType(FileInfo)), FileInfo)

        End Function

        Public Function GetFileById(ByVal FileId As Integer, ByVal PortalId As Integer) As FileInfo

            Return CType(CBO.FillObject(DataProvider.Instance().GetFileById(FileId, PortalId), GetType(FileInfo)), FileInfo)

        End Function

        Public Sub DeleteFile(ByVal PortalId As Integer, ByVal FileName As String, ByVal folder As String)
            DeleteFile(PortalId, FileName, folder, True)
        End Sub
        Public Sub DeleteFile(ByVal PortalId As Integer, ByVal FileName As String, ByVal folder As String, ByVal ClearCache As Boolean)

            DataProvider.Instance().DeleteFile(PortalId, FileName, folder)
            If ClearCache Then
                GetAllFilesRemoveCache()
            End If
        End Sub
        Public Sub DeleteFiles(ByVal PortalId As Integer)
            DeleteFiles(PortalId, True)
        End Sub
        Public Sub DeleteFiles(ByVal PortalId As Integer, ByVal ClearCache As Boolean)

            DataProvider.Instance().DeleteFiles(PortalId)
            If ClearCache Then
                GetAllFilesRemoveCache()
            End If

        End Sub

        Public Function AddFile(ByVal file As FileInfo, ByVal folder As String) As Integer

            Return AddFile(file.PortalId, file.FileName, file.Extension, file.Size, file.Width, file.Height, file.ContentType, folder)

        End Function
        Public Function AddFile(ByVal PortalId As Integer, ByVal FileName As String, ByVal Extension As String, ByVal Size As Long, ByVal Width As Integer, ByVal Height As Integer, ByVal ContentType As String, ByVal Folder As String) As Integer
            Return AddFile(PortalId, FileName, Extension, Size, Width, Height, ContentType, Folder, True)
        End Function
        Public Function AddFile(ByVal PortalId As Integer, ByVal FileName As String, ByVal Extension As String, ByVal Size As Long, ByVal Width As Integer, ByVal Height As Integer, ByVal ContentType As String, ByVal Folder As String, ByVal ClearCache As Boolean) As Integer
            Dim IsDirty As Boolean = False
            Dim FileId As Integer
            Try
                Dim dt As DataTable
                dt = GetAllFiles()
                Dim dr As DataRow()
                Dim OriginalFile As DataRow
                dr = dt.Select("FileName='" + FileName + "' and PortalId " + IIf(PortalId = Null.NullInteger, "IS NULL", "=" + PortalId.ToString).ToString + " and Folder='" + Folder + "'")

                If dr.Length > 0 Then
                    OriginalFile = dr(0)
                    FileId = Convert.ToInt32(OriginalFile("FileId"))
                    If FileChanged(OriginalFile, FileName, Extension, Size, Width, Height, ContentType, Folder) Then
                        DataProvider.Instance().UpdateFile(FileId, FileName, Extension, Size, Width, Height, ContentType, Folder)
                        IsDirty = True
                    End If
                Else
                    FileId = DataProvider.Instance().AddFile(PortalId, FileName, Extension, Size, Width, Height, ContentType, Folder)
                    IsDirty = True
                End If

                Return FileId

            Finally
                If IsDirty And ClearCache Then
                    GetAllFilesRemoveCache()
                End If
            End Try
        End Function

        Public Sub UpdateFile(ByVal PortalId As Integer, ByVal OriginalFileName As String, ByVal FileName As String, ByVal Extension As String, ByVal Size As Long, ByVal Width As Integer, ByVal Height As Integer, ByVal ContentType As String, ByVal SourceFolder As String, ByVal DestinationFolder As String)
            UpdateFile(PortalId, OriginalFileName, FileName, Extension, Size, Width, Height, ContentType, SourceFolder, DestinationFolder, True)
        End Sub

        Public Sub UpdateFile(ByVal PortalId As Integer, ByVal OriginalFileName As String, ByVal FileName As String, ByVal Extension As String, ByVal Size As Long, ByVal Width As Integer, ByVal Height As Integer, ByVal ContentType As String, ByVal SourceFolder As String, ByVal DestinationFolder As String, ByVal ClearCache As Boolean)
            Dim IsDirty As Boolean = False
            Try
                Dim dt As DataTable
                dt = GetAllFiles()
                Dim dr As DataRow()
                Dim OriginalFile As DataRow
                dr = dt.Select("FileName='" + OriginalFileName + "' and PortalId" + IIf(PortalId = Null.NullInteger, "IS NULL", "=" + PortalId.ToString).ToString + " and Folder='" + SourceFolder + "'")

                Dim FileId As Integer
                If dr.Length > 0 Then
                    OriginalFile = dr(0)
                    FileId = Convert.ToInt32(OriginalFile("FileId"))
                    If FileChanged(OriginalFile, FileName, Extension, Size, Width, Height, ContentType, DestinationFolder) Then
                        DataProvider.Instance().UpdateFile(FileId, FileName, Extension, Size, Width, Height, ContentType, DestinationFolder)
                        IsDirty = True
                    End If
                End If
            Finally
                If IsDirty And ClearCache Then
                    GetAllFilesRemoveCache()
                End If
            End Try

        End Sub

        Public Sub GetAllFilesRemoveCache()
            DataCache.RemoveCache("GetAllFiles")
        End Sub

        Public Function GetAllFiles() As DataTable
            Dim dt As DataTable
            If DataCache.GetCache("GetAllFiles") Is Nothing Then
                dt = DataProvider.Instance.GetAllFiles()
                DataCache.SetCache("GetAllFiles", dt)
            Else
                dt = CType(DataCache.GetCache("GetAllFiles"), DataTable)
            End If
            If Not dt Is Nothing Then
                Return dt.Copy
            Else
                Return New DataTable
            End If
        End Function

        Public Function ConvertFilePathToFileId(ByVal FilePath As String, ByVal PortalID As Integer) As Integer
            Dim FileName As String = ""
            Dim FolderName As String = ""
            Dim FileId As Integer = -1

            If FilePath <> "" Then
                FileName = FilePath.Substring(FilePath.LastIndexOf("/") + 1)
                FolderName = FilePath.Replace(FileName, "")
            End If

            Dim objFiles As New FileController
            Dim objFile As FileInfo = objFiles.GetFile(FileName, PortalID, FolderName)
            If Not objFile Is Nothing Then
                FileId = objFile.FileId
            End If

            Return FileId
        End Function

        Friend Function FileChanged(ByVal drOriginalFile As DataRow, ByVal NewFileName As String, ByVal NewExtension As String, ByVal NewSize As Long, ByVal NewWidth As Integer, ByVal NewHeight As Integer, ByVal NewContentType As String, ByVal NewFolder As String) As Boolean
            If Convert.ToString(drOriginalFile("FileName")) <> NewFileName _
            Or Convert.ToString(drOriginalFile("Extension")) <> NewExtension _
            Or Convert.ToInt32(drOriginalFile("Size")) <> NewSize _
            Or Convert.ToInt32(drOriginalFile("Width")) <> NewWidth _
            Or Convert.ToInt32(drOriginalFile("Height")) <> NewHeight _
            Or Convert.ToString(drOriginalFile("ContentType")) <> NewContentType _
            Or Convert.ToString(drOriginalFile("Folder")) <> NewFolder Then
                Return True
            End If
            Return False
        End Function

    End Class

End Namespace
