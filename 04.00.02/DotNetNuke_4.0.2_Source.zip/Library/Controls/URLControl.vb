'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports System.IO
Imports DotNetNuke.Services.Localization
Imports DotNetNuke.Services.FileSystem
Imports DotNetNuke.UI.Utilities

Namespace DotNetNuke.UI.UserControls

    Public Class UrlControl

        Inherits Framework.UserControlBase

#Region "Controls"

        Protected WithEvents TypeRow As System.Web.UI.HtmlControls.HtmlTableRow
        Protected WithEvents optType As System.Web.UI.WebControls.RadioButtonList

        Protected WithEvents URLRow As System.Web.UI.HtmlControls.HtmlTableRow
        Protected WithEvents lblURL As System.Web.UI.WebControls.Label
        Protected WithEvents cboUrls As System.Web.UI.WebControls.DropDownList
        Protected WithEvents txtUrl As System.Web.UI.WebControls.TextBox
        Protected WithEvents cmdSelect As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdAdd As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdDelete As System.Web.UI.WebControls.LinkButton

        Protected WithEvents TabRow As System.Web.UI.HtmlControls.HtmlTableRow
        Protected WithEvents lblTab As System.Web.UI.WebControls.Label
        Protected WithEvents cboTabs As System.Web.UI.WebControls.DropDownList

        Protected WithEvents ErrorRow As System.Web.UI.HtmlControls.HtmlTableRow
        Protected WithEvents lblMessage As System.Web.UI.WebControls.Label

        Protected WithEvents FileRow As System.Web.UI.HtmlControls.HtmlTableRow
        Protected WithEvents lblFolder As System.Web.UI.WebControls.Label
        Protected WithEvents cboFolders As System.Web.UI.WebControls.DropDownList
        Protected WithEvents lblFile As System.Web.UI.WebControls.Label
        Protected WithEvents cboFiles As System.Web.UI.WebControls.DropDownList
        Protected WithEvents txtFile As System.Web.UI.HtmlControls.HtmlInputFile
        Protected WithEvents cmdUpload As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdSave As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton

        Protected WithEvents chkNewWindow As System.Web.UI.WebControls.CheckBox
        Protected WithEvents chkTrack As System.Web.UI.WebControls.CheckBox
        Protected WithEvents chkLog As System.Web.UI.WebControls.CheckBox

#End Region

#Region "Private Members"

        Private _ModuleID As Integer = -2
        Private _Width As String = ""
        Private _ShowNone As Boolean = False
        Private _ShowUrls As Boolean = True
        Private _ShowTabs As Boolean = True
        Private _ShowUpLoad As Boolean = True
        Private _ShowFiles As Boolean = True
        Private _ShowNewWindow As Boolean = False
        Private _ShowLog As Boolean = True
        Private _ShowTrack As Boolean = True
        Private _Required As Boolean = True
        Private _Url As String = ""
        Private _UrlType As String = ""
        Private _localResourceFile As String
        Protected WithEvents lblURLType As System.Web.UI.WebControls.Label
        Private _objPortal As PortalInfo

#End Region

#Region "Public Properties"

        Public Property ModuleID() As Integer
            Get
                ModuleID = Convert.ToInt32(ViewState("ModuleId"))
                If ModuleID = -2 Then
                    If Not Request.QueryString("mid") Is Nothing Then
                        ModuleID = Int32.Parse(Request.QueryString("mid"))
                    End If
                End If
            End Get
            Set(ByVal Value As Integer)
                _ModuleID = Value
            End Set
        End Property

        Public Property Width() As String
            Get
                Width = Convert.ToString(ViewState("SkinControlWidth"))
            End Get
            Set(ByVal Value As String)
                _Width = Value
            End Set
        End Property

        Public WriteOnly Property ShowNone() As Boolean
            Set(ByVal Value As Boolean)
                _ShowNone = Value
            End Set
        End Property

        Public WriteOnly Property ShowUrls() As Boolean
            Set(ByVal Value As Boolean)
                _ShowUrls = Value
            End Set
        End Property

        Public WriteOnly Property ShowTabs() As Boolean
            Set(ByVal Value As Boolean)
                _ShowTabs = Value
            End Set
        End Property

        Public WriteOnly Property ShowFiles() As Boolean
            Set(ByVal Value As Boolean)
                _ShowFiles = Value
            End Set
        End Property

        Public WriteOnly Property ShowLog() As Boolean
            Set(ByVal Value As Boolean)
                _ShowLog = Value
            End Set
        End Property

        Public WriteOnly Property ShowNewWindow() As Boolean
            Set(ByVal Value As Boolean)
                _ShowNewWindow = Value
            End Set
        End Property

        Public WriteOnly Property ShowTrack() As Boolean
            Set(ByVal Value As Boolean)
                _ShowTrack = Value
            End Set
        End Property

        Public WriteOnly Property ShowUpLoad() As Boolean
            Set(ByVal Value As Boolean)
                _ShowUpLoad = Value
            End Set
        End Property

        Public WriteOnly Property Required() As Boolean
            Set(ByVal Value As Boolean)
                _Required = Value
            End Set
        End Property

        Public Property Url() As String
            Get
                Url = ""
                Select Case optType.SelectedItem.Value
                    Case "U"
                        If cboUrls.Visible Then
                            If Not cboUrls.SelectedItem Is Nothing Then
                                Url = cboUrls.SelectedItem.Value
                            End If
                        Else
                            If txtUrl.Text = "http://" Then
                                txtUrl.Text = ""
                            End If
                            Url = AddHTTP(txtUrl.Text)
                        End If
                    Case "T"
                        If Not cboTabs.SelectedItem Is Nothing Then
                            Url = cboTabs.SelectedItem.Value
                        End If
                    Case "F"
                        If Not cboFiles.SelectedItem Is Nothing Then
                            If Not cboFiles.SelectedItem.Value = "" Then
                                Url = "FileID=" & cboFiles.SelectedItem.Value
                            Else
                                Url = ""
                            End If
                        End If
                End Select
            End Get
            Set(ByVal Value As String)
                _Url = Value
            End Set
        End Property

        Public Property UrlType() As String
            Get
                UrlType = optType.SelectedItem.Value
            End Get
            Set(ByVal Value As String)
                _UrlType = Value
            End Set
        End Property

        Public Property FileFilter() As String
            Get
                If Not viewstate("_FileFilter") Is Nothing Then
                    Return CType(viewstate("_FileFilter"), String)
                Else
                    Return ""
                End If
            End Get
            Set(ByVal Value As String)
                viewstate("_FileFilter") = Value
            End Set
        End Property

        Public ReadOnly Property Log() As Boolean
            Get
                If chkLog.Visible = True Then
                    Log = chkLog.Checked
                Else
                    Log = False
                End If
            End Get
        End Property

        Public ReadOnly Property Track() As Boolean
            Get
                If chkTrack.Visible = True Then
                    Track = chkTrack.Checked
                Else
                    Track = False
                End If
            End Get
        End Property

        Public ReadOnly Property NewWindow() As Boolean
            Get
                If chkNewWindow.Visible = True Then
                    NewWindow = chkNewWindow.Checked
                Else
                    NewWindow = False
                End If
            End Get
        End Property

        Public Property LocalResourceFile() As String
            Get
                Dim fileRoot As String

                If _localResourceFile = "" Then
                    fileRoot = Me.TemplateSourceDirectory & "/" & Localization.LocalResourceDirectory & "/URLControl.ascx"
                Else
                    fileRoot = _localResourceFile
                End If
                Return fileRoot
            End Get
            Set(ByVal Value As String)
                _localResourceFile = Value
            End Set
        End Property

#End Region

#Region "Private Methods"

        Private Function GetFileList(ByVal strExtensions As String, ByVal NoneSpecified As Boolean, ByVal Folder As String) As ArrayList

            Dim fileList As ArrayList

            If PortalSettings.ActiveTab.ParentId = PortalSettings.SuperTabId Then
                fileList = Common.Globals.GetFileList(Null.NullInteger, FileFilter, NoneSpecified, cboFolders.SelectedItem.Value, False)
            Else
                fileList = Common.Globals.GetFileList(_objPortal.PortalID, FileFilter, NoneSpecified, cboFolders.SelectedItem.Value, False)
            End If

            Return fileList

        End Function

        Private Function GetReadRoles(ByVal Folder As String) As String

            Return FileSystemUtils.GetRoles(Folder, _objPortal.PortalID, "READ")

        End Function

        Private Function GetWriteRoles(ByVal Folder As String) As String

            Return FileSystemUtils.GetRoles(Folder, _objPortal.PortalID, "WRITE")

        End Function

        Private Sub LoadFolders(ByVal ChildDir As DirectoryInfo)

            Dim CurrentDir As DirectoryInfo
            Dim ChildDirs As DirectoryInfo()
            Dim ChildDirirectory As DirectoryInfo
            Dim ParentFolderName As String

            If PortalSettings.ActiveTab.ParentId = PortalSettings.SuperTabId Then
                ParentFolderName = ChildDir.FullName.Substring(Common.Globals.HostMapPath.Length)
            Else
                ParentFolderName = ChildDir.FullName.Substring(_objPortal.HomeDirectoryMapPath.Length)
            End If

            CurrentDir = ChildDir
            ChildDirs = CurrentDir.GetDirectories
            For Each ChildDirirectory In ChildDirs
                Dim FolderItem As New ListItem
                Dim ItemText As String = ParentFolderName.Replace("\", "/") & "/" & ChildDirirectory.Name
                If ItemText.StartsWith("/") Then
                    ItemText = ItemText.Remove(0, 1)
                End If
                If ItemText.EndsWith("/") Then
                    ItemText = ItemText.Remove(ItemText.Length - 1, 1)
                End If
                Dim strReadRoles As String = GetReadRoles(ItemText)
                Dim strWriteRoles As String = GetWriteRoles(ItemText)
                If PortalSecurity.IsInRoles(strReadRoles) Or PortalSecurity.IsInRoles(strWriteRoles) Then
                    FolderItem.Text = ItemText
                    FolderItem.Value = ItemText & "/"
                    cboFolders.Items.Add(FolderItem)
                End If
                If ChildDirirectory.GetDirectories.Length > 0 Then
                    LoadFolders(ChildDirirectory)
                End If
            Next
        End Sub

        Private Sub ShowControls()

            Dim objUrls As New UrlController

            ' set url type
            If optType.SelectedItem Is Nothing Then
                If _Url <> "" Then

                    Dim TrackingUrl As String = _Url

                    _UrlType = GetURLType(_Url).ToString("g").Substring(0, 1)
                    If _UrlType = "F" Then
                        Dim objFiles As New FileController
                        TrackingUrl = "FileID=" & objFiles.ConvertFilePathToFileId(_Url, _objPortal.PortalID).ToString
                    End If

                    Dim objUrlTracking As UrlTrackingInfo = objUrls.GetUrlTracking(_objPortal.PortalID, TrackingUrl, ModuleID)
                    If Not objUrlTracking Is Nothing Then
                        optType.Items.FindByValue(objUrlTracking.UrlType).Selected = True
                        chkNewWindow.Checked = objUrlTracking.NewWindow
                        chkTrack.Checked = objUrlTracking.TrackClicks
                        chkLog.Checked = objUrlTracking.LogActivity
                    Else       ' the url does not exist in the tracking table
                        optType.Items.FindByValue(_UrlType).Selected = True
                        chkNewWindow.Checked = False
                        chkTrack.Checked = True
                        chkLog.Checked = False
                    End If
                Else
                    If _UrlType <> "" Then
                        If Not optType.Items.FindByValue(_UrlType) Is Nothing Then
                            optType.Items.FindByValue(_UrlType).Selected = True
                        Else
                            optType.Items(0).Selected = True
                        End If
                    Else
                        optType.Items(0).Selected = True
                    End If
                    chkNewWindow.Checked = False
                    chkTrack.Checked = True
                    chkLog.Checked = False
                End If
            End If

            ' load listitems
            Select Case optType.SelectedItem.Value
                Case "N"    ' None
                    URLRow.Visible = False
                    TabRow.Visible = False
                    FileRow.Visible = False
                Case "U"    ' Url
                    URLRow.Visible = True
                    TabRow.Visible = False
                    FileRow.Visible = False

                    If txtUrl.Text = "" Then
                        txtUrl.Text = _Url
                    End If
                    If txtUrl.Text = "" Then
                        txtUrl.Text = "http://"
                    End If
                    txtUrl.Visible = True

                    cmdSelect.Visible = True

                    cboUrls.Items.Clear()
                    cboUrls.DataSource = objUrls.GetUrls(_objPortal.PortalID)
                    cboUrls.DataBind()
                    If Not cboUrls.Items.FindByValue(_Url) Is Nothing Then
                        cboUrls.Items.FindByValue(_Url).Selected = True
                    End If
                    cboUrls.Visible = False

                    cmdAdd.Visible = False

                    cmdDelete.Visible = False
                Case "T"    ' tab
                    URLRow.Visible = False
                    TabRow.Visible = True
                    FileRow.Visible = False

                    cboTabs.Items.Clear()

                    cboTabs.DataSource = GetPortalTabs(_objPortal.PortalID, Not _Required, True, False, False, False)
                    cboTabs.DataBind()
                    If Not cboTabs.Items.FindByValue(_Url) Is Nothing Then
                        cboTabs.Items.FindByValue(_Url).Selected = True
                    End If
                Case "F"    ' file
                    URLRow.Visible = False
                    TabRow.Visible = False
                    FileRow.Visible = True

                    cboFolders.Items.Clear()
                    ' add root folder
                    Dim FolderItem As New ListItem
                    FolderItem.Text = Localization.GetString("Root", Me.LocalResourceFile)
                    FolderItem.Value = String.Empty

                    Dim ReadRoles As String = GetReadRoles("")
                    Dim WriteRoles As String = GetWriteRoles("")
                    If PortalSecurity.IsInRoles(ReadRoles) Or PortalSecurity.IsInRoles(WriteRoles) Then
                        cboFolders.Items.Add(FolderItem)
                    End If

                    ' add sub folders
                    Dim ParentFolderName As String
                    If PortalSettings.ActiveTab.ParentId = PortalSettings.SuperTabId Then
                        ParentFolderName = Common.Globals.HostMapPath
                    Else
                        ParentFolderName = _objPortal.HomeDirectoryMapPath
                    End If
                    Dim Root As New DirectoryInfo(ParentFolderName)
                    LoadFolders(Root)

                    If cboFolders.Items.Count = 0 Then
                        lblMessage.Text = Localization.GetString("NoPermission", Me.LocalResourceFile)
                        FileRow.Visible = False
                        Exit Sub
                    End If

                    ' select folder
                    Dim FileName As String
                    Dim FolderPath As String
                    If Not _Url = String.Empty Then
                        FileName = _Url.Substring(_Url.LastIndexOf("/") + 1)
                        FolderPath = _Url.Replace(FileName, "")
                    Else
                        FileName = _Url
                        FolderPath = String.Empty
                    End If
                    If Not cboFolders.Items.FindByValue(FolderPath) Is Nothing Then
                        cboFolders.Items.FindByValue(FolderPath).Selected = True
                    Else
                        cboFolders.Items(0).Selected = True
                        FolderPath = cboFolders.SelectedValue
                    End If

                    cboFiles.DataSource = GetFileList(FileFilter, Not _Required, cboFolders.SelectedItem.Value)
                    cboFiles.DataBind()
                    If Not cboFiles.Items.FindByText(FileName) Is Nothing Then
                        cboFiles.Items.FindByText(FileName).Selected = True
                    End If
                    cboFiles.Visible = True

                    txtFile.Visible = False

                    If FolderPath <> "" Then
                        FolderPath = FolderPath.Substring(0, FolderPath.Length - 1)
                    End If
                    Dim strWriteRoles As String = GetWriteRoles(FolderPath)
                    cmdUpload.Visible = PortalSecurity.IsInRoles(strWriteRoles) And _ShowUpLoad

                    txtUrl.Visible = False

                    cmdSave.Visible = False
                    cmdCancel.Visible = False
            End Select

        End Sub

#End Region

#Region "Event Handlers"

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try

                Dim objPortals As New PortalController
                If Not (Request.QueryString("pid") Is Nothing) And (PortalSettings.ActiveTab.ParentId = PortalSettings.SuperTabId Or UserController.GetCurrentUserInfo.IsSuperUser) Then
                    _objPortal = objPortals.GetPortal(Int32.Parse(Request.QueryString("pid")))
                Else
                    _objPortal = objPortals.GetPortal(PortalSettings.PortalId)
                End If

                If Not Page.IsPostBack Then

                    ClientAPI.AddButtonConfirm(cmdDelete, Services.Localization.Localization.GetString("DeleteItem"))

                    ' set width of control
                    If _Width <> "" Then
                        cboUrls.Width = System.Web.UI.WebControls.Unit.Parse(_Width)
                        txtUrl.Width = System.Web.UI.WebControls.Unit.Parse(_Width)
                        cboTabs.Width = System.Web.UI.WebControls.Unit.Parse(_Width)
                        cboFolders.Width = System.Web.UI.WebControls.Unit.Parse(_Width)
                        cboFiles.Width = System.Web.UI.WebControls.Unit.Parse(_Width)
                    End If

                    If _ShowNone Then
                        optType.Items.Add(New ListItem(Localization.GetString("NoneType", LocalResourceFile), "N"))
                    End If
                    If _ShowUrls Then
                        optType.Items.Add(New ListItem(Localization.GetString("URLType", LocalResourceFile), "U"))
                    End If
                    If _ShowTabs Then
                        optType.Items.Add(New ListItem(Localization.GetString("TabType", LocalResourceFile), "T"))
                    End If
                    If _ShowFiles Then
                        optType.Items.Add(New ListItem(Localization.GetString("FileType", LocalResourceFile), "F"))
                    End If
                    chkNewWindow.Visible = _ShowNewWindow
                    chkLog.Visible = _ShowLog
                    chkTrack.Visible = _ShowTrack
                    Dim URLType As Integer = CInt(_ShowUrls) + CInt(_ShowTabs) + CInt(_ShowFiles)
                    If URLType = -1 Then
                        TypeRow.Visible = False
                    End If
                    ' save persistent values
                    ViewState("ModuleId") = Convert.ToString(_ModuleID)
                    ViewState("SkinControlWidth") = _Width

                    ShowControls()

                End If

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cboFolders_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboFolders.SelectedIndexChanged
            Dim path As String
            If cboFolders.SelectedValue <> "" Then
                path = cboFolders.SelectedValue.Substring(0, cboFolders.SelectedValue.Length - 1)
            Else
                path = cboFolders.SelectedValue
            End If
            Dim strWriteRoles As String = GetWriteRoles(path)
            If PortalSecurity.IsInRoles(strWriteRoles) Then
                If Not txtFile.Visible Then
                    ' only show if not already in upload mode and not disabled
                    cmdUpload.Visible = _ShowUpLoad
                End If
            Else
                'reset controls
                cboFiles.Visible = True
                cmdUpload.Visible = False
                txtFile.Visible = False
                cmdSave.Visible = False
                cmdCancel.Visible = False
            End If

            cboFiles.Items.Clear()
            cboFiles.DataSource = GetFileList(FileFilter, False, cboFolders.SelectedItem.Value)
            cboFiles.DataBind()
        End Sub

        Private Sub cmdAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdAdd.Click
            cboUrls.Visible = False
            cmdSelect.Visible = True
            txtUrl.Visible = True
            cmdAdd.Visible = False
            cmdDelete.Visible = False
        End Sub

        Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
            cboFiles.Visible = True
            cmdUpload.Visible = True
            txtFile.Visible = False
            cmdSave.Visible = False
            cmdCancel.Visible = False
        End Sub

        Private Sub cmdDelete_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDelete.Click
            If Not cboUrls.SelectedItem Is Nothing Then

                Dim objUrls As New UrlController
                objUrls.DeleteUrl(_objPortal.PortalID, cboUrls.SelectedItem.Value)

                ShowControls()
            End If
        End Sub

        Private Sub cmdSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSave.Click

            ' if no file is selected exit
            If txtFile.PostedFile.FileName = "" Then
                Exit Sub
            End If

            Dim ParentFolderName As String
            If PortalSettings.ActiveTab.ParentId = PortalSettings.SuperTabId Then
                ParentFolderName = Common.Globals.HostMapPath
            Else
                ParentFolderName = PortalSettings.HomeDirectoryMapPath
            End If
            ParentFolderName += cboFolders.SelectedItem.Value

            Dim strExtension As String = Replace(Path.GetExtension(txtFile.PostedFile.FileName), ".", "")
            If FileFilter <> "" And InStr("," & FileFilter.ToLower, "," & strExtension.ToLower) = 0 Then
                ' trying to upload a file not allowed for current filter
                lblMessage.Text = String.Format(Localization.GetString("UploadError", Me.LocalResourceFile), FileFilter, strExtension)
            Else
                lblMessage.Text = UploadFile(ParentFolderName.Replace("/", "\"), txtFile.PostedFile, False)
            End If

            If lblMessage.Text = String.Empty Then
                cboFiles.Visible = True
                cmdUpload.Visible = _ShowUpLoad
                txtFile.Visible = False
                cmdSave.Visible = False
                cmdCancel.Visible = False

                Dim Root As New DirectoryInfo(ParentFolderName)
                cboFiles.Items.Clear()
                cboFiles.DataSource = GetFileList(FileFilter, False, cboFolders.SelectedItem.Value)
                cboFiles.DataBind()

                Dim FileName As String = txtFile.PostedFile.FileName.Substring(txtFile.PostedFile.FileName.LastIndexOf("\") + 1)
                If Not cboFiles.Items.FindByText(FileName) Is Nothing Then
                    cboFiles.Items.FindByText(FileName).Selected = True
                End If
            End If
        End Sub

        Private Sub cmdSelect_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSelect.Click
            cboUrls.Visible = True
            cmdSelect.Visible = False
            txtUrl.Visible = False
            cmdAdd.Visible = True
            cmdDelete.Visible = PortalSecurity.IsInRole(_objPortal.AdministratorRoleName)
        End Sub

        Private Sub cmdUpload_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdUpload.Click
            cboFiles.Visible = False
            cmdUpload.Visible = False
            txtFile.Visible = True
            cmdSave.Visible = True
            cmdCancel.Visible = True
        End Sub

        Private Sub optType_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles optType.SelectedIndexChanged
            ShowControls()
        End Sub

#End Region

#Region " Web Form Designer Generated Code "


        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

    End Class

End Namespace
