﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("DotNetNuke")> 
<Assembly: AssemblyDescription("Open Source Web Application Framework")> 
<Assembly: AssemblyCompany("DotNetNuke Corporation")> 
<Assembly: AssemblyProduct("http://www.dotnetnuke.com")> 
<Assembly: AssemblyCopyright("DotNetNuke® is copyright 2002-2007 by DotNetNuke Corporation. All Rights Reserved.")> 
<Assembly: AssemblyTrademark("DotNetNuke")> 
<Assembly: CLSCompliant(True)> 

<Assembly: ComVisible(False)> 

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("a4fb04bb-7ce8-40ed-bad5-218f7687443c")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:

<Assembly: AssemblyVersion("2.0.0.*")> 
