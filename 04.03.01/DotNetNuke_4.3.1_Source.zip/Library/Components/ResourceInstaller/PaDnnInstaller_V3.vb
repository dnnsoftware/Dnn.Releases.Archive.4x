'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2006
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports ICSharpCode.SharpZipLib.Zip
Imports System.IO
Imports System.Text
Imports DotNetNuke.Entities.Modules
Imports DotNetNuke.Services.EventQueue

Namespace DotNetNuke.Modules.Admin.ResourceInstaller

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' The PaDnnInstaller_V3 extends PaDnnInstallerBase to support V3 Modules
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[cnurse]	04/21/2005  documented
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Public Class PaDnnInstaller_V3
        Inherits PaDnnInstallerBase

#Region "Constructors"

        Public Sub New(ByVal InstallerInfo As PaInstallInfo)
            MyBase.New(InstallerInfo)
        End Sub

#End Region

#Region "Protected Methods"

        Protected Overrides Function GetDesktopModule(ByVal Folder As PaFolder) As DesktopModuleInfo

            Dim objDesktopModules As New DesktopModuleController
            Dim objDesktopModule As DesktopModuleInfo = objDesktopModules.GetDesktopModuleByModuleName(Folder.ModuleName)

            Return objDesktopModule

        End Function

        Protected Overrides Function GetDesktopModuleSettings(ByVal objDesktopModule As DesktopModuleInfo, ByVal Folder As PaFolder) As Entities.Modules.DesktopModuleInfo

            ' call the V2 implementation to load the values
            objDesktopModule = MyBase.GetDesktopModuleSettings(objDesktopModule, Folder)

            ' V3 .dnn file format adds the optional businesscontrollerclass node to the folder node element
            objDesktopModule.BusinessControllerClass = Folder.BusinessControllerClass

            'V3.1 adds the IsSearchable/IsPortable properties - set them to false
            objDesktopModule.IsSearchable = False
            objDesktopModule.IsPortable = False

            'Create an instance of the business controller and determine the values of IsSearchable and
            'IsPortable by Reflection
            Try
                If objDesktopModule.BusinessControllerClass <> "" Then
                    Dim objController As Object = Framework.Reflection.CreateObject(objDesktopModule.BusinessControllerClass, objDesktopModule.BusinessControllerClass)
                    If TypeOf objController Is ISearchable Then
                        objDesktopModule.IsSearchable = True
                    End If
                    If TypeOf objController Is IPortable Then
                        objDesktopModule.IsPortable = True
                    End If
                End If
            Catch
                'this code may not work because the module may have just been upgraded and did not have
                'the BusinessControllerClass in the version that is currently in the Application Domain
                'if this is the case, then the updating of thos features will be handled after the application is restarted
            End Try

            Return objDesktopModule
        End Function

        Protected Overrides Function UpgradeModule(ByVal ModuleInfo As Entities.Modules.DesktopModuleInfo) As String
            If ModuleInfo.BusinessControllerClass <> "" Then
                Dim UpgradeVersionsList As String = ""

                If UpgradeVersions.Count > 0 Then
                    For Each Version As String In UpgradeVersions
                        UpgradeVersionsList = UpgradeVersionsList & Version & ","
                    Next
                    If UpgradeVersionsList.EndsWith(",") Then
                        UpgradeVersionsList = UpgradeVersionsList.Remove(UpgradeVersionsList.Length - 1, 1)
                    End If
                Else
                    UpgradeVersionsList = ModuleInfo.Version
                End If

                'this cannot be done directly at this time because 
                'the module may not be loaded into the app domain yet
                'So send an EventMessage that will process the update 
                'after the App recycles
                Dim oAppStartMessage As New EventQueue.EventMessage
                oAppStartMessage.ProcessorType = "DotNetNuke.Entities.Modules.EventMessageProcessor, DotNetNuke"
                oAppStartMessage.Attributes.Add("ProcessCommand", "UpgradeModule")
                oAppStartMessage.Attributes.Add("BusinessControllerClass", ModuleInfo.BusinessControllerClass)
                oAppStartMessage.Attributes.Add("DesktopModuleId", ModuleInfo.DesktopModuleID.ToString())
                oAppStartMessage.Attributes.Add("UpgradeVersionsList", UpgradeVersionsList)
                oAppStartMessage.Priority = MessagePriority.High
                oAppStartMessage.SentDate = System.DateTime.Now
                'make it expire as soon as it's processed
                oAppStartMessage.ExpirationDate = Now.AddYears(-1)
                'send it
                Dim oEventQueueController As New EventQueueController
                oEventQueueController.SendMessage(oAppStartMessage, "Application_Start")

                'force an app restart
                DotNetNuke.Common.Utilities.Config.Touch()
            End If
            'TODO: Need to implement a feedback loop to display the results of the upgrade.

            Return ""
        End Function

#End Region

    End Class
End Namespace
