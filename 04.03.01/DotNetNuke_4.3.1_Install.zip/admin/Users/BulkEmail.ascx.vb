'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2006
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports System.Threading
Imports System.Web.Mail

Imports DotNetNuke.Entities.Modules
Imports DotNetNuke.Security.Roles
Imports DotNetNuke.Services.FileSystem

Namespace DotNetNuke.Modules.Admin.Users

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' The BulkEmail PortalModuleBase is used to manage a Bulk Email mesages
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[cnurse]	9/13/2004	Updated to reflect design changes for Help, 508 support
    '''                       and localisation
    '''     [lpointer]  03-Feb-06   Added 'From' email address support.
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Partial Class BulkEmail
        Inherits DotNetNuke.Entities.Modules.PortalModuleBase

#Region "Event Handlers"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Page_Load runs when the control is loaded
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/10/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try

                If Not Page.IsPostBack Then
                    Dim objRoleController As New RoleController
                    chkRoles.DataSource = objRoleController.GetPortalRoles(PortalId)
                    chkRoles.DataBind()

                    'Dim FileList As ArrayList = GetFileList(PortalId)
                    'cboAttachment.DataSource = FileList
                    'cboAttachment.DataBind()
                    'cmdUpload.NavigateUrl = NavigateURL("File Manager")

                    txtFrom.Text = UserInfo.Email

                End If

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' cmdSend_Click runs when the cmdSend Button is clicked
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/10/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdSend_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSend.Click
            Try
                Dim objRecipients As New ArrayList
                Dim objRoles As New RoleController
                Dim objRole As ListItem
                Dim objListItem As ListItem
                Dim objUser As UserInfo

                ' load all user emails based on roles selected
                For Each objRole In chkRoles.Items
                    If objRole.Selected Then
                        For Each objUser In objRoles.GetUsersByRoleName(PortalId, objRole.Value)
                            If objUser.Membership.Approved Then
                                objListItem = New ListItem(objUser.Email, objUser.DisplayName)
                                If Not objRecipients.Contains(objListItem) Then
                                    objRecipients.Add(objListItem)
                                End If
                            End If
                        Next
                    End If
                Next

                ' load emails specified in email distribution list
                If txtEmail.Text <> "" Then
                    Dim arrEmail As Array = Split(txtEmail.Text, ";")
                    Dim strEmail As String
                    For Each strEmail In arrEmail
                        objListItem = New ListItem(strEmail, strEmail)
                        If Not objRecipients.Contains(objListItem) Then
                            objRecipients.Add(objListItem)
                        End If
                    Next
                End If

                ' create object
                Dim objSendBulkEMail As New Services.Mail.SendBulkEmail(objRecipients, cboPriority.SelectedItem.Value, teMessage.Mode, PortalSettings.PortalAlias.HTTPAlias)
                objSendBulkEMail.Subject = txtSubject.Text
                objSendBulkEMail.Body &= teMessage.Text
                If ctlAttachment.Url.StartsWith("FileID=") Then
                    Dim fileId As Integer = Integer.Parse(ctlAttachment.Url.Substring(7))
                    Dim objFileController As New FileController
                    Dim objFileInfo As FileInfo = objFileController.GetFileById(fileId, PortalId)

                    objSendBulkEMail.Attachment = PortalSettings.HomeDirectoryMapPath & objFileInfo.Folder & objFileInfo.FileName

                End If
                objSendBulkEMail.SendMethod = cboSendMethod.SelectedItem.Value
                objSendBulkEMail.SMTPServer = Convert.ToString(PortalSettings.HostSettings("SMTPServer"))
                objSendBulkEMail.SMTPAuthentication = Convert.ToString(PortalSettings.HostSettings("SMTPAuthentication"))
                objSendBulkEMail.SMTPUsername = Convert.ToString(PortalSettings.HostSettings("SMTPUsername"))
                objSendBulkEMail.SMTPPassword = Convert.ToString(PortalSettings.HostSettings("SMTPPassword"))
                objSendBulkEMail.Administrator = txtFrom.Text
                objSendBulkEMail.Heading = Services.Localization.Localization.GetString("Heading", Me.LocalResourceFile)

                ' send mail
                If optSendAction.SelectedItem.Value = "S" Then
                    objSendBulkEMail.Send()
                Else    ' ansynchronous uses threading
                    Dim objThread As New Thread(AddressOf objSendBulkEMail.Send)
                    objThread.Start()
                End If

                ' completed
                UI.Skins.Skin.AddModuleMessage(Me, Services.Localization.Localization.GetString("MessageSent", Me.LocalResourceFile), DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.GreenSuccess)

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

#End Region

    End Class

End Namespace
