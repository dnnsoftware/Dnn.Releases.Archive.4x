'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2006
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports DotNetNuke.Entities.Modules
Imports DotNetNuke.Security.Membership
Imports DotNetNuke.Services.Localization
Imports DotNetNuke.Services.Mail
Imports DotNetNuke.UI.Skins.Controls.ModuleMessage
Imports DotNetNuke.UI.Utilities
Imports DotNetNuke.UI.WebControls

Namespace DotNetNuke.Modules.Admin.Users

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' The User UserModuleBase is used to manage the base parts of a User.
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[cnurse]	03/01/2006  created
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Partial Class User
        Inherits UserModuleBase

#Region "Delegates"

        Public Delegate Sub UserCreatedEventHandler(ByVal sender As Object, ByVal e As UserCreatedEventArgs)
        Public Delegate Sub UserDeletedEventHandler(ByVal sender As Object, ByVal e As UserDeletedEventArgs)

#End Region

#Region "Events"

        Public Event UserCreated As UserCreatedEventHandler
        Public Event UserDeleted As UserDeletedEventHandler
        Public Event UserUpdated As EventHandler

#End Region

#Region "Protected Properties"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets whether the Captcha control is used to validate the login
        ''' </summary>
        ''' <history>
        ''' 	[cnurse]	03/21/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Protected ReadOnly Property UseCaptcha() As Boolean
            Get
                Dim setting As Object = UserModuleBase.GetSetting(PortalId, "Security_CaptchaRegister")
                Return CType(setting, Boolean) And IsRegister
            End Get
        End Property

#End Region

#Region "Public Properties"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets whether the User is valid
        ''' </summary>
        ''' <history>
        ''' 	[cnurse]	03/21/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public ReadOnly Property IsValid() As Boolean
            Get
                Dim _IsValid As Boolean = True

                'Check Captcha Control
                If UseCaptcha Then
                    _IsValid = ctlCaptcha.IsValid
                End If

                'Check User Editor
                If _IsValid Then
                    _IsValid = UserEditor.IsValid
                End If

                'Check Password is valid
                If AddUser Then
                    Dim createStatus As UserCreateStatus = UserCreateStatus.AddUser
                    If Not chkRandom.Checked Then
                        '1. Check Password and Confirm are the same
                        If txtPassword.Text <> txtConfirm.Text Then
                            createStatus = UserCreateStatus.PasswordMismatch
                        End If
                        '2. Check Password is Valid
                        If createStatus = UserCreateStatus.AddUser And Not UserController.ValidatePassword(txtPassword.Text) Then
                            createStatus = UserCreateStatus.InvalidPassword
                        End If
                        If createStatus = UserCreateStatus.AddUser Then
                            User.Membership.Password = txtPassword.Text
                        End If
                    Else
                        'Generate a random password for the user
                        User.Membership.Password = UserController.GeneratePassword()
                    End If

                    If createStatus <> UserCreateStatus.AddUser Then
                        _IsValid = False
                        valPassword.ErrorMessage = "<br/>" + UserController.GetUserCreateStatus(createStatus)
                        valPassword.IsValid = False
                    End If

                End If

                Return _IsValid
            End Get
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets and sets whether the Update button
        ''' </summary>
        ''' <history>
        ''' 	[cnurse]	05/18/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Property ShowUpdate() As Boolean
            Get
                Return pnlUpdate.Visible
            End Get
            Set(ByVal Value As Boolean)
                pnlUpdate.Visible = Value
            End Set
        End Property

#End Region

#Region "Event Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Raises the UserCreated Event
        ''' </summary>
        ''' <history>
        ''' 	[cnurse]	03/01/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub OnUserCreated(ByVal e As UserCreatedEventArgs)

            RaiseEvent UserCreated(Me, e)

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Raises the UserDeleted Event
        ''' </summary>
        ''' <history>
        ''' 	[cnurse]	03/01/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub OnUserDeleted(ByVal e As UserDeletedEventArgs)

            RaiseEvent UserDeleted(Me, e)

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Raises the UserUpdated Event
        ''' </summary>
        ''' <history>
        ''' 	[cnurse]	03/01/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub OnUserUpdated(ByVal e As EventArgs)

            RaiseEvent UserUpdated(Me, e)

        End Sub

#End Region

#Region "Public Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' CreateUser creates a new user in the Database
        ''' </summary>
        ''' <history>
        ''' 	[cnurse]	05/18/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub CreateUser()

            If IsRegister Then
                'Set the Approved status based on the Portal Settings
                If PortalSettings.UserRegistration = PortalRegistrationType.PublicRegistration Then
                    User.Membership.Approved = True
                Else
                    User.Membership.Approved = False
                End If
            Else
                'Set the Approved status from the value in the Authorized checkbox
                User.Membership.Approved = chkAuthorize.Checked
            End If

            If User.Profile.LastName = Null.NullString Then
                User.Profile.LastName = User.LastName
            End If
            If User.Profile.FirstName = Null.NullString Then
                User.Profile.FirstName = User.FirstName
            End If

            Dim createStatus As UserCreateStatus = UserController.CreateUser(User)

            Dim args As UserCreatedEventArgs
            If createStatus = UserCreateStatus.Success Then
                args = New UserCreatedEventArgs(User)
                args.Notify = chkNotify.Checked
            Else       ' registration error
                args = New UserCreatedEventArgs(Nothing)
            End If
            args.CreateStatus = createStatus
            OnUserCreated(args)
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' DataBind binds the data to the controls
        ''' </summary>
        ''' <history>
        ''' 	[cnurse]	03/01/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overrides Sub DataBind()

            If UseCaptcha Then
                ctlCaptcha.ErrorMessage = Localization.GetString("InvalidCaptcha", Me.LocalResourceFile)
                ctlCaptcha.Text = Localization.GetString("CaptchaText", Me.LocalResourceFile)
            End If

            If Page.IsPostBack = False Then
                ClientAPI.AddButtonConfirm(cmdDelete, Localization.GetString("DeleteItem"))
                chkRandom.Checked = False
            End If

            ' disable deletion of the currently logged in account
            If IsUser Or AddUser Then
                cmdDelete.Visible = False
            End If

            If AddUser Then
                If IsRegister Then
                    tblAddUser.Visible = False
                    trRandom.Visible = False
                    lblPasswordHelp.Text = Localization.GetString("PasswordHelpUser", Me.LocalResourceFile)
                Else
                    lblPasswordHelp.Text = Localization.GetString("PasswordHelpAdmin", Me.LocalResourceFile)
                End If
                pnlAddUser.Visible = True
                txtConfirm.Attributes.Add("value", txtConfirm.Text)
                txtPassword.Attributes.Add("value", txtPassword.Text)
            End If

            UserEditor.DataSource = User
            UserEditor.DataBind()

            trCaptcha.Visible = UseCaptcha

        End Sub

#End Region

#Region "Event Handlers"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Page_Init runs when the control is initialised
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	03/01/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Page_Load runs when the control is loaded
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	03/01/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            UserEditor.LocalResourceFile = Me.LocalResourceFile

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' cmdDelete_Click runs when the delete Button is clicked
        ''' </summary>
        ''' <history>
        ''' 	[cnurse]	03/01/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdDelete.Click
            Dim name As String = User.Username
            Dim id As Integer = UserId

            If UserController.DeleteUser(User, True, False) Then
                OnUserDeleted(New UserDeletedEventArgs(id, name))
            End If
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' cmdUpdate_Click runs when the Update Button is clicked
        ''' </summary>
        ''' <history>
        ''' 	[cnurse]	03/01/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdUpdate.Click
            If AddUser Then
                If IsValid Then
                    CreateUser()
                End If
            Else
                If UserEditor.IsValid AndAlso UserEditor.IsDirty AndAlso (Not User Is Nothing) Then
                    UserController.UpdateUser(PortalId, User)
                    OnUserUpdated(EventArgs.Empty)
                End If
            End If
        End Sub

#End Region

#Region "Event Args"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' The UserCreatedEventArgs class provides a customised EventArgs class for
        ''' the UserCreated Event
        ''' </summary>
        ''' <history>
        ''' 	[cnurse]	03/08/2006  created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Class UserCreatedEventArgs

            Private _NewUser As UserInfo
            Private _CreateStatus As UserCreateStatus = UserCreateStatus.Success
            Private _Notify As Boolean = False

            ''' -----------------------------------------------------------------------------
            ''' <summary>
            ''' Constructs a new UserCreatedEventArgs
            ''' </summary>
            ''' <param name="newUser">The newly Created User</param>
            ''' <history>
            ''' 	[cnurse]	03/08/2006  Created
            ''' </history>
            ''' -----------------------------------------------------------------------------
            Public Sub New(ByVal newUser As UserInfo)
                _NewUser = newUser
            End Sub

            ''' -----------------------------------------------------------------------------
            ''' <summary>
            ''' Gets and sets the Create Status
            ''' </summary>
            ''' <history>
            ''' 	[cnurse]	03/08/2006  Created
            ''' </history>
            ''' -----------------------------------------------------------------------------
            Public Property CreateStatus() As UserCreateStatus
                Get
                    Return _CreateStatus
                End Get
                Set(ByVal Value As UserCreateStatus)
                    _CreateStatus = Value
                End Set
            End Property

            ''' -----------------------------------------------------------------------------
            ''' <summary>
            ''' Gets and sets the New User
            ''' </summary>
            ''' <history>
            ''' 	[cnurse]	03/08/2006  Created
            ''' </history>
            ''' -----------------------------------------------------------------------------
            Public Property NewUser() As UserInfo
                Get
                    Return _NewUser
                End Get
                Set(ByVal Value As UserInfo)
                    _NewUser = Value
                End Set
            End Property

            ''' -----------------------------------------------------------------------------
            ''' <summary>
            ''' Gets and sets a flag whether to Notify the new User of the Creation
            ''' </summary>
            ''' <history>
            ''' 	[cnurse]	03/08/2006  Created
            ''' </history>
            ''' -----------------------------------------------------------------------------
            Public Property Notify() As Boolean
                Get
                    Return _Notify
                End Get
                Set(ByVal Value As Boolean)
                    _Notify = Value
                End Set
            End Property

        End Class

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' The UserDeletedEventArgs class provides a customised EventArgs class for
        ''' the UserDeleted Event
        ''' </summary>
        ''' <history>
        ''' 	[cnurse]	03/08/2006  created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Class UserDeletedEventArgs

            Private _userName As String
            Private _userId As Integer

            ''' -----------------------------------------------------------------------------
            ''' <summary>
            ''' Constructs a new UserDeletedEventArgs
            ''' </summary>
            ''' <param name="id">The Id of the deleted User</param>
            ''' <param name="name">The user name of the deleted User</param>
            ''' <history>
            ''' 	[cnurse]	03/08/2006  Created
            ''' </history>
            ''' -----------------------------------------------------------------------------
            Public Sub New(ByVal id As Integer, ByVal name As String)

                _userId = id
                _userName = name

            End Sub

            ''' -----------------------------------------------------------------------------
            ''' <summary>
            ''' Gets and sets the Id of the deleted User
            ''' </summary>
            ''' <history>
            ''' 	[cnurse]	03/08/2006  Created
            ''' </history>
            ''' -----------------------------------------------------------------------------
            Public Property UserId() As Integer
                Get
                    Return _userId
                End Get
                Set(ByVal Value As Integer)
                    _userId = Value
                End Set
            End Property

            ''' -----------------------------------------------------------------------------
            ''' <summary>
            ''' Gets and sets the username of the deleted User
            ''' </summary>
            ''' <history>
            ''' 	[cnurse]	03/08/2006  Created
            ''' </history>
            ''' -----------------------------------------------------------------------------
            Public Property UserName() As String
                Get
                    Return _userName
                End Get
                Set(ByVal Value As String)
                    _userName = Value
                End Set
            End Property

        End Class

#End Region

    End Class

End Namespace