Namespace ASPNetPortal

    Public Class ManageStore
        Inherits ASPNetPortal.PortalModuleControl

        Protected WithEvents moduletitle As System.Web.UI.HtmlControls.HtmlGenericControl

        Protected WithEvents optStore As System.Web.UI.WebControls.RadioButtonList
        Protected WithEvents cboColumns As System.Web.UI.WebControls.DropDownList
        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton

        Protected WithEvents cmdAddProduct As System.Web.UI.WebControls.LinkButton
        Protected WithEvents grdProducts As System.Web.UI.WebControls.DataGrid
        Protected WithEvents cmdAddCategory As System.Web.UI.WebControls.LinkButton
        Protected WithEvents grdCategories As System.Web.UI.WebControls.DataGrid

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        '*******************************************************
        '
        ' The Page_Load server event handler on this page is used
        ' to populate the role information for the page
        '
        '*******************************************************

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            ' Verify that the current user has access to access this page
            If Context.User.Identity.Name <> _portalSettings.SuperUserId And Context.User.IsInRole(_portalSettings.AdministratorRoleId) = False Then
                Response.Redirect("~/EditModule.aspx?tabindex=" & TabIndex & "&def=Edit Access Denied")
            End If

            ' If this is the first visit to the page, bind the role data to the datalist
            If Page.IsPostBack = False Then
                ' Get settings from the database
                Dim settings As Hashtable = PortalSettings.GetModuleSettings(ModuleId)

                Dim StoreType As String = CType(settings("storetype"), String)
                If StoreType = "" Then
                    StoreType = "L"
                End If
                optStore.Items.FindByValue(StoreType).Selected = True

                Dim Columns As String = CType(settings("storecolumns"), String)
                If Columns = "" Then
                    Columns = "2"
                End If
                cboColumns.Items.FindByText(Columns).Selected = True

                BindData()

                ' Store URL Referrer to return to portal
                ViewState("UrlReferrer") = "~/DesktopDefault.aspx?tabid=" & TabId & "&tabindex=" & TabIndex
            End If
        End Sub

        Public Sub grdCategories_CancelEdit(ByVal sender As Object, ByVal e As DataGridCommandEventArgs)
            grdCategories.EditItemIndex = -1
            BindData()
        End Sub

        Public Sub grdCategories_Edit(ByVal sender As Object, ByVal e As DataGridCommandEventArgs)
            grdCategories.EditItemIndex = e.Item.ItemIndex
            grdCategories.SelectedIndex = -1
            BindData()
        End Sub

        Public Sub grdCategories_Update(ByVal sender As Object, ByVal e As DataGridCommandEventArgs)

            Dim intPortalId As Integer

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            Dim objStore As New StoreDB()

            Dim txtCategoryName As TextBox = e.Item.Cells(1).Controls(1)

            ' if superuser then we are managing the global Products 
            If Context.User.Identity.Name = _portalSettings.SuperUserId Then
                intPortalId = -1
            Else
                intPortalId = _portalSettings.PortalId
            End If

            If Integer.Parse(grdCategories.DataKeys(e.Item.ItemIndex).ToString()) = -1 Then
                objStore.AddCategory(txtCategoryName.Text, intPortalId)
            Else
                objStore.UpdateCategory(Integer.Parse(grdCategories.DataKeys(e.Item.ItemIndex).ToString()), txtCategoryName.Text)
            End If

            grdCategories.EditItemIndex = -1
            BindData()
        End Sub

        Public Sub grdCategories_Delete(ByVal sender As Object, ByVal e As DataGridCommandEventArgs)
            Dim objStore As New StoreDB()

            objStore.DeleteCategory(Integer.Parse(grdCategories.DataKeys(e.Item.ItemIndex).ToString()))

            grdCategories.EditItemIndex = -1
            BindData()
        End Sub

        Private Sub cmdAddCategory_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdAddCategory.Click
            grdCategories.EditItemIndex = 0
            BindData(True)
        End Sub

        Public Sub BindData(Optional ByVal blnInsertCategory As Boolean = False)

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            Dim objStore As New StoreDB()

            If Context.User.Identity.Name = _portalSettings.SuperUserId Then
                grdProducts.DataSource = objStore.GetProducts()
            Else
                grdProducts.DataSource = objStore.GetProducts(PortalId)
            End If
            grdProducts.DataBind()

            Dim ds As DataSet

            If Context.User.Identity.Name = _portalSettings.SuperUserId Then
                ds = ConvertDataReaderToDataSet(objStore.GetCategories())
            Else
                ds = ConvertDataReaderToDataSet(objStore.GetCategories(PortalId))
            End If

            ' inserting a new group
            If blnInsertCategory Then
                Dim row As DataRow
                row = ds.Tables(0).NewRow()
                row("CategoryId") = "-1"
                row("CategoryName") = ""
                ds.Tables(0).Rows.InsertAt(row, 0)
                grdCategories.EditItemIndex = 0
            End If

            ' bind stat report groups to dropdownlist
            grdCategories.DataSource = ds
            grdCategories.DataBind()
        End Sub

        Private Sub cmdAddProduct_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdAddProduct.Click
            Response.Redirect("~/EditModule.aspx?tabid=" & TabId & "&tabindex=" & TabIndex & "&mid=" & ModuleId & "&def=Product")
        End Sub

        Private Sub grdCategories_ItemCreated(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles grdCategories.ItemCreated

            Dim cmdDeleteCategory As Control = e.Item.FindControl("cmdDeleteCategory")

            If Not cmdDeleteCategory Is Nothing Then
                CType(cmdDeleteCategory, ImageButton).Attributes.Add("onClick", "javascript: return confirm('Are You Sure You Wish To Delete This Item ?')")
            End If

        End Sub

        Private Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdUpdate.Click
            Dim admin As New AdminDB()

            admin.UpdateModuleSetting(ModuleId, "storetype", optStore.SelectedItem.Value)
            admin.UpdateModuleSetting(ModuleId, "storecolumns", cboColumns.SelectedItem.Text)

            ' Redirect back to the portal home page
            Response.Redirect(CType(ViewState("UrlReferrer"), String))
        End Sub

        Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
            ' Redirect back to the portal home page
            Response.Redirect(CType(ViewState("UrlReferrer"), String))

        End Sub

        Public Function EditURL(ByVal strKeyName As String, ByVal strKeyValue As String) As String
            EditURL = "~/EditModule.aspx?tabid=" & TabId & "&tabindex=" & TabIndex & "&mid=" & ModuleId & "&" & strKeyName & "=" & strKeyValue & "&def=Product"
        End Function

    End Class

End Namespace