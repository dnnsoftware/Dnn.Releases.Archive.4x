Namespace ASPNetPortal

	Public Class ShoppingCart
        Inherits ASPNetPortal.PortalModuleControl

        Protected WithEvents pnlDetailsPanel As System.Web.UI.WebControls.Panel
		Protected WithEvents pnlNavigation As System.Web.UI.WebControls.Panel
		Protected WithEvents pnlEmptyCartNav As System.Web.UI.WebControls.Panel

        Protected WithEvents lblCartError As System.Web.UI.WebControls.Label
		Protected WithEvents dgrCartItems As System.Web.UI.WebControls.DataGrid
		Protected WithEvents lblTotal As System.Web.UI.WebControls.Label
		Protected WithEvents hypUpdate As System.Web.UI.WebControls.LinkButton
		Protected WithEvents hypCheckout As System.Web.UI.WebControls.LinkButton
		Protected WithEvents hypContinue As System.Web.UI.WebControls.LinkButton
		Protected WithEvents hypContinue2 As System.Web.UI.WebControls.LinkButton
		Protected WithEvents hypExitStore As System.Web.UI.WebControls.LinkButton

        Private ItemId As Integer = -1
        Public StoreType As String

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        '*******************************************************
        '
        ' The Page_Load server event handler on this page is used
        ' to populate the role information for the page
        '
        '*******************************************************

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            ' Determine ItemId of Contacts to Update
            If Not (Request.Params("ItemId") Is Nothing) Then
                ItemId = Int32.Parse(Request.Params("ItemId"))
            End If

            StoreType = Request.Params("storetype")

            ' If this is the first visit to the page, bind the role data to the datalist
            If Page.IsPostBack = False Then

                PopulateShoppingCartList()

                ' Store URL Referrer to return to portal
                ViewState("UrlReferrer") = Request.UrlReferrer.ToString()
            End If
        End Sub


        Private Sub hypUpdate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles hypUpdate.Click
            UpdateShoppingCartDatabase()
            PopulateShoppingCartList()
        End Sub



        '*******************************************************
        '
        ' The PopulateShoppingCartList helper method is used to
        ' dynamically populate a GridControl with the contents of
        ' the current user's shopping cart.
        '
        '*******************************************************

        Sub PopulateShoppingCartList()

            Dim objStore As New StoreDB()

            ' Obtain current user's shopping cart ID
            Dim strCartId As String = objStore.GetShoppingCartId()

            ' If no items, hide details and display message
            If objStore.GetItemCount(strCartId) = 0 Then
                pnlDetailsPanel.Visible = False
                lblCartError.Text = "There are currently no items in your shopping cart."
                pnlNavigation.Visible = False
                pnlEmptyCartNav.Visible = True
            Else
                ' Databind Gridcontrol with Shopping Cart Items
                dgrCartItems.DataSource = objStore.GetItems(strCartId)
                dgrCartItems.DataBind()
                dgrCartItems.Columns(0).Visible = False

                'Update Total Price Label
                lblTotal.Text = String.Format("{0:c}", objStore.GetTotal(strCartId))
            End If

        End Sub


        '*******************************************************
        '
        ' The UpdateShoppingCartDatabase helper method is used to
        ' update a user's items within the shopping cart database
        ' using client input from the GridControl.
        '
        '*******************************************************

        Sub UpdateShoppingCartDatabase()

            Dim objStore As New StoreDB()

            ' Obtain current user's shopping cart ID
            Dim strCartId As String = objStore.GetShoppingCartId()

            ' Iterate through all rows within shopping cart list
            Dim i As Integer
            For i = 0 To dgrCartItems.Items.Count - 1

                ' Obtain references to row's controls
                Dim quantityTxt As TextBox = CType(dgrCartItems.Items(i).FindControl("txtQuantity"), TextBox)
                Dim removeChk As CheckBox = CType(dgrCartItems.Items(i).FindControl("chkRemove"), CheckBox)

                ' Wrap in try/catch block to catch errors in the event that someone types in
                ' an invalid value for quantity
                Dim intQuantity As Integer
                Try
                    intQuantity = CInt(quantityTxt.Text)

                    ' If the quantity field is changed or delete is checked
                    If intQuantity <> CInt(dgrCartItems.DataKeys(i)) Or removeChk.Checked = True Then

                        Dim lblProductID As Label = CType(dgrCartItems.Items(i).FindControl("lblProductID"), Label)

                        If intQuantity = 0 Or removeChk.Checked = True Then
                            objStore.RemoveItem(strCartId, CInt(lblProductID.Text))
                        Else
                            objStore.UpdateItem(strCartId, CInt(lblProductID.Text), intQuantity)
                        End If
                    End If
                Catch ice As InvalidCastException
                    lblCartError.Text = "You entered a non-numeric value for one or more of your products.  Please enter numbers only."
                Catch e As Exception
                    lblCartError.Text = "There was a problem updating your cart."
                End Try
            Next
        End Sub


        Private Sub hypCheckout_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles hypCheckout.Click

            ' Update Shopping Cart
            UpdateShoppingCartDatabase()

            ' If cart is not empty, proceed on to checkout page
            Dim objStore As New StoreDB()

            ' Calculate shopping cart ID
            Dim strCartId As String = objStore.GetShoppingCartId()

            ' If the cart isn't empty, navigate to checkout page
            If objStore.GetItemCount(strCartId) <> 0 Then
                Response.Redirect("~/EditModule.aspx?tabid=" & TabId & "&tabindex=" & TabIndex & "&mid=" & ModuleId & "&def=Purchase")
            Else
                lblCartError.Text = "You can't proceed to the Check Out page with an empty cart."
            End If
        End Sub


        Private Sub hypContinue_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles hypContinue.Click
            Response.Redirect("~/DesktopDefault.aspx?tabid=" & tabId & "&tabindex=" & tabIndex)
        End Sub

        Private Sub hypContinue2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles hypContinue2.Click
            Response.Redirect("~/DesktopDefault.aspx?tabid=" & tabId & "&tabindex=" & tabIndex)
        End Sub

        Private Sub hypExitStore_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles hypExitStore.Click
            Response.Redirect("~/DesktopDefault.aspx")
        End Sub

        Public Function EditURL(ByVal strKeyName As String, ByVal strKeyValue As String) As String
            EditURL = "~/EditModule.aspx?tabid=" & TabId & "&tabindex=" & TabIndex & "&mid=" & ModuleId & "&storetype=" & StoreType & "&" & strKeyName & "=" & strKeyValue & "&def=Product Details"
        End Function
    End Class

End Namespace