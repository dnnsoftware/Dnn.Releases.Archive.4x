Namespace ASPNetPortal

    Public Class Store
        Inherits ASPNetPortal.PortalModuleControl

        Protected WithEvents cmdViewCart As System.Web.UI.WebControls.ImageButton
        Protected WithEvents txtProducts As System.Web.UI.WebControls.TextBox
        Protected WithEvents lblSpace As System.Web.UI.WebControls.Label
        Protected WithEvents cboCategories As System.Web.UI.WebControls.DropDownList
        Protected WithEvents cmdSearch As System.Web.UI.WebControls.LinkButton
        Protected WithEvents lblMessage As System.Web.UI.WebControls.Label
        Protected WithEvents lstProducts As System.Web.UI.WebControls.DataList
        Protected WithEvents imgProduct As System.Web.UI.WebControls.Image
        Protected WithEvents lblErrorMsg As System.Web.UI.WebControls.Label

        Private StoreType As String

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        '*******************************************************
        '
        ' The Page_Load server event handler on this user control is used
        ' to populate the current roles settings from the configuration system
        '
        '*******************************************************

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            If Not Request.IsAuthenticated Then
                lblMessage.Text = "<br>In order to purchase products from our Store, you must first identify yourself as a member of the site. If you have already registered in the past, please enter your Email and Password on the Account Login screen. If you have not yet registered for the site, click the Register button on the Account Login screen and enter your Account Registration details.<br><br>Please click <b><a href=""" & Request.ApplicationPath & "/DesktopDefault.aspx"">here</a></b> to proceed to the Account Login screen."
                cmdViewCart.Visible = False
            Else
                lblMessage.Text = "&nbsp;"
                cmdViewCart.Visible = True
            End If

            StoreType = CType(Settings("storetype"), String)
            If StoreType = "" Then
                StoreType = "G"
            End If

            'If this is the first visit to the page, bind the role data to the datalist
            If Page.IsPostBack = False Then
                Dim Columns As String = CType(Settings("storecolumns"), String)
                If Columns = "" Then
                    Columns = "2"
                End If
                If CType(Settings("storecolumns"), String) <> "" Then
                    lstProducts.RepeatColumns = Int32.Parse(Columns)
                End If
                If Columns = "1" Then
                    lblSpace.Text = "<br>"
                Else
                    lblSpace.Text = "&nbsp;&nbsp;"
                End If

                BindData()
            End If
        End Sub

        '*******************************************************
        '
        ' The BindData helper method is used to bind the list of
        ' users for this portal to an asp:DropDownList server control
        '
        '*******************************************************
        Sub BindData()

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            ' Get the list of registered users from the database
            Dim store As New StoreDB()

            ' bind all portal users to dropdownlist
            Select Case StoreType
                Case "L" ' local
                    cboCategories.DataSource = store.GetCategories(PortalId)
                Case "G" ' global
                    cboCategories.DataSource = store.GetCategories()
            End Select
            cboCategories.DataBind()
            'add blank item to force selection
            cboCategories.Items.Add("")
            cboCategories.Items(cboCategories.Items.Count - 1).Selected = True

            Select Case StoreType
                Case "L" ' local
                    lstProducts.DataSource = store.FindProducts(PortalId, , , True)
                Case "G" ' global
                    lstProducts.DataSource = store.FindProducts(, , , True)
            End Select
            lstProducts.DataBind()
        End Sub


        '*******************************************************
        '
        ' The cmdSearch_click() event procedure was intentionally scrapped in this control.
        ' The cmdSearch_click() event would not fire when the enter key was pressed, so 
        ' this method is called from form_load on postbacks, instead of trying to 
        ' trap the event.
        '
        '*******************************************************
        Private Sub ExecuteSearch()

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            Dim objStore As StoreDB = New StoreDB()

            Dim strSearchTerm As String = txtProducts.Text.Trim()

            Dim intCategoryID As Integer = -1
            If cboCategories.SelectedItem.Value <> "" Then
                intCategoryID = Int32.Parse(cboCategories.SelectedItem.Value)
            End If

            If strSearchTerm <> "" Or intCategoryID <> -1 Then
                Select Case StoreType
                    Case "L" ' local
                        lstProducts.DataSource = objStore.FindProducts(PortalId, strSearchTerm, intCategoryID)
                    Case "G" ' global
                        lstProducts.DataSource = objStore.FindProducts(, strSearchTerm, intCategoryID)
                End Select
                lstProducts.DataBind()
            End If

            ' Display a message if no results are found
            If lstProducts.Items.Count = 0 Then
                lblErrorMsg.Text = "No products were found matching your query."
            Else
                lblErrorMsg.Text = ""
            End If
        End Sub

        Public Function CartURL(ByVal strKeyName As String, ByVal strKeyValue As String) As String
            CartURL = "~/DesktopModules/Store/AddToCart.aspx?tabid=" & TabId & "&tabindex=" & TabIndex & "&mid=" & ModuleId & "&" & strKeyName & "=" & strKeyValue & "&storetype=" & StoreType
        End Function

        Public Function FormatImage(ByVal value As Object) As String

            Dim strImage As String = value.ToString()

            ' images are optional for products
            If strImage = "" Then
                strImage = "~" & System.Configuration.ConfigurationSettings.AppSettings("siteUploadDirectory") & "noimage.gif"
            Else
                ' Obtain PortalSettings from Current Context
                Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

                Select Case StoreType
                    Case "L" ' local
                        strImage = _portalSettings.UploadDirectory & "thumb_" & strImage
                    Case "G" ' global
                        strImage = "~" & System.Configuration.ConfigurationSettings.AppSettings("siteUploadDirectory") & "thumb_" & strImage
                End Select
            End If

            Return strImage

        End Function

        Private Sub cmdViewCart_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles cmdViewCart.Click
            Response.Redirect("~/EditModule.aspx?tabid=" & TabId & "&tabindex=" & TabIndex & "&mid=" & ModuleId & "&storetype=" & StoreType & "&def=Shopping Cart")
        End Sub

        Private Sub cmdSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSearch.Click
            ExecuteSearch()
        End Sub

        Private Sub cboCategories_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCategories.SelectedIndexChanged
            ExecuteSearch()
        End Sub

        Public Function EditURL(ByVal strKeyName As String, ByVal strKeyValue As String) As String
            EditURL = "~/EditModule.aspx?tabid=" & TabId & "&tabindex=" & TabIndex & "&mid=" & ModuleId & "&storetype=" & StoreType & "&" & strKeyName & "=" & strKeyValue & "&def=Product Details"
        End Function

    End Class

End Namespace
