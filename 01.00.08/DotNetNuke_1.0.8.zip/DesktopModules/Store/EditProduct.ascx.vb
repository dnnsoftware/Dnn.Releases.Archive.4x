Imports System.IO

Namespace ASPNetPortal

    Public Class EditProduct
        Inherits ASPNetPortal.PortalModuleControl

        Protected WithEvents txtProductNumber As System.Web.UI.WebControls.TextBox
        Protected WithEvents valProductNumber As System.Web.UI.WebControls.RequiredFieldValidator
        Protected WithEvents txtProductName As System.Web.UI.WebControls.TextBox
        Protected WithEvents valProductName As System.Web.UI.WebControls.RequiredFieldValidator
        Protected WithEvents chkCategories As System.Web.UI.WebControls.CheckBoxList
        Protected WithEvents txtDescription As System.Web.UI.WebControls.TextBox
        Protected WithEvents cboImage As System.Web.UI.WebControls.DropDownList
        Protected WithEvents cmdUpload As System.Web.UI.WebControls.HyperLink
        Protected WithEvents txtUnitCost As System.Web.UI.WebControls.TextBox
        Protected WithEvents valUnitCost1 As System.Web.UI.WebControls.RequiredFieldValidator
        Protected WithEvents valUnitCost2 As System.Web.UI.WebControls.CompareValidator
        Protected WithEvents chkFeatured As System.Web.UI.WebControls.CheckBox

        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdDelete As System.Web.UI.WebControls.LinkButton

        Protected WithEvents pnlAudit As System.Web.UI.WebControls.Panel
        Protected WithEvents lblCreatedBy As System.Web.UI.WebControls.Label
        Protected WithEvents lblCreatedDate As System.Web.UI.WebControls.Label

        Private ProductId As Integer = -1

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            ' Verify that the current user has access to access this page
            If Context.User.Identity.Name <> _portalSettings.SuperUserId And Context.User.IsInRole(_portalSettings.AdministratorRoleId) = False Then
                Response.Redirect("~/EditModule.aspx?tabindex=" & TabIndex & "&def=Edit Access Denied")
            End If

            ' Determine StoreId of Store to Update
            If Not (Request.Params("ProductId") Is Nothing) Then
                ProductId = Int32.Parse(Request.Params("ProductId"))
            End If

            If Page.IsPostBack = False Then

                cmdDelete.Attributes.Add("onClick", "javascript:return confirm('Are You Sure You Wish To Delete This Item ?');")

                Dim objStore As New StoreDB()
                Dim dr As SqlDataReader

                ' load the list of files found in the upload directory
                If PortalSecurity.IsInRole(_portalSettings.AdministratorRoleId.ToString) Then
                    cmdUpload.NavigateUrl = "~/EditModule.aspx?tabid=" & TabId & "&tabindex=" & TabIndex & "&def=File Manager"
                Else
                    cmdUpload.Visible = False
                End If
                Dim FileList As ArrayList
                If Context.User.Identity.Name = _portalSettings.SuperUserId Then
                    FileList = GetFileList(, "jpg,jpeg,gif")
                Else
                    FileList = GetFileList(PortalId, "jpg,jpeg,gif")
                End If
                cboImage.DataSource = FileList
                cboImage.DataBind()

                ' load categories
                If Context.User.Identity.Name = _portalSettings.SuperUserId Then
                    dr = objStore.GetCategories()
                Else
                    dr = objStore.GetCategories(PortalId)
                End If
                While dr.Read()
                    Dim item As New ListItem()
                    item.Text = dr("CategoryName").ToString()
                    item.Value = dr("CategoryID").ToString()
                    chkCategories.Items.Add(item)
                End While
                dr.Close()

                If ProductId <> -1 Then

                    dr = objStore.GetSingleProduct(ProductId)

                    ' Read first row from database
                    If dr.Read() Then
                        txtProductNumber.Text = dr("ProductNumber").ToString
                        txtProductName.Text = dr("ProductName").ToString
                        If Not IsDBNull(dr("Description")) Then
                            txtDescription.Text = dr("Description").ToString
                        End If
                        If cboImage.Items.Contains(New ListItem(dr("ImageFile").ToString)) Then
                            cboImage.Items.FindByText(dr("ImageFile").ToString).Selected = True
                        End If
                        txtUnitCost.Text = Format(dr("UnitCost"), "#,##0.00")
                        chkFeatured.Checked = dr("Featured")
                        lblCreatedBy.Text = dr("CreatedByUser").ToString
                        lblCreatedDate.Text = CType(dr("CreatedDate"), DateTime).ToShortDateString()
                    End If
                    dr.Close()

                    dr = objStore.GetProductCategories(ProductId)
                    While dr.Read()
                        If Not chkCategories.Items.FindByValue(dr("CategoryID")) Is Nothing Then
                            chkCategories.Items.FindByValue(dr("CategoryID")).Selected = True
                        End If
                    End While
                    dr.Close()
                Else
                    cmdDelete.Visible = False
                    pnlAudit.Visible = False
                End If

                ' Store URL Referrer to return to portal
                ViewState("UrlReferrer") = "~/EditModule.aspx?tabid=" & TabId & "&tabindex=" & TabIndex & "&mid=" & ModuleId

            End If

        End Sub

        Private Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click

            Dim intPortalId As Integer
            Dim strDirectory As String

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            ' Only Update if the Entered Data is Valid
            If Page.IsValid = True Then

                ' Create an instance of the Store DB component
                Dim objStore As New StoreDB()

                ' if superuser then we are managing the global Products 
                If Context.User.Identity.Name = _portalSettings.SuperUserId Then
                    intPortalId = -1
                Else
                    intPortalId = PortalId
                End If

                If Context.User.Identity.Name = _portalSettings.SuperUserId Then
                    strDirectory = Request.MapPath("~" & System.Configuration.ConfigurationSettings.AppSettings("siteUploadDirectory"))
                Else
                    strDirectory = Request.MapPath(_portalSettings.UploadDirectory)
                End If

                ' check if thumbnail exists and if not create
                If Not File.Exists(strDirectory & "thumb_" & cboImage.SelectedItem.Text) Then
                    Dim imgImage As System.Drawing.Image
                    imgImage = imgImage.FromFile(strDirectory & cboImage.SelectedItem.Text)

                    Dim intHeight As Integer
                    Dim intWidth As Integer
                    Dim dblAspectRatio As Double

                    intHeight = 150
                    dblAspectRatio = imgImage.Width / imgImage.Height
                    intWidth = Int(intHeight * dblAspectRatio)

                    Dim imgThumbNail As Bitmap

                    imgThumbNail = New Bitmap(imgImage, intWidth, intHeight)
                    imgImage.Dispose()

                    imgThumbNail.Save(strDirectory & "thumb_" & cboImage.SelectedItem.Text, System.Drawing.Imaging.ImageFormat.Jpeg)
                    imgThumbNail.Dispose()
                End If

                If ProductId = -1 Then
                    objStore.AddProduct(txtProductNumber.Text, txtProductName.Text, Double.Parse(txtUnitCost.Text), chkFeatured.Checked, txtDescription.Text, cboImage.SelectedItem.Value, Context.User.Identity.Name, intPortalId)
                Else
                    objStore.UpdateProduct(ProductId, txtProductNumber.Text, txtProductName.Text, Double.Parse(txtUnitCost.Text), chkFeatured.Checked, txtDescription.Text, cboImage.SelectedItem.Value, Context.User.Identity.Name)
                End If

                objStore.UpdateProductCategory(ProductId)
                Dim item As ListItem
                For Each item In chkCategories.Items
                    If item.Selected Then
                        objStore.UpdateProductCategory(ProductId, Int32.Parse(item.Value))
                    End If
                Next

                ' Redirect back to the portal home page
                Response.Redirect(CType(ViewState("UrlReferrer"), String))

            End If

        End Sub

        Private Sub cmdDelete_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdDelete.Click

            If ProductId <> -1 Then
                Dim objStore As New StoreDB()
                objStore.DeleteProduct(ProductId)
            End If

            ' Redirect back to the portal home page
            Response.Redirect(CType(ViewState("UrlReferrer"), String))

        End Sub

        Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click

            ' Redirect back to the portal home page
            Response.Redirect(CType(ViewState("UrlReferrer"), String))

        End Sub

    End Class

End Namespace