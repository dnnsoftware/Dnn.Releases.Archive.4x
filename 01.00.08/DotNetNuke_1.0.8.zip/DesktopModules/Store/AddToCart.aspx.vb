Namespace ASPNetPortal
	Public Class AddToCart
		Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

		'This call is required by the Web Form Designer.
		<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

		End Sub

		Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
			'CODEGEN: This method call is required by the Web Form Designer
			'Do not modify it using the code editor.
			InitializeComponent()
		End Sub

#End Region

		Private tabIndex As Integer = 0
        Private tabId As Integer = 0
        Private moduleId As Integer = 0
        Private StoreType As String

		'*******************************************************
		'
		' The Page_Load event on this page is used to add the
		' identified product to the user's shopping cart, and then immediately
		' redirect to the shoppingcart page (this avoids problems were a user hits 
		' "refresh" and accidentally adds another product to the cart)  
		'    
		' The product to add to the cart is specified using
		' a querystring argument to the page.
		'
		'*******************************************************

		Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

			Dim context As HttpContext = HttpContext.Current

			If Not (Request.Params("tabid") Is Nothing) Then
				tabId = Int32.Parse(Request.Params("tabid"))
			End If

			If Not (Request.Params("tabindex") Is Nothing) Then
				tabIndex = Int32.Parse(Request.Params("tabindex"))
			End If

            If Not (Request.Params("mid") Is Nothing) Then
                moduleId = Int32.Parse(Request.Params("mid"))
            End If

            StoreType = Request.Params("storetype")

            If Not Request.Params("ProductID") Is Nothing Then

                Dim objStore As New StoreDB()

                ' Obtain current user's shopping cart ID  
                Dim strCartId As String = objStore.GetShoppingCartId()

                ' Add Product Item to Cart
                objStore.AddItem(strCartId, CInt(Request.Params("ProductID")), 1)

            End If

            Response.Redirect("~/EditModule.aspx?tabid=" & tabId & "&tabindex=" & tabIndex & "&mid=" & moduleId & "&storetype=" & StoreType & "&def=Shopping Cart")

		End Sub

	End Class
End Namespace
