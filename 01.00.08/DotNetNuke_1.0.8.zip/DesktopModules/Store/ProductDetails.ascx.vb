Namespace ASPNetPortal

	Public Class ProductDetailsPage
        Inherits ASPNetPortal.PortalModuleControl

        Protected WithEvents Title1 As DesktopModuleTitle
        Protected WithEvents ProductImage As System.Web.UI.WebControls.Image
        Protected WithEvents Description As System.Web.UI.WebControls.Label
        Protected WithEvents ProductNumber As System.Web.UI.WebControls.Label
        Protected WithEvents UnitCost As System.Web.UI.WebControls.Label
        Protected WithEvents cmdAddToCart As System.Web.UI.WebControls.HyperLink

        Private ItemId As Integer = -1
        Private ProductID As Integer = 0
        Private StoreType As String

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        '*******************************************************
        '
        ' The Page_Load server event handler on this page is used
        ' to populate the role information for the page
        '
        '*******************************************************

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            StoreType = Request.Params("storetype")

            ' If this is the first visit to the page, bind the role data to the datalist
            If Page.IsPostBack = False Then
                ' Obtain PortalSettings from Current Context
                Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

                Dim StoreType As String = Request.Params("storetype")

                If Not (Request.Params("ProductID") Is Nothing) Then
                    ProductID = Int32.Parse(Request.Params("ProductID"))

                    ' Obtain Product Details
                    Dim objStore As New StoreDB()

                    Dim dr As SqlDataReader = objStore.GetSingleProduct(ProductID)

                    If dr.Read Then
                        ProductNumber.Text = dr("ProductNumber").ToString
                        Title1.DisplayTitle = dr("ProductName").ToString
                        Description.Text = dr("Description").ToString
                        Select Case StoreType
                            Case "G" ' global
                                ProductImage.ImageUrl = "~" & System.Configuration.ConfigurationSettings.AppSettings("siteUploadDirectory") & dr("ImageFile").ToString
                            Case "L" ' local
                                ProductImage.ImageUrl = _portalSettings.UploadDirectory & dr("ImageFile").ToString
                        End Select
                        ProductImage.AlternateText = dr("ProductName").ToString
                        UnitCost.Text = String.Format("{0:c}", dr("UnitCost"))
                    End If

                    cmdAddToCart.NavigateUrl = "~/DesktopModules/Store/AddToCart.aspx?tabid=" & TabId & "&tabindex=" & TabIndex & "&mid=" & ModuleId & "&ProductID=" & ProductID & "&storetype=" & StoreType

                    If Request.IsAuthenticated Then
                        cmdAddToCart.Visible = True
                    Else
                        cmdAddToCart.Visible = False
                    End If

                Else
                    Response.Redirect(Request.UrlReferrer.ToString())
                End If

                ' Store URL Referrer to return to portal
                ViewState("UrlReferrer") = Request.UrlReferrer.ToString()
            End If

        End Sub

    End Class

End Namespace