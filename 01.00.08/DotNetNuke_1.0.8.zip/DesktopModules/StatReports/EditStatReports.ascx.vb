Namespace ASPNetPortal

    Public Class EditStatReports
        Inherits ASPNetPortal.PortalModuleControl

        Protected WithEvents moduleTitle2 As System.Web.UI.HtmlControls.HtmlGenericControl

        Protected WithEvents cboSport As System.Web.UI.WebControls.DropDownList
        Protected WithEvents cboStatDefinition As System.Web.UI.WebControls.DropDownList
        Protected WithEvents optType As System.Web.UI.WebControls.RadioButtonList
        Protected WithEvents txtTitle As System.Web.UI.WebControls.TextBox
        Protected WithEvents valTitle As System.Web.UI.WebControls.RequiredFieldValidator
        Protected WithEvents cboStatReportGroup As System.Web.UI.WebControls.DropDownList
        Protected WithEvents txtDescription As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtViewOrder As System.Web.UI.WebControls.TextBox
        Protected WithEvents valViewOrder As System.Web.UI.WebControls.CompareValidator
        Protected WithEvents chkVisible As System.Web.UI.WebControls.CheckBox
        Protected WithEvents txtTopN As System.Web.UI.WebControls.TextBox
        Protected WithEvents valTopN As System.Web.UI.WebControls.CompareValidator
        Protected WithEvents chkRowNumbers As System.Web.UI.WebControls.CheckBox
        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdDelete As System.Web.UI.WebControls.LinkButton
        Protected WithEvents pnlAudit As System.Web.UI.WebControls.Panel
        Protected WithEvents lblCreatedBy As System.Web.UI.WebControls.Label
        Protected WithEvents lblCreatedDate As System.Web.UI.WebControls.Label

        Protected WithEvents rowStatFields As System.Web.UI.WebControls.Panel
        Protected WithEvents cmdAddFields As System.Web.UI.WebControls.ImageButton
        Protected WithEvents cmdFieldUp As System.Web.UI.WebControls.ImageButton
        Protected WithEvents cmdFieldDown As System.Web.UI.WebControls.ImageButton
        Protected WithEvents cmdRemoveField As System.Web.UI.WebControls.ImageButton
        Protected WithEvents cmdAddSort As System.Web.UI.WebControls.ImageButton
        Protected WithEvents cmdSortUp As System.Web.UI.WebControls.ImageButton
        Protected WithEvents cmdRemoveSort As System.Web.UI.WebControls.ImageButton
        Protected WithEvents cmdSortDown As System.Web.UI.WebControls.ImageButton
        Protected WithEvents cmdSortAscending As System.Web.UI.WebControls.ImageButton
        Protected WithEvents cmdSortDescending As System.Web.UI.WebControls.ImageButton
        Protected WithEvents lstSchema As System.Web.UI.WebControls.ListBox
        Protected WithEvents lstFields As System.Web.UI.WebControls.ListBox
        Protected WithEvents lstSort As System.Web.UI.WebControls.ListBox
        Protected WithEvents cmdAddCustomField As System.Web.UI.WebControls.LinkButton
        Protected WithEvents grdFields As System.Web.UI.WebControls.DataGrid
        Protected WithEvents lblError As System.Web.UI.WebControls.Label
        Protected WithEvents hypViewReport As System.Web.UI.WebControls.HyperLink

        Protected WithEvents grdStatReportGroups As System.Web.UI.WebControls.DataGrid
        Protected WithEvents cmdAddStatReportGroup As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdReturn As System.Web.UI.WebControls.LinkButton

        Public StatReportId As Integer = -1
        Private StatReportGroupId As Integer = 0

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            ' Determine Report to Update
            If Not (Request.Params("StatReportId") Is Nothing) Then
                StatReportId = Int32.Parse(Request.Params("StatReportId"))
            End If

            If Not (Request.Params("StatReportGroupId") Is Nothing) Then
                StatReportGroupId = Int32.Parse(Request.Params("StatReportGroupId"))
            End If

            If Page.IsPostBack = False Then

                cmdDelete.Attributes.Add("onClick", "javascript:return confirm('Are You Sure You Wish To Delete This Item ?');")

                Dim objStatReports As New StatReportsDB()
                Dim objSports As New SportsDB()

                ' bind stat definitions to dropdownlist
                cboSport.DataSource = objSports.GetPortalsSports(PortalId)
                cboSport.DataBind()

                ' bind stat definitions to dropdownlist
                cboStatDefinition.DataSource = objStatReports.GetStatDefinitions()
                cboStatDefinition.DataBind()

                If StatReportId <> -1 Then

                    BindData()

                    Dim dr As SqlDataReader = objStatReports.GetSingleStatReport(StatReportId, ModuleId)

                    If dr.Read() Then
                        cboSport.Items.FindByValue(CType(dr("PortalSportId"), String)).Selected = True
                        cboStatDefinition.Items.FindByValue(CType(dr("StatDefId"), String)).Selected = True
                        optType.Items.FindByValue(CType(dr("ReportType"), String)).Selected = True
                        txtTitle.Text = CStr(dr("Title"))
                        If Not IsDBNull(dr("StatReportGroupId")) Then
                            cboStatReportGroup.Items.FindByValue(CType(dr("StatReportGroupId"), String)).Selected = True
                        End If
                        txtDescription.Text = CStr(dr("Description"))
                        txtViewOrder.Text = dr("ViewOrder").ToString()
                        chkVisible.Checked = dr("Visible")
                        If Not IsDBNull(dr("TopN")) Then
                            txtTopN.Text = dr("TopN").ToString()
                        Else
                            txtTopN.Text = ""
                        End If
                        chkRowNumbers.Checked = dr("RowNumbers")
                        lblCreatedBy.Text = dr("CreatedByUser").ToString
                        lblCreatedDate.Text = CType(dr("CreatedDate"), DateTime).ToShortDateString()

                        ' Close datareader
                        dr.Close()
                    Else ' security violation attempt to access item not related to this Module
                        Response.Redirect("~/desktopdefault.aspx?tabid=" & TabId & "&tabindex=" & TabIndex)
                    End If

                    hypViewReport.NavigateUrl = "~/EditModule.aspx?tabId=" & TabId & "&tabIndex=" & TabIndex & "&mid=" & ModuleId & "&StatReportId=" & StatReportId & "&def=Stat Report"

                    cboSport.Enabled = False
                    cboStatDefinition.Enabled = False
                    rowStatFields.Visible = True
                Else
                    chkVisible.Checked = True
                    optType.Items(0).Selected = True
                    cmdUpdate.Text = "Save"
                    cmdDelete.Visible = False
                    pnlAudit.Visible = False

                    BindData()
                End If

                ' Store URL Referrer to return to portal
                ViewState("UrlReferrer") = Request.UrlReferrer.ToString()

            End If

        End Sub

        Private Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click

            Dim intViewOrder As Integer
            Dim intTopN As Integer

            If Page.IsValid = True Then

                ' Create an instance of the Link DB component
                Dim objStatReports As New StatReportsDB()

                If txtViewOrder.Text = "" Then
                    intViewOrder = 0
                Else
                    intViewOrder = Integer.Parse(txtViewOrder.Text)
                End If

                If txtTopN.Text = "" Then
                    intTopN = 0
                Else
                    intTopN = Integer.Parse(txtTopN.Text)
                End If

                If StatReportId = -1 Then

                    ' Add the link within the objStatReports table
                    objStatReports.AddStatReport(moduleId, Integer.Parse(cboSport.SelectedItem.Value), Integer.Parse(cboStatDefinition.SelectedItem.Value), optType.SelectedItem.Value, txtTitle.Text, Integer.Parse(cboStatReportGroup.SelectedItem.Value), txtDescription.Text, intViewOrder, chkVisible.Checked, intTopN, chkRowNumbers.Checked, Context.User.Identity.Name, StatReportId)

                Else

                    ' Update the link within the objStatReports table
                    objStatReports.UpdateStatReport(StatReportId, moduleId, Integer.Parse(cboSport.SelectedItem.Value), Integer.Parse(cboStatDefinition.SelectedItem.Value), optType.SelectedItem.Value, txtTitle.Text, Integer.Parse(cboStatReportGroup.SelectedItem.Value), txtDescription.Text, intViewOrder, chkVisible.Checked, intTopN, chkRowNumbers.Checked, Context.User.Identity.Name)

                End If

                ' Redirect back to the portal home page
                Response.Redirect(CStr(ViewState("UrlReferrer")))

            End If

        End Sub

        Private Sub cmdDelete_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdDelete.Click

            ' Only attempt to delete the item if it is an existing item
            ' (new items will have "ItemId" of 0)
            If StatReportId <> 0 Then

                Dim objStatReports As New StatReportsDB()
                objStatReports.DeleteStatReport(StatReportId)

            End If

            ' Redirect back to the portal home page
            Response.Redirect(CStr(ViewState("UrlReferrer")))

        End Sub

        Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click, cmdReturn.Click

            ' Redirect back to the portal home page
            Response.Redirect(CStr(ViewState("UrlReferrer")))

        End Sub

        Public Sub grdFields_CancelEdit(ByVal sender As Object, ByVal e As DataGridCommandEventArgs)
            grdFields.EditItemIndex = -1
            BindData()
        End Sub

        Public Sub grdFields_Edit(ByVal sender As Object, ByVal e As DataGridCommandEventArgs)
            grdFields.EditItemIndex = e.Item.ItemIndex
            grdFields.SelectedIndex = -1
            BindData()
        End Sub

        Public Sub grdFields_Update(ByVal sender As Object, ByVal e As DataGridCommandEventArgs)
            Dim objStatReports As New StatReportsDB()
            Dim objMathParser As New MathParser()

            Dim intStatFieldId As Integer = Integer.Parse(grdFields.DataKeys(e.Item.ItemIndex).ToString())
            Dim chkVisible As CheckBox = e.Item.Cells(1).Controls(1)
            Dim txtTitle As TextBox = e.Item.Cells(3).Controls(3)
            Dim txtCriteria As TextBox = e.Item.Cells(5).Controls(1)
            Dim txtFormula As TextBox = e.Item.Cells(6).Controls(1)
            Dim chkTotal As CheckBox = e.Item.Cells(7).Controls(1)
            Dim chkSummarize As CheckBox = e.Item.Cells(8).Controls(1)
            Dim chkBreak As CheckBox = e.Item.Cells(9).Controls(1)
            Dim cboHyperlink As DropDownList = e.Item.Cells(10).Controls(1)
            Dim Hyperlink As Integer = -1
            Dim FormulaTable As New ArrayList()
            Dim VariableNames As New ArrayList()
            Dim ParseError As String
            Dim intVariable As Integer

            If cboHyperlink.SelectedIndex <> -1 Then
                Hyperlink = Int32.Parse(cboHyperlink.SelectedItem.Value)
            End If

            If txtFormula.Text <> "" Then
                objMathParser.ParseFormula(txtFormula.Text, FormulaTable, VariableNames, ParseError)
                If ParseError = "" Then
                    For intVariable = 0 To VariableNames.Count - 1
                        Dim lstItem As New ListItem(VariableNames(intVariable))
                        If Not lstSchema.Items.Contains(lstItem) Then
                            ParseError = ParseError & IIf(ParseError = "", "", ", ") & VariableNames(intVariable)
                        End If
                    Next intVariable
                    If ParseError <> "" Then
                        ParseError = "An Error Was Encountered With The Formula Specified - The Following FieldName(s) Are Not Valid: " & ParseError
                    End If
                End If
            End If

            If ParseError = "" Then
                objStatReports.UpdateStatField(intStatFieldId, _
                    txtTitle.Text, _
                    txtCriteria.Text, _
                    Hyperlink, _
                    chkVisible.Checked, _
                    chkTotal.Checked, _
                    chkSummarize.Checked, _
                    chkBreak.Checked, _
                    txtFormula.Text)

                grdFields.EditItemIndex = -1
                BindData()
            Else
                lblError.Text = ParseError
            End If

        End Sub

        Private Sub BindData(Optional ByVal blnInsertStatReportGroup As Boolean = False)
            Dim objStatReports As New StatReportsDB()

            grdFields.DataSource = objStatReports.GetStatFields(StatReportId)
            grdFields.DataBind()

            lstSchema.DataSource = objStatReports.GetSchemaFields(StatReportId)
            lstSchema.DataBind()
            lstFields.DataSource = objStatReports.GetStatFields(StatReportId)
            lstFields.DataBind()

            lstSort.Items.Clear()
            Dim dr As SqlDataReader = objStatReports.GetSortFields(StatReportId)
            While dr.Read()
                lstSort.Items.Add(dr("FieldTitle") & " - " & IIf(dr("SortOrder") = "A", "Ascending", "Descending"))
                lstSort.Items(lstSort.Items.Count - 1).Value = dr("StatFieldId")
            End While

            Dim ds As DataSet
            ds = objStatReports.GetStatReportGroups(moduleId)

            ' inserting a new group
            If blnInsertStatReportGroup Then
                Dim row As DataRow
                row = ds.Tables(0).NewRow()
                row("StatReportGroupId") = "-1"
                row("StatReportGroupName") = ""
                ds.Tables(0).Rows.InsertAt(row, 0)
                grdStatReportGroups.EditItemIndex = 0
            End If

            ' bind stat report groups to dropdownlist
            cboStatReportGroup.DataSource = objStatReports.GetStatReportGroups(moduleId)
            cboStatReportGroup.DataBind()
            cboStatReportGroup.Items.Insert(0, "None Specified")
            cboStatReportGroup.Items.FindByText("None Specified").Value = "-1"

            grdStatReportGroups.DataSource = ds
            grdStatReportGroups.DataBind()

            lblError.Text = ""
        End Sub

        Private Sub cmdAddFields_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles cmdAddFields.Click
            Dim objStatReports As New StatReportsDB()
            Dim intCounter As Integer

            For intCounter = 0 To lstSchema.Items.Count - 1
                If lstSchema.Items(intCounter).Selected Then
                    objStatReports.AddStatField(StatReportId, lstSchema.Items(intCounter).Value)
                End If
            Next intCounter

            BindData()
        End Sub

        Private Sub cmdRemoveField_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles cmdRemoveField.Click
            Dim objStatReports As New StatReportsDB()
            Dim intCounter As Integer

            For intCounter = 0 To lstFields.Items.Count - 1
                If lstFields.Items(intCounter).Selected Then
                    objStatReports.DeleteStatField(lstFields.Items(intCounter).Value)
                End If
            Next intCounter

            BindData()
        End Sub

        Private Sub cmdFieldUp_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles cmdFieldUp.Click
            Dim objStatReports As New StatReportsDB()
            Dim intCounter As Integer

            For intCounter = 1 To lstFields.Items.Count - 1
                If lstFields.Items(intCounter).Selected Then
                    objStatReports.UpdateStatFieldOrder(lstFields.Items(intCounter).Value, -1)
                End If
            Next intCounter

            BindData()
        End Sub

        Private Sub cmdFieldDown_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles cmdFieldDown.Click
            Dim objStatReports As New StatReportsDB()
            Dim intCounter As Integer

            For intCounter = 0 To lstFields.Items.Count - 2
                If lstFields.Items(intCounter).Selected Then
                    objStatReports.UpdateStatFieldOrder(lstFields.Items(intCounter).Value, 1)
                End If
            Next intCounter

            BindData()
        End Sub

        Private Sub cmdAddCustomField_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdAddCustomField.Click
            Dim objStatReports As New StatReportsDB()

            objStatReports.AddStatField(StatReportId, "Custom")

            BindData()
        End Sub

        Private Sub cmdAddSort_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles cmdAddSort.Click
            Dim objStatReports As New StatReportsDB()
            Dim intCounter As Integer

            For intCounter = 0 To lstFields.Items.Count - 1
                If lstFields.Items(intCounter).Selected Then
                    objStatReports.AddSortField(lstFields.Items(intCounter).Value)
                End If
            Next intCounter

            BindData()
        End Sub

        Private Sub cmdRemoveSort_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles cmdRemoveSort.Click
            Dim objStatReports As New StatReportsDB()

            objStatReports.DeleteSortField(lstSort.SelectedItem.Value)

            BindData()
        End Sub

        Private Sub cmdSortUp_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles cmdSortUp.Click
            Dim objStatReports As New StatReportsDB()

            objStatReports.UpdateSortField(lstSort.SelectedItem.Value, -1)

            BindData()
        End Sub

        Private Sub cmdSortDown_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles cmdSortDown.Click
            Dim objStatReports As New StatReportsDB()

            objStatReports.UpdateSortField(lstSort.SelectedItem.Value, 1)

            BindData()
        End Sub

        Private Sub cmdSortAscending_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles cmdSortAscending.Click
            Dim objStatReports As New StatReportsDB()

            objStatReports.UpdateSortField(lstSort.SelectedItem.Value, , "A")

            BindData()
        End Sub

        Private Sub cmdSortDescending_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles cmdSortDescending.Click
            Dim objStatReports As New StatReportsDB()

            objStatReports.UpdateSortField(lstSort.SelectedItem.Value, , "D")

            BindData()
        End Sub

        Public Function HandleDBNull(ByVal obj As Object) As String
            If IsDBNull(obj) Then
                Return ""
            Else
                Return CStr(obj)
            End If
        End Function

        Class StatReport
            Private _Id As String
            Private _Name As String

            Public Sub New(ByVal Id As String, ByVal Name As String)
                _Id = Id
                _Name = Name
            End Sub

            Public ReadOnly Property Id() As String
                Get
                    Return _Id
                End Get
            End Property

            Public ReadOnly Property Name() As String
                Get
                    Return _Name
                End Get
            End Property

        End Class

        Public Function Hyperlinks(ByVal FieldName As String) As ICollection
            Dim objStatReports As New StatReportsDB()
            Dim arrHyperlinks As New ArrayList()

            arrHyperlinks.Add(New StatReport("-1", ""))

            Dim dr As SqlDataReader = objStatReports.GetStatFieldHyperlinks(moduleId, StatReportId, FieldName)
            While dr.Read()
                arrHyperlinks.Add(New StatReport(dr("StatReportId"), dr("Title")))
            End While
            dr.Close()

            Return arrHyperlinks

        End Function

        Public Function SelectHyperlink(ByVal obj As Object, ByVal FieldName As String) As String
            Dim intCounter As Integer
            Dim clsHyperlink As StatReport

            If IsDBNull(obj) Then
                Return "0"
            Else
                intCounter = -1
                For Each clsHyperlink In Hyperlinks(FieldName)
                    intCounter += 1
                    If clsHyperlink.Id = obj Then
                        Return CStr(intCounter)
                    End If
                Next
            End If
        End Function

        Public Sub grdStatReportGroups_CancelEdit(ByVal sender As Object, ByVal e As DataGridCommandEventArgs)
            grdStatReportGroups.EditItemIndex = -1
            BindData()
        End Sub

        Public Sub grdStatReportGroups_Edit(ByVal sender As Object, ByVal e As DataGridCommandEventArgs)
            grdStatReportGroups.EditItemIndex = e.Item.ItemIndex
            grdStatReportGroups.SelectedIndex = -1
            BindData()
        End Sub

        Public Sub grdStatReportGroups_Update(ByVal sender As Object, ByVal e As DataGridCommandEventArgs)
            Dim objStatReports As New StatReportsDB()

            Dim txtStatReportGroupName As TextBox = e.Item.Cells(1).Controls(1)

            If Integer.Parse(grdStatReportGroups.DataKeys(e.Item.ItemIndex).ToString()) = -1 Then
                objStatReports.AddStatReportGroup(txtStatReportGroupName.Text, moduleId)
            Else
                objStatReports.UpdateStatReportGroup(Integer.Parse(grdStatReportGroups.DataKeys(e.Item.ItemIndex).ToString()), txtStatReportGroupName.Text)
            End If

            grdStatReportGroups.EditItemIndex = -1
            BindData()
        End Sub

        Public Sub grdStatReportGroups_Delete(ByVal sender As Object, ByVal e As DataGridCommandEventArgs)
            Dim objStatReports As New StatReportsDB()

            objStatReports.DeleteStatReportGroup(Integer.Parse(grdStatReportGroups.DataKeys(e.Item.ItemIndex).ToString()))

            grdStatReportGroups.EditItemIndex = -1
            BindData()
        End Sub

        Private Sub cmdAddStatReportGroup_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdAddStatReportGroup.Click
            grdStatReportGroups.EditItemIndex = 0
            BindData(True)
        End Sub

        Private Sub grdStatReportGroups_ItemCreated(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles grdStatReportGroups.ItemCreated

            Dim cmdDeleteStatReportGroup As Control = e.Item.FindControl("cmdDeleteStatReportGroup")

            If Not cmdDeleteStatReportGroup Is Nothing Then
                CType(cmdDeleteStatReportGroup, ImageButton).Attributes.Add("onClick", "javascript: return confirm('Are You Sure You Wish To Delete This Item ?')")
            End If

        End Sub

    End Class

End Namespace