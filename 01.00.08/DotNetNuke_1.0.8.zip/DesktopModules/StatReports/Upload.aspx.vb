Imports System.Xml
Imports System.IO

Namespace ASPNetPortal

    Public Class Upload
        Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Dim objSecurity As New PortalSecurity()
            Dim objUser As New UsersDB()
            Dim intPortalId As Integer = -1
            Dim intUserId As Integer = -1

            ' portal must exist
            intPortalId = PortalSettings.GetPortalByAlias(Request.Params("Address"))
            If intPortalId <> -1 Then
                ' user must exist
                intUserId = objSecurity.UserLogin(Request.Params("Email"), Request.Params("Password"), intPortalId)
                If intUserId >= 0 Then
                    Dim _portalSettings As PortalSettings = New PortalSettings(0, 0, Request.Params("Address"), Request.ApplicationPath)
                    ' user must be a portal objAdministrator
                    If objUser.IsUserInRole(intUserId, _portalSettings.AdministratorRoleId, intPortalId) Then
                        ProcessFileXML(intPortalId, Request.InputStream)
                    End If
                End If
            End If

        End Sub

        Private Sub ProcessFileXML(ByVal intPortalId As Integer, ByVal FileXML As Stream)

            Dim arrBinary() As Byte

            ' load XML document
            Dim objReader = New StreamReader(FileXML)
            objReader.BaseStream.Seek(0, SeekOrigin.Begin)
            Dim xmlDocument = New xmlDocument()
            xmlDocument.LoadXml(objReader.ReadToEnd())
            objReader.Close()

            ' convert Base64 encoded XML to byte array 
            arrBinary = Convert.FromBase64String(xmlDocument.selectSingleNode("File/Contents").InnerText)

            ' create file
            Dim objStream As New FileStream(Request.MapPath("") & "/" & intPortalId.ToString() & "/" & xmlDocument.SelectSingleNode("File/Name").InnerText, FileMode.CreateNew, FileAccess.Write)

            ' write byte array to file
            objStream.Write(arrBinary, 0, arrBinary.Length - 1)
            objStream.Close()

        End Sub

    End Class

End Namespace
