Namespace ASPNetPortal

    Public MustInherit Class StatReports
        Inherits ASPNetPortal.PortalModuleControl

        Protected WithEvents lstReports As System.Web.UI.WebControls.DataList

        Protected linkImage As String = ""

        Public LastStatReportGroupName As String = ""

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        '*******************************************************
        '
        ' The Page_Load event handler on this User Control is used to
        ' obtain a DataReader of link information from the Links
        ' table, and then databind the results to a templated DataList
        ' server control.  It uses the ASPNetPortal.LinkDB()
        ' data component to encapsulate all data functionality.
        '
        '*******************************************************

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            ' Set the link image type
            If IsEditable Then
                linkImage = "~/images/edit.gif"
            End If

            ' Obtain links information from the Links table
            ' and bind to the datalist control
            Dim objStatReports As New StatReportsDB()

            If PortalSecurity.IsInRoles(_portalSettings.AdministratorRoleId.ToString) Then
                lstReports.DataSource = objStatReports.GetStatReports(ModuleId, True)
            Else
                lstReports.DataSource = objStatReports.GetStatReports(ModuleId)
            End If
            lstReports.DataBind()

        End Sub

        Private Sub lstReports_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataListItemEventArgs) Handles lstReports.ItemDataBound
            Dim lblStatReportGroupName As Label = e.Item.Controls(1)
            If lstReports.DataKeys(e.Item.ItemIndex).ToString <> LastStatReportGroupName Then
                lblStatReportGroupName.Text = lstReports.DataKeys(e.Item.ItemIndex) & "<br><br>&nbsp;&nbsp;&nbsp;"
                LastStatReportGroupName = lstReports.DataKeys(e.Item.ItemIndex)
            Else
                lblStatReportGroupName.Text = "&nbsp;&nbsp;&nbsp;"
            End If
        End Sub

        Public Function EditURL(ByVal strKeyName As String, ByVal strKeyValue As String) As String
            EditURL = "~/EditModule.aspx?tabid=" & TabId & "&tabindex=" & TabIndex & "&mid=" & ModuleId & "&" & strKeyName & "=" & strKeyValue
        End Function

        Public Function ReportURL(ByVal strKeyName As String, ByVal strKeyValue As String) As String
            ReportURL = "~/EditModule.aspx?tabid=" & TabId & "&tabindex=" & TabIndex & "&mid=" & ModuleId & "&" & strKeyName & "=" & strKeyValue & "&def=Stat Report"
        End Function

    End Class

End Namespace
