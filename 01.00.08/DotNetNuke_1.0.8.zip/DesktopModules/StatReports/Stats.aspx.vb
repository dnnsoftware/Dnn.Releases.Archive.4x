Imports System.Xml
Imports System.IO

Namespace ASPNetPortal

    Public Class PublishStats
        Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Dim objSecurity As New PortalSecurity()
            Dim objUser As New UsersDB()
            Dim intPortalId As Integer = -1
            Dim intUserId As Integer = -1

            ' portal must exist
            intPortalId = PortalSettings.GetPortalByAlias(Request.Params("Address"))
            If intPortalId <> -1 Then
                ' user must exist
                intUserId = objSecurity.UserLogin(Request.Params("Email"), Request.Params("Password"), intPortalId)
                If intUserId >= 0 Then
                    Dim _portalSettings As PortalSettings = New PortalSettings(0, 0, Request.Params("Address"), Request.ApplicationPath)
                    ' user must be a portal Administrator
                    If objUser.IsUserInRole(intUserId, _portalSettings.AdministratorRoleId, intPortalId) Then
                        ProcessStatsXML(intPortalId, intUserId, Request.InputStream)
                    End If
                End If
            End If

        End Sub

        Private Sub ProcessStatsXML(ByVal intPortalId As Integer, ByVal intUserId As Integer, ByVal StatsXML As Stream)
            Dim objSports As New SportsDB()

            Dim strElement As String
            Dim strValue As String
            Dim intSportId As Integer = -1
            Dim intPortalSportId As Integer = -1
            Dim intSeasonId As Integer = -1
            Dim intEntityId As Integer
            Dim intDataEntityId As Integer
            Dim strExternalEntityId As String
            Dim arrStaticFields() As String
            Dim arrEntityFields() As String
            Dim intStaticField As Integer
            Dim arrGroupId As New ArrayList()
            Dim intParentId As Integer
            Dim strEntity As String
            Dim arrImage(3) As String
            Dim intCounter As Integer

            ' load data
            Dim xmlReader = New XmlTextReader(StatsXML)
            While xmlReader.Read()
                Select Case xmlReader.NodeType
                    Case XmlNodeType.Element 'start of element
                        strElement = xmlReader.Name
                        Select Case strElement
                            Case "Group", "Participant", "Event"  ' entities
                                If strElement <> strEntity Then
                                    strEntity = strElement
                                    arrStaticFields = Split(objSports.GetSportStaticFields(strEntity, True), ",")
                                    arrEntityFields = Split(objSports.GetSportStaticFields(strEntity, True), ",")
                                End If
                                For intCounter = 0 To arrEntityFields.GetUpperBound(0)
                                    arrEntityFields(intCounter) = ""
                                Next intCounter
                            Case "Image"
                                For intCounter = 0 To arrImage.GetUpperBound(0)
                                    arrImage(intCounter) = ""
                                Next intCounter
                        End Select
                    Case XmlNodeType.Text ' element value
                        strValue = xmlReader.Value
                        If Trim(strValue) <> "" Then
                            Select Case strElement
                                Case "SeasonId", "GroupId", "ParticipantId", "EventId" ' key fields
                                    strExternalEntityId = strValue
                                Case "SportId"
                                    intSportId = Int32.Parse(strValue)
                                    intPortalSportId = objSports.UpdatePortalSport(intPortalId, intSportId)
                                Case "SportName"
                                    intSportId = objSports.GetSportByName(strValue)
                                    intPortalSportId = objSports.UpdatePortalSport(intPortalId, intSportId)
                                Case "SeasonName"
                                    intSeasonId = objSports.UpdateSeason(intPortalSportId, , strExternalEntityId, strValue, intUserId.ToString())
                                Case "GroupName"
                                    If arrGroupId.Count > 0 Then
                                        intParentId = CType(arrGroupId(arrGroupId.Count - 1), Integer)
                                    Else
                                        intParentId = -1
                                    End If
                                    intEntityId = objSports.UpdateGroup(intPortalSportId, , strExternalEntityId, strValue, intParentId, intUserId.ToString())
                                    intDataEntityId = intEntityId
                                    arrGroupId.Add(intEntityId)
                                Case "ParticipantName"
                                    If arrGroupId.Count > 0 Then
                                        intParentId = CType(arrGroupId(arrGroupId.Count - 1), Integer)
                                    Else
                                        intParentId = -1
                                    End If
                                    Dim dr As SqlDataReader = objSports.UpdateParticipant(intPortalSportId, , strExternalEntityId, strValue, intParentId, intSeasonId, intUserId.ToString())
                                    If dr.Read() Then
                                        intEntityId = dr("ParticipantId")
                                        intDataEntityId = dr("ParticipantGroupId")
                                    End If
                                    dr.Close()
                                Case "EventName"
                                    intEntityId = objSports.UpdateEvent(intPortalSportId, , strExternalEntityId, strValue, intUserId.ToString())
                                    intDataEntityId = intEntityId
                                Case "ImagePath" ' image
                                    arrImage(0) = strValue
                                Case "ImageWidth" ' image
                                    arrImage(1) = strValue
                                Case "ImageHeight" ' image
                                    arrImage(2) = strValue
                                Case Else
                                    intStaticField = Array.IndexOf(arrStaticFields, strElement)
                                    If intStaticField <> -1 Then
                                        arrEntityFields(intStaticField) = strValue
                                    Else ' dynamic stat field
                                        objSports.UpdateData(intSportId, intSeasonId, strEntity, intDataEntityId, strElement, strValue)
                                    End If
                            End Select
                        End If
                    Case XmlNodeType.EndElement ' end of element
                        Select Case xmlReader.Name
                            Case "Group"
                                arrGroupId.RemoveAt(arrGroupId.Count - 1)
                            Case "Participant"
                                Dim dr As SqlDataReader = objSports.UpdateParticipant(intPortalSportId, intEntityId, , , , , intUserId.ToString(), arrEntityFields(0), arrEntityFields(1), arrEntityFields(2), arrEntityFields(3), arrEntityFields(4), arrEntityFields(5), arrEntityFields(6), arrEntityFields(7), arrEntityFields(8), arrEntityFields(9), arrEntityFields(10), arrEntityFields(11))
                                dr.Close()
                            Case "Event"
                                objSports.UpdateEvent(intPortalSportId, intEntityId, , , intUserId.ToString(), arrEntityFields(0), arrEntityFields(1), arrEntityFields(2), arrEntityFields(3))
                            Case "Image"
                                objSports.UpdateImage(strEntity, intEntityId, arrImage(0), arrImage(1), arrImage(2))
                        End Select
                End Select
            End While

        End Sub

    End Class

End Namespace
