Namespace ASPNetPortal

    Public Class StatReport
        Inherits ASPNetPortal.PortalModuleControl

        Protected WithEvents Title1 As ASPNetPortal.DesktopModuleTitle

        Protected WithEvents colSeason As System.Web.UI.HtmlControls.HtmlTableCell
        Protected WithEvents lblSeason As System.Web.UI.WebControls.Label
        Protected WithEvents cboSeason As System.Web.UI.WebControls.DropDownList
        Protected WithEvents colEvent As System.Web.UI.HtmlControls.HtmlTableCell
        Protected WithEvents lblEvent As System.Web.UI.WebControls.Label
        Protected WithEvents cboEvent As System.Web.UI.WebControls.DropDownList
        Protected WithEvents colGroup As System.Web.UI.HtmlControls.HtmlTableCell
        Protected WithEvents lblGroup As System.Web.UI.WebControls.Label
        Protected WithEvents cboGroup As System.Web.UI.WebControls.DropDownList
        Protected WithEvents colParticipant As System.Web.UI.HtmlControls.HtmlTableCell
        Protected WithEvents lblParticipant As System.Web.UI.WebControls.Label
        Protected WithEvents cboParticipant As System.Web.UI.WebControls.DropDownList

        Protected WithEvents tblDetails As System.Web.UI.HtmlControls.HtmlTable
        Protected WithEvents colImages As System.Web.UI.HtmlControls.HtmlTableCell
        Protected WithEvents colFields As System.Web.UI.HtmlControls.HtmlTableCell
        Protected WithEvents colNotes As System.Web.UI.HtmlControls.HtmlTableCell

        Protected WithEvents grdReport As System.Web.UI.WebControls.DataGrid
        Protected WithEvents cmdReturn As System.Web.UI.WebControls.LinkButton
        Protected WithEvents lblFooter As System.Web.UI.WebControls.Label

        Private StatReportId As Integer = -1
        Private SeasonId As Integer = -1
        Private EventId As Integer = -1
        Private GroupId As Integer = -1
        Private ParticipantId As Integer = -1
        Private intGridRow As Integer = 0
        Private arrTotal As New ArrayList()
        Private arrSummarize As New ArrayList()
        Private arrBreak As New ArrayList()
        Private strBreak As String
        Private strFooter As String
        Private blnTotal As Boolean = False
        Private blnSummarize As Boolean = False
        Private arrFooter As New ArrayList()

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        '*******************************************************
        '
        ' The Page_Load server event handler on this page is used
        ' to populate the role information for the page
        '
        '*******************************************************

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            If Not (Request.Params("StatReportId") Is Nothing) Then
                StatReportId = Int32.Parse(Request.Params("StatReportId"))
            End If

            ' parameters
            If cboSeason.SelectedIndex <> -1 Then
                SeasonId = Int32.Parse(cboSeason.SelectedItem.Value)
            Else
                If Not (Request.Params("SeasonId") Is Nothing) Then
                    SeasonId = Int32.Parse(Request.Params("SeasonId"))
                End If
            End If
            If cboEvent.SelectedIndex <> -1 Then
                EventId = Int32.Parse(cboEvent.SelectedItem.Value)
            Else
                If Not (Request.Params("EventId") Is Nothing) Then
                    EventId = Int32.Parse(Request.Params("EventId"))
                End If
            End If
            If cboGroup.SelectedIndex <> -1 Then
                GroupId = Int32.Parse(cboGroup.SelectedItem.Value)
            Else
                If Not (Request.Params("GroupId") Is Nothing) Then
                    GroupId = Int32.Parse(Request.Params("GroupId"))
                End If
            End If
            If cboParticipant.SelectedIndex <> -1 Then
                ParticipantId = Int32.Parse(cboParticipant.SelectedItem.Value)
            Else
                If Not (Request.Params("ParticipantId") Is Nothing) Then
                    ParticipantId = Int32.Parse(Request.Params("ParticipantId"))
                End If
            End If

            ' If this is the first visit to the page, bind the role data to the datalist
            If Page.IsPostBack = False Then

                ' Store URL Referrer to return to portal
                ViewState("UrlReferrer") = Request.UrlReferrer.ToString()
            End If

            BindData()
        End Sub

        Private Sub cmdReturn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.Click
            Response.Redirect(CType(Viewstate("UrlReferrer"), String))
        End Sub

        Public Sub grdReport_Sort(ByVal sender As Object, ByVal e As DataGridSortCommandEventArgs)
            Dim strSort() As String = Split(e.SortExpression, "|")

            If strSort(0) = ViewState("SortField") Then
                If ViewState("SortOrder") = "ASC" Then
                    ViewState("SortOrder") = "DESC"
                Else
                    ViewState("SortOrder") = "ASC"
                End If
            Else
                ViewState("SortOrder") = strSort(1)
            End If

            ViewState("SortField") = strSort(0)

            BindData()
        End Sub

        Private Sub BindData()
            Dim objStatReports As New StatReportsDB()
            Dim objSports As New SportsDB()
            Dim objMathParser As New MathParser()

            Dim arrSort() As String
            Dim strSort As String = ""
            Dim arrSortFooter() As String
            Dim strSortFooter As String = ""
            Dim intCounter As Integer
            Dim strCriteria As String = ""
            Dim strFilter As String = ""
            Dim strFilterFooter As String = ""
            Dim dsData As DataSet
            Dim dvData As DataView
            Dim arrDetailName As New ArrayList()
            Dim arrDetailTitle As New ArrayList()
            Dim intDetail As Integer
            Dim arrFormula As New ArrayList()
            Dim intRow As Integer
            Dim arrFormulaTable As New ArrayList()
            Dim dblResult As Double
            Dim arrVariableNames As New ArrayList()
            Dim arrVariableValues As New ArrayList()
            Dim intVariable As Integer
            Dim strError As String
            Dim intCustomFieldDecimals As Integer
            Dim blnCustom As Boolean = False
            Dim strBreakFooter As String = ""
            Dim intFooter As Integer
            Dim strImage As String

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            intGridRow = 0

            ' Load the report 
            Dim drReport As SqlDataReader = objStatReports.GetSingleStatReport(StatReportId, ModuleId)
            If drReport.Read() Then
                Title1.DisplayTitle = drReport("Title")
                strFooter = ""

                If SeasonId = -1 Then
                    Dim drSeasons As SqlDataReader = objSports.GetSeasons(drReport("PortalSportId"))
                    If drSeasons.Read() Then
                        SeasonId = drSeasons("SeasonId")
                    End If
                    drSeasons.Close()
                End If

                ' Load the report fields
                Dim drFields As SqlDataReader = objStatReports.GetStatFields(StatReportId)

                ' initialization
                ReDim arrSort(drFields.FieldCount)
                ReDim arrSortFooter(drFields.FieldCount)
                grdReport.Columns.Clear()
                strBreak = ""

                ' summary reports always have season option
                If drReport("ReportType") = "S" Then
                    BuildParameter(colSeason, lblSeason, cboSeason, "Season", objSports.GetSeasons(drReport("PortalSportId")), SeasonId, False)
                End If

                ' add a row number column to the report
                If drReport("RowNumbers") Then
                    Dim colRow As New TemplateColumn()
                    colRow.HeaderText = "##"
                    colRow.ItemStyle.CssClass = "Normal"
                    colRow.HeaderStyle.CssClass = "NormalBold"
                    colRow.ItemStyle.HorizontalAlign = HorizontalAlign.Right
                    colRow.HeaderStyle.HorizontalAlign = HorizontalAlign.Right
                    grdReport.Columns.Add(colRow)
                    arrTotal.Add(-1)
                    arrSummarize.Add(False)
                    arrBreak.Add("")
                    arrFormula.Add("")
                End If

                ' get the crosstab dataset
                Select Case drReport("StatDefName")
                    Case "Group"
                        dsData = objSports.GetGroupsData(drReport("PortalSportId"), IIf(drReport("ReportType") = "S", SeasonId, -1), IIf(drReport("ReportType") = "S" Or GroupId <> -1, GroupId, -2))
                    Case "EventGroup"
                        dsData = objSports.GetEventsGroupsData(drReport("PortalSportId"), IIf(drReport("ReportType") = "S", SeasonId, -1), , EventId, GroupId)
                    Case "Event"
                        dsData = objSports.GetEventsData(drReport("PortalSportId"), IIf(drReport("ReportType") = "S", SeasonId, -1), IIf(drReport("ReportType") = "S" Or EventId <> -1, EventId, -2))
                    Case "EventParticipant"
                        dsData = objSports.GetEventsParticipantsData(drReport("PortalSportId"), IIf(drReport("ReportType") = "S", SeasonId, -1), , EventId, ParticipantId, GroupId)
                    Case "Participant"
                        dsData = objSports.GetParticipantsData(drReport("PortalSportId"), IIf(drReport("ReportType") = "S", SeasonId, -1), IIf(drReport("ReportType") = "S" Or ParticipantId <> -1, ParticipantId, -2), GroupId)
                End Select

                ' create a dataview to process the sort and filter options
                dvData = New DataView(dsData.Tables(0))

                ' process fields
                While drFields.Read()

                    If Not IsDBNull(drFields("FieldId")) Then
                        If (drReport("ReportType") = "S" And Replace(drFields("FieldId"), "Id", "") <> drReport("StatDefName")) Or _
                           (drReport("ReportType") = "D" And Replace(drFields("FieldId"), "Id", "") = drReport("StatDefName")) Then
                            Select Case drFields("FieldId")
                                Case "EventId"
                                    BuildParameter(colEvent, lblEvent, cboEvent, drFields("FieldTitle"), objSports.GetEvents(drReport("PortalSportId"), SeasonId), EventId)
                                Case "GroupId"
                                    BuildParameter(colGroup, lblGroup, cboGroup, drFields("FieldTitle"), objSports.GetGroups(drReport("PortalSportId"), SeasonId), GroupId)
                                Case "ParticipantId"
                                    BuildParameter(colParticipant, lblParticipant, cboParticipant, drFields("FieldTitle"), objSports.GetParticipants(drReport("PortalSportId"), SeasonId, GroupId), ParticipantId)
                            End Select
                        End If
                    End If

                    ' add custom fields to dataview
                    If drFields("FieldName") = "Custom" Then
                        Dim col As New DataColumn("Custom" & drFields("FieldTitle"), System.Type.GetType("System.Decimal"))
                        dvData.Table.Columns.Add(col)
                    End If

                    ' add visible field to report
                    If drFields("Visible") = 1 Then
                        If drReport("ReportType") = "S" Or (drReport("ReportType") = "D" And drFields("ReportType") = "S") Then
                            If Not IsDBNull(drFields("Hyperlink")) Then
                                Dim colId As New BoundColumn()
                                colId.HeaderText = drFields("FieldId")
                                colId.DataField = drFields("FieldId")
                                colId.Visible = False
                                grdReport.Columns.Add(colId)
                                arrTotal.Add(-1)
                                arrSummarize.Add(False)
                                arrBreak.Add("")
                                arrFormula.Add("")

                                Dim colHyperlink As New HyperLinkColumn()
                                colHyperlink.HeaderText = drFields("FieldTitle")
                                colHyperlink.DataNavigateUrlField = drFields("FieldId")
                                colHyperlink.DataNavigateUrlFormatString = "~/EditModule.aspx?tabId=" & TabId & "&tabIndex=" & TabIndex & "&mid=" & ModuleId & "&SeasonId=" & SeasonId & "&" & drFields("FieldId") & "={0}&StatReportId=" & drFields("Hyperlink") & "&def=Stat Report"
                                colHyperlink.DataTextField = drFields("FieldName")
                                colHyperlink.HeaderStyle.CssClass = "NormalBold"
                                colHyperlink.HeaderStyle.HorizontalAlign = IIf(drFields("FieldType") = "Decimal", HorizontalAlign.Right, HorizontalAlign.Left)
                                colHyperlink.ItemStyle.CssClass = "Normal"
                                colHyperlink.ItemStyle.HorizontalAlign = IIf(drFields("FieldType") = "Decimal", HorizontalAlign.Right, HorizontalAlign.Left)
                                colHyperlink.ItemStyle.VerticalAlign = VerticalAlign.Bottom
                                colHyperlink.SortExpression = drFields("FieldName") & "|" & IIf(drFields("FieldType") = "Decimal", "DESC", "ASC")
                                If Not IsDBNull(drFields("FieldMask")) Then
                                    colHyperlink.DataTextFormatString = drFields("FieldMask")
                                End If
                                grdReport.Columns.Add(colHyperlink)
                                arrTotal.Add(-1)
                                If drFields("Summarize") = 1 Then
                                    arrSummarize.Add(True)
                                Else
                                    arrSummarize.Add(False)
                                End If
                                arrBreak.Add("")
                                arrFormula.Add("")
                            Else
                                Dim colField As New BoundColumn()
                                colField.HeaderText = drFields("FieldTitle")
                                If drFields("FieldName") = "Custom" Then
                                    colField.DataField = "Custom" & drFields("FieldTitle")
                                Else
                                    colField.DataField = drFields("FieldName")
                                End If
                                colField.HeaderStyle.CssClass = "NormalBold"
                                colField.HeaderStyle.HorizontalAlign = IIf(drFields("FieldType") = "Decimal", HorizontalAlign.Right, HorizontalAlign.Left)
                                colField.ItemStyle.CssClass = "Normal"
                                colField.ItemStyle.HorizontalAlign = IIf(drFields("FieldType") = "Decimal", HorizontalAlign.Right, HorizontalAlign.Left)
                                colField.ItemStyle.VerticalAlign = VerticalAlign.Bottom
                                colField.FooterStyle.CssClass = "NormalBold"
                                colField.FooterStyle.HorizontalAlign = HorizontalAlign.Right
                                colField.SortExpression = drFields("FieldName") & "|" & IIf(drFields("FieldType") = "Decimal", "DESC", "ASC")
                                If Not IsDBNull(drFields("FieldMask")) Then
                                    colField.DataFormatString = drFields("FieldMask")
                                End If
                                grdReport.Columns.Add(colField)
                                If drFields("Total") = 1 Then
                                    arrTotal.Add(0)
                                    blnTotal = True
                                Else
                                    arrTotal.Add(-1)
                                End If
                                If drFields("Summarize") = 1 Then
                                    arrSummarize.Add(True)
                                    blnSummarize = True
                                Else
                                    arrSummarize.Add(False)
                                End If
                                arrBreak.Add("")
                                If drFields("FieldName") = "Custom" Then
                                    If Not IsDBNull(drFields("Formula")) Then
                                        arrFormula.Add(drFields("Formula"))
                                        blnCustom = True
                                    Else
                                        arrFormula.Add("")
                                    End If
                                Else
                                    arrFormula.Add("")
                                End If
                            End If
                        Else ' detail report - detail section
                            arrDetailName.Add(drFields("FieldName"))
                            arrDetailTitle.Add(drFields("FieldTitle"))
                        End If
                        If drFields("Break") = 1 Then
                            strBreak = strBreak & "," & CStr(grdReport.Columns.Count - 1)
                            strBreakFooter = strBreakFooter & IIf(strBreakFooter = "", "", ", ") & drFields("FieldTitle")
                        End If
                    End If

                    If drFields("FieldType") = "Decimal" Then
                        strFooter = strFooter & IIf(strFooter = "", "( ", ", ") & drFields("FieldTitle") & " = " & IIf(drFields("FieldName") = "Custom", drFields("Formula"), drFields("FieldDescription"))
                    End If

                    If IsDBNull(drFields("SortIndex")) = False And ViewState("SortField") = "" Then
                        If drFields("FieldName") = "Custom" Then
                            arrSort(drFields("SortIndex")) = "Custom" & drFields("FieldTitle") & " " & IIf(drFields("SortOrder") = "A", "ASC", "DESC")
                        Else
                            arrSort(drFields("SortIndex")) = drFields("FieldName") & " " & IIf(drFields("SortOrder") = "A", "ASC", "DESC")
                        End If
                        arrSortFooter(drFields("SortIndex")) = drFields("FieldTitle") & " " & IIf(drFields("SortOrder") = "A", "Ascending", "Descending")
                    End If

                    strCriteria = ""
                    If Not IsDBNull(drFields("Criteria")) Then
                        strCriteria = BuildCriteria(drFields("Criteria"), drFields("FieldType"))
                    End If

                    If strCriteria <> "" Then
                        strFilter = strFilter & IIf(strFilter = "", "", " AND ") & "( "
                        strFilter = strFilter & drFields("FieldName") & " " & strCriteria
                        strFilter = strFilter & " )"

                        strFilterFooter = strFilterFooter & IIf(strFilterFooter = "", "", " AND ") & "( "
                        strFilterFooter = strFilterFooter & drFields("FieldTitle") & " " & strCriteria
                        strFilterFooter = strFilterFooter & " )"
                    End If

                End While

                ' populate the custom columns in the dataview
                If blnCustom Then
                    For intCounter = 0 To grdReport.Columns.Count - 1
                        If arrFormula(intCounter) <> "" Then
                            ' parse the formula
                            arrFormulaTable.Clear()
                            arrVariableNames.Clear()
                            objMathParser.ParseFormula(arrFormula(intCounter), arrFormulaTable, arrVariableNames, strError)
                            If strError = "" Then
                                ' populate the dataview
                                intCustomFieldDecimals = 0
                                For intRow = 0 To dvData.Table.Rows.Count - 1
                                    ' set the variable values
                                    arrVariableValues.Clear()
                                    For intVariable = 0 To arrVariableNames.Count - 1
                                        arrVariableValues.Add(dvData.Table.Rows(intRow).Item(arrVariableNames(intVariable)))
                                    Next intVariable
                                    ' calculate the result
                                    dblResult = objMathParser.CalculateFormulaValue(arrVariableValues, strError, arrFormulaTable)
                                    ' assign the result
                                    If strError = "" Then
                                        dvData.Table.Rows(intRow).Item("Custom" & grdReport.Columns(intCounter).HeaderText) = dblResult
                                    Else
                                        dvData.Table.Rows(intRow).Item("Custom" & grdReport.Columns(intCounter).HeaderText) = 0
                                    End If
                                    If dblResult <> CInt(dblResult) Then
                                        intCustomFieldDecimals = 2
                                    End If
                                Next intRow
                            End If
                            If intCustomFieldDecimals > 0 Then
                                CType(grdReport.Columns(intCounter), BoundColumn).DataFormatString = "{0:0." & New String("0", intCustomFieldDecimals) & "}"
                            End If
                        End If
                    Next intCounter
                End If

                If blnSummarize = True Or strBreak <> "" Then
                    grdReport.AllowSorting = False
                Else
                    grdReport.AllowSorting = True
                End If

                ' create sort statement
                If ViewState("SortField") = "" Then
                    For intCounter = 0 To arrSort.GetUpperBound(0)
                        If arrSort(intCounter) <> "" Then
                            strSort = strSort & IIf(strSort = "", "", ", ") & arrSort(intCounter)
                            strSortFooter = strSortFooter & IIf(strSortFooter = "", "", ", ") & arrSortFooter(intCounter)
                        End If
                    Next intCounter
                Else ' column heading was clicked
                    strSort = ViewState("SortField") & " " & ViewState("SortOrder")
                    strSortFooter = ViewState("SortField") & " " & IIf(ViewState("SortOrder") = "ASC", "Ascending", "Descending")
                End If

                ' filter the dataview
                dvData.RowFilter = strFilter

                ' sort dataview
                dvData.Sort = strSort

                ' reduce the number of rows
                If Not IsDBNull(drReport("TopN")) Then
                    For intCounter = (dvData.Count - 1) To drReport("TopN") Step -1
                        dvData.Delete(drReport("TopN"))
                    Next intCounter
                End If

                ' bind data to grid
                grdReport.DataSource = dvData
                grdReport.DataBind()

                ' detail report
                tblDetails.Visible = False
                If drReport("ReportType") = "D" Then
                    If dsData.Tables(0).Rows.Count > 0 Then
                        ' load images
                        Dim drImages As SqlDataReader
                        Dim drNotes As SqlDataReader
                        Select Case drReport("StatDefParent")
                            Case "Group"
                                drImages = objSports.GetGroupsImages(GroupId)
                                drNotes = objSports.GetGroupsNotes(GroupId)
                            Case "Event"
                                drImages = objSports.GetEventsImages(EventId)
                                drNotes = objSports.GetEventsNotes(EventId)
                            Case "Participant"
                                drImages = objSports.GetParticipantsImages(ParticipantId)
                                drNotes = objSports.GetParticipantsNotes(ParticipantId)
                        End Select
                        colImages.InnerHtml = ""
                        While drImages.Read()
                            strImage = "<img src=""" & _portalSettings.UploadDirectory & drImages("ImagePath") & """"
                            If Not IsDBNull(drImages("ImageWidth")) Then
                                strImage = strImage & " width=""" & CStr(drImages("ImageWidth")) & """"
                            End If
                            If Not IsDBNull(drImages("ImageHeight")) Then
                                strImage = strImage & " height=""" & CStr(drImages("ImageHeight")) & """"
                            End If
                            strImage = strImage & " border=""0"">"
                            colImages.InnerHtml = colImages.InnerHtml & IIf(colImages.InnerHtml <> "", "<br><br>", "<br>") & strImage
                        End While
                        If colImages.InnerHtml <> "" Then
                            tblDetails.Visible = True
                        End If

                        ' display fields
                        If arrDetailName.Count <> 0 Then
                            tblDetails.Visible = True
                            colFields.InnerHtml = "&nbsp;&nbsp;<table border=""0"" cellspacing=""2"" cellpadding=""2"">"
                            For intDetail = 0 To arrDetailName.Count - 1
                                colFields.InnerHtml = colFields.InnerHtml & "<tr><td><span class=""NormalBold"">" & arrDetailTitle(intDetail) & ":</span></td><td><span class=""Normal"">" & dsData.Tables(0).Rows(0).Item(arrDetailName(intDetail)) & "</span></td></tr>"
                            Next intDetail
                            colFields.InnerHtml = colFields.InnerHtml & "</table>"
                        End If

                        ' display notes
                        If drNotes.Read() Then
                            If Not IsDBNull(drNotes("Notes")) Then
                                colNotes.InnerHtml = "<br><span class=""Normal"">" & drNotes("Notes") & "</span>"
                            End If
                        End If
                        If colNotes.InnerHtml <> "" Then
                            tblDetails.Visible = True
                        End If
                    End If
                End If
                drReport.Close()
            Else ' security violation attempt to access item not related to this Module
                Response.Redirect("~/desktopdefault.aspx?tabid=" & tabId & "&tabindex=" & tabIndex)
            End If

            ' create report footer
            If strFooter <> "" Then
                strFooter = strFooter & " )<br>"
            End If
            arrFooter.Clear()
            If strSortFooter <> "" Then
                arrFooter.Add("sorted by " & strSortFooter)
            End If
            If strFilterFooter <> "" Then
                arrFooter.Add("filtered by " & strFilterFooter)
            End If
            If strBreakFooter <> "" Then
                arrFooter.Add("grouped by " & strBreakFooter)
            End If
            If arrFooter.Count <> 0 Then
                strFooter = strFooter & "Information"
                For intFooter = 0 To arrFooter.Count - 1
                    strFooter = strFooter & " " & arrFooter(intFooter) & IIf(intFooter <> arrFooter.Count - 1, " and ", "")
                Next intFooter
            End If
            lblFooter.Text = strFooter

        End Sub

        Private Sub BuildParameter(ByVal colParameter As HtmlTableCell, ByVal lblParameter As Label, ByVal cboParameter As DropDownList, ByVal strFieldTitle As String, ByVal drParameters As SqlDataReader, ByVal intFieldId As Integer, Optional ByVal blnAll As Boolean = True)
            colParameter.Visible = True

            lblParameter.Text = "&nbsp;&nbsp;" & strFieldTitle & ":"
            lblParameter.Visible = True

            cboParameter.Visible = True
            cboParameter.DataSource = drParameters
            cboParameter.DataBind()
            If blnAll Then
                cboParameter.Items.Insert(0, "<All " & strFieldTitle & "s>")
                cboParameter.Items.FindByText("<All " & strFieldTitle & "s>").Value = "-1"
            End If
            If Not cboParameter.Items.FindByValue(CType(intFieldId, String)) Is Nothing Then
                cboParameter.Items.FindByValue(CType(intFieldId, String)).Selected = True
            End If
        End Sub

        Private Function BuildCriteria(ByVal strCriteria As String, ByVal strFieldType As String) As String

            Dim intChar As Integer
            Dim strOperator As String
            Dim strValue As String = ""

            If strCriteria <> "" Then
                If InStr(1, "<>=~", Mid(strCriteria, 1, 1)) Then
                    intChar = 1
                    While InStr(1, " <>=~", Mid(strCriteria, intChar, 1))
                        intChar = intChar + 1
                    End While
                    strOperator = Replace(Left(strCriteria, intChar - 1), " ", "")
                    If strOperator = "~" Then
                        strOperator = "like"
                    End If
                    strCriteria = Mid(strCriteria, intChar)
                Else
                    strOperator = "="
                End If

                Select Case strFieldType
                    Case "String"
                        strValue = " " & strOperator & " '" & IIf(strOperator = "like", "%", "") & Replace(strCriteria, "'", "''") & IIf(strOperator = "like", "%", "") & "'"
                    Case "DateTime"
                        If IsDate(strCriteria) Then
                            strValue = " " & strOperator & " '" & Replace(strCriteria, "'", "''") & "'"
                        End If
                    Case "Boolean"
                        strValue = " " & strOperator & " " & strCriteria
                    Case "Decimal", "Int32"
                        If IsNumeric(strCriteria) Then
                            strValue = " " & strOperator & " " & strCriteria
                        End If
                End Select
            End If

            Return strValue

        End Function

        ' populate the row number column 
        Private Sub grdReport_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles grdReport.ItemDataBound
            Dim intCounter As Integer
            Dim strValue As String
            Dim blnControlBreak As Boolean = False
            Dim arrRow(grdReport.Columns.Count) As String

            If e.Item.ItemType <> ListItemType.Header Then
                If e.Item.ItemType = ListItemType.Footer Then
                    ' display totals
                    For intCounter = 0 To grdReport.Columns.Count - 1
                        If arrTotal(intCounter) <> -1 Then
                            e.Item.Cells(intCounter).Text = arrTotal(intCounter)
                        End If
                    Next intCounter
                Else
                    ' add row numbering
                    intGridRow += 1
                    If grdReport.Columns(0).HeaderText = "##" Then
                        e.Item.Cells(0).Text = CStr(intGridRow) & ".&nbsp;"
                    End If

                    ' summarize
                    For intCounter = 0 To grdReport.Columns.Count - 1
                        If e.Item.Cells(intCounter).Controls.Count > 0 Then
                            ' hyperlink column
                            Dim hypValue As HyperLink = e.Item.Cells(intCounter).Controls(0)
                            strValue = hypValue.Text
                        Else
                            ' bound column
                            strValue = e.Item.Cells(intCounter).Text
                        End If
                        If blnSummarize = True Or strBreak <> "" Then
                            If strValue = arrBreak(intCounter) Then
                                If arrSummarize(intCounter) = True Then
                                    e.Item.Cells(intCounter).Text = ""
                                End If
                            Else
                                arrBreak(intCounter) = strValue
                                ' control break
                                If InStr(1, strBreak, "," & CStr(intCounter)) <> 0 And intGridRow > 1 Then
                                    blnControlBreak = True
                                End If
                            End If
                        End If
                        arrRow(intCounter) = strValue
                    Next intCounter

                    ' control break
                    If blnControlBreak Then
                        For intCounter = 0 To grdReport.Columns.Count - 1
                            If arrTotal(intCounter) <> -1 Then
                                e.Item.Cells(intCounter).Text = "<span class=""NormalBold"">" & arrTotal(intCounter).ToString() & "</span><br><br>" & e.Item.Cells(intCounter).Text
                                arrTotal(intCounter) = 0
                            End If
                        Next intCounter
                    End If

                    If blnTotal Then
                        For intCounter = 0 To grdReport.Columns.Count - 1
                            ' calculate totals
                            If arrTotal(intCounter) <> -1 Then
                                If IsNumeric(arrRow(intCounter)) Then
                                    arrTotal(intCounter) += Decimal.Parse(arrRow(intCounter))
                                End If
                            End If
                        Next intCounter
                    End If
                End If
            End If
        End Sub

    End Class

End Namespace