Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("ASP.NET Hierarchical Menu Control")> 
<Assembly: AssemblyDescription("ASP.NET Hierarchical Menu Control")> 
<Assembly: AssemblyCompany("Solution Partners, Inc.")> 
<Assembly: AssemblyProduct("solpart.spmenu.dll")> 
<Assembly: AssemblyCopyright("Copyright (c) 2001-2002 Solution Partners, Inc.")> 
<Assembly: AssemblyTrademark("SolpartMenu is a trademark of Solution Partners, Inc.")> 
<Assembly: CLSCompliant(True)> 

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("6F608DE5-D06F-4EE7-8B83-9605296BD145")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:

<Assembly: AssemblyVersion("1.0.0.5")> 
