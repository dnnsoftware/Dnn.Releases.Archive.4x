'=============================================================================
'No Nonsense Copyright and License for Solpart ASP.NET Hierarchical WebControl
'=============================================================================
'
'Copyright:
'
'This library was written by me.  You are welcome to use it, modify it to suit 
'your needs, distribute it as you see fit.  I'm happy if you use it for 
'personal stuff or for commercial gain.
'
'The only thing you can't do is to restrict anyone else from using it however 
'they see fit.  You may not copyright it yourself or change the rules I have 
'set on how it can be used.
'
'Solpart ASP.NET Hierarchical WebControl Copyright (C) 2002 by Jon Henning
'
'License:
'
'You can use this however you like.  I make no guarantees whatsoever that it 
'will suit your purpose.  You take full responsibility for getting it working 
'properly and for any implications of its failure or inability to satisfy your 
'every need.
'
'=============================================================================
'
'Email:     jhenning@solpart.com
'Web:       http://www.solpart.com/techcorner
'
'
'Version    Change
'-------    -------------------------------------------------------------------
'1.0.0.0    Inital Release
'1.0.0.1    Performance improvement - decreased amount of output by over 50%
'           MenuEffects - Expandable property, supports enumerators and images
'1.0.0.2    Added Menu Transitions (MenuExample 2), added menu breaks, 
'           allowed menu to be displayed vertical (MenuExample 4), 
'           and added property for setting the icon cell width.
'1.0.0.3    Allowed control to have external scripts by specifying a script directory
'           Added ui editor form to generate menu xml
'           Added ability for menu to be aligned to right and handled cases when menu
'           would scroll off right side of screen
'1.0.0.4    Added menu caching, MouseOverExpand, MouseOverDisplay, Start Menu Functionality, 
'           Arrows on Root, Client Postbacks, Custom Styles on MenuItems.
'1.0.0.5    MouseOutHideDelay, BindDataTable, IBuySpyPortal integration (ibspmenu.zip),
'           fixed bug when xml contained processing instructions like <?xml version="1.0" encoding="utf-8" ?> 


Imports System.ComponentModel
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Xml
Imports SolpartWebControls.SolpartLib
Imports System.Drawing

Imports System
Imports System.IO
Imports System.Web

Imports System.Windows.Forms.Design
Imports System.Drawing.Design

#Region "Helper Classes"

Public Enum MenuEffectsMouseOverDisplay
	Outset
	Highlight
	None
End Enum

Public Class SolpartException : Inherits System.Exception
	Sub New(ByVal Message As String)
		MyBase.New(Message)
	End Sub
End Class

Namespace MyDesign.ControlDesigners
	Public Class MenuDataDesigner : Inherits System.Drawing.Design.UITypeEditor
		Dim m_objEditorSvc As System.Windows.Forms.Design.IWindowsFormsEditorService
		Dim m_objEditor As SolpartMenuDataDesignerForm

		Public Overloads Overrides Function GetEditStyle(ByVal context As System.ComponentModel.ITypeDescriptorContext) As System.Drawing.Design.UITypeEditorEditStyle
			If Not context Is Nothing And Not context.Instance Is Nothing Then
				Return UITypeEditorEditStyle.Modal
			Else
				Return MyBase.GetEditStyle(context)
			End If
		End Function

		Public Overloads Overrides Function EditValue(ByVal context As System.ComponentModel.ITypeDescriptorContext, ByVal provider As System.IServiceProvider, ByVal value As Object) As Object
			If Not context Is Nothing And Not context.Instance Is Nothing And Not provider Is Nothing Then
				m_objEditorSvc = CType(provider.GetService(GetType(IWindowsFormsEditorService)), IWindowsFormsEditorService)
			End If
			If Not m_objEditorSvc Is Nothing Then
				m_objEditor = New SolpartMenuDataDesignerForm(CStr(value))
				m_objEditor.ShowDialog()
				value = m_objEditor.XML
			End If

			Return value
		End Function
	End Class

	Public Class MenuAboutDesigner : Inherits System.Drawing.Design.UITypeEditor
		Dim m_objEditorSvc As System.Windows.Forms.Design.IWindowsFormsEditorService
		Dim m_objEditor As About

		Public Overloads Overrides Function GetEditStyle(ByVal context As System.ComponentModel.ITypeDescriptorContext) As System.Drawing.Design.UITypeEditorEditStyle
			If Not context Is Nothing And Not context.Instance Is Nothing Then
				Return UITypeEditorEditStyle.Modal
			Else
				Return MyBase.GetEditStyle(context)
			End If
		End Function

		Public Overloads Overrides Function EditValue(ByVal context As System.ComponentModel.ITypeDescriptorContext, ByVal provider As System.IServiceProvider, ByVal value As Object) As Object
			If Not context Is Nothing And Not context.Instance Is Nothing And Not provider Is Nothing Then
				m_objEditorSvc = CType(provider.GetService(GetType(IWindowsFormsEditorService)), IWindowsFormsEditorService)
			End If
			If Not m_objEditorSvc Is Nothing Then
				m_objEditor = New About()
				m_objEditor.ShowDialog()
				value = ""
			End If

			Return value
		End Function
	End Class


	Public Class MenuDesigner : Inherits UI.Design.ControlDesigner
		'--- This class allows us to render the design time mode with custom HTML ---'
		Public Overrides Function GetDesignTimeHtml() As String
      ' Component is the instance of the component or control that
			' this designer object is associated with. This property is 
			' inherited from System.ComponentModel.ComponentDesigner.
			Dim objMenu As SolpartMenu = CType(Component, SolpartMenu)

			If objMenu.ID.Length > 0 Then
				Dim sw As New StringWriter()
				Dim tw As New HtmlTextWriter(sw)
				Dim objText As Label = New Label()

				objText.BackColor = objMenu.BackColor
				objText.Font.CopyFrom(objMenu.Font)
				objText.Text = objMenu.ID
				objText.ForeColor = objMenu.ForeColor

				objText.BorderStyle = BorderStyle.Outset
				objText.BorderWidth = New Unit(objMenu.MenuBorderWidth)
				If objMenu.MenuAlignment <> "Justify" Then objText.Style.Add("text-align", objMenu.MenuAlignment)
				If objMenu.Display = "Horizontal" Then
					objText.Width = New Unit("100%")
					objText.Height = New Unit(objMenu.MenuBarHeight)
				Else
					objText.Height = New Unit(500)			'---not sure why 100% doesn't work here ---' 'Unit("100%")
					objText.Width = Unit.Empty
				End If
				objText.RenderControl(tw)
				Return sw.ToString()
			End If
		End Function

		Public Overrides ReadOnly Property AllowResize() As Boolean
			Get
				Return False
			End Get
		End Property
	End Class
End Namespace


Namespace MyDesign.TypeConverters

	Public Class MenuAlignmentConverter : Inherits TypeConverter
		'--- This class provides enumerators for the SolpartMenu.MenuEffects.ShadowDir property ---'
		Public Overloads Overrides Function GetStandardValues(ByVal context As ITypeDescriptorContext) As TypeConverter.StandardValuesCollection
			Dim s As String() = {"Left", "Right", "Center", "Justify"}
			Return New TypeConverter.StandardValuesCollection(s)
		End Function

		Public Overloads Overrides Function GetStandardValuesSupported(ByVal context As ITypeDescriptorContext) As Boolean
			Return True		'determins if standard values are supported
		End Function

		Public Overloads Overrides Function GetStandardValuesExclusive(ByVal context As ITypeDescriptorContext) As Boolean
			Return True		'determines if free form text is allowed
		End Function
	End Class

	Public Class MenuEffectsShadowDirConverter : Inherits TypeConverter
		'--- This class provides enumerators for the SolpartMenu.MenuEffects.ShadowDir property ---'
		Public Overloads Overrides Function GetStandardValues(ByVal context As ITypeDescriptorContext) As TypeConverter.StandardValuesCollection
			Dim s As String() = {"None", "Top", "Upper Right", "Right", "Lower Right", "Bottom", "Lower Left", "Left", "Upper Left"}
			Return New TypeConverter.StandardValuesCollection(s)
		End Function

		Public Overloads Overrides Function GetStandardValuesSupported(ByVal context As ITypeDescriptorContext) As Boolean
			Return True		'determins if standard values are supported
		End Function

		Public Overloads Overrides Function GetStandardValuesExclusive(ByVal context As ITypeDescriptorContext) As Boolean
			Return True		'determines if free form text is allowed
		End Function
	End Class

	Public Class MenuTransitionConverter : Inherits TypeConverter
		'--- This class provides enumerators for the SolpartMenu.MenuEffects.MenuTransition property ---'
		Public Overloads Overrides Function GetStandardValues(ByVal context As ITypeDescriptorContext) As TypeConverter.StandardValuesCollection
			Dim s As String() = {"None", "AlphaFade", "AlphaFadeBottomRight", "Barn", "Blinds", "Checkerboard", "ConstantWave", "Fade", "GradientWipe", "Inset", "Iris", "RadialWipe", "Random", "RandomBars", "Slide", "Spiral", "Stretch", "Strips", "Wave", "Wheel", "Zigzag"}
			Return New TypeConverter.StandardValuesCollection(s)
		End Function

		Public Overloads Overrides Function GetStandardValuesSupported(ByVal context As ITypeDescriptorContext) As Boolean
			Return True		'determins if standard values are supported
		End Function

		Public Overloads Overrides Function GetStandardValuesExclusive(ByVal context As ITypeDescriptorContext) As Boolean
			Return True		'determines if free form text is allowed
		End Function
	End Class

	Public Class MenuDisplayConverter : Inherits TypeConverter
		'--- This class provides enumerators for the SolpartMenu.Display property ---'
		Public Overloads Overrides Function GetStandardValues(ByVal context As ITypeDescriptorContext) As TypeConverter.StandardValuesCollection
			Dim s As String() = {"Horizontal", "Vertical"}
			Return New TypeConverter.StandardValuesCollection(s)
		End Function

		Public Overloads Overrides Function GetStandardValuesSupported(ByVal context As ITypeDescriptorContext) As Boolean
			Return True		'determins if standard values are supported
		End Function

		Public Overloads Overrides Function GetStandardValuesExclusive(ByVal context As ITypeDescriptorContext) As Boolean
			Return True		'determines if free form text is allowed
		End Function
	End Class

	Public Class MenuEffectsConverter : Inherits ExpandableObjectConverter
		'--- This class allows us to display the MenuEffects expandable property in the properties window ---'
		Public Overloads Overrides Function ConvertFrom(ByVal context As ITypeDescriptorContext, ByVal culture As System.Globalization.CultureInfo, ByVal value As Object) As Object

			If value Is GetType(String) Then
				Dim arr As String() = Split(CType(value, String), ",")
				If UBound(arr) >= 3 Then
					Dim objEffect As MenuEffects = New MenuEffects()
					objEffect.ShadowColor = GetColor(arr(0))
					objEffect.ShadowDirection = CStr(arr(1))
					objEffect.ShadowStrength = CInt(arr(2))
					'objEffect.UseShadow = CBool(arr(3))
					'objEffect.MenuTransition = CStr(arr(4))
				Else
					MsgBox("Cannot convert value: " & CStr(value))
				End If
			Else
				MsgBox("Cannot convert value. (" & TypeName(value) & ")")
			End If

		End Function

		Public Overloads Overrides Function CanConvertFrom(ByVal context As ITypeDescriptorContext, ByVal sourceType As System.Type) As Boolean
			If sourceType Is GetType(String) Then
				Return True
			Else
				Return MyBase.CanConvertFrom(context, sourceType)
			End If
		End Function

		Public Overloads Overrides Function ConvertTo(ByVal context As ITypeDescriptorContext, ByVal culture As System.Globalization.CultureInfo, ByVal value As Object, ByVal destinationType As System.Type) As Object
			If TypeOf value Is MenuEffects And destinationType Is GetType(String) Then
				Dim obj As MenuEffects = CType(value, MenuEffects)
				Return GetColor(obj.ShadowColor) & "," & obj.ShadowDirection & "," & obj.ShadowStrength		 '& "," & obj.UseShadow
			Else
				MsgBox("convertto error")
			End If
		End Function

	End Class

	Public Class MenuShadowDirEditor : Inherits System.Drawing.Design.UITypeEditor
		'--- This class allows us to use custom graphics in the SolpartMenu.MenuEffects.ShadowDir dropdown ---'
		Private m_objRes As System.Resources.ResourceManager = New System.Resources.ResourceManager("SolpartWebControls.spimages", GetType(SolpartMenu).Assembly)		 'used to retrieve client side javascript

		Public Overloads Overrides Function GetPaintValueSupported(ByVal context As ITypeDescriptorContext) As Boolean
			Return True		'--- let the property browser know we are doing custom painting here ---'
		End Function


		Public Overloads Overrides Sub PaintValue(ByVal e As System.Drawing.Design.PaintValueEventArgs)
			If e.Value.ToString <> "None" Then
				Dim sImageName As String = "spshadow" & CType(e.Value, String).ToLower
				'--- draw image from resource file ---'
				e.Graphics.DrawImage(CType(m_objRes.GetObject(sImageName), Bitmap), e.Bounds)

				'--- could have specified many ways to free-draw the image here ---'
				'e.Graphics.DrawEllipse(New System.Drawing.Pen(System.Drawing.Color.Blue), New RectangleF(5, 5, 10, 10))
			End If
		End Sub
	End Class

End Namespace

Public Class MenuEffects
	Private m_objShadowColor As Color
	'Private m_objGradientColor1 As Color
	'Private m_objGradientColor2 As Color
	Private m_iShadowStrength As Integer
	Private m_sShadowDirection As String
	Private m_bUseShadow As Boolean
	Private m_bUseGradient As Boolean
	Private m_sMenuTransition As String
	Private m_dMenuTransitionLength As Double
	Private m_eMenuEffectsMouseOverDisplay As MenuEffectsMouseOverDisplay
	Private m_bMouseOverExpand As Boolean
	'Private m_sGradientDirection As String
  Private m_iMouseOutHideDelay As Integer = 0

	<NotifyParentProperty(True), Browsable(False), Category("Appearance"), DefaultValue(False), Description("Toggles whether to show a shadow or not")> _
	Public Property UseShadow() As Boolean
		'left for backward compatibility- use shadowdir of none to disable
		Get
			Return m_bUseShadow
		End Get
		Set(ByVal Value As Boolean)
			m_bUseShadow = Value
		End Set
	End Property

  <NotifyParentProperty(True), Category("Behavior"), DefaultValue(0), Description("Number of milliseconds to wait until menu is hidden on mouse out.  (0 = disable)")> _
  Public Property MouseOutHideDelay() As Integer
    Get
      Return m_iMouseOutHideDelay
    End Get
    Set(ByVal Value As Integer)
      m_iMouseOutHideDelay = Value
    End Set
  End Property


  '<NotifyParentProperty(True), Browsable(True), TypeConverter(GetType(WebColorConverter)), Category("Appearance"), DefaultValue(GetType(Color), "dimgray"), Description("Color of the Gradient")> _
  'Public Property GradientColor1() As Color
  '    Get
  '        If m_objGradientColor1.IsEmpty Then
  '            Dim objConvert As ColorConverter = New ColorConverter()
  '            Return CType(objConvert.ConvertFromString("silver"), Color)
  '        Else
  '            Return m_objGradientColor1
  '        End If
  '    End Get
  '    Set(ByVal Value As Color)
  '        m_objGradientColor1 = Value
  '    End Set
  'End Property

  '<NotifyParentProperty(True), Browsable(True), TypeConverter(GetType(WebColorConverter)), Category("Appearance"), DefaultValue(GetType(Color), "dimgray"), Description("Color of the Gradient")> _
  'Public Property GradientColor2() As Color
  '    Get
  '        If m_objGradientColor2.IsEmpty Then
  '            Dim objConvert As ColorConverter = New ColorConverter()
  '            Return CType(objConvert.ConvertFromString("silver"), Color)
  '        Else
  '            Return m_objGradientColor2
  '        End If
  '    End Get
  '    Set(ByVal Value As Color)
  '        m_objGradientColor2 = Value
  '    End Set
  'End Property

  <NotifyParentProperty(True), Browsable(True), TypeConverter(GetType(WebColorConverter)), Category("Appearance"), DefaultValue(GetType(Color), "dimgray"), Description("Color of the shadow")> _
  Public Property ShadowColor() As Color
    Get
      If m_objShadowColor.IsEmpty Then
        Dim objConvert As ColorConverter = New ColorConverter()
        Return CType(objConvert.ConvertFromString("dimgray"), Color)
      Else
        Return m_objShadowColor
      End If
    End Get
    Set(ByVal Value As Color)
      m_objShadowColor = Value
    End Set
  End Property

  <NotifyParentProperty(True), Browsable(True), Category("Appearance"), DefaultValue(3), Description("Determines how many pixels the shadow extends")> _
  Public Property ShadowStrength() As Integer
    Get
      If m_iShadowStrength = 0 Then
        Return 3
      Else
        Return m_iShadowStrength
      End If

    End Get
    Set(ByVal Value As Integer)
      m_iShadowStrength = Value
    End Set
  End Property

  <Editor(GetType(MyDesign.TypeConverters.MenuShadowDirEditor), GetType(System.Drawing.Design.UITypeEditor)), TypeConverter(GetType(MyDesign.TypeConverters.MenuEffectsShadowDirConverter)), NotifyParentProperty(True), Browsable(True), Category("Appearance"), DefaultValue("Lower Right"), Description("Determines which direction the shadow will fall")> _
    Public Property ShadowDirection() As String
    Get
      If Len(m_sShadowDirection) = 0 Then
        Return "Lower Right"
      Else
        Return m_sShadowDirection
      End If
    End Get
    Set(ByVal Value As String)
      m_sShadowDirection = Value
    End Set
  End Property

  <DefaultValue(MenuEffectsMouseOverDisplay.Outset), NotifyParentProperty(True), Browsable(True), Category("Appearance"), Description("Adjusts effect when mouse moves over menu bar item")> _
  Public Property MouseOverDisplay() As MenuEffectsMouseOverDisplay
    Get
      Return m_eMenuEffectsMouseOverDisplay
    End Get
    Set(ByVal Value As MenuEffectsMouseOverDisplay)
      m_eMenuEffectsMouseOverDisplay = Value
    End Set
  End Property

  <DefaultValue(False), NotifyParentProperty(True), Browsable(True), Category("Behavior"), Description("Makes menu expand on mouse over (unlike any menu found within the Windows environment).")> _
  Public Property MouseOverExpand() As Boolean
    Get
      Return m_bMouseOverExpand
    End Get
    Set(ByVal Value As Boolean)
      m_bMouseOverExpand = Value
    End Set
  End Property

  '<TypeConverter(GetType(MyDesign.TypeConverters.MenuEffectsShadowDirConverter)), NotifyParentProperty(True), Browsable(True), Category("Appearance"), DefaultValue("Lower Right"), Description("Determines which direction the shadow will fall")> _
  'Public Property GradientDirection() As String
  '    Get
  '        If Len(m_sGradientDirection) = 0 Then
  '            Return "Lower Right"
  '        Else
  '            Return m_sGradientDirection
  '        End If
  '    End Get
  '    Set(ByVal Value As String)
  '        m_sGradientDirection = Value
  '    End Set
  'End Property

  <TypeConverter(GetType(MyDesign.TypeConverters.MenuTransitionConverter)), NotifyParentProperty(True), Browsable(True), Category("Appearance"), Description("Determines which direction the shadow will fall"), DefaultValue("None")> _
  Public Property MenuTransition() As String
    Get
      If Len(m_sMenuTransition) = 0 Then
        Return "None"
      Else
        '--- TODO:  need to only do this if not design mode ---'
        'If CType(Me.container, Control).site.DesignMode = False Then
        If m_sMenuTransition = "Random" Then m_sMenuTransition = GetRandomTransition()
        'End If
        Return m_sMenuTransition
      End If
    End Get
    Set(ByVal Value As String)
      m_sMenuTransition = Value
    End Set
  End Property

  <Description("Number of seconds the transition will take"), DefaultValue(0.3), NotifyParentProperty(True)> _
  Public Property MenuTransitionLength() As Double
    Get
      If m_dMenuTransitionLength = 0 Then
        Return 0.3
      Else
        Return m_dMenuTransitionLength
      End If
    End Get
    Set(ByVal Value As Double)
      m_dMenuTransitionLength = Value
    End Set
  End Property

  <Browsable(False)> _
  Public ReadOnly Property Style() As String
    Get
      Dim sStyle As String
      If m_bUseShadow Or m_sShadowDirection <> "None" Then
        sStyle = "progid:DXImageTransform.Microsoft.Shadow(color='" & GetColor(ShadowColor) & "', Direction=" & GetShadowDir(ShadowDirection) & ", Strength=" & ShadowStrength & ") "
      End If

      'If m_sGradientDirection <> "None" Then
      '    sStyle += "progid:DXImageTransform.Microsoft.Gradient(GradientType=1, StartColorStr='" & GetColor(GradientColor1) & "', '" & GetColor(GradientColor2) & "') "
      'End If


      Select Case MenuTransition
        Case "AlphaFade"
          sStyle += "progid:DXImageTransform.Microsoft.Alpha(opacity=100) "
        Case "AlphaFadeBottomRight"
          sStyle += "progid:DXImageTransform.Microsoft.Alpha( Opacity=100, FinishOpacity=75, Style=1, StartX=0,  FinishX=100, StartY=0, FinishY=100)"
        Case "Wave"
          sStyle += "progid:DXImageTransform.Microsoft.Wave(freq=0,LightStrength=0,Phase=0,Strength=0) "
        Case "ConstantWave"
          sStyle += "progid:DXImageTransform.Microsoft.Wave(freq=0,LightStrength=0,Phase=0,Strength=0) "
        Case "Inset"
          sStyle += "progid:DXImageTransform.Microsoft.Inset() "
        Case "RadialWipe"
          sStyle += "progid:DXImageTransform.Microsoft.RadialWipe(wipestyle=RADIAL) "
        Case "Slide"
          sStyle += "progid:DXImageTransform.Microsoft.Slide(slidestyle=PUSH,Bands=3) "
        Case "Spiral"
          sStyle += "progid:DXImageTransform.Microsoft.Spiral(GridSizeX=32,GridSizeY=32) "
        Case "Stretch"
          sStyle += "progid:DXImageTransform.Microsoft.Stretch(stretchstyle=PUSH) "
        Case "Strips"
          sStyle += "progid:DXImageTransform.Microsoft.Strips(motion=rightdown) "
        Case "Wheel"
          sStyle += "progid:DXImageTransform.Microsoft.Wheel(spokes=6) "
        Case "GradientWipe"
          sStyle += "progid:DXImageTransform.Microsoft.GradientWipe(GradientSize=1.00,wipestyle=1,motion=forward) "
        Case "Zigzag"
          sStyle += "progid:DXImageTransform.Microsoft.Zigzag(GridSizeX=8,GridSizeY=8) "
        Case "Barn"
          sStyle += "progid:DXImageTransform.Microsoft.Barn( motion=out,orientation=vertical) "
        Case "Blinds"
          sStyle += "progid:DXImageTransform.Microsoft.Blinds( Bands=6,direction=down) "
        Case "Checkerboard"
          sStyle += "progid:DXImageTransform.Microsoft.Checkerboard( Direction=right,SquaresX=6,SquaresY=6) "
        Case "Fade"
          sStyle += "progid:DXImageTransform.Microsoft.Fade(Overlap=1.00) "
        Case "Iris"
          sStyle += "progid:DXImageTransform.Microsoft.Iris(irisstyle=CIRCLE,motion=out) "
        Case "RandomBars"
          sStyle += "progid:DXImageTransform.Microsoft.RandomBars() "
        Case "None"
          sStyle += ""
        Case Else
          sStyle += ""
      End Select
      Return "filter:" & sStyle & ";"
    End Get
  End Property

  Private Function GetShadowDir(ByVal s As String) As Integer
    'shadowdirection for the DXImageTransform is defined in degrees 0 - 360
    Select Case s
      Case "Top"
        Return 0
      Case "Upper Right"
        Return 45
      Case "Right"
        Return 90
      Case "Lower Right"
        Return 135
      Case "Bottom"
        Return 180
      Case "Lower Left"
        Return 225
      Case "Left"
        Return 270
      Case "Upper Left"
        Return 315
    End Select
  End Function

  Private Function GetRandomTransition() As String
    Dim o As MyDesign.TypeConverters.MenuTransitionConverter = New MyDesign.TypeConverters.MenuTransitionConverter()
    Dim arr(o.GetStandardValues().Count) As String
    o.GetStandardValues().CopyTo(arr, 0)

    Randomize()
    Dim iNum As Integer = CInt((arr.Length - 1) * Rnd() + 0)
    If CStr(arr.GetValue(iNum)) = "Random" Then iNum = 0 'don't randomize to random
    If Len(CStr(arr.GetValue(iNum))) > 0 Then
      Return CStr(arr.GetValue(iNum))
    Else
      Return "None"
    End If

  End Function


End Class
#End Region

<ToolboxData("<{0}:SolpartMenu runat=server></{0}:SolpartMenu>"), Description("Solution Partners ASP.NET Hierarchical Menu WebControl"), _
Designer(GetType(MyDesign.ControlDesigners.MenuDesigner)), ParseChildren(False)> _
Public Class SolpartMenu : Inherits WebControl : Implements System.Web.UI.IPostBackEventHandler

  Private m_objDOM As XmlDocument = New XmlDocument() 'DOM object storing structure of menu
  Private m_objRes As System.Resources.ResourceManager = New System.Resources.ResourceManager("SolpartWebControls.solpartwc-script", GetType(SolpartMenu).Assembly)  'used to retrieve client side javascript
  Private m_sOuterTables As String 'variable to store sub menu HTML

  Public Event MenuClick(ByVal ID As String)

#Region "Property Code"
  '--- Property Variables ---'
  Private m_sMenuData As String
  Private m_sMenuDataFileName As String
  Private m_sSelectedMenuItemID As String = ""
  Private m_sSelectedMenuPath As String = ""
  Private m_sSystemImagesPath As String
  Private m_sSystemScriptPath As String = ""
  Private m_bMoveable As Boolean
  Private m_bForceDownlevel As Boolean
  Private m_objShadowColor As Color
  Private m_objHighlightColor As Color
  Private m_objSelectedColor As Color
  Private m_objSelectedForeColor As Color
  Private m_objSelectedBorderColor As Color
  Private m_objIconBackgroundColor As Color
  Private m_sMenuBackgroundImage As String
  Private m_lMenuBarHeight As Long
  Private m_lMenuItemHeight As Long
  Private m_lIconWidth As Long
  Private m_sArrowImage As String
  Private m_bRootArrow As Boolean
  Private m_sMenuDisplay As String
  Private m_sMenuAlignment As String
  Private m_iMenuBorderWidth As Integer = 1

  'Private m_objMenuItemFont As Font
  Private m_objMenuItemFont As FontInfo

  Private m_objMenuEffects As MenuEffects '= New MenuEffects()


  'Not sure why this doesn't work! - All I want to do is default the color to gray!
  '<Category("Appearance"), DefaultValue("gray"), Description("Color of menu")> _
  'Public Overrides Property BackColor() As Color
  '    Get
  '        Return MyBase.BackColor
  '    End Get
  '    Set(ByVal Value As Color)
  '        MyBase.BackColor = Value
  '    End Set
  'End Property

  <Editor(GetType(MyDesign.ControlDesigners.MenuAboutDesigner), GetType(System.Drawing.Design.UITypeEditor)), Category("About")> _
  Public ReadOnly Property About() As String
    Get

    End Get
  End Property

  <TypeConverter(GetType(WebColorConverter)), Category("Appearance"), DefaultValue("gray"), Description("Color of right and bottom border to give a shadow effect")> _
  Public Property ShadowColor() As Color
    Get
      If m_objShadowColor.IsEmpty Then
        Return m_objShadowColor.Gray
      Else
        Return m_objShadowColor
      End If
    End Get
    Set(ByVal Value As Color)
      m_objShadowColor = Value
    End Set
  End Property

  <TypeConverter(GetType(WebColorConverter)), Category("Appearance"), DefaultValue("white"), Description("Color of top and left border to give a highlight effect")> _
  Public Property HighlightColor() As Color
    Get
      If m_objHighlightColor.IsEmpty Then
        Return m_objHighlightColor.White
      Else
        Return m_objHighlightColor
      End If
    End Get
    Set(ByVal Value As Color)
      m_objHighlightColor = Value
    End Set
  End Property

  <Category("Appearance"), DefaultValue(""), Description("Background image for main menu bar")> _
  Public Property BackgroundMenuImage() As String
    Get
      Return m_sMenuBackgroundImage
    End Get
    Set(ByVal Value As String)
      m_sMenuBackgroundImage = Value
    End Set
  End Property

  <Category("Appearance"), DefaultValue(""), Description("Arrow defaults to using WingDings font.  If you wish to not use this then specify an image to use instead.")> _
  Public Property ArrowImage() As String
    Get
      Return m_sArrowImage
    End Get
    Set(ByVal Value As String)
      m_sArrowImage = Value
    End Set
  End Property

  <Category("Appearance"), DefaultValue(False), Description("Causes arrow to be displayed on the root menu items.")> _
  Public Property RootArrow() As Boolean
    Get
      Return m_bRootArrow
    End Get
    Set(ByVal Value As Boolean)
      m_bRootArrow = Value
    End Set
  End Property

  <TypeConverter(GetType(WebColorConverter)), Category("Appearance"), DefaultValue("navy"), Description("Background color of menu item when selected")> _
  Public Property SelectedColor() As Color
    Get
      If m_objSelectedColor.IsEmpty Then
        Return m_objSelectedColor.Navy
      Else
        Return m_objSelectedColor
      End If
    End Get
    Set(ByVal Value As Color)
      m_objSelectedColor = Value
    End Set
  End Property

  <TypeConverter(GetType(WebColorConverter)), Category("Appearance"), DefaultValue("navy"), Description("Fore colof of menu item when selected")> _
  Public Property SelectedForeColor() As Color
    Get
      If m_objSelectedForeColor.IsEmpty Then
        Return m_objSelectedForeColor.White
      Else
        Return m_objSelectedForeColor
      End If
    End Get
    Set(ByVal Value As Color)
      m_objSelectedForeColor = Value
    End Set
  End Property

  <TypeConverter(GetType(WebColorConverter)), Category("Appearance"), DefaultValue(""), Description("Color of border surrounding selected menu item")> _
  Public Property SelectedBorderColor() As Color
    Get
      Return m_objSelectedBorderColor
    End Get
    Set(ByVal Value As Color)
      m_objSelectedBorderColor = Value
    End Set
  End Property

  <TypeConverter(GetType(WebColorConverter)), Category("Appearance"), DefaultValue("Horizontal"), Description("Background color in area where icon is displayed")> _
  Public Property IconBackgroundColor() As Color
    Get
      If m_objIconBackgroundColor.IsEmpty Then
        Return BackColor
      Else
        Return m_objIconBackgroundColor
      End If
    End Get
    Set(ByVal Value As Color)
      m_objIconBackgroundColor = Value
    End Set
  End Property

  <TypeConverter(GetType(MyDesign.TypeConverters.MenuEffectsConverter)), DesignerSerializationVisibilityAttribute(DesignerSerializationVisibility.Content), Category("Appearance"), Description("Object to handle IE specific filters for sub menus"), Browsable(True)> _
  Public Property MenuEffects() As MenuEffects
    Get
      If m_objMenuEffects Is Nothing Then
        m_objMenuEffects = New MenuEffects()
      End If
      Return m_objMenuEffects
    End Get
    Set(ByVal Value As MenuEffects)
      m_objMenuEffects = Value
    End Set
  End Property

  <TypeConverter(GetType(MyDesign.TypeConverters.MenuDisplayConverter)), Category("Appearance"), Description("Determines how the menu is displayed, horizontal or vertical"), Browsable(True)> _
  Public Property Display() As String
    Get
      If Len(m_sMenuDisplay) = 0 Then
        Return "Horizontal"
      Else
        Return m_sMenuDisplay
      End If
    End Get
    Set(ByVal Value As String)
      m_sMenuDisplay = Value
    End Set
  End Property

  <TypeConverter(GetType(MyDesign.TypeConverters.MenuAlignmentConverter)), Category("Appearance"), Description("Determines how the menus are aligned"), Browsable(True)> _
  Public Property MenuAlignment() As String
    Get
      If Len(m_sMenuAlignment) = 0 Then
        Return "Left"
      Else
        Return m_sMenuAlignment
      End If
    End Get
    Set(ByVal Value As String)
      m_sMenuAlignment = Value
    End Set
  End Property

  <Category("Behavior"), DefaultValue("True"), Description("Flag to detemine if menu can be moved")> _
  Public Property Moveable() As Boolean
    Get
      Return m_bMoveable
    End Get
    Set(ByVal Value As Boolean)
      m_bMoveable = Value
    End Set
  End Property

  <Category("Appearance"), DefaultValue("False"), Description("Flag to force the downlevel menu to display")> _
  Public Property ForceDownlevel() As Boolean
    Get
      Return m_bForceDownlevel
    End Get
    Set(ByVal Value As Boolean)
      m_bForceDownlevel = Value
    End Set
  End Property

  <Browsable(False), Category("Appearance"), Description("Readonly property holding the style of the menu")> _
  Public ReadOnly Property MenuStyle() As String
    Get
      'Return "color: " & GetColor(ForeColor) & "; background-color: " & GetColor(BackColor) & "; " & MyIIf(MenuBarHeight > 0, "height: " & MenuBarHeight & "px;", "") & MenuBorderStyle
      Return "color: " & GetColor(ForeColor) & "; background-color: " & GetColor(BackColor) & "; " & MenuBorderStyle
    End Get
  End Property

  <Browsable(False), Category("Appearance"), Description("Readonly property holding the style of the menu border")> _
  Public ReadOnly Property MenuBorderStyle() As String
    Get
      Return "border-bottom: " & GetColor(ShadowColor) & " " & MenuBorderWidth & "px solid; border-left: " & GetColor(HighlightColor) & " " & MenuBorderWidth & "px solid; border-top: " & GetColor(HighlightColor) & " " & MenuBorderWidth & "px solid; border-right: " & GetColor(ShadowColor) & " " & MenuBorderWidth & "px solid;"
    End Get
  End Property

  'Not sure why this property causes the interface to crash!  If you know then email me:  jhenning@solpart.com
  '<Category("Appearance"), TypeConverter(GetType(Font))> _
  'Public Property MenuItemFont() As FontInfo
  '    Get
  '        If m_objMenuItemFont Is Nothing Then
  '            Dim objStyle As Style = New Style()
  '            objStyle.Font.Name = "Arial"
  '            Return objStyle.Font
  '        Else
  '            Return m_objMenuItemFont
  '        End If
  '    End Get
  '    Set(ByVal Value As FontInfo)
  '        m_objMenuItemFont = Value
  '    End Set
  'End Property


  'THIS WORKS but is not meant for the web
  '<Category("Appearance"), TypeConverter(GetType(Font))> _
  'Public Property MenuItemFont() As Font
  '    Get
  '        If m_objMenuItemFont Is Nothing Then
  '            Return New Font(New FontFamily("Arial"), 8)
  '        Else
  '            Return m_objMenuItemFont
  '        End If
  '    End Get
  '    Set(ByVal Value As Font)
  '        m_objMenuItemFont = Value
  '    End Set
  'End Property

  <Browsable(False), Category("Appearance"), Description("Readonly property holdin the menu item font style")> _
  Public ReadOnly Property MenuItemFontStyle() As String
    Get
      Return "font-family: " & Join(Font.Names, ", ") & "; font-size: " & Font.Size.ToString & "; font-weight: " & MyIIf(Font.Bold, "bold", "normal") & "; font-style: " & MyIIf(Font.Italic, "italic", "normal") & "; text-decoration: " & MyIIf(Font.Underline, "underline ", "") & MyIIf(Font.Overline, "overline ", "") & MyIIf(Font.Strikeout, "line-through ", "")

    End Get
  End Property

  <Editor(GetType(MyDesign.ControlDesigners.MenuDataDesigner), GetType(System.Drawing.Design.UITypeEditor)), PersistenceMode(PersistenceMode.InnerDefaultProperty), Category("Data"), Description("Provides the means to populate the menu from an XML string")> _
  Public Property MenuData() As String
    Get
      If HasControls() Then
        If TypeOf Controls(0) Is LiteralControl Then
          Return Replace(Replace(CType(Controls(0), LiteralControl).Text, vbCrLf, ""), vbTab, "")
        Else
          Return Replace(Replace(CType(Controls(0), HtmlControls.HtmlGenericControl).InnerHtml, vbCrLf, ""), vbTab, "")
        End If
      Else
        Return m_sMenuData
      End If
    End Get
    Set(ByVal Value As String)
      m_sMenuData = Value
      If HasControls() Then Controls.RemoveAt(0)
      Controls.Add(New LiteralControl(m_sMenuData))
    End Set
  End Property

  <Description("Allows menu to be populated from an XML file"), Category("Data")> _
  Public Property MenuDataXMLFileName() As String
    Get
      Return m_sMenuDataFileName
    End Get
    Set(ByVal Value As String)
      'If Len(Value) > 0 Then
      m_sMenuDataFileName = Value
      'End If
    End Set
  End Property

  <Browsable(False), Description("For downgraded browsers this property stores the ID of the selected menu item")> _
  Public ReadOnly Property SelectedMenuItemID() As String
    Get
      Return m_sSelectedMenuItemID
    End Get
  End Property

  <Browsable(False), Description("For downgraded browsers this property stores the path of the currently selected menu item")> _
  Public ReadOnly Property SelectedMenuPath() As String
    Get
      Return m_sSelectedMenuPath
    End Get
  End Property

  <Description("Directory to find the images for the menu.  Need to have spacer.gif here!")> _
  Public Property SystemImagesPath() As String
    Get
      Return MyIIf(Len(m_sSystemImagesPath) = 0, "images/", m_sSystemImagesPath)
    End Get
    Set(ByVal Value As String)
      m_sSystemImagesPath = Value
    End Set
  End Property

  <Description("Directory to find the scripts for the menu.  If none specified then will use internal script files.  (External files can be cached by client browser)")> _
  Public Property SystemScriptPath() As String
    Get
      If m_sSystemScriptPath.Length > 0 Then
        Return MyIIf(Right(m_sSystemScriptPath, 1) = "/", m_sSystemScriptPath, m_sSystemScriptPath & "/")
      Else
        Return ""
      End If
    End Get
    Set(ByVal Value As String)
      m_sSystemScriptPath = Value
    End Set
  End Property

  <Description("Height of Menu Bar"), Category("Layout")> _
  Public Property MenuBarHeight() As Long
    Get
      Return m_lMenuBarHeight
    End Get
    Set(ByVal Value As Long)
      m_lMenuBarHeight = Value
    End Set
  End Property

  <Description("Height of Menu Items"), Category("Layout")> _
  Public Property MenuItemHeight() As Long
    Get
      Return m_lMenuItemHeight
    End Get
    Set(ByVal Value As Long)
      m_lMenuItemHeight = Value
    End Set
  End Property

  <Description("Width of icon area"), Category("Layout"), DefaultValue(15)> _
  Public Property IconWidth() As Long
    Get
      If m_lIconWidth = 0 Then
        Return 15
      Else
        Return m_lIconWidth
      End If
    End Get
    Set(ByVal Value As Long)
      m_lIconWidth = Value
    End Set
  End Property

  <Description("Width of menu border"), Category("Layout"), DefaultValue(1)> _
  Public Property MenuBorderWidth() As Integer
    Get
      Return m_iMenuBorderWidth
    End Get
    Set(ByVal Value As Integer)
      m_iMenuBorderWidth = Value
    End Set
  End Property



#End Region

#Region "Public Member Functions"
  <Description("Adds root menuitem")> _
  Public Function AddMenuItem(ByVal sID As String, ByVal sTitle As String, ByVal sURL As String) As System.Xml.XmlNode
    Return AddMenuItem(m_objDOM.ChildNodes(0), sID, sTitle, sURL)
  End Function

  <Description("Adds menuitem when parent id passed in")> _
  Public Function AddMenuItem(ByVal sParentID As String, ByVal sID As String, ByVal sTitle As String, ByVal sURL As String) As System.Xml.XmlNode
    Dim objList As XmlNodeList
    objList = m_objDOM.SelectNodes("//menuitem[@id='" & sParentID & "']")
    If objList.Count = 0 Then
      Throw New ArgumentException("Parent Node Not Found.")
    Else
      Return AddMenuItem(objList.Item(0), sID, sTitle, sURL)
    End If
  End Function

  <Description("Adds menuitem as child of passed in parent")> _
  Public Function AddMenuItem(ByVal objParent As XmlNode, ByVal sID As String, ByVal sTitle As String, ByVal sURL As String, Optional ByVal sImage As String = "", Optional ByVal bRunatServer As Boolean = False, Optional ByVal sItemStyle As String = "", Optional ByVal sImageStyle As String = "") As System.Xml.XmlNode
    Dim objNode As XmlNode = m_objDOM.CreateNode(XmlNodeType.Element, "menuitem", "")
    Dim objAttr As XmlAttribute

    If m_objDOM.ChildNodes.Count = 0 Then
      m_objDOM.AppendChild(m_objDOM.CreateNode(XmlNodeType.Element, "root", ""))
    End If

    If m_objDOM.SelectNodes("//menuitem[@id='" & sID & "']").Count > 0 Then
      Throw New ArgumentException("This ID is already in use")
    Else
      If objParent Is Nothing Then objParent = m_objDOM.ChildNodes(0)

      objAttr = m_objDOM.CreateAttribute("id")
      objAttr.Value = sID
      objNode.Attributes.Append(objAttr)

      objAttr = m_objDOM.CreateAttribute("title")
      objAttr.Value = sTitle
      objNode.Attributes.Append(objAttr)

      objAttr = m_objDOM.CreateAttribute("url")
      objNode.Attributes.Append(objAttr)
      objAttr.Value = sURL

      If Len(sImage) > 0 Then
        objAttr = m_objDOM.CreateAttribute("image")
        objNode.Attributes.Append(objAttr)
        objAttr.Value = sImage
      End If

      If bRunatServer Then
        objAttr = m_objDOM.CreateAttribute("runat")
        objNode.Attributes.Append(objAttr)
        objAttr.Value = "server"
      End If
      If Len(sItemStyle) > 0 Then
        objAttr = m_objDOM.CreateAttribute("itemstyle")
        objNode.Attributes.Append(objAttr)
        objAttr.Value = sItemStyle
      End If
      If Len(sImageStyle) > 0 Then
        objAttr = m_objDOM.CreateAttribute("imagestyle")
        objNode.Attributes.Append(objAttr)
        objAttr.Value = sImageStyle
      End If

      objParent.AppendChild(objNode)
      Return objNode
    End If

  End Function

  Public Function AddBreak(ByVal sParentID As String) As System.Xml.XmlNode
    Return AddBreak(m_objDOM.SelectSingleNode("//menuitem[@id='" & sParentID & "']"))
  End Function

  Public Function AddBreak(ByVal objParent As XmlNode) As System.Xml.XmlNode
    Dim objNode As XmlNode = m_objDOM.CreateNode(XmlNodeType.Element, "menubreak", "")
    objParent.AppendChild(objNode)
    Return objNode
  End Function

  Public Function RemoveMenuItem(ByVal sID As String) As Boolean
    Dim objNode As XmlNode = m_objDOM.SelectSingleNode("//menuitem[@id='" & sID & "']")
    If TypeName(objNode) = "XmlElement" Then
      objNode.ParentNode.RemoveChild(objNode)
    End If
  End Function

  Public Sub SetMenuItemAttribute(ByVal oMenuItem As XmlNode, ByVal sAttrName As String, ByVal sVal As String)
    Dim oAttr As XmlAttribute

    oAttr = oMenuItem.OwnerDocument.CreateAttribute(sAttrName)
    oAttr.Value = sVal
    oMenuItem.Attributes.Append(oAttr)
  End Sub

  Public Sub BindDataTable(ByVal dt As DataTable, Optional ByVal sParentId As String = Nothing, Optional ByVal sIdCol As String = "id", Optional ByVal sParentIdCol As String = "parent_id", Optional ByVal sTitleCol As String = "title", Optional ByVal sUrlCol As String = "url", Optional ByVal sImageCol As String = "image", Optional ByVal sSortCol As String = "sequence")
    'Binding the menu to a datatable is accomplished throug the new BindDataTable method
    'your table needs to have the following columns (although they can be named whatever you want - simply pass in the appropriate column names as optional parameters)
    '----------------------
    'id - unique numeric id
    'parent_id - id of its parent (null or -1 if top level)
    'title - text of menuitem
    'url - navigation url (nullable)
    'image - url of the image (nullable)
    'sequence - order for menu items within a parent (nullable)

    Dim dr As DataRow
    Dim aryRows() As DataRow
    Dim oNode As XmlNode

    If Not sParentId Is Nothing AndAlso sParentId.Length > 0 Then
      aryRows = dt.Select(sParentIdCol & " = " & sParentId, sSortCol)
    Else
      aryRows = dt.Select(sParentIdCol & " is null OR " & sParentIdCol & " = -1", sSortCol)
    End If

    For Each dr In aryRows
      If dr.IsNull(sParentIdCol) OrElse CInt(dr(sParentIdCol)) = -1 Then
        oNode = Me.AddMenuItem(GetRowValue(dr, sIdCol), GetRowValue(dr, sTitleCol), GetRowValue(dr, sUrlCol))
      Else
        oNode = Me.AddMenuItem(GetRowValue(dr, sParentIdCol), GetRowValue(dr, sIdCol), GetRowValue(dr, sTitleCol), GetRowValue(dr, sUrlCol))
      End If

      If GetRowValue(dr, sImageCol).Length > 0 Then
        SetMenuItemAttribute(oNode, "image", GetRowValue(dr, sImageCol))
      End If

      BindDataTable(dt, GetRowValue(dr, sIdCol))
    Next
  End Sub

  Private Function GetRowValue(ByVal dr As DataRow, ByVal sCol As String) As String
    If dr.Table.Columns.Contains(sCol) = False OrElse dr.IsNull(sCol) Then
      Return ""
    Else
      Return CStr(dr(sCol))
    End If
  End Function


#End Region

#Region "Overridden Functions"

  Protected Overrides Sub Render(ByVal output As System.Web.UI.HtmlTextWriter)

    If HasControls() Then
      If TypeOf Controls(0) Is LiteralControl Then
        MenuData = CType(Controls(0), LiteralControl).Text
      End If
    End If

    If Len(MenuData) > 0 Then
      'ideally this value should be validated against a schema
      m_objDOM.LoadXml(MenuData)
    End If
    If Len(MenuDataXMLFileName) > 0 Then
      'ideally this value should be validated against a schema
      m_objDOM.Load(Me.Page.Server.MapPath(MenuDataXMLFileName))
    End If
    If IsCoolBrowser() Then
      output.Write(GenerateCachedMenuHTML())
    Else
      output.Write(GenerateMenuHTML())
    End If

    'output.Write(MenuData())
  End Sub

  Protected Overrides Sub OnPreRender(ByVal e As System.EventArgs)
    Dim sScript As String
    Dim sSPMenuContainerStyle As String
    If DownLevelBrowser() Then
      'Nutscape GPFs if we have position: relative in IBuySpyPortal!
      sSPMenuContainerStyle = ".spmbctr {display: block; " & MyIIf(Len(BackgroundMenuImage) > 0, "background-image:url(" & SystemImagesPath & BackgroundMenuImage & ")", "") & ";" & MenuStyle & ";}"
    Else
      sSPMenuContainerStyle = ".spmbctr {position: relative; display: block; " & MyIIf(Len(BackgroundMenuImage) > 0, "background-image:url(" & SystemImagesPath & BackgroundMenuImage & ")", "") & ";" & MenuStyle & "; vertical-align: center}"
    End If
    Dim sSPMenuBarStyle As String = ".spmbar {cursor: pointer; cursor: hand; " & MenuItemFontStyle & "; border: " & GetColor(BackColor) & " 1px none;" & MyIIf(MenuBarHeight > 0, "height: " & MenuBarHeight & "px;", "") & ";}"
    Dim sSPMenuItemStyle As String = ".spmitm {color: " & GetColor(ForeColor) & "; cursor: pointer; cursor: hand; 1px solid;}"
    Dim sSPMenuItemRowStyle As String = ".spmitmr {" & MenuItemFontStyle & "}"
    Dim sSPSubMenuStyle As String = ".spsub {z-index: 1000; position: absolute; cursor: pointer; cursor: hand; " & MenuEffects.Style & "}"
    Dim sSPMenuStyle As String = ".spmenu {" & MenuStyle & "}"
    Dim sSPMenuIconStyle As String = ".spmicn {cursor: pointer; cursor: hand; background-color: " & GetColor(IconBackgroundColor) & "; border-left: " & GetColor(IconBackgroundColor) & " 1px solid; border-bottom: " & GetColor(IconBackgroundColor) & " 1px solid; border-top: " & GetColor(IconBackgroundColor) & " 1px solid; border-right: " & GetColor(BackColor) & " 0px none; text-align: center; width: " & IconWidth.ToString & "px;" & MyIIf(MenuItemHeight > 0, "height: " & MenuItemHeight & ";", "") & "}"
    Dim sSPMenuArrowStyle As String = ".spmarw {font-family: webdings; font-size: " & Font.Size.ToString & "px; cursor: pointer; cursor: hand;}"
    Dim sSPBreakStyle As String = ".spbrk {border-top: " & GetColor(ShadowColor) & " 1px solid; border-bottom: " & GetColor(BackColor) & " 1px solid; border-left: 0px; border-right: 0px; background-color: " & GetColor(HighlightColor) & "; height: 1px;}"

    If Not Page.IsClientScriptBlockRegistered("solpartmenuscript") Then
      If SystemScriptPath.Length > 0 Then
        'if systemscriptpath specified then simply declare constants
        'if performance is a concern then use a scriptpath so the .js file can be cached on the client

        sScript = "var SPM_COLOR = """ & GetColor(BackColor) & """;"
        sScript = sScript & "var SPM_FORECOLOR = """ & GetColor(ForeColor) & """;"
        sScript = sScript & "var SPM_HIGHLIGHTCOLOR = """ & GetColor(HighlightColor) & """;"
        sScript = sScript & "var SPM_SHADOWCOLOR = """ & GetColor(ShadowColor) & """;"
        sScript = sScript & "var SPM_ICONBACKGROUNDCOLOR = """ & GetColor(IconBackgroundColor) & """;"
        sScript = sScript & "var SPM_SELECTEDBORDERCOLOR = """ & GetColor(SelectedBorderColor) & """;"
        sScript = sScript & "var SPM_SELECTEDCOLOR = """ & GetColor(SelectedColor) & """;"
        sScript = sScript & "var SPM_SELECTEDFORECOLOR = """ & GetColor(SelectedForeColor) & """;"
        sScript = sScript & "var SPM_MOUSEOVERDISPLAY = """ & Me.MenuEffects.MouseOverDisplay.ToString & """;"
        sScript = sScript & "var SPM_MOUSEOVEREXPAND = """ & Val(Me.MenuEffects.MouseOverExpand) & """;"
        sScript = sScript & "var SPM_MOUSEOUTDELAY = " & Me.MenuEffects.MouseOutHideDelay & ";"

        '--- Fix transition ---'
        sScript = sScript & "var SPM_HANDLETRANSITION = " & MyIIf(IsCoolBrowser(), "true", "false") & ";"

        sScript = sScript & "var SPM_DISPLAYVERTICAL = " & (Display = "Vertical").ToString.ToLower & ";"    '--- if displaying vertical we need to notify the script ---'

        sScript = sScript & "var SPM_UNIQUEID = '" & Me.UniqueID & "';"     '--- send down unique id so we can call __doPostBack ---'

        Page.RegisterClientScriptBlock("solpartmenuscript", "<SCRIPT>" & sScript & vbCrLf & GetMenuTransitionScript() & "</SCRIPT>")

        sScript = Page.GetPostBackClientEvent(Me, "") 'make sure we render this on client

        Select Case BrowserType.Browser
          Case "IE"
            sScript = "spmenu-ie.js"
          Case "Netscape"
            If BrowserType.MajorVersion >= 5 Then
              sScript = "spmenu-ns6.js"
            Else
              sScript = "spmenu-all.js"
            End If
          Case Else
            sScript = "spmenu-all.js"
        End Select

        Page.RegisterClientScriptBlock("solpartmenuscriptref", "<SCRIPT SRC=""" & SystemScriptPath & sScript & """></SCRIPT>")

      Else
        Select Case BrowserType.Browser
          Case "IE"
            sScript = m_objRes.GetString("spmenu-ie")
          Case "Netscape"
            If BrowserType.MajorVersion >= 5 Then
              sScript = m_objRes.GetString("spmenu-ns6")
            Else
              sScript = m_objRes.GetString("spmenu-all")
            End If
          Case Else
            sScript = m_objRes.GetString("spmenu-all")
        End Select
        sScript = sScript.Replace("SPM_COLOR", """" & GetColor(BackColor) & """").Replace("SPM_FORECOLOR", """" & GetColor(ForeColor) & """")
        sScript = sScript.Replace("SPM_HIGHLIGHTCOLOR", """" & GetColor(HighlightColor) & """").Replace("SPM_SHADOWCOLOR", """" & GetColor(ShadowColor) & """")
        sScript = sScript.Replace("SPM_ICONBACKGROUNDCOLOR", """" & GetColor(IconBackgroundColor) & """")
        sScript = sScript.Replace("SPM_SELECTEDBORDERCOLOR", """" & GetColor(SelectedBorderColor) & """")
        sScript = sScript.Replace("SPM_SELECTEDCOLOR", """" & GetColor(SelectedColor) & """").Replace("SPM_SELECTEDFORECOLOR", """" & GetColor(SelectedForeColor) & """")
        sScript = sScript.Replace("SPM_DISPLAYVERTICAL", (Display = "Vertical").ToString.ToLower)    '--- if displaying vertical we need to notify the script ---'
        sScript = sScript & "var SPM_MOUSEOVERDISPLAY = """ & Me.MenuEffects.MouseOverDisplay.ToString & """;"
        sScript = sScript & "var SPM_MOUSEOVEREXPAND = """ & Val(Me.MenuEffects.MouseOverExpand) & """;"
        sScript = sScript & "var SPM_MOUSEOUTDELAY = " & Me.MenuEffects.MouseOutHideDelay.ToString & ";"
        sScript = sScript & "var SPM_UNIQUEID = '" & Me.UniqueID & "';"     '--- send down unique id so we can call __doPostBack ---'

        Page.RegisterClientScriptBlock("solpartmenuscript", "<SCRIPT>" & sScript & vbCrLf & GetMenuTransitionScript() & "</SCRIPT>")
        sScript = "var SPM_HANDLETRANSITION = " & MyIIf(m_objMenuEffects.MenuTransition.Length > 0, "true", "false") & ";"    '--- I know IE 4 had transitions and filters but not sure if it supports all the ones this menu is using ---'
        Page.RegisterClientScriptBlock("solpartmenuscripttransition", "<SCRIPT>" & sScript & vbCrLf & GetMenuTransitionScript() & "</SCRIPT>")

        sScript = Page.GetPostBackClientEvent(Me, "") 'make sure we render this on client

      End If

      'are we using data islands?
      If IsCoolBrowser() Then
        If SystemScriptPath.Length > 0 Then    'if using external script files
          Page.RegisterClientScriptBlock("solpartmenucachescriptref", "<SCRIPT SRC=""" & SystemScriptPath & "spmenu-iecache.js""></SCRIPT>")
        Else
          Page.RegisterClientScriptBlock("solpartmenucachescriptref", "<SCRIPT>" & m_objRes.GetString("spmenu-iecache") & "</SCRIPT>")
        End If
      End If

      Page.RegisterClientScriptBlock("styles", "<STYLE>" & vbCrLf & _
       sSPMenuContainerStyle & vbCrLf & _
       sSPMenuBarStyle & vbCrLf & _
       sSPMenuItemStyle & vbCrLf & _
       sSPMenuStyle & vbCrLf & _
       sSPSubMenuStyle & vbCrLf & _
       sSPMenuIconStyle & vbCrLf & _
       sSPMenuArrowStyle & vbCrLf & _
       sSPMenuItemRowStyle & vbCrLf & _
       sSPBreakStyle & vbCrLf & _
       "</STYLE>")

    End If
  End Sub
#End Region

#Region "Private Functions"
  Private Function GenerateCachedMenuHTML() As String
    'cache data on xml data island.
    Dim sHTML As String

    sHTML = "<span id=""divCacheMenu"" Display=""" & Me.Display & """ BackColor=""" & GetColor(Me.BackColor) & """ Moveable=""" & Val(Me.Moveable) & """ MenuBorderStyle=""" & Me.MenuBorderStyle & """ IconBackgroundColor=""" & GetColor(Me.IconBackgroundColor) & """ MenuAlignment=""" & Me.MenuAlignment & """ SystemImagesPath=""" & Me.SystemImagesPath & """ ArrowImage=""" & Me.ArrowImage & """ RootArrow=""" & Me.RootArrow & """ ></span>"
    If Len(Me.MenuDataXMLFileName) > 0 Then
      sHTML = sHTML & "<xml id=""SolpartMenuDI"" src=""" & Me.MenuDataXMLFileName & """ ondatasetcomplete=""GenerateMenuHTML(this, document.all('divCacheMenu'))""/>"
    Else
      sHTML = sHTML & "<xml id=""SolpartMenuDI"" ondatasetcomplete=""GenerateMenuHTML(this, document.all('divCacheMenu'))"">" & m_objDOM.InnerXml & "</xml>"
    End If

    Return sHTML
  End Function

  Private Function GenerateMenuHTML() As String
    'Generates the main menu bar
    Dim sHTML As String

    If Display = "Vertical" Then
      sHTML = _
      "<TABLE ID='tblMenuBar' CELLPADDING=""0"" CELLSPACING=""0"" BORDER='0' BGCOLOR='" & GetColor(BackColor) & "' CLASS='spmbctr' HEIGHT='100%' TABINDEX='0' onfocus='menuhook_MenuFocus();'>" & vbCrLf & _
      "	<TR ID='trMenuBar' >" & vbCrLf & _
      MyIIf(Moveable, "       <TD height=""3px"" style=""cursor: move; " & MenuBorderStyle & """ onmousedown=""menuhook_MouseDown(this)"" onmouseup=""menuhook_MouseUp(this)"" onmousemove=""menuhook_MouseMove(event)"">" & GetSpacer() & "</TD>", "") & vbCrLf & _
      "   </TR>" & vbCrLf & _
       GetMenuItems(m_objDOM.DocumentElement) & vbCrLf & _
      "       <TR><TD HEIGHT='100%'>" & GetSpacer() & "</TD>" & vbCrLf & _
   "   </TR>" & vbCrLf & _
   "</TABLE>" & vbCrLf
    Else
      sHTML = _
      "<TABLE ID='tblMenuBar' CELLPADDING=""0"" CELLSPACING=""0"" BORDER='0' BGCOLOR='" & GetColor(BackColor) & "' CLASS='spmbctr' WIDTH='100%' TABINDEX='0' onfocus='menuhook_MenuFocus();' onkeydown='menuhook_KeyDown();' onkeypress='menuhook_KeyPress();'>" & vbCrLf & _
      "	<TR ID='trMenuBar' >" & vbCrLf & _
      MyIIf(Moveable, "       <TD width=""3px"" style=""cursor: move; " & MenuBorderStyle & """ onmousedown=""menuhook_MouseDown(this)"" onmouseup=""menuhook_MouseUp(this)"" onmousemove=""menuhook_MouseMove(event)"">" & GetSpacer() & "</TD>", "") & vbCrLf & _
      GetMenuSpacingImage("left") & vbCrLf & _
       GetMenuItems(m_objDOM.DocumentElement) & vbCrLf & _
      GetMenuSpacingImage("right") & vbCrLf & _
      "   </TR>" & vbCrLf & _
      "</TABLE>" & vbCrLf
    End If

    If Len(m_sSelectedMenuPath) > 0 Then
      'if downgraded browser we may have a path.  Show that path above the menu
      sHTML = "<TABLE WIDTH=""100%""><TR><TD><FONT SIZE=""1"" CLASS=""spmitm"">" & m_sSelectedMenuPath & "</FONT></TD></TR><TR><TD>" & sHTML & "</TD></TR></TABLE>" & vbCrLf & vbCrLf & m_sOuterTables
    Else
      'upgraded browser, show the main menu bar then pass the HTML for the submenus (note: they are not visible yet)
      sHTML = sHTML & vbCrLf & vbCrLf & m_sOuterTables
    End If
    Return sHTML

  End Function

  Function GetMenuItems(ByVal objParent As XmlNode) As String
    Dim objNode As XmlNode
    Dim sHTML As String
    Dim sID As String
    Dim sParentID As String
    Dim sClickAction As String

    If Len(m_sSelectedMenuItemID) > 0 And DownLevelBrowser() Then
      'if downgraded browser then grab the selected menu item and show its children
      objParent = m_objDOM.SelectSingleNode("//menuitem[@id='" & m_sSelectedMenuItemID & "']")
      objNode = objParent
      Do Until objNode.Name <> "menuitem"
        m_sSelectedMenuPath = objNode.Attributes("title").Value.ToString & " \ " & m_sSelectedMenuPath
        objNode = objNode.ParentNode
      Loop
    End If

    For Each objNode In objParent
      'determine if root level item and set parent id accordingly
      If objNode.ParentNode.Name <> "menuitem" Then
        sParentID = "-1"
      Else
        sParentID = objNode.ParentNode.Attributes("id").Value.ToString
      End If
      If objNode.Name = "menuitem" Then
        sID = objNode.Attributes("id").Value.ToString
      Else
        sID = ""
      End If
      If DownLevelBrowser() Then
        'downlevelbrowser so render the ugly menu
        If objNode.Name = "menuitem" Then
          If Display = "Vertical" Then sHTML = sHTML & "<TR>" 'if vertical display then add rows for each top menuitem
          sHTML += "<TD id=""td" & sID & """ style=""cursor: pointer; cursor: hand; " & MenuStyle & """ NOWRAP>&nbsp;&nbsp;" & vbCrLf & _
           "<A HREF=""" & GetUglyMenuURL(objNode) & """ STYLE=""text-decoration: none;""><FONT STYLE=""" & MenuItemFontStyle & """ COLOR=""" & GetColor(ForeColor) & """>" & objNode.Attributes("title").Value.ToString & "</FONT></A>" & vbCrLf & _
           "&nbsp;&nbsp;</TD>" & vbCrLf
          If Display = "Vertical" Then sHTML = sHTML & "</TR>"
        End If
      Else    'uplevel browser
        If sParentID = "-1" Then    'if top level menu item
          If Len(GetMenuClickAction(objNode)) = 0 Then
            'if no URL associated then display sub menu
            sClickAction = "mb_c(this)"
          Else
            'top level menu item has URL so navigate to it when clicked
            sClickAction = GetMenuClickAction(objNode)
          End If
          If Display = "Vertical" Then sHTML = sHTML & "<TR>" 'if vertical display then add rows for each top menuitem
          sHTML = sHTML & "   <TD id=""td" & sID & """ class=""spmbar"" onclick=""" & sClickAction & """ onmousedown=""mb_md(this)"" onmouseup=""mb_mu(this)"" onmouseover=""mb_mo(this)"" onmouseout=""mb_mout(this)"" NOWRAP><table width=""100%""><tr class=""spmbar""><td class=""spmitm"" NOWRAP style=""" & GetMenuItemStyle("item", objNode) & """>&nbsp;" & Replace(objNode.Attributes("title").Value.ToString, " ", "&nbsp;") & MyIIf(Me.RootArrow, "</td><td class=""spmarw"" align=""right"" NOWRAP>" & GetArrow() & "", "&nbsp;") & "</td></tr></table></TD>" & vbCrLf
          If Display = "Vertical" Then sHTML = sHTML & "</TR>"
        Else         'submenu - not top level menu item
          Select Case objNode.Name
            Case "menuitem"
              sHTML = sHTML & _
                "   <TR ID=""tr" & sID & """ parentID=""" & sParentID & """ onclick=""mbi_c(this);" & GetMenuClickAction(objNode) & """ onmouseover=""mbi_mo(this)"" onmouseout=""mbi_mout(this)"" class=""spmitmr"" style=""" & GetMenuItemStyle("item", objNode) & """>" & vbCrLf & _
                "       <TD id=""icon" & sID & """ class=""spmicn"" style=""" & GetMenuItemStyle("image", objNode) & """>" & GetImage(objNode.Attributes("image")) & "</TD>" & _
                "       <TD id=""td" & sID & """ class=""spmitm"" NOWRAP >" & objNode.Attributes("title").Value.ToString & "</TD>" & _
                "       <TD id=""arrow" & sID & """ width=""15px"" CLASS=""spmarw"">" & MyIIf(objNode.ChildNodes.Count > 0, GetArrow(), GetSpacer()) & "</TD>" & _
                "   </TR>" & vbCrLf
            Case "menubreak"
              If IconBackgroundColor.Equals(BackColor) Then
                sHTML = sHTML & _
                  "   <TR>" & vbCrLf & _
                  "       <TD NOWRAP height=""0px"" colspan=""3"" class=""spbrk"">" & GetSpacer() & "</TD>" & _
                  "   </TR>" & vbCrLf
              Else
                sHTML = sHTML & _
                  "   <TR>" & vbCrLf & _
                  "       <TD style=""height: 0px"" class=""spmicn"">" & GetSpacer() & "</TD>" & _
                  "       <TD NOWRAP height=""0px"" colspan=""2"" class=""spbrk"">" & GetSpacer() & "</TD>" & _
                  "   </TR>" & vbCrLf
              End If
          End Select
        End If

        'Generate sub menu - note: we are recursively calling ourself
        'netscape renders tables with display: block as having cellpadding!!! therefore using div outside table - LAME!
        If objNode.ChildNodes.Count > 0 Then
          m_sOuterTables = "<DIV ID=""tbl" & sID + """ CLASS=""spsub"" STYLE=""display:none;""><TABLE BGCOLOR=""" & GetColor(BackColor) & """ CELLPADDING=""0"" CELLSPACING=""0"" CLASS=""spmenu"">" & _
            GetMenuItems(objNode) & _
            "</TABLE></DIV>" & vbCrLf & vbCrLf & m_sOuterTables
        End If
      End If
    Next

    Return sHTML

  End Function

  Private Function GetUglyMenuURL(ByVal objNode As XmlNode) As String
    'for downlevel browser we need to generate a post for every click on the item
    Select Case True
      Case objNode.Attributes("url") Is Nothing OrElse objNode.ChildNodes.Count > 0 'if node has children then we must allow them to be navigated to
        Return Page.GetPostBackClientHyperlink(Me, objNode.Attributes("id").Value.ToString)
        'Return Page.GetPostBackClientEvent(Me, objNode.Attributes("id").Value.ToString)
      Case objNode.Attributes("url").Value.Length > 0
        Return objNode.Attributes("url").Value.ToString
      Case Else
        Return Page.GetPostBackClientHyperlink(Me, objNode.Attributes("id").Value.ToString)
    End Select

  End Function

  Private Function GetArrow() As String
    If Len(ArrowImage) > 0 Then
      Return GetImage(ArrowImage)
    Else
      Return "4"   'defaults to using wingdings font (4 = arrow)
    End If
  End Function

  Private Function GetMenuItemStyle(ByVal sType As String, ByVal objNode As XmlNode) As String
    Dim sStyle As String = ""
    If IsNothing(objNode.Attributes(sType & "style")) = False Then
      sStyle &= objNode.Attributes(sType & "style").Value
    End If
    Return sStyle
  End Function

  Private Function GetMenuClickAction(ByVal objNode As XmlNode) As String
    'function to determine if menu item has action associated (URL)
    Select Case True
      Case Not objNode.Attributes("runat") Is Nothing 'assume server for now
        Return Page.GetPostBackClientEvent(Me, objNode.Attributes("id").Value.ToString)
      Case Not objNode.Attributes("server") Is Nothing 'cannot have menudata of runat=server. it confuses asp.net
        Return Page.GetPostBackClientEvent(Me, objNode.Attributes("id").Value.ToString)
      Case objNode.Attributes("url") Is Nothing
        Return ""
      Case objNode.Attributes("url").Value.Length > 0
        If objNode.Attributes("url").Value.ToLower().StartsWith("javascript:") Then
          Return objNode.Attributes("url").Value.ToString().Remove(0, "javascript:".Length) & ";"
        Else
          Return "document.location.href='" & objNode.Attributes("url").Value.ToString & "';"
        End If
      Case Else
        Return ""
    End Select
  End Function

  Private Function GetMenuTransitionScript() As String
    Dim s As String

    Select Case m_objMenuEffects.MenuTransition
      Case "None"
        s = ""
      Case "AlphaFade"
        s = "if (msTransitionStarted.indexOf(objMenu.id + ',') == -1) {" & vbCrLf & _
        "           eval('doFilter(""' + objMenu.id + '"", 0)'); " & vbCrLf & _
        "           msTransitionStarted += objMenu.id + ',';}" & vbCrLf & _
        "       }" & vbCrLf & _
        "       var msTransitionStarted = '';" & vbCrLf & _
        "       function doFilter(sMenuID, iOpacity) {" & vbCrLf & _
        "           document.all[sMenuID].filters(""DXImageTransform.Microsoft.Alpha"").opacity = iOpacity;" & vbCrLf & _
        "           if (iOpacity < 100)" & vbCrLf & _
        "               setTimeout('doFilter(""' + sMenuID + '"",' + (iOpacity + (100/(20*" & m_objMenuEffects.MenuTransitionLength & ")) ) + ')', 50);"
      Case "Wave"
        s = "if (msTransitionStarted.indexOf(objMenu.id + ',') == -1) {" & vbCrLf & _
        "           eval('doFilter(""' + objMenu.id + '"", 0)'); " & vbCrLf & _
        "           msTransitionStarted += objMenu.id + ',';}" & vbCrLf & _
        "       }" & vbCrLf & _
        "       var msTransitionStarted = ''" & vbCrLf & _
        "       function doFilter(sMenuID, iPhase) {" & vbCrLf & _
        "           document.all[sMenuID].filters(""DXImageTransform.Microsoft.Wave"").freq = 1;" & vbCrLf & _
        "           document.all[sMenuID].filters(""DXImageTransform.Microsoft.Wave"").lightstrength = 20;" & vbCrLf & _
        "           document.all[sMenuID].filters(""DXImageTransform.Microsoft.Wave"").strength = 5;" & vbCrLf & _
        "           document.all[sMenuID].filters(""DXImageTransform.Microsoft.Wave"").phase = iPhase;" & vbCrLf & _
        "           if (iPhase < 100 * " & m_objMenuEffects.MenuTransitionLength & ")" & vbCrLf & _
        "               setTimeout('doFilter(""' + sMenuID + '"",' + (iPhase + 5) + ')', 50);" & vbCrLf & _
        "           else {" & vbCrLf & _
        "               msTransitionStarted = msTransitionStarted.replace(sMenuID + ',', '');" & vbCrLf & _
        "               document.all[sMenuID].filters(""DXImageTransform.Microsoft.Wave"").freq = 0;" & vbCrLf & _
        "               document.all[sMenuID].filters(""DXImageTransform.Microsoft.Wave"").lightstrength = 0;" & vbCrLf & _
        "               document.all[sMenuID].filters(""DXImageTransform.Microsoft.Wave"").phase = 0;" & vbCrLf & _
        "               document.all[sMenuID].filters(""DXImageTransform.Microsoft.Wave"").strength = 0;" & vbCrLf & _
        "               }"
      Case "ConstantWave"
        s = "if (msTransitionStarted.indexOf(objMenu.id + ',') == -1) {" & vbCrLf & _
        "           eval('doFilter(""' + objMenu.id + '"", 0)'); " & vbCrLf & _
        "           msTransitionStarted += objMenu.id + ',';}" & vbCrLf & _
        "       }" & vbCrLf & _
        "       var msTransitionStarted = '';" & vbCrLf & _
        "       function doFilter(sMenuID, iPhase) {" & vbCrLf & _
        "           document.all[sMenuID].filters(""DXImageTransform.Microsoft.Wave"").freq = 1;" & vbCrLf & _
        "           document.all[sMenuID].filters(""DXImageTransform.Microsoft.Wave"").lightstrength = 20;" & vbCrLf & _
        "           document.all[sMenuID].filters(""DXImageTransform.Microsoft.Wave"").strength = 1;" & vbCrLf & _
        "           document.all[sMenuID].filters(""DXImageTransform.Microsoft.Wave"").phase = iPhase;" & vbCrLf & _
        "           setTimeout('doFilter(""' + sMenuID + '"",' + (iPhase + 5) + ')', " & m_objMenuEffects.MenuTransitionLength * 100 & ");" & vbCrLf

      Case "Inset", "RadialWipe", "Slide", "Spiral", "Stretch", "Strips", "Wheel", "GradientWipe", "Zigzag", "Barn", "Blinds", "Checkerboard", "Fade", "Iris", "RandomBars"
        s = "objMenu.filters(""DXImageTransform.Microsoft." & m_objMenuEffects.MenuTransition & """).apply();" & vbCrLf & _
        "objMenu.filters(""DXImageTransform.Microsoft." & m_objMenuEffects.MenuTransition & """).duration = " & m_objMenuEffects.MenuTransitionLength & ";" & vbCrLf & _
        "objMenu.filters(""DXImageTransform.Microsoft." & m_objMenuEffects.MenuTransition & """).play();"
    End Select
    Return "function spm_doTransition(objMenu) {" & s & "}"
  End Function

  Private Function GetMenuSpacingImage(ByVal sPos As String) As String
    Select Case True
      Case (sPos = "left" And MenuAlignment = "Right") Or (sPos = "right" And MenuAlignment = "Left")
        Return "       <TD width=""100%"">" & GetSpacer() & "</TD>"

      Case (sPos = "right" And MenuAlignment = "Left") Or (sPos = "left" And MenuAlignment = "Right")
        Return "       <TD width=""3px"">" & GetSpacer() & "</TD>"
      Case MenuAlignment = "Center"
        Return "       <TD width=""33%"">" & GetSpacer() & "</TD>"
    End Select

  End Function


  Private Function DownLevelBrowser() As Boolean
    'determines if browser is downlevel
    Select Case True
      Case ForceDownlevel
        Return True
      Case (BrowserType.Browser = "IE" And BrowserType.MajorVersion > 4) Or (BrowserType.Browser = "Netscape" And BrowserType.MajorVersion >= 5)
        Return False
      Case Else
        Return True
    End Select
  End Function

  Private Function BrowserType() As System.Web.HttpBrowserCapabilities
    Return Me.Page.Request.Browser
  End Function

  Public Sub RaisePostBackEvent(ByVal eventArgument As String) Implements System.Web.UI.IPostBackEventHandler.RaisePostBackEvent
    'called on downlevel browsers when menu item is clicked
    'store selected menu item id
    m_sSelectedMenuItemID = eventArgument
    RaiseEvent MenuClick(eventArgument)
  End Sub

  Private Function GetSpacer() As String
    'unfortunately the menu bar relys on a transparent gif called spacer.gif.
    'I wanted to have no dependencies outside the solpartwebcontrols but found no way to send the 
    'binary for the spacer down when stored in a resource file.  If you know of a way to do this send me an email:  jhenning@solpart.com
    Return "<IMG SRC=""" & SystemImagesPath & "spacer.gif"">"
  End Function

  Private Function GetImage(ByVal sImage As String) As String
    'generates html for image using the SystemImagesPath property
    If Len(sImage) > 0 Then
      Return "<IMG SRC=""" & SystemImagesPath & sImage & """>"
    End If
  End Function

  Private Function GetImage(ByVal objAttr As XmlAttribute) As String
    'retrieves an image for a passed in XMLAttribute
    If objAttr Is Nothing Then
      Return GetImage("spacer.gif")
    Else
      Return GetImage(objAttr.Value.ToString)
    End If
  End Function

  Private Function MyIIf(ByVal bFlag As Boolean, ByVal sTrue As String, ByVal sFalse As String) As String
    'to get around option script conversion to object each time I am doing in central place
    Return CType(IIf(bFlag, CType(sTrue, Object), CType(sFalse, Object)), String)
  End Function

  Private Function IsCoolBrowser() As Boolean
    Return BrowserType.Browser = "IE" And (BrowserType.MajorVersion > 5 Or (BrowserType.MajorVersion + BrowserType.MinorVersion >= 5.5)) And ForceDownlevel = False
  End Function


#End Region

#Region "Overrides WebControl properties to suppress from showing in property window"
  <Browsable(False), Bindable(False)> _
  Public Overrides Property BorderColor() As Color
    Get

    End Get
    Set(ByVal Value As Color)

    End Set
  End Property

  <Browsable(False), Bindable(False)> _
  Public Overrides Property BorderStyle() As System.Web.UI.WebControls.BorderStyle
    Get

    End Get
    Set(ByVal Value As System.Web.UI.WebControls.BorderStyle)

    End Set
  End Property

  <Browsable(False), Bindable(False)> _
  Public Overrides Property CssClass() As String
    Get

    End Get
    Set(ByVal Value As String)

    End Set
  End Property

  <Browsable(False), Bindable(False)> _
  Public Overrides Property BorderWidth() As System.Web.UI.WebControls.Unit
    Get

    End Get
    Set(ByVal Value As System.Web.UI.WebControls.Unit)

    End Set
  End Property

  <Browsable(False), Bindable(False)> _
   Public Overrides Property Height() As System.Web.UI.WebControls.Unit
    Get

    End Get
    Set(ByVal Value As System.Web.UI.WebControls.Unit)

    End Set
  End Property

  <Browsable(False), Bindable(False)> _
    Public Overrides Property Width() As System.Web.UI.WebControls.Unit
    Get

    End Get
    Set(ByVal Value As System.Web.UI.WebControls.Unit)

    End Set
  End Property

#End Region

End Class
