Imports System.Windows.Forms
Imports SolpartWebControls.SolpartLib
Imports System.Xml

Public Class SolpartMenuDataDesignerForm
    Inherits System.Windows.Forms.Form

    Private m_sXML As String
    Private m_objXML As XML.XmlDocument = New XML.XmlDocument()
    Private m_objMenu As MainMenu = New MainMenu()
    Private m_objSelectedNode As XML.XmlNode

    Public Property XML() As String
        Get
            Return m_sXML
        End Get
        Set(ByVal Value As String)
            m_sXML = Value
        End Set
    End Property


#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    Public Sub New(ByVal sXML As String)
        MyBase.New()
        InitializeComponent()
        XML = sXML
    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents btnOk As System.Windows.Forms.Button
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lstSiblings As System.Windows.Forms.ListBox
    Friend WithEvents btnUp As System.Windows.Forms.Button
    Friend WithEvents btnDown As System.Windows.Forms.Button
    Friend WithEvents btnDelete As System.Windows.Forms.Button
    Friend WithEvents btnEdit As System.Windows.Forms.Button
    Friend WithEvents btnAddBreak As System.Windows.Forms.Button
    Friend WithEvents btnAdd As System.Windows.Forms.Button
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents cboParent As System.Windows.Forms.ComboBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(SolpartMenuDataDesignerForm))
        Me.btnOk = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lstSiblings = New System.Windows.Forms.ListBox()
        Me.btnUp = New System.Windows.Forms.Button()
        Me.btnDown = New System.Windows.Forms.Button()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.btnEdit = New System.Windows.Forms.Button()
        Me.btnAddBreak = New System.Windows.Forms.Button()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.cboParent = New System.Windows.Forms.ComboBox()
        Me.SuspendLayout()
        '
        'btnOk
        '
        Me.btnOk.Location = New System.Drawing.Point(173, 179)
        Me.btnOk.Name = "btnOk"
        Me.btnOk.Size = New System.Drawing.Size(68, 22)
        Me.btnOk.TabIndex = 1
        Me.btnOk.Text = "Ok"
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(246, 179)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(68, 22)
        Me.btnCancel.TabIndex = 2
        Me.btnCancel.Text = "Cancel"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(8, 33)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(50, 12)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Parent:"
        '
        'lstSiblings
        '
        Me.lstSiblings.Location = New System.Drawing.Point(7, 53)
        Me.lstSiblings.Name = "lstSiblings"
        Me.lstSiblings.Size = New System.Drawing.Size(285, 69)
        Me.lstSiblings.TabIndex = 14
        '
        'btnUp
        '
        Me.btnUp.Image = CType(resources.GetObject("btnUp.Image"), System.Drawing.Bitmap)
        Me.btnUp.Location = New System.Drawing.Point(295, 55)
        Me.btnUp.Name = "btnUp"
        Me.btnUp.Size = New System.Drawing.Size(19, 22)
        Me.btnUp.TabIndex = 16
        '
        'btnDown
        '
        Me.btnDown.Image = CType(resources.GetObject("btnDown.Image"), System.Drawing.Bitmap)
        Me.btnDown.Location = New System.Drawing.Point(295, 85)
        Me.btnDown.Name = "btnDown"
        Me.btnDown.Size = New System.Drawing.Size(19, 22)
        Me.btnDown.TabIndex = 17
        '
        'btnDelete
        '
        Me.btnDelete.Location = New System.Drawing.Point(225, 139)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(68, 22)
        Me.btnDelete.TabIndex = 19
        Me.btnDelete.Text = "Delete"
        '
        'btnEdit
        '
        Me.btnEdit.Location = New System.Drawing.Point(152, 139)
        Me.btnEdit.Name = "btnEdit"
        Me.btnEdit.Size = New System.Drawing.Size(68, 22)
        Me.btnEdit.TabIndex = 18
        Me.btnEdit.Text = "Edit"
        '
        'btnAddBreak
        '
        Me.btnAddBreak.Location = New System.Drawing.Point(80, 139)
        Me.btnAddBreak.Name = "btnAddBreak"
        Me.btnAddBreak.Size = New System.Drawing.Size(69, 22)
        Me.btnAddBreak.TabIndex = 21
        Me.btnAddBreak.Text = "Add Break"
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(7, 139)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(69, 22)
        Me.btnAdd.TabIndex = 20
        Me.btnAdd.Text = "Add"
        '
        'Label6
        '
        Me.Label6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label6.Location = New System.Drawing.Point(10, 171)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(301, 2)
        Me.Label6.TabIndex = 26
        '
        'cboParent
        '
        Me.cboParent.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboParent.Location = New System.Drawing.Point(58, 30)
        Me.cboParent.Name = "cboParent"
        Me.cboParent.Size = New System.Drawing.Size(234, 21)
        Me.cboParent.TabIndex = 27
        '
        'SolpartMenuDataDesignerForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(321, 234)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.cboParent, Me.Label6, Me.btnAddBreak, Me.btnAdd, Me.btnDelete, Me.btnEdit, Me.btnDown, Me.btnUp, Me.lstSiblings, Me.Label1, Me.btnCancel, Me.btnOk})
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "SolpartMenuDataDesignerForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Menu Designer"
        Me.ResumeLayout(False)

    End Sub

#End Region

#Region " Control Events "
    Private Sub SolpartMenuDataDesignerForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        RefreshMenu()

    End Sub

    Private Sub btnOk_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOk.Click
        If validData() Then
            XML = m_objXML.InnerXml
            Me.Close()
        End If
    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    Private Sub btnUp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUp.Click
        Dim iIndex As Integer = MoveItem(lstSiblings.SelectedIndex, -1)
        RefreshMenu()
        RefreshSiblingList(m_objSelectedNode.ParentNode, iIndex)

    End Sub

    Private Sub btnDown_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDown.Click
        Dim iIndex As Integer = MoveItem(lstSiblings.SelectedIndex, 1)
        RefreshMenu()
        RefreshSiblingList(m_objSelectedNode.ParentNode, iIndex)

    End Sub

    Private Sub btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd.Click

        Dim objNode As XmlNode

        objNode = ShowDetail(CStr(cboParent.SelectedValue), m_objXML.CreateNode(XmlNodeType.Element, "menuitem", ""))
        If Not objNode Is Nothing Then

            GetParentNode().InsertBefore(objNode, Nothing)

            RefreshMenu()
            RefreshSiblingList(objNode.ParentNode, lstSiblings.Items.Count - 1)
        End If
    End Sub

    Private Sub btnAddBreak_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddBreak.Click
        Dim objNode As XmlNode = m_objXML.CreateNode(XmlNodeType.Element, "menubreak", "")
        If cboParent.SelectedIndex > 0 Then
            GetParentNode().InsertBefore(objNode, Nothing)
            RefreshMenu()
            RefreshSiblingList(objNode.ParentNode, lstSiblings.Items.Count - 1)
        Else
            MsgBox("Cannot add break to root menu", MsgBoxStyle.Information)
        End If
    End Sub

    Private Sub btnEdit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEdit.Click
        EditMenuItem()
    End Sub

    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        Dim objParent As XmlNode = m_objSelectedNode.ParentNode
        If MsgBox("Are you sure you wish to delete the selected item?", CType(MsgBoxStyle.YesNo + MsgBoxStyle.Question, MsgBoxStyle)) = MsgBoxResult.Yes Then
            m_objSelectedNode.ParentNode.RemoveChild(m_objSelectedNode)
            RefreshMenu()
            RefreshSiblingList(objParent, lstSiblings.SelectedIndex)
        End If
    End Sub

    Private Sub lstSiblings_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles lstSiblings.DoubleClick
        If CType(sender, ListBox).SelectedIndex > -1 Then
            EditMenuItem()
        End If
    End Sub

    Private Sub lstSiblings_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstSiblings.SelectedIndexChanged
        m_objSelectedNode = CType(lstSiblings.SelectedItem, SelectedNodeItem).Node
    End Sub

    Private Sub cboParent_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboParent.SelectedIndexChanged
        If cboParent.SelectedIndex > 0 Then
            RefreshSiblingList(CType(cboParent.SelectedItem, SelectedNodeItem).Node)
        Else
            RefreshSiblingList(m_objXML.ChildNodes(0))
        End If
    End Sub

#End Region

#Region " Private Refresh Routines "
    Private Sub RefreshMenu()
        Dim iSelIndex As Integer

        m_objMenu = New MainMenu()
        iSelIndex = cboParent.SelectedIndex
        If iSelIndex = -1 Then iSelIndex = 0
        cboParent.Items.Clear()
        cboParent.Items.Add("<Root>")
        If m_objXML.InnerXml.Length = 0 Then
            If Len(XML) = 0 Then XML = "<root></root>"
            m_objXML.LoadXml(XML)
        End If
        RefreshMenuItems(m_objXML.ChildNodes(0), m_objMenu.MenuItems)
        Me.Menu = m_objMenu
        cboParent.SelectedIndex = iSelIndex

    End Sub

    Private Sub RefreshMenuItems(ByVal objParent As XML.XmlNode, ByVal objMenuItems As MenuItem.MenuItemCollection)
        Dim objNode As Xml.XmlNode
        Dim objItem As MenuItemNode
        For Each objNode In objParent
            objItem = New MenuItemNode(objNode)
            AddHandler objItem.Select, AddressOf MenuItemClick
            objMenuItems.Add(objItem)
            cboParent.Items.Add(New SelectedNodeItem(objNode))

            If objNode.ChildNodes.Count > 0 Then
                RefreshMenuItems(objNode, objItem.MenuItems)
            End If
        Next

    End Sub

    Private Sub RefreshSiblingList(ByVal objParent As XML.XmlNode, Optional ByVal iSelIndex As Integer = -1)
        Dim objNode As Xml.XmlNode

        lstSiblings.Items.Clear()
        For Each objNode In objParent.ChildNodes
            lstSiblings.Items.Add(New SelectedNodeItem(objNode))
        Next
        lstSiblings.SelectedIndex = iSelIndex
    End Sub


#End Region


    Private Sub MenuItemClick(ByVal sender As Object, ByVal e As EventArgs)
        Dim objItem As MenuItemNode = CType(sender, MenuItemNode)
        Dim sID As String
        Dim i As Integer
        Dim objNode As XmlNode

        m_objSelectedNode = objItem.Node

        RefreshSiblingList(m_objSelectedNode.ParentNode)

        If objItem.Node.ParentNode.Name = "menuitem" Then
            For i = 1 To cboParent.Items.Count - 1
                objNode = CType(cboParent.Items(i), SelectedNodeItem).Node
                If GetSafeAttribute(objNode, "id") = GetSafeAttribute(objItem.Node.ParentNode, "id") Then
                    cboParent.SelectedIndex = i
                    Exit For
                End If
            Next
        Else
            cboParent.SelectedIndex = 0
        End If

    End Sub

    Private Sub EditMenuItem()
        Dim objNode As XmlNode
        objNode = ShowDetail(CStr(cboParent.SelectedValue), m_objSelectedNode)
        If Not objNode Is Nothing Then
            RefreshMenu()
            RefreshSiblingList(objNode.ParentNode, lstSiblings.SelectedIndex)
        End If
    End Sub

    Private Function MoveItem(ByVal iIndex As Integer, ByVal iDir As Integer) As Integer
        If iIndex < 0 Then
            MsgBox("You must select an item to move")
            Return iIndex
        Else
            If iDir = -1 Then
                If iIndex = 0 Then
                    MsgBox("Cannot move")
                    Return iIndex
                End If
                m_objSelectedNode.ParentNode.InsertBefore(m_objSelectedNode.ParentNode.ChildNodes(iIndex), m_objSelectedNode.ParentNode.ChildNodes(iIndex + iDir))
            Else
                If iIndex >= lstSiblings.Items.Count - 1 Then
                    MsgBox("Cannot move down")
                    Return iIndex
                End If
                m_objSelectedNode.ParentNode.InsertAfter(m_objSelectedNode.ParentNode.ChildNodes(iIndex), m_objSelectedNode.ParentNode.ChildNodes(iIndex + iDir))
            End If
            Return iIndex + iDir
        End If
    End Function

    Private Function ShowDetail(ByVal sParentID As String, ByVal objNode As XmlNode) As XmlNode
        Dim objDetail As SolpartMenuDataDesignerForm2
        objDetail = New SolpartMenuDataDesignerForm2(sParentID, objNode)
        objDetail.ShowDialog()
        Return objDetail.EditNode
    End Function

    Private Function validData() As Boolean
        Dim sIDs As String
        Dim objNodes As XmlNodeList
        Dim objNode As XmlNode
        objNodes = m_objXML.SelectNodes("//menuitem")
        For Each objNode In objNodes
            If InStr(sIDs, GetSafeAttribute(objNode, "id") & ",") > 0 Then
                MsgBox("Duplicate ID: " & GetSafeAttribute(objNode, "title") & " - " & GetSafeAttribute(objNode, "id"))
                Return False
            Else
                sIDs += GetSafeAttribute(objNode, "id") & ","
            End If
        Next
        Return True
    End Function

    Private Function GetParentNode() As XmlNode
        If cboParent.SelectedIndex > 0 Then
            Return CType(cboParent.SelectedItem, SelectedNodeItem).Node
        Else
            Return m_objXML.ChildNodes(0)
        End If

    End Function

End Class


Public Class SelectedNodeItem
    Private m_objNode As XmlNode

    Public Property Node() As XmlNode
        Get
            Return m_objNode
        End Get
        Set(ByVal Value As XmlNode)
            m_objNode = Value
        End Set
    End Property
    Public Sub New(ByVal objNode As XmlNode)
        MyBase.new()
        Node = objNode
    End Sub
    Public Overrides Function ToString() As String
        If Node.Name = "menubreak" Then
            Return getIndent(Node) & "------------------"
        Else
            Return getIndent(Node) & GetSafeAttribute(Node, "title")
        End If
    End Function

    Private Function getIndent(ByVal objNode As XmlNode) As String
        Dim s As String
        Do Until objNode.ParentNode.Name <> "menuitem"
            s += "   "
            objNode = objNode.ParentNode
        Loop
        Return s
    End Function
End Class

Public Class MenuItemNode : Inherits MenuItem
    Private m_objNode As XmlNode

    Public Property Node() As XmlNode
        Get
            Return m_objNode
        End Get
        Set(ByVal Value As XmlNode)
            m_objNode = Value
        End Set
    End Property
    Public Sub New(ByVal objNode As XmlNode)
        MyBase.new()
        Node = objNode

        If Node.Name = "menuitem" Then
            Me.Text = GetSafeAttribute(Node, "title")
        Else
            Me.Text = "-"
        End If

    End Sub

End Class
