Graphics for the DotNetNuke portal

Created by: Jason Graves [Shuzo] 
Date: March 31, 2003
Email: Buddy109@sbcglobal.net
Site: http://kirannika.has.it

questions/comments appreciated but no liability or warranty is implied. 