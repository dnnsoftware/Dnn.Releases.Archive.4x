'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2003
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Namespace DotNetNuke

    Public Class EditModule

        Inherits DotNetNuke.BasePage

        Protected WithEvents Body As System.Web.UI.HtmlControls.HtmlContainerControl
        Protected WithEvents ScrollTop As System.Web.UI.HtmlControls.HtmlInputHidden

        Protected EditPane As System.Web.UI.HtmlControls.HtmlTableCell

        Protected WithEvents hypCopyright As System.Web.UI.WebControls.HyperLink

        Private moduleId As Integer = -1

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

#End Region

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            '
            ' CODEGEN: This call is required by the ASP.NET Web Form Designer.
            '
            InitializeComponent()

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            ' Determine ModuleId of Portal Module
            If Not (Request.Params("mid") Is Nothing) Then
                moduleId = Int32.Parse(Request.Params("mid"))
            End If

            Dim objAdmin As New AdminDB()

            ' get module container
            Dim settings As Hashtable = PortalSettings.GetModuleSettings(objAdmin.GetSiteModule("Site Settings", _portalSettings.PortalId))
            Dim strContainer As String = settings("container")

            Dim _moduleSettings As New ModuleSettings()

            ' initialize security
            _moduleSettings.Secure = True

            ' load module settings based on moduleid ( instance of desktopmodule )
            If moduleId <> -1 Then
                _moduleSettings = PortalSettings.GetEditModuleSettings(moduleId)
            End If

            ' load module definition by name
            If Not (Request.Params("def") Is Nothing) Then
                Dim dr As SqlDataReader = objAdmin.GetSingleModuleDefinitionByName(Request.Params("def"))
                If dr.Read Then
                    _moduleSettings.ModuleId = moduleId
                    _moduleSettings.ModuleDefId = Int32.Parse(dr("ModuleDefID").ToString)
                    _moduleSettings.TabId = _portalSettings.ActiveTab.TabId
                    _moduleSettings.PaneName = "Edit"
                    _moduleSettings.ModuleTitle = dr("FriendlyName").ToString
                    _moduleSettings.AuthorizedEditRoles = ""
                    _moduleSettings.EditSrc = dr("EditSrc").ToString
                    _moduleSettings.Secure = dr("Secure")
                    _moduleSettings.EditModuleIcon = dr("EditModuleIcon").ToString
                    _moduleSettings.ShowTitle = True
                    _moduleSettings.Personalize = 2
                    _moduleSettings.FriendlyName = dr("FriendlyName").ToString
                End If
                dr.Close()
            End If

            ' Verify that the current user has access to edit this module
            If _moduleSettings.Secure Then
                If PortalSecurity.IsInRole(_portalSettings.AdministratorRoleId.ToString) = False And PortalSecurity.IsInRoles(_portalSettings.ActiveTab.AdministratorRoles.ToString) = False Then
                    If (moduleId = -1 Or PortalSecurity.HasEditPermissions(moduleId) = False) Then
                        Response.Redirect("~/EditModule.aspx?tabid=" & _portalSettings.ActiveTab.TabId & "&def=Edit Access Denied")
                    End If
                End If
            End If

            ' load user control
            If _moduleSettings.EditSrc <> "" Then
                Try
                    Dim objModule As PortalModuleControl = CType(Me.LoadModule(_moduleSettings.EditSrc), PortalModuleControl)
                    objModule.ModuleConfiguration = _moduleSettings

                    If Not Request.Params("options") Is Nothing Then
                        Dim pnlOptions As Panel = objModule.FindControl("pnlOptions")
                        If Not pnlOptions Is Nothing Then
                            pnlOptions.Visible = True
                        End If
                        Dim pnlContent As Panel = objModule.FindControl("pnlContent")
                        If Not pnlContent Is Nothing Then
                            pnlContent.Visible = False
                        End If
                    End If

                    AddModule(EditPane, objModule, strContainer, _portalSettings.UploadDirectory)
                Catch objException As Exception
                    ' error loading user control - the file may have been deleted or moved
                    If InStr(1, Request.Url.ToString.ToLower, "localhost") Then
                        Throw objException
                    Else
                        EditPane.Controls.Add(New LiteralControl("<span class=""NormalRed"">Error Loading " & _moduleSettings.EditSrc & "</span>"))
                    End If
                End Try
            End If

            hypCopyright.Text = Replace(System.Diagnostics.FileVersionInfo.GetVersionInfo(System.Reflection.Assembly.GetExecutingAssembly.Location).LegalCopyright.ToString, "YYYY", Year(Now).ToString)
            hypCopyright.NavigateUrl = System.Diagnostics.FileVersionInfo.GetVersionInfo(System.Reflection.Assembly.GetExecutingAssembly.Location).ProductName.ToString
        End Sub

        Private Sub AddModule(ByVal objPane As HtmlTableCell, ByVal objModule As Control, ByVal strContainer As String, ByVal strUploadDirectory As String, Optional ByVal strAlignment As String = "", Optional ByVal strColor As String = "", Optional ByVal strBorder As String = "")

            Dim arrContainer As Array

            strContainer = Replace(strContainer, "[ALIGN]", IIf(strAlignment <> "", " align=""" & strAlignment & """", ""))
            strContainer = Replace(strContainer, "[COLOR]", IIf(strColor <> "", " bgcolor=""" & strColor & """", ""))
            strContainer = Replace(strContainer, "[BORDER]", IIf(strBorder <> "", " border=""" & strBorder & """", ""))
            strContainer = ManageUploadDirectory(strContainer, strUploadDirectory)

            arrContainer = Split(strContainer, "[MODULE]")

            objPane.Controls.Add(New LiteralControl(arrContainer(0)))
            objPane.Controls.Add(objModule)
            objPane.Controls.Add(New LiteralControl(arrContainer(1)))
            objPane.Visible = True

        End Sub

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            If ScrollTop.Value <> "" Then
                Body.Attributes.Add("onload", "javascript:Body.scrollTop=" & ScrollTop.Value & ";")
            End If
        End Sub

    End Class

End Namespace