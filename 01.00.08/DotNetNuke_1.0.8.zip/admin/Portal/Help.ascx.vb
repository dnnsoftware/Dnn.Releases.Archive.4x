Namespace ASPNetPortal

    Public Class Help
        Inherits ASPNetPortal.PortalModuleControl

        Protected WithEvents moduletitle1 As System.Web.UI.HtmlControls.HtmlGenericControl
        Protected WithEvents moduletitle2 As System.Web.UI.HtmlControls.HtmlGenericControl
        Protected WithEvents moduletitle3 As System.Web.UI.HtmlControls.HtmlGenericControl
        Protected WithEvents moduletitle4 As System.Web.UI.HtmlControls.HtmlGenericControl
        Protected WithEvents moduletitle5 As System.Web.UI.HtmlControls.HtmlGenericControl
        Protected WithEvents moduletitle6 As System.Web.UI.HtmlControls.HtmlGenericControl
        Protected WithEvents moduletitle7 As System.Web.UI.HtmlControls.HtmlGenericControl
        Protected WithEvents moduletitle8 As System.Web.UI.HtmlControls.HtmlGenericControl
        Protected WithEvents moduletitle9 As System.Web.UI.HtmlControls.HtmlGenericControl
        Protected WithEvents moduletitle10 As System.Web.UI.HtmlControls.HtmlGenericControl
        Protected WithEvents moduletitle11 As System.Web.UI.HtmlControls.HtmlGenericControl
        Protected WithEvents moduletitle12 As System.Web.UI.HtmlControls.HtmlGenericControl
        Protected WithEvents Image1 As System.Web.UI.WebControls.Image
        Protected WithEvents Image2 As System.Web.UI.WebControls.Image
        Protected WithEvents Image3 As System.Web.UI.WebControls.Image
        Protected WithEvents Image4 As System.Web.UI.WebControls.Image
        Protected WithEvents Image5 As System.Web.UI.WebControls.Image
        Protected WithEvents Image6 As System.Web.UI.WebControls.Image
        Protected WithEvents Image7 As System.Web.UI.WebControls.Image
        Protected WithEvents Image8 As System.Web.UI.WebControls.Image
        Protected WithEvents Image9 As System.Web.UI.WebControls.Image
        Protected WithEvents Image10 As System.Web.UI.WebControls.Image
        Protected WithEvents Image11 As System.Web.UI.WebControls.Image
        Protected WithEvents Image12 As System.Web.UI.WebControls.Image
        Protected WithEvents Image13 As System.Web.UI.WebControls.Image
        Protected WithEvents Image14 As System.Web.UI.WebControls.Image
        Protected WithEvents Image15 As System.Web.UI.WebControls.Image

        Protected WithEvents cmdCancel As System.Web.UI.WebControls.HyperLink

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        '*******************************************************
        '
        ' The Page_Load server event handler on this page is used
        ' to populate the role information for the page
        '
        '*******************************************************

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            If Page.IsPostBack = False Then
                ' Store URL Referrer to return to portal
                ViewState("UrlReferrer") = Request.UrlReferrer.ToString()
            End If
        End Sub

        Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs)
            Response.Redirect(CType(Viewstate("UrlReferrer"), String))
        End Sub

    End Class

End Namespace