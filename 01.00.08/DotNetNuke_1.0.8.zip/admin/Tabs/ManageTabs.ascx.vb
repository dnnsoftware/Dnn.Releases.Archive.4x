'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2003
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Namespace DotNetNuke

    Public Class ManageTabs
        Inherits DotNetNuke.PortalModuleControl

        Protected WithEvents tabName As System.Web.UI.WebControls.TextBox
        Protected WithEvents valtabName As System.Web.UI.WebControls.RequiredFieldValidator
        Protected WithEvents cboIcon As System.Web.UI.WebControls.DropDownList
        Protected WithEvents cmdUpload As System.Web.UI.WebControls.HyperLink
        Protected WithEvents cboTab As System.Web.UI.WebControls.DropDownList
        Protected WithEvents IsVisible As System.Web.UI.WebControls.CheckBox
        Protected WithEvents txtLeftPaneWidth As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtRightPaneWidth As System.Web.UI.WebControls.TextBox
        Protected WithEvents adminRoles As System.Web.UI.WebControls.CheckBoxList
        Protected WithEvents authRoles As System.Web.UI.WebControls.CheckBoxList
        Protected WithEvents showMobile As System.Web.UI.WebControls.CheckBox
        Protected WithEvents mobileTabName As System.Web.UI.WebControls.TextBox

        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdDelete As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCopy As System.Web.UI.WebControls.LinkButton

        Private strAction As String = ""

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        '*******************************************************
        '
        ' The Page_Load server event handler on this page is used
        ' to populate a tab's layout settings on the page
        '
        '*******************************************************

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            ' Verify that the current user has access to edit this module
            If PortalSecurity.IsInRoles(_portalSettings.AdministratorRoleId.ToString) = False And PortalSecurity.IsInRoles(_portalSettings.ActiveTab.AdministratorRoles.ToString) = False Then
                Response.Redirect("~/EditModule.aspx?tabid=" & TabId & "&def=Edit Access Denied")
            End If

            If Not (Request.Params("action") Is Nothing) Then
                strAction = Request.Params("action")
            End If

            If Page.IsPostBack = False Then

                cmdDelete.Attributes.Add("onClick", "javascript:return confirm('Are You Sure You Wish To Delete This Item ?');")

                ' load the list of files found in the upload directory
                cmdUpload.NavigateUrl = "~/EditModule.aspx?tabid=" & TabId & "&def=File Manager"
                Dim LogoFileList As ArrayList = GetFileList(PortalId, glbImageFileTypes)
                cboIcon.DataSource = LogoFileList
                cboIcon.DataBind()

                cboTab.DataSource = GetPortalTabs(_portalSettings.DesktopTabs, True)
                cboTab.DataBind()

                ' tab administrators can only manage their own tab
                If PortalSecurity.IsInRoles(_portalSettings.AdministratorRoleId.ToString) = False Then
                    cboTab.Enabled = False
                End If

                If strAction = "" Then
                    InitializeTab()
                    cmdDelete.Visible = False
                    cmdCopy.Visible = False
                Else
                    BindData()
                End If

                If Not Request.UrlReferrer Is Nothing Then
                    ViewState("UrlReferrer") = Request.UrlReferrer.ToString()
                Else
                    ViewState("UrlReferrer") = ""
                End If
            End If

        End Sub


        '*******************************************************
        '
        ' The cmdCancel_Click() handler cancels operation and redirects
        ' user to admin tab of their portal.
        '
        '*******************************************************

        Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCancel.Click

            Response.Redirect(ViewState("UrlReferrer"))

        End Sub


        Sub InitializeTab()

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            ' Populate Tab Names, etc.
            tabName.Text = ""

            If _portalSettings.ActiveTab.ParentId <> _portalSettings.AdminTabId Then
                If Not cboTab.Items.FindByValue(TabId.ToString) Is Nothing Then
                    cboTab.Items.FindByValue(TabId).Selected = True
                End If
            End If

            IsVisible.Checked = True
            mobileTabName.Text = ""
            showMobile.Checked = False
            txtLeftPaneWidth.Text = "200"
            txtRightPaneWidth.Text = "200"

            ' Populate checkbox list with all security roles for this portal
            ' and "check" the ones already configured for this tab
            Dim objUser As New UsersDB()
            Dim roles As SqlDataReader = objUser.GetPortalRoles(PortalId)

            ' Clear existing items in checkboxlist
            authRoles.Items.Clear()

            Dim allAuthItem As New ListItem()
            allAuthItem.Text = "All Users"
            allAuthItem.Value = glbRoleAllUsers
            allAuthItem.Selected = True
            authRoles.Items.Add(allAuthItem)

            Dim allAdminItem As New ListItem()
            allAdminItem.Text = "All Users"
            allAdminItem.Value = glbRoleAllUsers
            adminRoles.Items.Add(allAdminItem)

            While roles.Read()
                Dim authItem As New ListItem()
                authItem.Text = CType(roles("RoleName"), String)
                authItem.Value = roles("RoleID").ToString()
                If authItem.Value = _portalSettings.AdministratorRoleId.ToString Then
                    authItem.Selected = True
                End If
                If InStr(1, _portalSettings.ActiveTab.AdministratorRoles.ToString, authItem.Value) Then
                    authItem.Selected = True
                End If
                authRoles.Items.Add(authItem)

                Dim adminItem As New ListItem()
                adminItem.Text = CType(roles("RoleName"), String)
                adminItem.Value = roles("RoleID").ToString()
                If adminItem.Value = _portalSettings.AdministratorRoleId.ToString Then
                    adminItem.Selected = True
                End If
                If InStr(1, _portalSettings.ActiveTab.AdministratorRoles.ToString, adminItem.Value) Then
                    adminItem.Selected = True
                End If
                adminRoles.Items.Add(adminItem)
            End While

        End Sub

        Private Sub cmdUpdate_Click(ByVal Sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click

            SaveTabData(strAction)

            Response.Redirect(ViewState("UrlReferrer"))

        End Sub

        Private Sub cmdDelete_Click(ByVal Sender As Object, ByVal e As EventArgs) Handles cmdDelete.Click

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(Context.Items("PortalSettings"), PortalSettings)

            Dim objAdmin As New AdminDB()

            objAdmin.DeleteTab(TabId)
            Dim dr As SqlDataReader = objAdmin.GetTabById(TabId)
            If Not dr.Read Then
                objAdmin.UpdatePortalTabOrder(_portalSettings.DesktopTabs, TabId, -2)
            End If
            dr.Close()

            Response.Redirect(GetPortalDomainName(PortalAlias, Request))
        End Sub

        '*******************************************************
        '
        ' The SaveTabData helper method is used to persist the
        ' current tab settings to the database.
        '
        '*******************************************************

        Sub SaveTabData(ByVal strAction As String)

            Dim intTabId As Integer

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(Context.Items("PortalSettings"), PortalSettings)

            ' Construct AdministratorRoles String
            Dim strAdministratorRoles As String = ""

            Dim item As ListItem

            For Each item In adminRoles.Items
                ' admins always have access to all tabs
                If item.Selected = True Or item.Value = _portalSettings.AdministratorRoleId.ToString Or (PortalSecurity.IsInRole(_portalSettings.AdministratorRoleId.ToString) = False And InStr(1, _portalSettings.ActiveTab.AdministratorRoles.ToString, item.Value) <> 0) Then
                    strAdministratorRoles += item.Value & ";"
                End If
            Next item

            ' Construct AuthorizedRoles String
            Dim strAuthorizedRoles As String = ""

            For Each item In authRoles.Items
                ' admins always have access to all tabs
                If item.Selected = True Or item.Value = _portalSettings.AdministratorRoleId.ToString Or (PortalSecurity.IsInRole(_portalSettings.AdministratorRoleId.ToString) = False And InStr(1, _portalSettings.ActiveTab.AdministratorRoles.ToString, item.Value) <> 0) Then
                    strAuthorizedRoles += item.Value & ";"
                End If
            Next item

            Dim strIcon As String = ""
            If Not cboIcon.SelectedItem Is Nothing Then
                strIcon = cboIcon.SelectedItem.Value
            End If

            Dim admin As New AdminDB()

            If strAction = "edit" Then

                ' trap circular tab reference
                If (TabId <> Int32.Parse(cboTab.SelectedItem.Value)) And (Int32.Parse(cboTab.SelectedItem.Value) = -1 Or IsVisible.Checked = True) Then
                    admin.UpdateTab(TabId, tabName.Text, showMobile.Checked, mobileTabName.Text, strAuthorizedRoles, txtLeftPaneWidth.Text, txtRightPaneWidth.Text, IsVisible.Checked, Int32.Parse(cboTab.SelectedItem.Value), strIcon, strAdministratorRoles)
                    admin.UpdatePortalTabOrder(_portalSettings.DesktopTabs, TabId, Int32.Parse(cboTab.SelectedItem.Value), , , IsVisible.Checked.ToString)
                End If

            Else ' add or copy

                ' child tabs must be visible
                If Int32.Parse(cboTab.SelectedItem.Value) <> -1 Then
                    IsVisible.Checked = True
                End If

                intTabId = admin.AddTab(PortalId, tabName.Text, showMobile.Checked, mobileTabName.Text, strAuthorizedRoles, txtLeftPaneWidth.Text, txtRightPaneWidth.Text, IsVisible.Checked, Int32.Parse(cboTab.SelectedItem.Value), strIcon, strAdministratorRoles, intTabId)
                admin.UpdatePortalTabOrder(_portalSettings.DesktopTabs, intTabId, Int32.Parse(cboTab.SelectedItem.Value), , , IsVisible.Checked.ToString)

                If strAction = "copy" Then
                    ' copy all modules to new tab
                    admin.CopyTab(TabId, intTabId)
                End If
            End If

        End Sub

        '*******************************************************
        '
        ' The BindData helper method is used to update the tab's
        ' layout panes with the current configuration information
        '
        '*******************************************************
        Sub BindData()

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(Context.Items("PortalSettings"), PortalSettings)

            Dim tab As TabSettings = _portalSettings.ActiveTab

            ' Populate Tab Names, etc.
            tabName.Text = tab.TabName
            If cboIcon.Items.Contains(New ListItem(tab.IconFile)) Then
                cboIcon.Items.FindByText(tab.IconFile).Selected = True
            End If
            cboTab.Items.FindByValue(tab.ParentId).Selected = True
            IsVisible.Checked = tab.IsVisible
            mobileTabName.Text = tab.MobileTabName
            showMobile.Checked = tab.ShowMobile
            txtLeftPaneWidth.Text = tab.LeftPaneWidth
            txtRightPaneWidth.Text = tab.RightPaneWidth

            Dim objUser As New UsersDB()
            Dim roles As SqlDataReader = objUser.GetPortalRoles(PortalId)

            ' Populate AuthorizedRoles, AdministratorRoles
            authRoles.Items.Clear()
            adminRoles.Items.Clear()

            Dim allAuthItem As New ListItem()
            allAuthItem.Text = "All Users"
            allAuthItem.Value = glbRoleAllUsers
            If tab.AuthorizedRoles.LastIndexOf(allAuthItem.Value & ";") > -1 Then
                allAuthItem.Selected = True
            End If
            authRoles.Items.Add(allAuthItem)

            Dim allAdminItem As New ListItem()
            allAdminItem.Text = "All Users"
            allAdminItem.Value = glbRoleAllUsers
            If tab.AdministratorRoles.LastIndexOf(allAdminItem.Value & ";") > -1 Then
                allAdminItem.Selected = True
            End If
            adminRoles.Items.Add(allAdminItem)

            While roles.Read()
                Dim authItem As New ListItem()
                authItem.Text = CType(roles("RoleName"), String)
                authItem.Value = roles("RoleID").ToString()
                If tab.AuthorizedRoles.LastIndexOf(authItem.Value & ";") > -1 Then
                    authItem.Selected = True
                End If
                authRoles.Items.Add(authItem)

                Dim adminItem As New ListItem()
                adminItem.Text = CType(roles("RoleName"), String)
                adminItem.Value = roles("RoleID").ToString()
                If tab.AdministratorRoles.LastIndexOf(adminItem.Value & ";") > -1 Then
                    adminItem.Selected = True
                End If
                adminRoles.Items.Add(adminItem)
            End While

        End Sub

        Private Sub cmdCopy_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCopy.Click

            SaveTabData("copy")

            Response.Redirect(ViewState("UrlReferrer"))

        End Sub

    End Class

End Namespace
