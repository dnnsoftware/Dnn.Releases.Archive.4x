Namespace ASPNetPortal

    Public MustInherit Class Sales
        Inherits ASPNetPortal.PortalModuleControl

        Protected WithEvents txtStartDate As System.Web.UI.WebControls.TextBox
        Protected WithEvents valStartDate1 As System.Web.UI.WebControls.RequiredFieldValidator
        Protected WithEvents valStartDate2 As System.Web.UI.WebControls.CompareValidator
        Protected WithEvents txtEndDate As System.Web.UI.WebControls.TextBox
        Protected WithEvents valEndDate1 As System.Web.UI.WebControls.RequiredFieldValidator
        Protected WithEvents valEndDate2 As System.Web.UI.WebControls.CompareValidator
        Protected WithEvents cmdDisplay As System.Web.UI.WebControls.LinkButton
        Protected WithEvents grdInvoices As System.Web.UI.WebControls.DataGrid

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        '*******************************************************
        '
        ' The Page_Load server event handler on this user control is used
        ' to populate the current roles settings from the configuration system
        '
        '*******************************************************

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            ' If this is the first visit to the page, bind the role data to the datalist
            If Page.IsPostBack = False Then
                txtStartDate.Text = Format(Now(), "MM/dd/yyyy")
                txtEndDate.Text = Format(Now(), "MM/dd/yyyy")
                BindData()
            End If

        End Sub

        '*******************************************************
        '
        ' The BindData helper method is used to bind the list of
        ' users for this portal to an asp:DropDownList server control
        '
        '*******************************************************

        Sub BindData()
            ' Get the portal's roles from the database
            Dim objUser As New UsersDB()

            grdInvoices.DataSource = objUser.GetInvoices(PortalId, txtStartDate.Text, txtEndDate.Text)
            grdInvoices.DataBind()
        End Sub

        Private Sub cmdDisplay_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDisplay.Click
            BindData()
        End Sub

    End Class

End Namespace
