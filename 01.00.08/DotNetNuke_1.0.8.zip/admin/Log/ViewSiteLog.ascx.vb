'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2003
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Namespace DotNetNuke

    Public Class ViewSiteLog
        Inherits DotNetNuke.PortalModuleControl

        Protected WithEvents cboReportType As System.Web.UI.WebControls.DropDownList
        Protected WithEvents txtStartDate As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtEndDate As System.Web.UI.WebControls.TextBox
        Protected WithEvents cmdDisplay As System.Web.UI.WebControls.LinkButton
        Protected WithEvents lblPages As System.Web.UI.WebControls.Label
        Protected WithEvents lblVisitors As System.Web.UI.WebControls.Label
        Protected WithEvents lblUsers As System.Web.UI.WebControls.Label
        Protected WithEvents grdLog As System.Web.UI.WebControls.DataGrid
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        '*******************************************************
        '
        ' The Page_Load server event handler on this page is used
        ' to populate the role information for the page
        '
        '*******************************************************

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            ' If this is the first visit to the page, bind the role data to the datalist
            If Page.IsPostBack = False Then
                Dim objAdmin As New AdminDB()

                cboReportType.DataSource = objAdmin.GetSiteLogReports
                cboReportType.DataBind()
                cboReportType.SelectedIndex = 0

                txtStartDate.Text = GetRegionalDate(DateAdd(DateInterval.Day, -6, Date.Today).ToString)
                txtEndDate.Text = GetRegionalDate(DateAdd(DateInterval.Day, 1, Date.Today).ToString)

                ' Store URL Referrer to return to portal
                If Not Request.UrlReferrer Is Nothing Then
                    ViewState("UrlReferrer") = Request.UrlReferrer.ToString()
                Else
                    ViewState("UrlReferrer") = ""
                End If
            End If
        End Sub

        Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
            Response.Redirect(CType(Viewstate("UrlReferrer"), String))
        End Sub

        Private Sub cmdDisplay_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDisplay.Click
            BindData()
        End Sub

        Private Sub BindData()

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            Dim strPortalAlias As String

            strPortalAlias = GetPortalDomainName(PortalAlias)
            If InStr(1, strPortalAlias, "/") <> 0 Then ' child portal
                strPortalAlias = Left(strPortalAlias, InStrRev(strPortalAlias, "/") - 1)
            End If

            Dim strStartDate As String = txtStartDate.Text
            If strStartDate <> "" Then
                strStartDate = GetRegionalDate(strStartDate) & " 00:00"
            End If

            Dim strEndDate As String = txtEndDate.Text
            If strEndDate <> "" Then
                strEndDate = GetRegionalDate(strEndDate) & " 23:59"
            End If

            Dim objAdmin As New AdminDB()

            grdLog.DataSource = objAdmin.GetSiteLog(PortalId, strPortalAlias, Int32.Parse(cboReportType.SelectedItem.Value), strStartDate, strEndDate)
            grdLog.DataBind()

        End Sub

    End Class

End Namespace