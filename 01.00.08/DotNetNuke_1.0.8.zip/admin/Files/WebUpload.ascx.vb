'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2003
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Namespace DotNetNuke

    Public Class WebUpload
        Inherits DotNetNuke.PortalModuleControl

        Protected WithEvents cmdBrowse As System.Web.UI.HtmlControls.HtmlInputFile
        Protected WithEvents lstFiles As System.Web.UI.WebControls.ListBox
        Protected WithEvents cmdAdd As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdRemove As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdUpload As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
        Protected WithEvents lblMessage As System.Web.UI.WebControls.Label

        Public Shared arrFiles As ArrayList = New ArrayList()

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        '*******************************************************
        '
        ' The Page_Load server event handler on this page is used
        ' to populate the role information for the page
        '
        '*******************************************************

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            Dim objAdmin As New AdminDB()
            Dim intModuleId As Integer = objAdmin.GetSiteModule("File Manager", PortalId)
            Dim settings As Hashtable = _portalSettings.GetModuleSettings(intModuleId)
            Dim UploadRoles As String = ""
            If Not CType(settings("uploadroles"), String) Is Nothing Then
                UploadRoles = CType(settings("uploadroles"), String)
            End If

            If PortalSecurity.IsInRole(_portalSettings.AdministratorRoleId.ToString) = False And PortalSecurity.IsInRoles(UploadRoles) = False Then
                Response.Redirect("~/EditModule.aspx?tabid=" & _portalSettings.ActiveTab.TabId & "&def=Edit Access Denied")
            End If

            If Page.IsPostBack = False Then
                ' Store URL Referrer to return to portal
                If Not Request.UrlReferrer Is Nothing Then
                    ViewState("UrlReferrer") = Request.UrlReferrer.ToString()
                Else
                    ViewState("UrlReferrer") = ""
                End If
            End If

        End Sub

        Private Sub cmdAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdAdd.Click
            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            If Page.IsPostBack Then
                Dim strExtension As String = ""
                If InStr(1, cmdBrowse.PostedFile.FileName, ".") Then
                    strExtension = Mid(cmdBrowse.PostedFile.FileName, InStrRev(cmdBrowse.PostedFile.FileName, ".") + 1).ToLower
                End If
                If InStr(1, "," & _portalSettings.HostSettings("FileExtensions").ToString, "," & strExtension) <> 0 Or _portalSettings.ActiveTab.ParentId = _portalSettings.SuperTabId Then
                    arrFiles.Add(cmdBrowse)
                    lstFiles.Items.Add(cmdBrowse.PostedFile.FileName)
                Else
                    ' restricted file type
                    lblMessage.Text = "<br>The File " & cmdBrowse.PostedFile.FileName & " Is A Restricted File Type. Valid File Types Include ( *." & Replace(_portalSettings.HostSettings("FileExtensions").ToString, ",", ", *.") & " ). Please Contact Your Hosting Provider If You Need To Upload A File Type Which Is Not Supported."
                End If
            End If
        End Sub

        Private Sub cmdRemove_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRemove.Click
            If lstFiles.Items.Count <> 0 Then
                arrFiles.RemoveAt(lstFiles.SelectedIndex)
                lstFiles.Items.Remove(lstFiles.SelectedItem.Text)
            End If
        End Sub

        Private Sub cmdUpload_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdUpload.Click
            Dim strFileName As String
            Dim strFileNamePath As String
            Dim strExtension As String = ""
            Dim imgImage As System.Drawing.Image
            Dim strWidth As String = ""
            Dim strHeight As String = ""
            Dim strMessage As String = ""

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            Dim objAdmin As New AdminDB()
            Dim objHtmlInputFile As System.Web.UI.HtmlControls.HtmlInputFile

            For Each objHtmlInputFile In arrFiles
                If ((((objAdmin.GetPortalSpaceUsed(PortalId) + objHtmlInputFile.PostedFile.ContentLength) / 1000000) <= _portalSettings.HostSpace) Or _portalSettings.HostSpace = 0) Or (_portalSettings.ActiveTab.ParentId = _portalSettings.SuperTabId) Then

                    'Gets the file name
                    strFileName = System.IO.Path.GetFileName(objHtmlInputFile.PostedFile.FileName)

                    If _portalSettings.ActiveTab.ParentId = _portalSettings.SuperTabId Then
                        strFileNamePath = Request.MapPath(glbSiteDirectory) & strFileName
                    Else
                        strFileNamePath = Request.MapPath(_portalSettings.UploadDirectory) & strFileName
                    End If

                    'Save Uploaded file to server
                    Try
                        objHtmlInputFile.PostedFile.SaveAs(strFileNamePath)

                        strExtension = ""
                        If InStr(1, strFileName, ".") Then
                            strExtension = Mid(strFileName, InStrRev(strFileName, ".") + 1)
                        End If

                        If InStr(1, glbImageFileTypes, strExtension) Then
                            imgImage = imgImage.FromFile(strFileNamePath)
                            strHeight = imgImage.Height
                            strWidth = imgImage.Width
                            imgImage.Dispose()
                        End If

                        If _portalSettings.ActiveTab.ParentId = _portalSettings.SuperTabId Then
                            objAdmin.AddFile(-1, strFileName, strExtension, FileLen(strFileNamePath), strWidth, strHeight, objHtmlInputFile.PostedFile.ContentType)
                        Else
                            objAdmin.AddFile(PortalId, strFileName, strExtension, FileLen(strFileNamePath), strWidth, strHeight, objHtmlInputFile.PostedFile.ContentType)
                        End If

                    Catch
                        ' save error - can happen if the security settings are incorrect
                        strMessage += "<br>An Error Has Occurred When Attempting To Save The File " & objHtmlInputFile.PostedFile.FileName & ". Please Contact Your Hosting Provider To Ensure The Appropriate Security Settings Have Been Enabled On The Server."
                    End Try
                Else ' file too large
                    strMessage += "<br>The File " & objHtmlInputFile.PostedFile.FileName & " Exceeds The Amount Of Disk Space You Currently Have Available. Please Contact Your Hosting Provider For Inquiries Related To Increasing Your Portal Disk Space."
                End If
            Next

            If strMessage = "" Then
                Response.Redirect(CType(Viewstate("UrlReferrer"), String))
            Else
                lblMessage.Text = strMessage
            End If

        End Sub

        Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
            Response.Redirect(CType(Viewstate("UrlReferrer"), String))
        End Sub

    End Class

End Namespace