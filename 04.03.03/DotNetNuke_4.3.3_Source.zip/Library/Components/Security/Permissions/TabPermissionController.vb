'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2006
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports System
Imports System.Data
Imports DotNetNuke

Namespace DotNetNuke.Security.Permissions


#Region "TabPermissionController"
    Public Class TabPermissionController


        Public Function GetTabPermissionsByTabID(ByVal TabID As Integer) As ArrayList

            Return CBO.FillCollection(DataProvider.Instance().GetTabPermissionsByTabID(TabID, -1), GetType(TabPermissionInfo))

        End Function

        Public Function GetTabPermissionsByPortal(ByVal PortalID As Integer) As ArrayList
            Dim objTabPermissionController As New Security.Permissions.TabPermissionController
            Dim arrTabPermissions As ArrayList = Nothing
            If Not Common.Globals.PerformanceSetting = Common.Globals.PerformanceSettings.NoCaching Then
                arrTabPermissions = CType(DataCache.GetCache("GetTabPermissionsByPortal" & PortalID.ToString), ArrayList)
            End If
            If arrTabPermissions Is Nothing Then
                arrTabPermissions = CBO.FillCollection(DataProvider.Instance().GetTabPermissionsByPortal(PortalID), GetType(TabPermissionInfo))
                If Not Common.Globals.PerformanceSetting = Common.Globals.PerformanceSettings.NoCaching Then
                    DataCache.SetCache("GetTabPermissionsByPortal" & PortalID.ToString, arrTabPermissions)
                End If
            End If
            Return arrTabPermissions
        End Function

        Public Function GetTabPermissionsCollectionByTabID(ByVal TabID As Integer) As Security.Permissions.TabPermissionCollection
            Dim objTabPermissionCollection As IList = New Security.Permissions.TabPermissionCollection
            CBO.FillCollection(DataProvider.Instance().GetTabPermissionsByTabID(TabID, -1), GetType(TabPermissionInfo), objTabPermissionCollection)
            Return CType(objTabPermissionCollection, Security.Permissions.TabPermissionCollection)
        End Function

        Public Function GetTabPermissionsCollectionByTabID(ByVal arrTabPermissions As ArrayList, ByVal TabID As Integer) As Security.Permissions.TabPermissionCollection
            Dim objTabPermissionCollection As New Security.Permissions.TabPermissionCollection(arrTabPermissions, TabID)
            Return objTabPermissionCollection
        End Function

        Public Sub DeleteTabPermissionsByTabID(ByVal TabID As Integer)

            DataProvider.Instance().DeleteTabPermissionsByTabID(TabID)

        End Sub

        Public Sub DeleteTabPermission(ByVal TabPermissionID As Integer)

            DataProvider.Instance().DeleteTabPermission(TabPermissionID)

        End Sub

        Public Function AddTabPermission(ByVal objTabPermission As TabPermissionInfo) As Integer

            Return CType(DataProvider.Instance().AddTabPermission(objTabPermission.TabID, objTabPermission.PermissionID, objTabPermission.RoleID, objTabPermission.AllowAccess), Integer)

        End Function

        Public Sub UpdateTabPermission(ByVal objTabPermission As TabPermissionInfo)

            DataProvider.Instance().UpdateTabPermission(objTabPermission.TabPermissionID, objTabPermission.TabID, objTabPermission.PermissionID, objTabPermission.RoleID, objTabPermission.AllowAccess)

        End Sub



        Public Shared Function HasTabPermission(ByVal PermissionKey As String) As Boolean
            Dim _PortalSettings As PortalSettings = PortalController.GetCurrentPortalSettings

            Dim t As Security.Permissions.TabPermissionCollection = _PortalSettings.ActiveTab.TabPermissions
            Dim i As Integer
            For i = 0 To t.Count - 1
                Dim tp As Security.Permissions.TabPermissionInfo
                tp = t(i)
                If tp.PermissionKey = PermissionKey AndAlso PortalSecurity.IsInRoles(tp.RoleName) Then
                    Return True
                End If
            Next
            Return False
        End Function

        Public Shared Function HasTabPermission(ByVal objTabPermissions As Security.Permissions.TabPermissionCollection, ByVal PermissionKey As String) As Boolean
            Dim _PortalSettings As PortalSettings = PortalController.GetCurrentPortalSettings

            Dim t As Security.Permissions.TabPermissionCollection = objTabPermissions
            Dim i As Integer
            For i = 0 To t.Count - 1
                Dim tp As Security.Permissions.TabPermissionInfo
                tp = t(i)
                If tp.PermissionKey = PermissionKey AndAlso PortalSecurity.IsInRoles(tp.RoleName) Then
                    Return True
                End If
            Next
            Return False
        End Function

        Public Function GetTabPermissionsByTabID(ByVal arrTabPermissions As ArrayList, ByVal TabID As Integer, ByVal PermissionKey As String) As String

            Dim strRoles As String = ";"
            Dim i As Integer
            For i = 0 To arrTabPermissions.Count - 1
                Dim objTabPermission As Security.Permissions.TabPermissionInfo = CType(arrTabPermissions(i), Security.Permissions.TabPermissionInfo)
                If objTabPermission.TabID = TabID AndAlso objTabPermission.AllowAccess = True AndAlso objTabPermission.PermissionKey = PermissionKey Then
                    strRoles += objTabPermission.RoleName + ";"
                End If
            Next
            Return strRoles
        End Function

        Public Function GetTabPermissionsByTabID(ByVal arrTabPermissions As ArrayList, ByVal TabID As Integer) As Security.Permissions.TabPermissionCollection

            Dim p As New Security.Permissions.TabPermissionCollection

            Dim i As Integer
            For i = 0 To arrTabPermissions.Count - 1
                Dim objTabPermission As Security.Permissions.TabPermissionInfo = CType(arrTabPermissions(i), Security.Permissions.TabPermissionInfo)
                If objTabPermission.TabID = TabID Then
                    p.Add(objTabPermission)
                End If
            Next
            Return p
        End Function



    End Class
#End Region


End Namespace
