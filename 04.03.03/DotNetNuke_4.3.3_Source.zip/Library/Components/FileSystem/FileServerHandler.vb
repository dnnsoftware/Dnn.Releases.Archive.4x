'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2006
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Option Strict On
Option Explicit On 

Imports System
Imports System.Web
Imports DotNetNuke
Imports DotNetNuke.Entities.Users
Imports DotNetNuke.Services.FileSystem
Imports System.IO
Imports DotNetNuke.Entities.Portals
Imports DotNetNuke.Common.Utilities

Namespace DotNetNuke.Services.FileSystem

    Public Class FileServerHandler
        Implements IHttpHandler

        Public Sub New()
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' This handler handles requests for LinkClick.aspx, but only those specifc
        ''' to file serving
        ''' </summary>
        ''' <param name="context">System.Web.HttpContext)</param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cpaterra]	4/19/2006	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub ProcessRequest(ByVal context As System.Web.HttpContext) Implements System.Web.IHttpHandler.ProcessRequest

            Dim _portalSettings As PortalSettings = PortalController.GetCurrentPortalSettings

            ' get TabId
            Dim TabId As Integer = -1
            If Not IsNothing(context.Request.QueryString("tabid")) Then
                TabId = Int32.Parse(context.Request.QueryString("tabid"))
            End If

            ' get ModuleId
            Dim ModuleId As Integer = -1
            If Not IsNothing(context.Request.QueryString("mid")) Then
                ModuleId = Int32.Parse(context.Request.QueryString("mid"))
            End If

            ' get UserId
            Dim UserId As Integer = -1
            Dim objUserInfo As UserInfo = UserController.GetCurrentUserInfo
            If context.Request.IsAuthenticated Then
                UserId = objUserInfo.UserID
            End If

            ' get the URL
            Dim URL As String = ""
            Dim blnClientCache As Boolean = True
            Dim blnForceDownload As Boolean = False

            If Not context.Request.QueryString("fileticket") Is Nothing Then
                URL = "FileID=" & UrlUtils.DecryptParameter(context.Request.QueryString("fileticket"))
            End If
            If Not context.Request.QueryString("userticket") Is Nothing Then
                URL = "UserId=" & UrlUtils.DecryptParameter(context.Request.QueryString("userticket"))
            End If
            If Not context.Request.QueryString("link") Is Nothing Then
                URL = context.Request.QueryString("link")
                If URL.ToLower.StartsWith("fileid=") Then
                    URL = "" ' restrict direct access by FileID
                End If
            End If

            If URL <> "" Then

                Dim UrlType As TabType = GetURLType(URL)

                If UrlType <> TabType.File Then
                    URL = Common.Globals.LinkClick(URL, TabId, ModuleId, False)
                End If

                If UrlType = TabType.File And URL.ToLower.StartsWith("fileid=") = False Then
                    ' to handle legacy scenarios before the introduction of the FileServerHandler
                    Dim objFiles As New FileController
                    URL = "FileID=" & objFiles.ConvertFilePathToFileId(URL, _portalSettings.PortalId)
                End If

                ' get optional parameters
                If Not context.Request.QueryString("clientcache") Is Nothing Then
                    blnClientCache = Boolean.Parse(context.Request.QueryString("clientcache"))
                End If

                If (Not context.Request.QueryString("forcedownload") Is Nothing) Or (Not context.Request.QueryString("contenttype") Is Nothing) Then
                    blnForceDownload = Boolean.Parse(context.Request.QueryString("forcedownload"))
                End If

                ' update clicks
                Dim objUrls As New UrlController
                objUrls.UpdateUrlTracking(_portalSettings.PortalId, URL, ModuleId, UserId)

                ' clear the current response
                context.Response.Clear()

                If UrlType = TabType.File Then
                    ' serve the file
                    If Not FileSystemUtils.DownloadFile(_portalSettings, Integer.Parse(UrlUtils.GetParameterValue(URL)), blnClientCache, blnForceDownload) Then
                        context.Response.Write(Services.Localization.Localization.GetString("FilePermission.Error"))
                    End If
                Else
                    ' redirect to URL
                    context.Response.Redirect(URL, True)
                End If
            End If

        End Sub

        Public ReadOnly Property IsReusable() As Boolean Implements System.Web.IHttpHandler.IsReusable
            Get
                Return True
            End Get
        End Property

    End Class

End Namespace