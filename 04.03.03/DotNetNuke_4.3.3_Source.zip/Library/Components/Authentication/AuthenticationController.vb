'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2006
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports DotNetNuke.Security.Membership
Imports System.Web.Security
Imports DotNetNuke.Security.Authentication.Configuration

Namespace DotNetNuke.Security.Authentication

    Public Class AuthenticationController

        Private mProcessLog As String = ""
        Private mProviderTypeName As String = ""
        Private _portalSettings As PortalSettings

        ''' -------------------------------------------------------------------
        ''' <summary>
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        '''     [tamttt]	08/01/2004	Created
        ''' </history>
        ''' -------------------------------------------------------------------
        Sub New()
            Dim _config As Authentication.Configuration = Authentication.Configuration.GetConfig()
            _portalSettings = PortalController.GetCurrentPortalSettings
            mProviderTypeName = _config.ProviderTypeName
        End Sub

        ''' -------------------------------------------------------------------
        ''' <summary>
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        '''     [tamttt]	08/01/2004	Created
        ''' </history>
        ''' -------------------------------------------------------------------
        Public Sub AuthenticationLogon()
            Dim _config As Authentication.Configuration = Authentication.Configuration.GetConfig()

            Dim objAuthUserController As New Authentication.UserController
            Dim authCookies As String = AUTHENTICATION_KEY & "_" & _portalSettings.PortalId.ToString
            Dim LoggedOnUserName As String = HttpContext.Current.Request.ServerVariables(LOGON_USER_VARIABLE)

            If LoggedOnUserName.Length > 0 Then
                Dim objDNNUser As DotNetNuke.Entities.Users.UserInfo
                Dim objAuthUser As Authentication.UserInfo

                Dim intUserId As Integer

                objDNNUser = DotNetNuke.Entities.Users.UserController.GetUserByName(_portalSettings.PortalId, LoggedOnUserName, False)

                If Not objDNNUser Is Nothing Then
                    intUserId = objDNNUser.UserID

                    ' Synchronize role membership if it's required in settings
                    If _config.SynchronizeRole Then
                        objAuthUser = objAuthUserController.GetUser(LoggedOnUserName)

                        ' user object might be in simple version in none active directory network
                        If Not objAuthUser.GUID.Length = 0 Then
                            objAuthUser.UserID = intUserId
                            UserController.AddUserRoles(_portalSettings.PortalId, objAuthUser)
                        End If
                    End If
                Else
                    ' User not exists in DNN database, obtain user info from provider to add new
                    objAuthUser = objAuthUserController.GetUser(LoggedOnUserName)
                    objDNNUser = CType(objAuthUser, DotNetNuke.Entities.Users.UserInfo)
                    If Not objAuthUser Is Nothing Then
                        Dim createStatus As UserCreateStatus = objAuthUserController.AddDNNUser(objAuthUser)
                        intUserId = objAuthUser.UserID
                        SetStatus(_portalSettings.PortalId, AuthenticationStatus.WinLogon)
                    End If
                End If

                If intUserId > 0 Then
                    FormsAuthentication.SetAuthCookie(Convert.ToString(LoggedOnUserName), True)
                    SetStatus(_portalSettings.PortalId, AuthenticationStatus.WinLogon)

                    ' Get ipAddress for eventLog
                    Dim ipAddress As String = ""
                    If Not HttpContext.Current.Request.UserHostAddress Is Nothing Then
                        ipAddress = HttpContext.Current.Request.UserHostAddress
                    End If

                    Dim objEventLog As New Services.Log.EventLog.EventLogController
                    Dim objEventLogInfo As New Services.Log.EventLog.LogInfo
                    objEventLogInfo.AddProperty("IP", ipAddress)
                    objEventLogInfo.LogPortalID = _portalSettings.PortalId
                    objEventLogInfo.LogPortalName = _portalSettings.PortalName
                    objEventLogInfo.LogUserID = intUserId
                    objEventLogInfo.LogUserName = LoggedOnUserName
                    objEventLogInfo.AddProperty("WindowsAuthentication", "True")
                    objEventLogInfo.LogTypeKey = "LOGIN_SUCCESS"

                    objEventLog.AddLog(objEventLogInfo)

                End If
            Else
                ' Not Windows Authentication
            End If

            ' params "logon=windows" does nothing, just to force page to be refreshed
            Dim strURL As String = NavigateURL(_portalSettings.ActiveTab.TabID, "", "logon=windows")
            HttpContext.Current.Response.Redirect(strURL, True)

        End Sub

        ''' -------------------------------------------------------------------
        ''' <summary>
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        '''     [tamttt]	08/01/2004	Created
        ''' </history>
        ''' -------------------------------------------------------------------
        Public Sub AuthenticationLogoff()
            Dim _portalSettings As PortalSettings = PortalController.GetCurrentPortalSettings
            Dim authCookies As String = AUTHENTICATION_KEY & "_" & _portalSettings.PortalId.ToString

            ' Log User Off from Cookie Authentication System
            FormsAuthentication.SignOut()
            If GetStatus(_portalSettings.PortalId) = AuthenticationStatus.WinLogon Then
                SetStatus(_portalSettings.PortalId, AuthenticationStatus.WinLogoff)
            End If

            ' expire cookies
            If PortalSecurity.IsInRoles(_portalSettings.AdministratorRoleId.ToString) And Not HttpContext.Current.Request.Cookies("_Tab_Admin_Content" & _portalSettings.PortalId.ToString) Is Nothing Then
                HttpContext.Current.Response.Cookies("_Tab_Admin_Content" & _portalSettings.PortalId.ToString).Value = Nothing
                HttpContext.Current.Response.Cookies("_Tab_Admin_Content" & _portalSettings.PortalId.ToString).Path = "/"
                HttpContext.Current.Response.Cookies("_Tab_Admin_Content" & _portalSettings.PortalId.ToString).Expires = DateTime.Now.AddYears(-30)
            End If

            HttpContext.Current.Response.Cookies("portalaliasid").Value = Nothing
            HttpContext.Current.Response.Cookies("portalaliasid").Path = "/"
            HttpContext.Current.Response.Cookies("portalaliasid").Expires = DateTime.Now.AddYears(-30)

            HttpContext.Current.Response.Cookies("portalroles").Value = Nothing
            HttpContext.Current.Response.Cookies("portalroles").Path = "/"
            HttpContext.Current.Response.Cookies("portalroles").Expires = DateTime.Now.AddYears(-30)

            ' Redirect browser back to portal 
            If _portalSettings.HomeTabId <> -1 Then
                HttpContext.Current.Response.Redirect(NavigateURL(_portalSettings.HomeTabId), True)
            Else
                'If (IsAdminTab(_portalSettings.ActiveTab.TabID, _portalSettings.ActiveTab.ParentId)) Then
                If (_portalSettings.ActiveTab.IsAdminTab) Then
                    HttpContext.Current.Response.Redirect("~/" & glbDefaultPage, True)
                Else
                    HttpContext.Current.Response.Redirect(NavigateURL(), True)
                End If
            End If
        End Sub

        ''' -------------------------------------------------------------------
        ''' <summary>
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        '''     [tamttt]	08/01/2004	Created
        ''' </history>
        ''' -------------------------------------------------------------------
        Public Function ProcessFormAuthentication(ByVal LoggedOnUserName As String, ByVal LoggedOnPassword As String) As Authentication.UserInfo  'DotNetNuke.Entities.Users.UserInfo
            'Dim _portalSettings As PortalSettings = PortalController.GetCurrentPortalSettings
            'Dim _config As Authentication.Configuration = Authentication.Configuration.GetConfig(_portalSettings.PortalId)
            Dim _config As Authentication.Configuration = Authentication.Configuration.GetConfig()
            Dim objAuthUserController As New Authentication.UserController
            Dim objUsers As New DotNetNuke.Entities.Users.UserController

            If _config.WindowsAuthentication Then
                Dim objAuthUser As Authentication.UserInfo = objAuthUserController.GetUser(LoggedOnUserName, LoggedOnPassword)
                Return objAuthUser
            End If
            Return Nothing
            'Return -1

        End Function

        ''' -------------------------------------------------------------------
        ''' <summary>
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        '''     [tamttt]	08/01/2004	Created
        ''' </history>
        ''' -------------------------------------------------------------------
        Public Function GetDNNUser(ByVal PortalID As Integer, ByVal LoggedOnUserName As String) As DotNetNuke.Entities.Users.UserInfo
            Dim objUser As DotNetNuke.Entities.Users.UserInfo

            'TODO: Check the new concept of 3.0 for user in multi portal
            ' check if this user exists in database for any portal
            objUser = DotNetNuke.Entities.Users.UserController.GetUserByName(Null.NullInteger, LoggedOnUserName, False)
            If Not objUser Is Nothing Then
                ' Check if user exists in this portal
                If DotNetNuke.Entities.Users.UserController.GetUserByName(PortalID, LoggedOnUserName, False) Is Nothing Then
                    ' The user does not exist in this portal - add them
                    objUser.PortalID = PortalID
                    DotNetNuke.Entities.Users.UserController.CreateUser(objUser)
                End If
                Return objUser
            Else
                ' the user does not exist
                Return Nothing
            End If

        End Function

        ''' -------------------------------------------------------------------
        ''' <summary>
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        '''     [tamttt]	08/01/2004	Created
        ''' </history>
        ''' -------------------------------------------------------------------
        Public Function AuthenticationTypes() As System.Array
            Return AuthenticationProvider.Instance(mProviderTypeName).GetAuthenticationTypes
        End Function

        ''' -------------------------------------------------------------------
        ''' <summary>
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        '''     [tamttt]	08/01/2004	Created
        ''' </history>
        ''' -------------------------------------------------------------------
        Public Function NetworkStatus() As String
            Return AuthenticationProvider.Instance(mProviderTypeName).GetNetworkStatus()
        End Function

        ''' -------------------------------------------------------------------
        ''' <summary>
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        '''     [tamttt]	08/01/2004	Created
        ''' </history>
        ''' -------------------------------------------------------------------
        Public Shared Function GetStatus(ByVal PortalID As Integer) As AuthenticationStatus
            Dim _portalSettings As PortalSettings = PortalController.GetCurrentPortalSettings
            Dim authCookies As String = AUTHENTICATION_STATUS_KEY & "." & PortalID.ToString
            Try
                If Not HttpContext.Current.Request.Cookies(authCookies) Is Nothing Then
                    ' get Authentication from cookie
                    Dim AuthenticationTicket As FormsAuthenticationTicket = FormsAuthentication.Decrypt(HttpContext.Current.Request.Cookies(authCookies).Value)
                    Return CType([Enum].Parse(GetType(AuthenticationStatus), AuthenticationTicket.UserData), AuthenticationStatus)
                Else
                    Return AuthenticationStatus.Undefined
                End If
            Catch ex As Exception
            End Try
        End Function

        ''' -------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        '''     [tamttt]	08/01/2004	Created
        ''' </history>
        ''' -------------------------------------------------------------------
        Public Shared Sub SetStatus(ByVal PortalID As Integer, ByVal Status As AuthenticationStatus)
            Dim authCookies As String = AUTHENTICATION_STATUS_KEY & "." & PortalID.ToString
            Dim Request As HttpRequest = HttpContext.Current.Request
            Dim Response As HttpResponse = HttpContext.Current.Response

            Dim AuthenticationTicket As New FormsAuthenticationTicket(1, authCookies, DateTime.Now, DateTime.Now.AddHours(1), False, Status.ToString)
            ' encrypt the ticket
            Dim strAuthentication As String = FormsAuthentication.Encrypt(AuthenticationTicket)

            If Not Request.Cookies(authCookies) Is Nothing Then
                ' expire
                Request.Cookies(authCookies).Value = Nothing
                Request.Cookies(authCookies).Path = "/"
                Request.Cookies(authCookies).Expires = DateTime.Now.AddYears(-1)
            End If

            Response.Cookies(authCookies).Value = strAuthentication
            Response.Cookies(authCookies).Path = "/"
            Response.Cookies(authCookies).Expires = DateTime.Now.AddHours(1)

        End Sub

    End Class


End Namespace
