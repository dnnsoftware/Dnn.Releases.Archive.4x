'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2006
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.Collections
Imports System.Configuration
Imports System.Data
Imports Microsoft.VisualBasic

Imports DotNetNuke.Common.Utilities
Imports DotNetNuke.Data
Imports DotNetNuke.Entities.Portals
Imports DotNetNuke.Entities.Users
Imports DotNetNuke.Services.Exceptions


Namespace DotNetNuke.Security.Roles

    ''' -----------------------------------------------------------------------------
    ''' Project:    DotNetNuke
    ''' Namespace:  DotNetNuke.Security.Roles
    ''' Class:      RoleController
    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' The RoleController class provides Business Layer methods for Roles
    ''' </summary>
    ''' <history>
    '''     [cnurse]    05/23/2005  made compatible with .NET 2.0
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Public Class RoleController

#Region "Private Shared Members"

        Private Shared provider As DotNetNuke.Security.Roles.RoleProvider = DotNetNuke.Security.Roles.RoleProvider.Instance()

#End Region

#Region "Private Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Auto Assign existing users to a role
        ''' </summary>
        ''' <param name="objRoleInfo">The Role to Auto assign</param>
        ''' <history>
        ''' 	[cnurse]	05/23/2005	Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub AutoAssignUsers(ByVal objRoleInfo As RoleInfo)

            If objRoleInfo.AutoAssignment Then

                ' loop through users for portal and add to role
                Dim arrUsers As ArrayList = UserController.GetUsers(objRoleInfo.PortalID, False)
                For Each objUser As UserInfo In arrUsers
                    Try
                        AddUserRole(objRoleInfo.PortalID, objUser.UserID, objRoleInfo.RoleID, Null.NullDate, Null.NullDate)
                    Catch ex As Exception
                        ' user already belongs to role
                    End Try
                Next
            End If

        End Sub

#End Region

#Region "Role Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' This overload adds a role and optionally adds the info to the AspNet Roles
        ''' </summary>
        ''' <param name="objRoleInfo">The Role to Add</param>
        ''' <returns>The Id of the new role</returns>
        ''' <history>
        ''' 	[cnurse]	05/23/2005	Documented
        '''     [cnurse]    12/15/2005  Abstracted to MembershipProvider
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function AddRole(ByVal objRoleInfo As RoleInfo) As Integer

            Dim roleId As Integer = -1
            Dim success As Boolean = provider.CreateRole(objRoleInfo.PortalID, objRoleInfo)

            If success Then
                AutoAssignUsers(objRoleInfo)
                roleId = objRoleInfo.RoleID
            End If

            Return roleId

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Delete a Role
        ''' </summary>
        ''' <param name="RoleId">The Id of the Role to delete</param>
        ''' <param name="PortalId">The Id of the Portal</param>
        ''' <history>
        ''' 	[cnurse]	05/24/2005	Documented
        '''     [cnurse]    12/15/2005  Abstracted to MembershipProvider
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub DeleteRole(ByVal RoleId As Integer, ByVal PortalId As Integer)

            Dim objRole As RoleInfo = GetRole(RoleId, PortalId)

            If Not objRole Is Nothing Then
                provider.DeleteRole(PortalId, objRole)
            End If

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Get a list of roles for the Portal
        ''' </summary>
        ''' <param name="PortalId">The Id of the Portal</param>
        ''' <returns>An ArrayList of RoleInfo objects</returns>
        ''' <history>
        ''' 	[cnurse]	05/24/2005	Documented
        '''     [cnurse]    12/15/2005  Abstracted to MembershipProvider
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function GetPortalRoles(ByVal PortalId As Integer) As ArrayList
            Return provider.GetRoles(PortalId)
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Fetch a single Role
        ''' </summary>
        ''' <param name="RoleID">The Id of the Role</param>
        ''' <param name="PortalID">The Id of the Portal</param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        ''' <history>
        ''' 	[cnurse]	05/24/2005	Documented
        '''     [cnurse]    12/15/2005  Abstracted to MembershipProvider
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function GetRole(ByVal RoleID As Integer, ByVal PortalID As Integer) As RoleInfo
            Return provider.GetRole(PortalID, RoleID)
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Obtains a role given the role name
        ''' </summary>
        ''' <param name="PortalId">Portal indentifier</param>
        ''' <param name="RoleName">Name of the role to be found</param>
        ''' <returns>A RoleInfo object is the role is found</returns>
        ''' <history>
        ''' 	[VMasanas]	27/08/2004	Created
        '''     [cnurse]    12/15/2005  Abstracted to MembershipProvider
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function GetRoleByName(ByVal PortalId As Integer, ByVal RoleName As String) As RoleInfo
            Return provider.GetRole(PortalId, RoleName)
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Returns an array of rolenames for a Portal
        ''' </summary>
        ''' <param name="PortalId">The Id of the Portal</param>
        ''' <returns>A String Array of Role Names</returns>
        ''' <history>
        ''' 	[cnurse]	05/24/2005	Documented
        '''     [cnurse]    12/15/2005  Abstracted to MembershipProvider
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function GetRoleNames(ByVal PortalID As Integer) As String()
            Return provider.GetRoleNames(PortalID)
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets an ArrayList of Roles
        ''' </summary>
        ''' <returns>An ArrayList of Roles</returns>
        ''' <history>
        ''' 	[cnurse]	05/24/2005	Documented
        '''     [cnurse]    12/15/2005  Abstracted to MembershipProvider
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function GetRoles() As ArrayList
            Return provider.GetRoles(Null.NullInteger)
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Get the roles for a Role Group
        ''' </summary>
        ''' <param name="portalId">Id of the portal</param>
        ''' <param name="roleGroupId">Id of the Role Group (If -1 all roles for the portal are
        ''' retrieved).</param>
        ''' <returns>An ArrayList of RoleInfo objects</returns>
        ''' <history>
        '''     [cnurse]	01/03/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function GetRolesByGroup(ByVal portalId As Integer, ByVal roleGroupId As Integer) As ArrayList

            Return provider.GetRolesByGroup(portalId, roleGroupId)

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets a List of Roles for a given User
        ''' </summary>
        ''' <param name="UserId">The Id of the User</param>
        ''' <param name="PortalId">The Id of the Portal</param>
        ''' <returns>A String Array of Role Names</returns>
        ''' <history>
        ''' 	[cnurse]	05/24/2005	Documented
        '''     [cnurse]    12/15/2005  Abstracted to MembershipProvider
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function GetRolesByUser(ByVal UserId As Integer, ByVal PortalId As Integer) As String()
            Return provider.GetRoleNames(PortalId, UserId)
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Persists a role to the Data Store
        ''' </summary>
        ''' <param name="objRoleInfo">The role to persist</param>
        ''' <history>
        ''' 	[cnurse]	05/24/2005	Documented
        '''     [cnurse]    12/15/2005  Abstracted to MembershipProvider
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub UpdateRole(ByVal objRoleInfo As RoleInfo)
            provider.UpdateRole(objRoleInfo)
            AutoAssignUsers(objRoleInfo)
        End Sub

#End Region

#Region "Role Group Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Adds a Role Group
        ''' </summary>
        ''' <param name="objRoleGroupInfo">The RoleGroup to Add</param>
        ''' <returns>The Id of the new role</returns>
        ''' <history>
        ''' 	[cnurse]	01/03/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function AddRoleGroup(ByVal objRoleGroupInfo As RoleGroupInfo) As Integer

            Return provider.CreateRoleGroup(objRoleGroupInfo)

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Deletes a Role Group
        ''' </summary>
        ''' <history>
        ''' 	[cnurse]	01/03/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Sub DeleteRoleGroup(ByVal PortalID As Integer, ByVal RoleGroupId As Integer)

            DeleteRoleGroup(GetRoleGroup(PortalID, RoleGroupId))

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Deletes a Role Group
        ''' </summary>
        ''' <param name="objRoleGroupInfo">The RoleGroup to Delete</param>
        ''' <history>
        ''' 	[cnurse]	01/03/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Sub DeleteRoleGroup(ByVal objRoleGroupInfo As RoleGroupInfo)

            provider.DeleteRoleGroup(objRoleGroupInfo)

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Fetch a single RoleGroup
        ''' </summary>
        ''' <param name="PortalID">The Id of the Portal</param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        ''' <history>
        ''' 	[cnurse]	01/03/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function GetRoleGroup(ByVal PortalID As Integer, ByVal RoleGroupID As Integer) As RoleGroupInfo
            Return provider.GetRoleGroup(PortalID, RoleGroupID)
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets an ArrayList of RoleGroups
        ''' </summary>
        ''' <param name="PortalID">The Id of the Portal</param>
        ''' <returns>An ArrayList of RoleGroups</returns>
        ''' <history>
        ''' 	[cnurse]	01/03/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function GetRoleGroups(ByVal PortalID As Integer) As ArrayList
            Return provider.GetRoleGroups(PortalID)
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Updates a Role Group
        ''' </summary>
        ''' <param name="objRoleGroupInfo">The RoleGroup to Update</param>
        ''' <history>
        ''' 	[cnurse]	01/03/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Sub UpdateRoleGroup(ByVal objRoleGroupInfo As RoleGroupInfo)

            provider.UpdateRoleGroup(objRoleGroupInfo)

        End Sub

#End Region

#Region "User Role Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Adds a User to a Role
        ''' </summary>
        ''' <param name="PortalID">The Id of the Portal</param>
        ''' <param name="UserId">The Id of the User</param>
        ''' <param name="RoleId">The Id of the Role</param>
        ''' <param name="ExpiryDate">The expiry Date of the Role membership</param>
        ''' <history>
        ''' 	[cnurse]	05/24/2005	Documented
        '''     [cnurse]    12/15/2005  Abstracted to MembershipProvider
        '''     [cnurse]    05/12/2006  Now calls new overload with EffectiveDate = Now()
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub AddUserRole(ByVal PortalID As Integer, ByVal UserId As Integer, ByVal RoleId As Integer, ByVal ExpiryDate As Date)
            AddUserRole(PortalID, UserId, RoleId, DateTime.Now, ExpiryDate)
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Adds a User to a Role
        ''' </summary>
        ''' <remarks>Overload adds Effective Date</remarks>
        ''' <param name="PortalID">The Id of the Portal</param>
        ''' <param name="UserId">The Id of the User</param>
        ''' <param name="RoleId">The Id of the Role</param>
        ''' <param name="EffectiveDate">The expiry Date of the Role membership</param>
        ''' <param name="ExpiryDate">The expiry Date of the Role membership</param>
        ''' <history>
        '''     [cnurse]    05/12/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub AddUserRole(ByVal PortalID As Integer, ByVal UserId As Integer, ByVal RoleId As Integer, ByVal EffectiveDate As Date, ByVal ExpiryDate As Date)

            Dim objUser As UserInfo = UserController.GetUser(PortalID, UserId, False)
            Dim objUserRole As UserRoleInfo = GetUserRole(PortalID, UserId, RoleId)

            If objUserRole Is Nothing Then
                'Create new UserRole
                objUserRole = New UserRoleInfo
                objUserRole.UserID = UserId
                objUserRole.RoleID = RoleId
                objUserRole.PortalID = PortalID
                objUserRole.EffectiveDate = EffectiveDate
                objUserRole.ExpiryDate = ExpiryDate
                provider.AddUserToRole(PortalID, objUser, objUserRole)
            Else
                objUserRole.EffectiveDate = EffectiveDate
                objUserRole.ExpiryDate = ExpiryDate
                provider.UpdateUserRole(objUserRole)
            End If

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Delete/Remove a User from a Role
        ''' </summary>
        ''' <param name="PortalID">The Id of the Portal</param>
        ''' <param name="UserId">The Id of the User</param>
        ''' <param name="RoleId">The Id of the Role</param>
        ''' <returns></returns>
        ''' <history>
        ''' 	[cnurse]	05/24/2005	Documented
        '''     [cnurse]    12/15/2005  Abstracted to MembershipProvider
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function DeleteUserRole(ByVal PortalId As Integer, ByVal UserId As Integer, ByVal RoleId As Integer) As Boolean

            Dim objUser As UserInfo = UserController.GetUser(PortalId, UserId, False)
            Dim objUserRole As UserRoleInfo = GetUserRole(PortalId, UserId, RoleId)

            Dim objPortals As New PortalController
            Dim blnDelete As Boolean = True

            Dim objPortal As PortalInfo = objPortals.GetPortal(PortalId)
            If Not objPortal Is Nothing Then
                If (objPortal.AdministratorId <> UserId Or objPortal.AdministratorRoleId <> RoleId) And objPortal.RegisteredRoleId <> RoleId Then
                    provider.RemoveUserFromRole(PortalId, objUser, objUserRole)
                Else
                    blnDelete = False
                End If
            End If

            Return blnDelete

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets a User/Role
        ''' </summary>
        ''' <param name="PortalID">The Id of the Portal</param>
        ''' <param name="UserId">The Id of the user</param>
        ''' <param name="RoleId">The Id of the Role</param>
        ''' <returns>A UserRoleInfo object</returns>
        ''' <history>
        ''' 	[cnurse]	05/24/2005	Documented
        '''     [cnurse]    12/15/2005  Abstracted to MembershipProvider
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function GetUserRole(ByVal PortalID As Integer, ByVal UserId As Integer, ByVal RoleId As Integer) As UserRoleInfo
            Return provider.GetUserRole(PortalID, UserId, RoleId)
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets a list of UserRoles for a Portal
        ''' </summary>
        ''' <param name="PortalId">The Id of the Portal</param>
        ''' <returns>An ArrayList of UserRoleInfo objects</returns>
        ''' <history>
        ''' 	[Nik Kalyani]	10/15/2004	Created multiple signatures to eliminate Optional parameters
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function GetUserRoles(ByVal PortalId As Integer) As ArrayList
            Return GetUserRoles(PortalId, -1)
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets a list of UserRoles for a User
        ''' </summary>
        ''' <param name="PortalId">The Id of the Portal</param>
        ''' <param name="UserId">The Id of the User</param>
        ''' <returns>An ArrayList of UserRoleInfo objects</returns>
        ''' <history>
        ''' 	[Nik Kalyani]	10/15/2004	Created multiple signatures to eliminate Optional parameters
        '''     [cnurse]    12/15/2005  Abstracted to MembershipProvider
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function GetUserRoles(ByVal PortalId As Integer, ByVal UserId As Integer) As ArrayList
            Return provider.GetUserRoles(PortalId, UserId, True)
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets a list of UserRoles for a User
        ''' </summary>
        ''' <param name="PortalId">The Id of the Portal</param>
        ''' <param name="UserId">The Id of the User</param>
        ''' <returns>An ArrayList of UserRoleInfo objects</returns>
        ''' <history>
        ''' 	[Nik Kalyani]	10/15/2004	Created multiple signatures to eliminate Optional parameters
        '''     [cnurse]    12/15/2005  Abstracted to MembershipProvider
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function GetUserRoles(ByVal PortalId As Integer, ByVal UserId As Integer, ByVal includePrivate As Boolean) As ArrayList
            Return provider.GetUserRoles(PortalId, UserId, includePrivate)
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets a List of UserRoles by UserName and RoleName
        ''' </summary>
        ''' <param name="PortalID">The Id of the Portal</param>
        ''' <param name="Username">The username of the user</param>
        ''' <param name="Rolename">The role name</param>
        ''' <returns>An ArrayList of UserRoleInfo objects</returns>
        ''' <history>
        ''' 	[cnurse]	05/24/2005	Documented
        '''     [cnurse]    12/15/2005  Abstracted to MembershipProvider
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function GetUserRolesByUsername(ByVal PortalID As Integer, ByVal Username As String, ByVal Rolename As String) As ArrayList
            Return provider.GetUserRoles(PortalID, Username, Rolename)
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Get the users in a role (as UserRole objects)
        ''' </summary>
        ''' <param name="portalId">Id of the portal (If -1 all roles for all portals are 
        ''' retrieved.</param>
        ''' <param name="roleName">The role to fetch users for</param>
        ''' <returns>An ArrayList of UserRoleInfo objects</returns>
        ''' <history>
        '''     [cnurse]	01/27/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function GetUserRolesByRoleName(ByVal portalId As Integer, ByVal roleName As String) As ArrayList
            Return provider.GetUserRolesByRoleName(portalId, roleName)
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Get the users in a role (as User objects)
        ''' </summary>
        ''' <param name="portalId">Id of the portal (If -1 all roles for all portals are 
        ''' retrieved.</param>
        ''' <param name="roleName">The role to fetch users for</param>
        ''' <returns>An ArrayList of UserInfo objects</returns>
        ''' <history>
        '''     [cnurse]	01/27/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function GetUsersByRoleName(ByVal PortalID As Integer, ByVal RoleName As String) As ArrayList
            Return provider.GetUsersByRoleName(PortalID, RoleName)
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Updates a Service (UserRole)
        ''' </summary>
        ''' <param name="PortalID">The Id of the Portal</param>
        ''' <param name="UserId">The Id of the User</param>
        ''' <param name="RoleId">The Id of the Role</param>
        ''' <history>
        ''' 	[Nik Kalyani]	10/15/2004	Created multiple signatures to eliminate Optional parameters
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub UpdateUserRole(ByVal PortalId As Integer, ByVal UserId As Integer, ByVal RoleId As Integer)
            UpdateUserRole(PortalId, UserId, RoleId, False)
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Updates a Service (UserRole)
        ''' </summary>
        ''' <param name="PortalID">The Id of the Portal</param>
        ''' <param name="UserId">The Id of the User</param>
        ''' <param name="RoleId">The Id of the Role</param>
        ''' <param name="Cancel">A flag that indicates whether to cancel (delete) the userrole</param>
        ''' <history>
        ''' 	[Nik Kalyani]	10/15/2004	Created multiple signatures to eliminate Optional parameters
        '''     [cnurse]    12/15/2005  Abstracted to MembershipProvider
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub UpdateUserRole(ByVal PortalId As Integer, ByVal UserId As Integer, ByVal RoleId As Integer, ByVal Cancel As Boolean)

            If Cancel Then
                DeleteUserRole(PortalId, UserId, RoleId)
            Else
                Dim UserRoleId As Integer = -1
                Dim userRole As UserRoleInfo
                Dim role As RoleInfo
                Dim ExpiryDate As Date = Now
                Dim EffectiveDate As Date = Null.NullDate
                Dim IsTrialUsed As Boolean = False
                Dim Period As Integer
                Dim Frequency As String = ""

                userRole = GetUserRole(PortalId, UserId, RoleId)

                If Not userRole Is Nothing Then
                    UserRoleId = userRole.UserRoleID
                    EffectiveDate = userRole.EffectiveDate
                    ExpiryDate = userRole.ExpiryDate
                    IsTrialUsed = userRole.IsTrialUsed
                End If

                role = GetRole(RoleId, PortalId)

                If Not role Is Nothing Then
                    If IsTrialUsed = False And role.TrialFrequency.ToString <> "N" Then
                        Period = role.TrialPeriod
                        Frequency = role.TrialFrequency
                    Else
                        Period = role.BillingPeriod
                        Frequency = role.BillingFrequency
                    End If
                End If

                If EffectiveDate < Now Then
                    EffectiveDate = Null.NullDate
                End If
                If ExpiryDate < Now Then
                    ExpiryDate = Now
                End If

                Select Case Frequency
                    Case "N" : ExpiryDate = Null.NullDate
                    Case "O" : ExpiryDate = New System.DateTime(9999, 12, 31)
                    Case "D" : ExpiryDate = DateAdd(DateInterval.Day, Period, Convert.ToDateTime(ExpiryDate))
                    Case "W" : ExpiryDate = DateAdd(DateInterval.Day, (Period * 7), Convert.ToDateTime(ExpiryDate))
                    Case "M" : ExpiryDate = DateAdd(DateInterval.Month, Period, Convert.ToDateTime(ExpiryDate))
                    Case "Y" : ExpiryDate = DateAdd(DateInterval.Year, Period, Convert.ToDateTime(ExpiryDate))
                End Select

                If UserRoleId <> -1 Then
                    userRole.ExpiryDate = ExpiryDate
                    provider.UpdateUserRole(userRole)
                Else
                    AddUserRole(PortalId, UserId, RoleId, EffectiveDate, ExpiryDate)
                End If
            End If

        End Sub

#End Region

#Region "Obsoleted Methods, retained for Binary Compatability"

        <Obsolete("This function has been replaced by AddRole(objRoleInfo)")> _
        Public Function AddRole(ByVal objRoleInfo As RoleInfo, ByVal SynchronizationMode As Boolean) As Integer
            AddRole(objRoleInfo)
        End Function

        <Obsolete("This function has been replaced by GetPortalRoles(PortalId)")> _
        Public Function GetPortalRoles(ByVal PortalId As Integer, ByVal SynchronizeRoles As Boolean) As ArrayList
            Return GetPortalRoles(PortalId)
        End Function

        <Obsolete("This function has been replaced by GetRolesByUser")> _
        Public Function GetPortalRolesByUser(ByVal UserId As Integer, ByVal PortalId As Integer) As String()
            Return GetRolesByUser(UserId, PortalId)
        End Function

        <Obsolete("This function has been replaced by GetUserRoles")> _
        Public Function GetServices(ByVal PortalId As Integer) As ArrayList
            Return GetUserRoles(PortalId, -1, False)
        End Function

        <Obsolete("This function has been replaced by GetUserRoles")> _
        Public Function GetServices(ByVal PortalId As Integer, ByVal UserId As Integer) As ArrayList
            Return GetUserRoles(PortalId, UserId, False)
        End Function

        <Obsolete("This function has been replaced by GetUserRolesByRoleName")> _
        Public Function GetUsersInRole(ByVal PortalID As Integer, ByVal RoleName As String) As ArrayList
            Return provider.GetUserRolesByRoleName(PortalID, RoleName)
        End Function

        <Obsolete("This function has been replaced by UpdateUserRole")> _
        Public Sub UpdateService(ByVal PortalId As Integer, ByVal UserId As Integer, ByVal RoleId As Integer)
            UpdateUserRole(PortalId, UserId, RoleId, False)
        End Sub

        <Obsolete("This function has been replaced by UpdateUserRole")> _
        Public Sub UpdateService(ByVal PortalId As Integer, ByVal UserId As Integer, ByVal RoleId As Integer, ByVal Cancel As Boolean)
            UpdateUserRole(PortalId, UserId, RoleId, Cancel)
        End Sub

#End Region

    End Class

End Namespace
