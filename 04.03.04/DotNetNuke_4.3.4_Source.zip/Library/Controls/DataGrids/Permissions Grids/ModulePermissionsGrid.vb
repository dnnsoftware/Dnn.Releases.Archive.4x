'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2006
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.Drawing
Imports System.Text
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.IO
Imports System.Collections
Imports System.Data
Imports DotNetNuke.Security.Roles
Imports DotNetNuke.Services.Localization

Namespace DotNetNuke.Security.Permissions.Controls

    Public Class ModulePermissionsGrid
        Inherits PermissionsGrid

#Region "Private Members"

        Private _InheritViewPermissionsFromTab As Boolean = False
        Private _ModuleID As Integer = -1
        Private ModulePermissions As ModulePermissionCollection
        Private _ViewColumnIndex As Integer

#End Region

#Region "Public Properties"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets and Sets whether the Module inherits the Page's(Tab's) permissions
        ''' </summary>
        ''' <history>
        '''     [cnurse]    01/09/2006  Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Property InheritViewPermissionsFromTab() As Boolean
            Get
                Return _InheritViewPermissionsFromTab
            End Get
            Set(ByVal Value As Boolean)
                _InheritViewPermissionsFromTab = Value
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets and Sets the Id of the Module
        ''' </summary>
        ''' <history>
        '''     [cnurse]    01/09/2006  Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Property ModuleID() As Integer
            Get
                Return _ModuleID
            End Get
            Set(ByVal Value As Integer)
                _ModuleID = Value
                If Not Page.IsPostBack Then
                    GetModulePermissions()
                End If
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets the ModulePermission Collection
        ''' </summary>
        ''' <history>
        '''     [cnurse]    01/09/2006  Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public ReadOnly Property Permissions() As Security.Permissions.ModulePermissionCollection
            Get
                'First Update Permissions in case they have been changed
                UpdatePermissions()

                'Return the ModulePermissions
                Return ModulePermissions
            End Get
        End Property

#End Region

#Region "Private Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets the ModulePermissions from the Data Store
        ''' </summary>
        ''' <history>
        '''     [cnurse]    01/12/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub GetModulePermissions()

            Dim objModulePermissionController As New Security.Permissions.ModulePermissionController
            ModulePermissions = objModulePermissionController.GetModulePermissionsCollectionByModuleID(Me.ModuleID)

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Check if the Role has the permission specified
        ''' </summary>
        ''' <param name="permissionID">The Id of the Permission to check</param>
        ''' <param name="roleId">The role id to check</param>
        ''' <history>
        '''     [cnurse]    01/09/2006  Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function ModuleHasPermission(ByVal permissionID As Integer, ByVal roleId As Integer) As Security.Permissions.ModulePermissionInfo
            Dim i As Integer
            For i = 0 To ModulePermissions.Count - 1
                Dim objModulePermission As Security.Permissions.ModulePermissionInfo = ModulePermissions(i)
                If objModulePermission.RoleID = roleId And permissionID = objModulePermission.PermissionID Then
                    Return objModulePermission
                End If
            Next
            Return Nothing
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Parse the Permission Keys used to persist the Permissions in the ViewState
        ''' </summary>
        ''' <param name="Settings">A string array of settings</param>
        ''' <param name="arrPermisions">An Arraylist to add the Permission object to</param>
        ''' <history>
        '''     [cnurse]    01/09/2006  Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub ParsePermissionKeys(ByVal Settings As String(), ByVal arrPermisions As ArrayList)

            Dim objRoleController As New RoleController
            Dim objModulePermissionController As New Security.Permissions.ModulePermissionController
            Dim objModulePermission As Security.Permissions.ModulePermissionInfo

            objModulePermission = New Security.Permissions.ModulePermissionInfo
            objModulePermission.PermissionID = Convert.ToInt32(Settings(1))
            objModulePermission.RoleID = Convert.ToInt32(Settings(4))

            If Settings(2) = "" Then
                objModulePermission.ModulePermissionID = -1
            Else
                objModulePermission.ModulePermissionID = Convert.ToInt32(Settings(2))
            End If
            objModulePermission.RoleName = Settings(3)
            objModulePermission.AllowAccess = True

            objModulePermission.ModuleID = ModuleID
            arrPermisions.Add(objModulePermission)

        End Sub


#End Region

#Region "Protected Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets the Enabled status of the permission
        ''' </summary>
        ''' <param name="objPerm">The permission being loaded</param>
        ''' <param name="role">The role</param>
        ''' <param name="column">The column of the Grid</param>
        ''' <history>
        '''     [cnurse]    01/13/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Protected Overrides Function GetEnabled(ByVal objPerm As PermissionInfo, ByVal role As RoleInfo, ByVal column As Integer) As Boolean

            Dim enabled As Boolean

            If InheritViewPermissionsFromTab And column = _ViewColumnIndex Then
                enabled = False
            Else
                If role.RoleID = AdministratorRoleId Then
                    enabled = False
                Else
                    enabled = True
                End If
            End If

            Return enabled

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets the Value of the permission
        ''' </summary>
        ''' <param name="objPerm">The permission being loaded</param>
        ''' <param name="role">The role</param>
        ''' <param name="column">The column of the Grid</param>
        ''' <returns>A Boolean (True or False)</returns>
        ''' <history>
        '''     [cnurse]    01/09/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Protected Overrides Function GetPermission(ByVal objPerm As PermissionInfo, ByVal role As RoleInfo, ByVal column As Integer) As Boolean

            Dim permission As Boolean

            If InheritViewPermissionsFromTab And column = _ViewColumnIndex Then
                permission = False
            Else
                If role.RoleID = AdministratorRoleId Then
                    permission = True
                Else
                    Dim objModulePermission As Security.Permissions.ModulePermissionInfo = ModuleHasPermission(objPerm.PermissionID, role.RoleID)
                    If Not objModulePermission Is Nothing Then
                        permission = objModulePermission.AllowAccess
                    Else
                        permission = False
                    End If
                End If
            End If

            Return permission

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets the Permissions from the Data Store
        ''' </summary>
        ''' <history>
        '''     [cnurse]    01/09/2006  Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Protected Overrides Function GetPermissions() As ArrayList

            Dim objPermissionController As New Security.Permissions.PermissionController
            Dim arrPermissions As ArrayList = objPermissionController.GetPermissionsByModuleID(Me.ModuleID)

            Dim i As Integer
            For i = 0 To arrPermissions.Count - 1
                Dim objPermission As Security.Permissions.PermissionInfo
                objPermission = CType(arrPermissions(i), Security.Permissions.PermissionInfo)
                If objPermission.PermissionKey = "VIEW" Then
                    _ViewColumnIndex = i + 1
                End If
            Next

            Return arrPermissions

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Load the ViewState
        ''' </summary>
        ''' <param name="savedState">The saved state</param>
        ''' <history>
        '''     [cnurse]    01/12/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Protected Overrides Sub LoadViewState(ByVal savedState As Object)

            If Not (savedState Is Nothing) Then
                ' Load State from the array of objects that was saved with SaveViewState.

                Dim myState As Object() = CType(savedState, Object())

                'Load Base Controls ViewStte
                If Not (myState(0) Is Nothing) Then
                    MyBase.LoadViewState(myState(0))
                End If

                'Load ModuleID
                If Not (myState(1) Is Nothing) Then
                    ModuleID = CInt(myState(1))
                End If

                'Load InheritViewPermissionsFromTab
                If Not (myState(2) Is Nothing) Then
                    InheritViewPermissionsFromTab = CBool(myState(2))
                End If

                'Load ModulePermissions
                If Not (myState(3) Is Nothing) Then
                    Dim arrPermissions As New ArrayList
                    Dim state As String = CStr(myState(3))
                    If state <> "" Then
                        'First Break the String into individual Keys
                        Dim permissionKeys As String() = Split(state, "##")
                        For Each key As String In permissionKeys
                            Dim Settings As String() = Split(key, "|")
                            ParsePermissionKeys(Settings, arrPermissions)
                        Next
                    End If
                    ModulePermissions = New ModulePermissionCollection(arrPermissions)
                End If
            End If

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Saves the ViewState
        ''' </summary>
        ''' <history>
        '''     [cnurse]    01/12/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Protected Overrides Function SaveViewState() As Object

            Dim allStates(3) As Object

            ' Save the Base Controls ViewState
            allStates(0) = MyBase.SaveViewState()

            'Save the ModuleID
            allStates(1) = ModuleID

            'Save the InheritViewPermissionsFromTab
            allStates(2) = InheritViewPermissionsFromTab

            'Persist the ModulePermissions
            Dim sb As New StringBuilder
            Dim addDelimiter As Boolean = False
            For Each objModulePermission As ModulePermissionInfo In ModulePermissions
                If addDelimiter Then
                    sb.Append("##")
                Else
                    addDelimiter = True
                End If
                sb.Append(BuildKey(objModulePermission.AllowAccess, objModulePermission.PermissionID, objModulePermission.ModulePermissionID, objModulePermission.RoleID, objModulePermission.RoleName))
            Next
            allStates(3) = sb.ToString()

            Return allStates

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Updates a Permission
        ''' </summary>
        ''' <param name="permission">The permission being updated</param>
        ''' <param name="roleName">The name of the role</param>
        ''' <param name="roleId">The id of the role</param>
        ''' <param name="allowAccess">The value of the permission</param>
        ''' <history>
        '''     [cnurse]    01/12/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Protected Overrides Sub UpdatePermission(ByVal permission As PermissionInfo, ByVal roleid As Integer, ByVal roleName As String, ByVal allowAccess As Boolean)

            Dim isMatch As Boolean = False
            Dim objPermission As ModulePermissionInfo
            Dim permissionId As Integer = permission.PermissionID

            'Search ModulePermission Collection for the permission to Update
            For Each objPermission In ModulePermissions
                If objPermission.PermissionID = permissionId And objPermission.RoleID = roleid Then
                    'ModulePermission is in collection
                    If Not allowAccess Then
                        'Remove from collection as we only keep AllowAccess permissions
                        ModulePermissions.Remove(objPermission)
                    End If
                    isMatch = True
                    Exit For
                End If
            Next

            'ModulePermission not found so add new
            If Not isMatch And allowAccess Then
                objPermission = New ModulePermissionInfo
                objPermission.PermissionID = permissionId
                objPermission.RoleName = roleName
                objPermission.RoleID = roleid
                objPermission.AllowAccess = allowAccess
                objPermission.ModuleID = ModuleID
                ModulePermissions.Add(objPermission)
            End If

        End Sub
#End Region

#Region "Public Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Overrides the Base method to Generate the Data Grid
        ''' </summary>
        ''' <history>
        '''     [cnurse]    01/09/2006  Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overrides Sub GenerateDataGrid()

        End Sub

#End Region

    End Class

End Namespace