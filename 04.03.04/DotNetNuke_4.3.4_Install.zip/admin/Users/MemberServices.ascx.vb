'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2006
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.Web.Security

Imports DotNetNuke.Entities.Modules
Imports DotNetNuke.Security.Roles
Imports DotNetNuke.Security.Membership
Imports DotNetNuke.Services.Localization
Imports DotNetNuke.Services.Mail
Imports DotNetNuke.UI.Skins


Namespace DotNetNuke.Modules.Admin.Security

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' The MemberServices UserModuleBase is used to manage a User's services
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[cnurse]	03/03/2006
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Partial Class MemberServices
        Inherits UserModuleBase

#Region "Private Members"

        Private Services As Integer = 0
        Private RoleID As Integer = -1

#End Region

#Region "Public Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' DataBind binds the data to the controls
        ''' </summary>
        ''' <history>
        ''' 	[cnurse]	03/13/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overrides Sub DataBind()

            'Localize the Headers
            Localization.LocalizeDataGrid(grdServices, Me.LocalResourceFile)

            If Services = 1 Then
                Dim objRoles As New RoleController
                grdServices.DataSource = objRoles.GetUserRoles(PortalId)
                grdServices.DataBind()

                If grdServices.Items.Count <> 0 Then
                    lblServices.Text = String.Format(Localization.GetString("PleaseRegister", Me.LocalResourceFile), GetPortalDomainName(PortalAlias.HTTPAlias, Request) & "/" & glbDefaultPage, TabId)
                Else
                    grdServices.Visible = False
                    lblServices.Text = Localization.GetString("MembershipNotOffered", Me.LocalResourceFile)
                End If
                lblServices.Visible = True

                grdServices.Columns(0).Visible = False    ' subscribe
                grdServices.Columns(9).Visible = False    ' expiry date

            Else
                If Request.IsAuthenticated Then
                    Dim objRoles As New RoleController

                    grdServices.DataSource = objRoles.GetUserRoles(PortalId, UserInfo.UserID, False)
                    grdServices.DataBind()

                    ' if no service available then hide options
                    'ServicesRow.Visible = (grdServices.Items.Count > 0)
                End If
            End If

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' FormatURL correctly formats a URL
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        '''	<returns>The correctly formatted url</returns>
        ''' <history>
        ''' 	[cnurse]	9/13/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function FormatURL() As String
            Dim _FormatURL As String = Null.NullString
            Try
                Dim strServerPath As String

                strServerPath = Request.ApplicationPath
                If Not strServerPath.EndsWith("/") Then
                    strServerPath += "/"
                End If

                _FormatURL = strServerPath & "Register.aspx?tabid=" & TabId
            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
            Return _FormatURL
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' FormatPrice formats the Fee amount and filters out null-values
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        '''	<param name="price">The price to format</param>
        '''	<returns>The correctly formatted price</returns>
        ''' <history>
        ''' 	[cnurse]	9/13/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Function FormatPrice(ByVal price As Single) As String
            Dim _FormatPrice As String = Null.NullString
            Try
                If price <> Null.NullSingle Then
                    _FormatPrice = price.ToString("##0.00")
                Else
                    _FormatPrice = ""
                End If
            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
            Return _FormatPrice
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' FormatPeriod formats the Period and filters out null-values
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        '''	<param name="period">The period to format</param>
        '''	<returns>The correctly formatted period</returns>
        ''' <history>
        ''' 	[cnurse]	9/13/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Function FormatPeriod(ByVal period As Integer) As String
            Dim _FormatPeriod As String = Null.NullString
            Try
                If period <> Null.NullInteger Then
                    _FormatPeriod = period.ToString
                End If
            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
            Return _FormatPeriod
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' FormatExpiryDate formats the expiry date and filters out null-values
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        '''	<param name="DateTime">The date to format</param>
        '''	<returns>The correctly formatted date</returns>
        ''' <history>
        ''' 	[cnurse]	9/13/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Function FormatExpiryDate(ByVal DateTime As Date) As String
            Dim _FormatExpiryDate As String = Null.NullString
            Try
                If Not Null.IsNull(DateTime) Then
                    _FormatExpiryDate = DateTime.ToShortDateString
                End If
            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
            Return _FormatExpiryDate
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' ServiceText gets the Service Text (Cancel or Subscribe)
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        '''	<param name="Subscribed">The service state</param>
        '''	<returns>The correctly formatted text</returns>
        ''' <history>
        ''' 	[cnurse]	9/13/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function ServiceText(ByVal Subscribed As Boolean) As String
            Dim _ServiceText As String = Null.NullString
            Try
                If Not Subscribed Then
                    _ServiceText = Localization.GetString("Subscribe", Me.LocalResourceFile)
                Else
                    _ServiceText = Localization.GetString("Unsubscribe", Me.LocalResourceFile)
                End If
            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
            Return _ServiceText
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' ServiceURL correctly formats the Subscription url
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        '''	<param name="strKeyName">The key name for the service</param>
        '''	<param name="strKeyValue">The key value for the service</param>
        '''	<param name="objServiceFee">The service fee</param>
        '''	<param name="Subscribed">The service state</param>
        '''	<returns>The correctly formatted url</returns>
        ''' <history>
        ''' 	[cnurse]	9/13/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function ServiceURL(ByVal strKeyName As String, ByVal strKeyValue As String, ByVal objServiceFee As Object, ByVal Subscribed As Boolean) As String
            Dim _ServiceURL As String = Null.NullString
            Try
                Dim dblServiceFee As Double = 0
                Dim ctlRegister As String = ""

                If Not IsDBNull(objServiceFee) Then
                    dblServiceFee = Convert.ToDouble(objServiceFee)
                End If

                If PortalSettings.UserTabId <> -1 Then
                    ' user defined tab
                    ctlRegister = ""
                Else
                    ' admin tab
                    ctlRegister = "Register"
                End If

                If Not Subscribed Then
                    If dblServiceFee > 0 Then
                        _ServiceURL = "~/admin/Sales/PayPalSubscription.aspx?tabid=" & TabId & "&" & strKeyName & "=" & strKeyValue
                    Else
                        _ServiceURL = NavigateURL(PortalSettings.UserTabId, ctlRegister, strKeyName & "=" & strKeyValue)
                    End If
                Else    ' cancel
                    If dblServiceFee > 0 Then
                        _ServiceURL = "~/admin/Sales/PayPalSubscription.aspx?tabid=" & TabId & "&" & strKeyName & "=" & strKeyValue & "&cancel=1"
                    Else
                        _ServiceURL = NavigateURL(PortalSettings.UserTabId, ctlRegister, strKeyName & "=" & strKeyValue, "cancel=1")
                    End If
                End If

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
            Return _ServiceURL
        End Function

#End Region

#Region "Event Handlers"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Page_Load runs when the control is loaded
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	03/13/2006
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                If Not (Request.QueryString("Services") Is Nothing) Then
                    Services = Int32.Parse(Request.QueryString("Services"))
                End If

                ' free subscriptions
                If Not (Request.QueryString("RoleID") Is Nothing) Then
                    RoleID = Int32.Parse(Request.QueryString("RoleID"))

                    Dim objRoles As New RoleController

                    Dim objRole As RoleInfo = objRoles.GetRole(RoleID, PortalSettings.PortalId)

                    If objRole.IsPublic And objRole.ServiceFee = 0.0 Then
                        objRoles.UpdateUserRole(PortalId, UserInfo.UserID, RoleID, Convert.ToBoolean(IIf(Not Request.QueryString("cancel") Is Nothing, True, False)))

                        If PortalSettings.UserTabId <> -1 Then
                            ' user defined tab
                            Response.Redirect(NavigateURL(PortalSettings.UserTabId), True)
                        Else
                            ' admin tab
                            Response.Redirect(NavigateURL(TabId, "profile", "UserID=" + UserInfo.UserID.ToString), True)
                        End If
                    Else
                        ' EVENTLOGGER
                    End If
                End If

                ' If this is the first visit to the page, bind the role data to the datalist
                If Page.IsPostBack = False Then

                    'DataBind()

                End If
            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' cmdRSVP_Click runs when the Subscribe to RSVP Code Roles Button is clicked
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	01/19/2006  created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdRSVP_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRSVP.Click

            'Get the RSVP code
            Dim code As String = txtRSVPCode.Text

            If code <> "" Then
                'Get the roles from the Database
                Dim objRoles As New RoleController
                Dim objRole As RoleInfo
                Dim arrRoles As ArrayList = objRoles.GetPortalRoles(PortalSettings.PortalId)

                'Parse the roles
                For Each objRole In arrRoles
                    If objRole.RSVPCode = code Then
                        'Subscribe User to Role
                        objRoles.UpdateUserRole(PortalId, UserInfo.UserID, objRole.RoleID)
                    End If
                Next
            End If

            'Reset RSVP Code field
            txtRSVPCode.Text = ""

            DataBind()

        End Sub
#End Region

    End Class

End Namespace
