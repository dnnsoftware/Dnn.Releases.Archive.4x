'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2006
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports DotNetNuke.Common.Lists
Imports DotNetNuke.Entities.Modules
Imports DotNetNuke.Entities.Modules.Actions
Imports DotNetNuke.Entities.Profile
Imports DotNetNuke.Services.Localization
Imports DotNetNuke.UI.Utilities
Imports DotNetNuke.UI.WebControls

Namespace DotNetNuke.Modules.Admin.Users

	''' -----------------------------------------------------------------------------
	''' <summary>
    ''' The ProfileDefinitions PortalModuleBase is used to manage the Profile Properties
    ''' for a portal
	''' </summary>
    ''' <remarks>
	''' </remarks>
	''' <history>
    ''' 	[cnurse]	02/16/2006  Created
	''' </history>
	''' -----------------------------------------------------------------------------
    Partial Class ProfileDefinitions
        Inherits Entities.Modules.PortalModuleBase
        Implements Entities.Modules.IActionable

#Region "Constants"

        Const COLUMN_REQUIRED As Integer = 10
        Const COLUMN_VISIBLE As Integer = 11
        Const COLUMN_MOVE_DOWN As Integer = 2
        Const COLUMN_MOVE_UP As Integer = 3

#End Region

#Region "Protected Members"
        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets whether we are dealing with SuperUsers
        ''' </summary>
        ''' <history>
        ''' 	[cnurse]	05/11/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Protected ReadOnly Property IsSuperUser() As Boolean
            Get
                If PortalSettings.ActiveTab.ParentId = PortalSettings.SuperTabId Then
                    Return True
                Else
                    Return False
                End If
            End Get
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets the Return Url for the page
        ''' </summary>
        ''' <history>
        ''' 	[cnurse]	03/09/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public ReadOnly Property ReturnUrl() As String
            Get
                Return NavigateURL(TabId)
            End Get
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets the Portal Id whose Users we are managing
        ''' </summary>
        ''' <history>
        ''' 	[cnurse]	05/11/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Protected ReadOnly Property UsersPortalId() As Integer
            Get
                Dim intPortalId As Integer = PortalId
                If IsSuperUser Then
                    intPortalId = Null.NullInteger
                End If
                Return intPortalId
            End Get
        End Property

#End Region

#Region "Private Members"
        Private m_objProperties As ProfilePropertyDefinitionCollection
#End Region

#Region "Private Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets the properties 
        ''' </summary>
        ''' <history>
        '''     [cnurse]	02/23/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function GetProperties() As ProfilePropertyDefinitionCollection
            Dim strKey As String = ProfileController.PROPERTIES_CACHEKEY & "." & UsersPortalId.ToString
            If m_objProperties Is Nothing Then
                m_objProperties = CType(DataCache.GetCache(strKey), ProfilePropertyDefinitionCollection)
                If m_objProperties Is Nothing Then
                    m_objProperties = ProfileController.GetPropertyDefinitionsByPortal(UsersPortalId)
                    DataCache.SetCache(strKey, m_objProperties)
                End If
            End If
            Return m_objProperties
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Helper function that clears property cache
        ''' </summary>
        ''' <history>
        '''     [Jon Henning]	03/12/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub ClearCachedProperties()
            Dim strKey As String = ProfileController.PROPERTIES_CACHEKEY & "." & UsersPortalId.ToString
            DataCache.RemoveCache(strKey)
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Helper function that determines whether the client-side functionality is possible
        ''' </summary>
        ''' <history>
        '''     [Jon Henning]	03/12/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function SupportsRichClient() As Boolean
            Return DotNetNuke.UI.Utilities.ClientAPI.BrowserSupportsFunctionality(ClientAPI.ClientFunctionality.DHTML)
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Deletes a property
        ''' </summary>
        ''' <param name="index">The index of the Property to delete</param>
        ''' <history>
        '''     [cnurse]	02/23/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub DeleteProperty(ByVal index As Integer)
            Dim profileProperties As ProfilePropertyDefinitionCollection = GetProperties()
            Dim objProperty As ProfilePropertyDefinition = profileProperties(index)

            ProfileController.DeletePropertyDefinition(objProperty)

            RefreshGrid()
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Moves a property
        ''' </summary>
        ''' <param name="index">The index of the Property to move</param>
        ''' <param name="destIndex">The new index of the Property</param>
        ''' <history>
        '''     [cnurse]	02/23/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub MoveProperty(ByVal index As Integer, ByVal destIndex As Integer)

            Dim profileProperties As ProfilePropertyDefinitionCollection = GetProperties()
            Dim objProperty As ProfilePropertyDefinition = profileProperties(index)
            Dim objNext As ProfilePropertyDefinition = profileProperties(destIndex)

            Dim currentOrder As Integer = objProperty.ViewOrder
            Dim nextOrder As Integer = objNext.ViewOrder

            'Swap ViewOrders
            objProperty.ViewOrder = nextOrder
            objNext.ViewOrder = currentOrder

            ''Refresh Grid
            profileProperties.Sort()
            BindGrid()

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Moves a property down in the ViewOrder
        ''' </summary>
        ''' <param name="index">The index of the Property to move</param>
        ''' <history>
        '''     [cnurse]	02/23/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub MovePropertyDown(ByVal index As Integer)

            MoveProperty(index, index + 1)

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Moves a property up in the ViewOrder
        ''' </summary>
        ''' <param name="index">The index of the Property to move</param>
        ''' <history>
        '''     [cnurse]	02/23/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub MovePropertyUp(ByVal index As Integer)

            MoveProperty(index, index - 1)

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Binds the Property Collection to the Grid
        ''' </summary>
        ''' <history>
        '''     [cnurse]	02/23/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub BindGrid()

            Dim properties As ProfilePropertyDefinitionCollection = GetProperties()
            Dim allRequired As Boolean = True
            Dim allVisible As Boolean = True

            'Check whether the checkbox column headers are true or false
            For Each profProperty As ProfilePropertyDefinition In properties
                If profProperty.Required = False Then
                    allRequired = False
                End If
                If profProperty.Visible = False Then
                    allVisible = False
                End If

                If Not allRequired And Not allVisible Then
                    Exit For
                End If
            Next

            For Each column As DataGridColumn In grdProfileProperties.Columns
                If column.GetType Is GetType(CheckBoxColumn) Then
                    'Manage CheckBox column events
                    Dim cbColumn As CheckBoxColumn = CType(column, CheckBoxColumn)
                    If cbColumn.DataField = "Required" Then
                        cbColumn.Checked = allRequired
                    End If
                    If cbColumn.DataField = "Visible" Then
                        cbColumn.Checked = allVisible
                    End If
                End If
            Next
            grdProfileProperties.DataSource = properties
            grdProfileProperties.DataBind()

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Refresh the Property Collection to the Grid
        ''' </summary>
        ''' <history>
        '''     [cnurse]	02/23/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub RefreshGrid()
            ProfileController.ClearProfileDefinitionCache(UsersPortalId)
            m_objProperties = Nothing
            BindGrid()
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Updates any "dirty" properties
        ''' </summary>
        ''' <history>
        '''     [cnurse]	02/23/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub UpdateProperties()
            Dim profileProperties As ProfilePropertyDefinitionCollection = GetProperties()
            For Each objProperty As ProfilePropertyDefinition In profileProperties
                If objProperty.IsDirty Then
                    ProfileController.UpdatePropertyDefinition(objProperty)
                End If
            Next
            ClearCachedProperties()
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' This method is responsible for taking in posted information from the grid and
        ''' persisting it to the property definition collection
        ''' </summary>
        ''' <history>
        '''     [Jon Henning]	03/12/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub ProcessPostBack()
            Try
                Dim objProperties As ProfilePropertyDefinitionCollection = GetProperties()
                Dim aryNewOrder() As String = DotNetNuke.UI.Utilities.ClientAPI.GetClientSideReorder(Me.grdProfileProperties.ClientID, Me.Page)
                Dim objProperty As ProfilePropertyDefinition
                Dim objItem As DataGridItem
                Dim chk As CheckBox
                For i As Integer = 0 To Me.grdProfileProperties.Items.Count - 1
                    objItem = Me.grdProfileProperties.Items(i)
                    objProperty = objProperties(i)
                    chk = CType(objItem.Cells(COLUMN_REQUIRED).Controls(0), CheckBox)
                    objProperty.Required = chk.Checked
                    chk = CType(objItem.Cells(COLUMN_VISIBLE).Controls(0), CheckBox)
                    objProperty.Visible = chk.Checked
                Next
                'assign vieworder
                For i As Integer = 0 To aryNewOrder.Length - 1
                    objProperties(CInt(aryNewOrder(i))).ViewOrder = i
                Next
                objProperties.Sort()

            Catch ex As Exception
                Throw ex
            End Try
        End Sub

#End Region

#Region "Public Methods"

        Public Function DisplayDataType(ByVal definition As ProfilePropertyDefinition) As String

            Dim retValue As String = Null.NullString
            Dim objListController As New ListController
            Dim definitionEntry As ListEntryInfo = objListController.GetListEntryInfo(definition.DataType)

            If Not definitionEntry Is Nothing Then
                retValue = definitionEntry.Value
            End If

            Return retValue

        End Function
#End Region

#Region "Event Handlers"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Page_Init runs when the control is initialised
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	02/16/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            For Each column As DataGridColumn In grdProfileProperties.Columns
                If column.GetType Is GetType(CheckBoxColumn) Then
                    If SupportsRichClient() = False Then
                        Dim cbColumn As CheckBoxColumn = CType(column, CheckBoxColumn)
                        AddHandler cbColumn.CheckedChanged, AddressOf grdProfileProperties_ItemCheckedChanged
                    End If
                ElseIf column.GetType Is GetType(ImageCommandColumn) Then
                    'Manage Delete Confirm JS
                    Dim imageColumn As ImageCommandColumn = CType(column, ImageCommandColumn)
                    Select Case imageColumn.CommandName
                        Case "Delete"
                            imageColumn.OnClickJS = Localization.GetString("DeleteItem")
                            imageColumn.Text = Localization.GetString("Delete", Me.LocalResourceFile)
                        Case "Edit"
                            'The Friendly URL parser does not like non-alphanumeric characters
                            'so first create the format string with a dummy value and then
                            'replace the dummy value with the FormatString place holder
                            Dim formatString As String = EditUrl("PropertyDefinitionID", "KEYFIELD", "EditProfileProperty")
                            formatString = formatString.Replace("KEYFIELD", "{0}")
                            imageColumn.NavigateURLFormatString = formatString
                        Case "MoveUp"
                            imageColumn.Text = Localization.GetString("MoveUp", Me.LocalResourceFile)
                        Case "MoveDown"
                            imageColumn.Text = Localization.GetString("MoveDown", Me.LocalResourceFile)
                    End Select
                End If
            Next

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Page_Load runs when the control is loaded
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	02/16/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                If Not Page.IsPostBack Then
                    Localization.LocalizeDataGrid(grdProfileProperties, Me.LocalResourceFile)
                    BindGrid()
                Else
                    ProcessPostBack()
                End If
            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' cmdRefresh_Click runs when the refresh button is clciked
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	02/23/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdRefresh_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRefresh.Click
            RefreshGrid()
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' cmdUpdate_Click runs when the update button is clciked
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	02/23/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdUpdate.Click
            Try
                UpdateProperties()

                'Redirect to Users page
                Response.Redirect(NavigateURL(TabId), True)
            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' grdProfileProperties_ItemCheckedChanged runs when a checkbox in the grid
        ''' is clicked
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	02/23/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub grdProfileProperties_ItemCheckedChanged(ByVal sender As Object, ByVal e As UI.WebControls.DNNDataGridCheckChangedEventArgs)
            Dim propertyName As String = e.Field
            Dim propertyValue As Boolean = e.Checked
            Dim isAll As Boolean = e.IsAll
            Dim index As Integer = e.Item.ItemIndex

            Dim properties As ProfilePropertyDefinitionCollection = GetProperties()
            Dim profProperty As ProfilePropertyDefinition

            If isAll Then
                'Update All the properties
                For Each profProperty In properties
                    Select Case propertyName
                        Case "Required"
                            profProperty.Required = propertyValue
                        Case "Visible"
                            profProperty.Visible = propertyValue
                    End Select
                Next
            Else
                'Update the indexed property
                profProperty = properties(index)
                Select Case propertyName
                    Case "Required"
                        profProperty.Required = propertyValue
                    Case "Visible"
                        profProperty.Visible = propertyValue
                End Select
            End If

            BindGrid()

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' grdProfileProperties_ItemCommand runs when a Command event is raised in the
        ''' Grid
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	02/23/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub grdProfileProperties_ItemCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles grdProfileProperties.ItemCommand

            Dim commandName As String = e.CommandName
            Dim commandArgument As Integer = CType(e.CommandArgument, Integer)
            Dim index As Integer = e.Item.ItemIndex

            Select Case commandName
                Case "Delete"
                    DeleteProperty(index)
                Case "MoveUp"
                    MovePropertyUp(index)
                Case "MoveDown"
                    MovePropertyDown(index)
            End Select

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' When it is determined that the client supports a rich interactivity the grdProfileProperties_ItemCreated 
        ''' event is responsible for disabling all the unneeded AutoPostBacks, along with assiging the appropriate
        '''	client-side script for each event handler
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        '''     [Jon Henning]	03/12/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub grdProfileProperties_ItemCreated(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles grdProfileProperties.ItemCreated
            If SupportsRichClient() Then
                Select Case e.Item.ItemType
                    Case ListItemType.Header
                        'we combined the header label and checkbox in same place, so it is control 1 instead of 0
                        CType(e.Item.Cells(COLUMN_REQUIRED).Controls(1), WebControl).Attributes.Add("onclick", "dnn.util.checkallChecked(this," & COLUMN_REQUIRED & ");")
                        CType(e.Item.Cells(COLUMN_REQUIRED).Controls(1), CheckBox).AutoPostBack = False
                        CType(e.Item.Cells(COLUMN_VISIBLE).Controls(1), WebControl).Attributes.Add("onclick", "dnn.util.checkallChecked(this," & COLUMN_VISIBLE & ");")
                        CType(e.Item.Cells(COLUMN_VISIBLE).Controls(1), CheckBox).AutoPostBack = False
                    Case ListItemType.AlternatingItem, ListItemType.Item
                        CType(e.Item.Cells(COLUMN_REQUIRED).Controls(0), CheckBox).AutoPostBack = False
                        CType(e.Item.Cells(COLUMN_VISIBLE).Controls(0), CheckBox).AutoPostBack = False

                        DotNetNuke.UI.Utilities.ClientAPI.EnableClientSideReorder(e.Item.Cells(COLUMN_MOVE_DOWN).Controls(0), Me.Page, False, Me.grdProfileProperties.ClientID)
                        DotNetNuke.UI.Utilities.ClientAPI.EnableClientSideReorder(e.Item.Cells(COLUMN_MOVE_UP).Controls(0), Me.Page, True, Me.grdProfileProperties.ClientID)

                End Select
            End If
        End Sub
#End Region

#Region "Optional Interfaces"
        Public ReadOnly Property ModuleActions() As ModuleActionCollection Implements Entities.Modules.IActionable.ModuleActions
            Get
                Dim Actions As New ModuleActionCollection
                Actions.Add(GetNextActionID, Services.Localization.Localization.GetString(ModuleActionType.AddContent, LocalResourceFile), ModuleActionType.AddContent, "", "add.gif", EditUrl("EditProfileProperty"), False, SecurityAccessLevel.Admin, True, False)

                Actions.Add(GetNextActionID, Localization.GetString("Cancel.Action", LocalResourceFile), ModuleActionType.AddContent, "", "lt.gif", ReturnUrl, False, SecurityAccessLevel.Admin, True, False)
                Return Actions
            End Get
        End Property
#End Region

    End Class

End Namespace
