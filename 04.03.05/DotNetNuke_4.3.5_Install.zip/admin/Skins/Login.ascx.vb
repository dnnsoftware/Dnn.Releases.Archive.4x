'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2006
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports DotNetNuke.Entities.Host

Namespace DotNetNuke.UI.Skins.Controls
    ''' -----------------------------------------------------------------------------
    ''' <summary></summary>
    ''' <remarks></remarks>
    ''' <history>
    ''' 	[smcculloch]10/15/2004	Fixed Logoff Link for FriendlyUrls
    ''' 	[cniknet]	10/15/2004	Replaced public members with properties and removed
    '''                             brackets from property names
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Partial Class Login

        Inherits UI.Skins.SkinObjectBase

        ' public attributes
        Private _text As String
        Private _cssClass As String
        Private _logoffText As String

        Const MyFileName As String = "Login.ascx"

#Region "Public Members"
        Public Property Text() As String
            Get
                Return _text
            End Get
            Set(ByVal Value As String)
                _text = Value
            End Set
        End Property

        Public Property CssClass() As String
            Get
                Return _cssClass
            End Get
            Set(ByVal Value As String)
                _cssClass = Value
            End Set
        End Property

        Public Property LogoffText() As String
            Get
                Return _logoffText
            End Get
            Set(ByVal Value As String)
                _logoffText = Value
            End Set
        End Property

#End Region

        '*******************************************************
        '
        ' The Page_Load server event handler on this page is used
        ' to populate the role information for the page
        '
        '*******************************************************
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            ' public attributes
            If CssClass <> "" Then
                hypLogin.CssClass = CssClass
            End If

            If Request.IsAuthenticated = True Then
                If LogoffText <> "" Then
                    If LogoffText.IndexOf("src=") <> -1 Then
                        LogoffText = Replace(LogoffText, "src=""", "src=""" & PortalSettings.ActiveTab.SkinPath)
                    End If
                    hypLogin.Text = LogoffText
                Else
                    hypLogin.Text = Services.Localization.Localization.GetString("Logout", Services.Localization.Localization.GetResourceFile(Me, MyFileName))
                End If

                If HostSettings.GetHostSetting("UseFriendlyUrls") = "Y" Then
                    hypLogin.NavigateUrl = FriendlyUrl(PortalSettings.ActiveTab, ApplicationURL(PortalSettings.ActiveTab.TabID) & "&portalid=" & PortalSettings.PortalId.ToString, "Logoff.aspx")
                Else
                    hypLogin.NavigateUrl = ResolveUrl("~/Admin/Security/Logoff.aspx?tabid=" & PortalSettings.ActiveTab.TabID & "&portalid=" & PortalSettings.PortalId.ToString)
                End If
            Else
                If Text <> "" Then
                    If Text.IndexOf("src=") <> -1 Then
                        Text = Replace(Text, "src=""", "src=""" & PortalSettings.ActiveTab.SkinPath)
                    End If
                    hypLogin.Text = Text
                Else
                    hypLogin.Text = Services.Localization.Localization.GetString("Login", Services.Localization.Localization.GetResourceFile(Me, MyFileName))
                End If

                If PortalSettings.LoginTabId <> -1 And Request.QueryString("override") Is Nothing Then
                    ' user defined tab
                    hypLogin.NavigateUrl = NavigateURL(PortalSettings.LoginTabId)
                Else
                    ' admin tab
                    hypLogin.NavigateUrl = NavigateURL("Login")
                End If
            End If

        End Sub

    End Class

End Namespace
