'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2006
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports System.Threading
Imports System.IO
Imports System.Xml
Imports DotNetNuke.UI.Skins
Imports DotNetNuke.Services.Localization

Namespace DotNetNuke.Modules.Admin.ResourceInstaller

    Public Class ResourceInstaller

        Public Sub Install()
            Install(False, 0, "")
        End Sub

        Public Sub Install(ByVal status As Boolean, ByVal indent As Int32)
            Install(status, indent, "")
        End Sub

        Public Sub Install(ByVal status As Boolean, ByVal indent As Int32, ByVal type As String)

            Dim arrFolders As String()
            Dim strFolder As String
            Dim arrFiles As String()
            Dim strFile As String

            Dim InstallPath As String = ApplicationMapPath & "\Install"

            If Directory.Exists(InstallPath) Then
                arrFolders = Directory.GetDirectories(InstallPath)
                For Each strFolder In arrFolders
                    arrFiles = Directory.GetFiles(strFolder)
                    For Each strFile In arrFiles

                        Select Case type.ToLower

                            Case "modules"

                                ' install custom module
                                InstallModules(strFile, status, indent)

                            Case Else

                                ' install custom module
                                InstallModules(strFile, status, indent)

                                ' install skin
                                If strFile.ToLower.IndexOf("\skin\") <> -1 Then
                                    ' check if valid skin
                                    If Path.GetExtension(strFile.ToLower) = ".zip" Then
                                        If status Then
                                            HtmlUtils.WriteFeedback(HttpContext.Current.Response, indent, "Installing Skin File " & strFile & ":<br>")
                                        End If
                                        SkinController.UploadSkin(Common.Globals.HostMapPath, SkinInfo.RootSkin, Path.GetFileNameWithoutExtension(strFile), strFile)
                                        ' delete file
                                        DeleteFile(strFile)
                                    End If
                                End If

                                ' install container
                                If strFile.ToLower.IndexOf("\container\") <> -1 Then
                                    ' check if valid container
                                    If Path.GetExtension(strFile.ToLower) = ".zip" Then
                                        If status Then
                                            HtmlUtils.WriteFeedback(HttpContext.Current.Response, indent, "Installing Container File " & strFile & ":<br>")
                                        End If
                                        SkinController.UploadSkin(Common.Globals.HostMapPath, SkinInfo.RootContainer, Path.GetFileNameWithoutExtension(strFile), strFile)
                                        ' delete file
                                        DeleteFile(strFile)
                                    End If
                                End If

                                ' install language pack
                                If strFile.ToLower.IndexOf("\language\") <> -1 Then
                                    ' check if valid language pack
                                    If Path.GetExtension(strFile.ToLower) = ".zip" Then
                                        If status Then
                                            HtmlUtils.WriteFeedback(HttpContext.Current.Response, indent, "Installing Language File " & strFile & ":<br>")
                                        End If
                                        Dim objLocaleFilePackReader As New LocaleFilePackReader
                                        objLocaleFilePackReader.Install(strFile)
                                        ' delete file
                                        DeleteFile(strFile)
                                    End If
                                End If

                                ' install template
                                If strFile.ToLower.IndexOf("\template\") <> -1 Then
                                    ' check if valid template file ( .template or .template.resources )
                                    If strFile.ToLower.IndexOf(".template") <> -1 Then
                                        If status Then
                                            HtmlUtils.WriteFeedback(HttpContext.Current.Response, indent, "Installing Template " & strFile & ":<br>")
                                        End If
                                        Dim strNewFile As String = Common.Globals.HostMapPath & "\" & Path.GetFileName(strFile)
                                        If File.Exists(strNewFile) Then
                                            File.Delete(strNewFile)
                                        End If
                                        File.Move(strFile, strNewFile)
                                    End If
                                End If

                                'Install Portal(s)
                                If strFile.ToLower.IndexOf("\portal\") <> -1 Then
                                    'Check if valid portals file
                                    If strFile.ToLower.IndexOf(".resources") <> -1 Then
                                        Dim xmlDoc As New XmlDocument
                                        Dim node As XmlNode
                                        Dim nodes As XmlNodeList
                                        Dim intPortalId As Integer
                                        xmlDoc.Load(strFile)

                                        ' parse portal(s) if available
                                        nodes = xmlDoc.SelectNodes("//dotnetnuke/portals/portal")
                                        For Each node In nodes
                                            If Not node Is Nothing Then
                                                If status Then
                                                    HtmlUtils.WriteFeedback(HttpContext.Current.Response, indent, "Installing Portals:<br>")
                                                End If
                                                intPortalId = Services.Upgrade.Upgrade.AddPortal(node, True, indent)
                                                If intPortalId > -1 Then
                                                    HtmlUtils.WriteFeedback(HttpContext.Current.Response, indent + 2, "Successfully Installed Portal " & intPortalId & ":<br>")
                                                Else
                                                    HtmlUtils.WriteFeedback(HttpContext.Current.Response, indent + 2, "Portal failed to install:<br>")
                                                End If
                                            End If
                                        Next
                                        ' delete file
                                        DeleteFile(strFile)
                                    End If
                                End If

                        End Select 'type

                    Next 'strFile In arrFiles
                Next 'strFolder In arrFolders
            End If 'Directory.Exists(InstallPath)

        End Sub

        Private Sub InstallModules(ByVal strFile As String, ByVal status As Boolean, ByVal indent As Integer)

            ' install custom module
            If strFile.ToLower.IndexOf("\module\") <> -1 Then
                ' check if valid custom module
                If Path.GetExtension(strFile.ToLower) = ".zip" Then
                    If status Then
                        HtmlUtils.WriteFeedback(HttpContext.Current.Response, indent, "Installing Module File " & strFile & ": ")
                    End If
                    Dim objPaInstaller As New PaInstaller(strFile, Common.Globals.ApplicationMapPath)
                    Dim blnSuccess As Boolean = objPaInstaller.Install()
                    HtmlUtils.WriteSuccessError(HttpContext.Current.Response, blnSuccess)
                    ' delete file (also when error on installing)
                    DeleteFile(strFile)
                End If
            End If

        End Sub

        Private Sub DeleteFile(ByVal strFile As String)

            ' delete the file
            Try
                File.SetAttributes(strFile, FileAttributes.Normal)
                File.Delete(strFile)
            Catch
                ' error removing the file
            End Try

        End Sub

    End Class

End Namespace
