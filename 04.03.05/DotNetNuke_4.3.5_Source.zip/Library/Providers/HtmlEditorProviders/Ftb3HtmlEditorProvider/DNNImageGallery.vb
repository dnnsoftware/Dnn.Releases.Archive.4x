'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2006
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.IO
Imports System.Web.UI

Imports DotNetNuke.Common.Utilities
Imports DotNetNuke.Entities.Portals
Imports DotNetNuke.Services.Localization

Namespace DotNetNuke.HtmlEditor

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' The DNNImageGallery Class subclasses the FTB ImageGallery to provide additional
    ''' security features, and support for the DNN File System
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[cnurse]	07/17/2006  Created
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Public Class DNNImageGallery
        Inherits FreeTextBoxControls.ImageGallery

        Private FTB_FolderCreated As String = Localization.GetString("FTB_FolderCreated")
        Private FTB_FolderCreateError As String = Localization.GetString("FTB_FolderCreate.Error")
        Private FTB_FolderCreatePermission As String = Localization.GetString("FTB_FolderCreate.Permission")
        Private FTB_FolderDeleted As String = Localization.GetString("FTB_FolderDeleted")
        Private FTB_FolderDeleteError As String = Localization.GetString("FTB_FolderDelete.Error")
        Private FTB_FolderDeletePermission As String = Localization.GetString("FTB_FolderDelete.Permission")
        Private FTB_ImageDeleted As String = Localization.GetString("FTB_ImageDeleted")
        Private FTB_ImageDeleteError As String = Localization.GetString("FTB_ImageDelete.Error")
        Private FTB_ImageDeletePermission As String = Localization.GetString("FTB_ImageDelete.Permission")
        Private FTB_ImageUploaded As String = Localization.GetString("FTB_ImageUploaded")
        Private FTB_ImageUploadError As String = Localization.GetString("FTB_ImageUpload.Error")
        Private FTB_ImageUploadNoFile As String = Localization.GetString("FTB_ImageUploadNoFile")
        Private FTB_ImageUploadPermission As String = Localization.GetString("FTB_ImageUpload.Permission")

        Public ReadOnly Property PortalId() As Integer
            Get
                Dim _PortalId As Integer = Null.NullInteger
                If PortalSettings.ActiveTab.ParentId <> PortalSettings.SuperTabId Then
                    _PortalId = PortalSettings.PortalId
                End If
                Return _PortalId
            End Get
        End Property

        Public ReadOnly Property PortalSettings() As PortalSettings
            Get
                PortalSettings = PortalController.GetCurrentPortalSettings()
            End Get
        End Property

        Private Sub CreateFolder(ByVal newFolder As String)
            If Me.AllowDirectoryCreate Then
                Try
                    Dim parentFolder As String = Me.Context.Server.MapPath(CurrentImagesFolder)

                    'Can only support Standard File System
                    FileSystemUtils.AddFolder(PortalSettings, parentFolder, newFolder, 0)

                    Me.returnMessage = String.Format(FTB_FolderCreated, newFolder)

                Catch ex As Exception
                    Me.returnMessage = FTB_FolderCreateError
                End Try
            Else
                Me.returnMessage = FTB_FolderCreatePermission
            End If

            'Clear the Folders Cache
            DataCache.RemoveCache("Folders:" + PortalId.ToString)
        End Sub

        Private Sub DeleteFolder(ByVal filePath As String)

            If Me.AllowDirectoryDelete Then
                Try
                    Dim folder As New DirectoryInfo(Context.Server.MapPath(CurrentImagesFolder) + "\" + filePath)
                    Dim folderName As String = folder.FullName.Replace(Context.Server.MapPath(RootImagesFolder) + "\", "")

                    FileSystemUtils.DeleteFolder(PortalId, folder, folderName)

                    Me.returnMessage = String.Format(FTB_FolderDeleted, filePath)
                Catch ex As Exception
                    Me.returnMessage = FTB_FolderDeleteError
                End Try
            Else
                Me.returnMessage = FTB_FolderDeletePermission
            End If

            'Clear the Folders Cache
            DataCache.RemoveCache("Folders:" + PortalId.ToString)
        End Sub

        Private Sub DeleteImage(ByVal filePath As String)

            If Me.AllowImageDelete Then
                Try
                    Dim folder As New DirectoryInfo(Context.Server.MapPath(CurrentImagesFolder))
                    Dim sourcefile As String = folder.FullName + "\" + filePath

                    FileSystemUtils.DeleteFile(sourcefile, PortalSettings)

                    Me.returnMessage = String.Format(FTB_ImageDeleted, filePath)

                Catch ex As Exception
                    Me.returnMessage = FTB_ImageDeleteError
                End Try
            Else
                Me.returnMessage = FTB_ImageDeletePermission
            End If
        End Sub

        Private Sub UploadImage(ByVal filePath As String)
            If Me.AllowImageUpload Then
                Try
                    Dim parentFolder As String = Me.Context.Server.MapPath(CurrentImagesFolder) + "\"
                    EnsureChildControls()
                    If Me.inputFile Is Nothing OrElse Me.inputFile.PostedFile Is Nothing Then
                        Me.returnMessage = FTB_ImageUploadNoFile
                    Else
                        Dim strMessage As String = FileSystemUtils.UploadFile(parentFolder, Me.inputFile.PostedFile, False)

                        If strMessage <> "" Then
                            Dim strFileName As String = parentFolder & Path.GetFileName(Me.inputFile.PostedFile.FileName)
                            strMessage = strMessage.Replace("<br>", "")
                            strMessage = strMessage.Replace(strFileName, Me.inputFile.PostedFile.FileName)
                            Me.returnMessage = strMessage
                        Else
                            Me.returnMessage = String.Format(FTB_ImageUploaded, filePath)
                        End If
                    End If

                Catch ex As Exception
                    Me.returnMessage = FTB_ImageUploadError
                End Try
            Else
                Me.returnMessage = FTB_ImageUploadPermission
            End If
        End Sub

        Public Overrides Sub RaisePostBackEvent(ByVal eventArgument As String)

            Dim command As String = Null.NullString
            Dim param As String = Null.NullString
            Dim argumentArray As String() = eventArgument.Split(New Char() {":"c})
            If argumentArray.Length > 0 AndAlso Not argumentArray(0) Is Nothing Then
                command = argumentArray(0)
            End If
            If argumentArray.Length > 1 AndAlso Not argumentArray(1) Is Nothing Then
                param = argumentArray(1)
            End If

            Select Case command
                Case "CreateFolder"
                    CreateFolder(param)
                Case "DeleteFolder"
                    DeleteFolder(param)
                Case "DeleteImage"
                    DeleteImage(param)
                Case "UploadImage"
                    UploadImage(param)
                Case Else
                    MyBase.RaisePostBackEvent(eventArgument)
            End Select

        End Sub

    End Class

End Namespace

