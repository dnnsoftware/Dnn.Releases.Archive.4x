'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2003
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.Web.Mail
Imports System.IO

Namespace DotNetNuke

    '*********************************************************************
    '
    ' Globals Module
    ' This module contains global utility functions, constants, and enumerations.
    '
    '*********************************************************************

    Public Module Globals

        Public Const glbRoleAllUsers As String = "-1"
        Public Const glbRoleSuperUser As String = "-2"

        ' returns the absolute server path to the root ( ie. D:\Inetpub\wwwroot\directory\ )
        Public Function GetAbsoluteServerPath(ByVal Request As HttpRequest) As String
            Dim strServerPath As String

            strServerPath = Request.MapPath(Request.ApplicationPath)
            If Not strServerPath.EndsWith("\") Then
                strServerPath += "\"
            End If

            GetAbsoluteServerPath = strServerPath
        End Function

        ' returns the domain name of the current request ( ie. www.domain.com or 207.132.12.123 or www.domain.com/directory if subhost )
        Public Function GetDomainName(ByVal Request As HttpRequest) As String
            Dim DomainName As String
            Dim URL() As String
            Dim intURL As Integer

            URL = Split(Request.Url.ToString(), "/")
            For intURL = 2 To URL.GetUpperBound(0)
                Select Case URL(intURL).ToLower
                    Case "admin", "controls", "desktopmodules", "mobilemodules", "premiummodules"
                        Exit For
                    Case Else
                        ' check if filename
                        If InStr(1, URL(intURL), ".aspx") = 0 Then
                            DomainName += IIf(DomainName <> "", "/", "") & URL(intURL)
                        Else
                            Exit For
                        End If
                End Select
            Next intURL

            GetDomainName = DomainName
        End Function

        ' sends a simple email
        Public Sub SendNotification(ByVal strFrom As String, ByVal strTo As String, ByVal strBcc As String, ByVal strSubject As String, ByVal strBody As String)

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            Dim mail As New MailMessage()

            mail.From = strFrom
            mail.To = strTo
            If strBcc <> "" Then
                mail.Bcc = strBcc
            End If
            mail.Subject = strSubject
            mail.Body = strBody

            ' external SMTP server
            If _portalSettings.HostSettings("SMTPServer") <> "" Then
                SmtpMail.SmtpServer = _portalSettings.HostSettings("SMTPServer")
            End If

            Try
                SmtpMail.Send(mail)
            Catch
                ' mail configuration problem
            End Try

        End Sub

        ' encodes a URL for posting to an external site
        Public Function HTTPPOSTEncode(ByVal strPost As String) As String
            strPost = Replace(strPost, "\", "")
            strPost = System.Web.HttpUtility.UrlEncode(strPost)
            strPost = Replace(strPost, "%2f", "/")
            HTTPPOSTEncode = strPost
        End Function

        ' retrieves the domain name of the portal ( ie. http://www.domain.com " )
        Public Function GetPortalDomainName(ByVal strPortalAlias As String, Optional ByVal Request As HttpRequest = Nothing) As String

            Dim strDomainName As String

            Dim strURL As String = ""
            Dim arrPortalAlias() As String
            Dim intAlias As Integer

            If Not Request Is Nothing Then
                strURL = GetDomainName(Request)
            End If

            arrPortalAlias = Split(strPortalAlias, ",")
            For intAlias = 0 To arrPortalAlias.Length - 1
                If arrPortalAlias(intAlias) = strURL Then
                    strDomainName = arrPortalAlias(intAlias)
                End If
            Next
            If strDomainName = "" Then
                strDomainName = arrPortalAlias(0)
            End If

            strDomainName = AddHTTP(strDomainName)

            GetPortalDomainName = strDomainName

        End Function

        ' adds HTTP to URL if no other protocol specified
        Public Function AddHTTP(ByVal strURL As String) As String
            If InStr(1, strURL, "://") = 0 Then
                strURL = "http://" & strURL
            End If
            Return strURL
        End Function

        ' convert datareader to dataset
        Public Function ConvertDataReaderToDataSet(ByVal reader As SqlDataReader) As DataSet

            Dim dataSet As dataSet = New dataSet()

            Dim schemaTable As dataTable = reader.GetSchemaTable()

            Dim dataTable As dataTable = New dataTable()

            Dim intCounter As Integer

            For intCounter = 0 To schemaTable.Rows.Count - 1
                Dim dataRow As DataRow = schemaTable.Rows(intCounter)
                Dim columnName As String = CType(dataRow("ColumnName"), String)
                Dim column As DataColumn = New DataColumn(columnName, CType(dataRow("DataType"), Type))
                dataTable.Columns.Add(column)
            Next

            dataSet.Tables.Add(dataTable)

            While reader.Read()
                Dim dataRow As DataRow = dataTable.NewRow()

                For intCounter = 0 To reader.FieldCount - 1
                    dataRow(intCounter) = reader.GetValue(intCounter)
                Next

                dataTable.Rows.Add(dataRow)
            End While

            Return dataSet

        End Function

        ' convert datareader to crosstab dataset
        Public Function BuildCrossTabDataSet(ByVal DataSetName As String, ByVal result As SqlDataReader, ByVal FixedColumns As String, ByVal VariableColumns As String, ByVal KeyColumn As String, ByVal FieldColumn As String, ByVal FieldTypeColumn As String, ByVal StringValueColumn As String, ByVal NumericValueColumn As String) As DataSet

            Dim arrFixedColumns As String()
            Dim arrVariableColumns As String()
            Dim arrField As String()
            Dim FieldName As String
            Dim FieldType As String
            Dim intColumn As Integer
            Dim intKeyColumn As Integer

            ' create dataset
            Dim crosstab As New DataSet(DataSetName)
            crosstab.Namespace = "NetFrameWork"

            ' create table
            Dim tab As New DataTable(DataSetName)

            ' split fixed columns
            arrFixedColumns = FixedColumns.Split(",".ToCharArray())

            ' add fixed columns to table
            For intColumn = LBound(arrFixedColumns) To UBound(arrFixedColumns)
                arrField = arrFixedColumns(intColumn).Split("|".ToCharArray())
                Dim col As New DataColumn(arrField(0), System.Type.GetType("System." & arrField(1)))
                tab.Columns.Add(col)
            Next intColumn

            ' split variable columns
            If VariableColumns <> "" Then
                arrVariableColumns = VariableColumns.Split(",".ToCharArray())

                ' add varible columns to table
                For intColumn = LBound(arrVariableColumns) To UBound(arrVariableColumns)
                    arrField = arrVariableColumns(intColumn).Split("|".ToCharArray())
                    Dim col As New DataColumn(arrField(0), System.Type.GetType("System." & arrField(1)))
                    col.AllowDBNull = True
                    tab.Columns.Add(col)
                Next intColumn
            End If

            ' add table to dataset
            crosstab.Tables.Add(tab)

            ' add rows to table
            intKeyColumn = -1
            Dim row As DataRow
            While result.Read()
                ' loop using KeyColumn as control break
                If result(KeyColumn) <> intKeyColumn Then
                    ' add row
                    If intKeyColumn <> -1 Then
                        tab.Rows.Add(row)
                    End If

                    ' create new row
                    row = tab.NewRow()

                    ' assign fixed column values
                    For intColumn = LBound(arrFixedColumns) To UBound(arrFixedColumns)
                        arrField = arrFixedColumns(intColumn).Split("|".ToCharArray())
                        row(arrField(0)) = result(arrField(0))
                    Next intColumn

                    ' initialize variable column values
                    If VariableColumns <> "" Then
                        For intColumn = LBound(arrVariableColumns) To UBound(arrVariableColumns)
                            arrField = arrVariableColumns(intColumn).Split("|".ToCharArray())
                            Select Case arrField(1)
                                Case "Decimal"
                                    row(arrField(0)) = 0
                                Case "String"
                                    row(arrField(0)) = ""
                            End Select
                        Next intColumn
                    End If

                    intKeyColumn = result(KeyColumn)
                End If

                ' assign pivot column value
                If FieldTypeColumn <> "" Then
                    FieldType = result(FieldTypeColumn)
                Else
                    FieldType = "String"
                End If
                Select Case FieldType
                    Case "Decimal" ' decimal
                        row(result(FieldColumn)) = result(NumericValueColumn)
                    Case "String" ' string
                        row(result(FieldColumn)) = result(StringValueColumn)
                End Select
            End While

            result.Close()

            ' add row
            If intKeyColumn <> -1 Then
                tab.Rows.Add(row)
            End If

            ' finalize dataset
            crosstab.AcceptChanges()

            ' return the dataset
            Return crosstab

        End Function

        Public Class FileItem
            Private _Value As String
            Private _Text As String

            Public Sub New(ByVal Value As String, ByVal Text As String)
                _Value = Value
                _Text = Text
            End Sub

            Public ReadOnly Property Value() As String
                Get
                    Return _Value
                End Get
            End Property

            Public ReadOnly Property Text() As String
                Get
                    Return _Text
                End Get
            End Property

        End Class

        ' get list of files from folder matching criteria
        Public Function GetFileList(Optional ByVal PortalId As Integer = -1, Optional ByVal strExtensions As String = "", Optional ByVal NoneSpecified As Boolean = True) As ArrayList
            Dim arrFileList As New ArrayList()

            If NoneSpecified Then
                arrFileList.Add(New FileItem("", "<None Specified>"))
            End If

            Dim objAdmin As New AdminDB()

            Dim dr As SqlDataReader = objAdmin.GetFiles(PortalId)
            While dr.Read()
                If InStr(1, strExtensions, dr("Extension")) <> 0 Or strExtensions = "" Then
                    arrFileList.Add(New FileItem(dr("FileName").ToString, dr("FileName").ToString))
                End If
            End While

            GetFileList = arrFileList
        End Function

        ' format an address on a single line ( ie. Unit, Street, City, Region, Country, PostalCode )
        Public Function FormatAddress(ByVal Unit As Object, ByVal Street As Object, ByVal City As Object, ByVal Region As Object, ByVal Country As Object, ByVal PostalCode As Object) As String

            Dim strAddress As String = ""

            If Not IsDBNull(Unit) Then
                If Trim(Unit.ToString()) <> "" Then
                    strAddress += ", " & Unit.ToString
                End If
            End If
            If Not IsDBNull(Street) Then
                If Trim(Street.ToString()) <> "" Then
                    strAddress += ", " & Street.ToString
                End If
            End If
            If Not IsDBNull(City) Then
                If Trim(City.ToString()) <> "" Then
                    strAddress += ", " & City.ToString
                End If
            End If
            If Not IsDBNull(Region) Then
                If Trim(Region.ToString()) <> "" Then
                    strAddress += ", " & Region.ToString
                End If
            End If
            If Not IsDBNull(Country) Then
                If Trim(Country.ToString()) <> "" Then
                    strAddress += ", " & Country.ToString
                End If
            End If
            If Not IsDBNull(PostalCode) Then
                If Trim(PostalCode.ToString()) <> "" Then
                    strAddress += ", " & PostalCode.ToString
                End If
            End If
            If Trim(strAddress) <> "" Then
                strAddress = Mid(strAddress, 3)
            End If

            FormatAddress = strAddress

        End Function

        ' format an email address including link
        Public Function FormatEmail(ByVal Email As Object) As String

            If Not IsDBNull(Email) Then
                If Trim(Email.ToString()) <> "" Then
                    If InStr(1, Email.ToString(), "@") Then
                        FormatEmail = "<a href=""mailto:" & Email.ToString() & """>" & Email.ToString() & "</a>"
                    Else
                        FormatEmail = Email.ToString()
                    End If
                End If
            End If

        End Function

        ' format a domain name including link
        Public Function FormatWebsite(ByVal Website As Object) As String

            If Not IsDBNull(Website) Then
                If Trim(Website.ToString()) <> "" Then
                    If InStr(1, Website.ToString(), ".") Then
                        FormatWebsite = "<a href=""" & IIf(InStr(1, Website.ToString(), "://"), "", "http://") & Website.ToString() & """>" & Website.ToString() & "</a>"
                    Else
                        FormatWebsite = Website.ToString()
                    End If
                End If
            End If

        End Function


        Public Function GetPortalTabs(ByVal objDesktopTabs As ArrayList, Optional ByVal blnNoneSpecified As Boolean = False, Optional ByVal blnHidden As Boolean = False) As ArrayList

            Dim arrPortalTabs = New ArrayList()
            Dim objPortalTab As TabItem
            Dim objTab As TabStripDetails

            If blnNoneSpecified Then
                objPortalTab = New TabItem()
                objPortalTab.TabId = -1
                objPortalTab.TabName = "<None Specified>"
                objPortalTab.TabOrder = 0
                objPortalTab.ParentId = -2
                arrPortalTabs.Add(objPortalTab)
            End If

            Dim intCounter As Integer
            Dim strIndent As String

            For Each objTab In objDesktopTabs
                If IsAdminTab(objTab.TabId, objTab.ParentId) = False And (objTab.IsVisible = True Or blnHidden = True) Then
                    strIndent = ""
                    For intCounter = 1 To objTab.Level
                        strIndent += "..."
                    Next

                    objPortalTab = New TabItem()
                    objPortalTab.TabId = objTab.TabId
                    objPortalTab.TabName = strIndent & objTab.TabName
                    objPortalTab.TabOrder = objTab.TabOrder
                    objPortalTab.ParentId = objTab.ParentId
                    arrPortalTabs.add(objPortalTab)
                End If
            Next

            Return arrPortalTabs

        End Function


        Public Sub CreateFreeTextBox(ByRef ftbControl As FreeTextBoxControls.FreeTextBox, ByVal strUploadDirectory As String)

            ' set the relative paths
            ftbControl.ImageGalleryPath = strUploadDirectory.Substring(strUploadDirectory.IndexOf("/Portals/"))
            ftbControl.HelperFilesPath = "controls"
            ftbControl.ButtonPath = "controls/ftb/images/ftb/raised/"

            ' build the toolbar layout
            Dim tb As FreeTextBoxControls.Toolbar = New FreeTextBoxControls.Toolbar("Edit")
            tb.Items.Add(FreeTextBoxControls.ToolbarItems.Print)
            tb.Items.Add(FreeTextBoxControls.ToolbarItems.Cut)
            tb.Items.Add(FreeTextBoxControls.ToolbarItems.Copy)
            tb.Items.Add(FreeTextBoxControls.ToolbarItems.Paste)
            tb.Items.Add(FreeTextBoxControls.ToolbarItems.Separator)
            tb.Items.Add(FreeTextBoxControls.ToolbarItems.Undo)
            tb.Items.Add(FreeTextBoxControls.ToolbarItems.Redo)
            ftbControl.Toolbars.Add(tb)

            tb = New FreeTextBoxControls.Toolbar("Format")
            tb.Items.Add(FreeTextBoxControls.ToolbarItems.Bold)
            tb.Items.Add(FreeTextBoxControls.ToolbarItems.Italic)
            tb.Items.Add(FreeTextBoxControls.ToolbarItems.Underline)
            tb.Items.Add(FreeTextBoxControls.ToolbarItems.Strikethrough)
            tb.Items.Add(FreeTextBoxControls.ToolbarItems.Superscript)
            tb.Items.Add(FreeTextBoxControls.ToolbarItems.Subscript)
            tb.Items.Add(FreeTextBoxControls.ToolbarItems.RemoveFormat)
            ftbControl.Toolbars.Add(tb)

            tb = New FreeTextBoxControls.Toolbar("Paragraph")
            tb.Items.Add(FreeTextBoxControls.ToolbarItems.JustifyLeft)
            tb.Items.Add(FreeTextBoxControls.ToolbarItems.JustifyCenter)
            tb.Items.Add(FreeTextBoxControls.ToolbarItems.JustifyRight)
            tb.Items.Add(FreeTextBoxControls.ToolbarItems.JustifyFull)
            tb.Items.Add(FreeTextBoxControls.ToolbarItems.Separator)
            tb.Items.Add(FreeTextBoxControls.ToolbarItems.BulletedList)
            tb.Items.Add(FreeTextBoxControls.ToolbarItems.NumberedList)
            tb.Items.Add(FreeTextBoxControls.ToolbarItems.Indent)
            tb.Items.Add(FreeTextBoxControls.ToolbarItems.Outdent)
            ftbControl.Toolbars.Add(tb)

            tb = New FreeTextBoxControls.Toolbar("Insert")
            tb.Items.Add(FreeTextBoxControls.ToolbarItems.CreateLink)
            tb.Items.Add(FreeTextBoxControls.ToolbarItems.Unlink)
            tb.Items.Add(FreeTextBoxControls.ToolbarItems.Separator)
            tb.Items.Add(FreeTextBoxControls.ToolbarItems.InsertImageFromGallery)

            Dim tbtn As FreeTextBoxControls.ToolbarButton = New FreeTextBoxControls.ToolbarButton("ImageProperties", "imageproperties", "FTB_ImageProperties")
            tbtn.Title = "Image Properties"
            tbtn.Function = "FTB_ImageProperties"
            tbtn.ScriptBlock = "<script language=""javascript"">function FTB_ImageProperties(editor,htmlmode){editor.document.execCommand('InsertImage',true);}</script>"
            tb.Items.Add(tbtn)
            tb.Items.Add(FreeTextBoxControls.ToolbarItems.Separator)
            tb.Items.Add(FreeTextBoxControls.ToolbarItems.InsertRule)
            tb.Items.Add(FreeTextBoxControls.ToolbarItems.InsertDate)
            tb.Items.Add(FreeTextBoxControls.ToolbarItems.InsertTime)
            ftbControl.Toolbars.Add(tb)

            tb = New FreeTextBoxControls.Toolbar("Colors")
            tb.Items.Add(FreeTextBoxControls.ToolbarItems.FontForeColorsMenu)
            tb.Items.Add(FreeTextBoxControls.ToolbarItems.FontForeColorPicker)
            tb.Items.Add(FreeTextBoxControls.ToolbarItems.FontBackColorsMenu)
            tb.Items.Add(FreeTextBoxControls.ToolbarItems.FontBackColorPicker)
            ftbControl.Toolbars.Add(tb)

            tb = New FreeTextBoxControls.Toolbar("Fonts")
            tb.Items.Add(FreeTextBoxControls.ToolbarItems.StyleMenu)
            tb.Items.Add(FreeTextBoxControls.ToolbarItems.ParagraphMenu)
            tb.Items.Add(FreeTextBoxControls.ToolbarItems.FontFacesMenu)
            tb.Items.Add(FreeTextBoxControls.ToolbarItems.FontSizesMenu)
            ftbControl.Toolbars.Add(tb)

            Dim sStyles() As String = {"Head", "SubHead", "Normal", "NormalRed", "NormalBold", "NormalTextBox", "Message", "ItemTitle"}
            ftbControl.StyleMenuNames = sStyles
            ftbControl.StyleMenuList = sStyles
            Dim sParaNames() As String = {"Normal", "Heading 1", "Heading 2", "Heading 3", "Heading 4", "Heading 5", "Heading 6", "Address", "Formatted"}
            Dim sParaList() As String = {"p", "h1", "h2", "h3", "h4", "h5", "h6", "address", "pre"}
            ftbControl.ParagraphMenuList = sParaList
            ftbControl.ParagraphMenuNames = sParaNames

        End Sub

        Public Function GetMediumDate(ByVal strDate As String, Optional ByVal YYYYMMDD As Boolean = False) As String

            If strDate <> "" Then
                Dim datDate As Date = CDate(strDate)

                Dim strYear As String
                Dim strMonth As String
                Dim strDay As String

                If Not YYYYMMDD Then
                    strYear = Year(datDate)
                    strMonth = MonthName(Month(datDate), True)
                    strDay = Day(datDate)
                    strDate = strDay & "-" & strMonth & "-" & strYear
                Else
                    strYear = Format(Year(datDate), "0000")
                    strMonth = Format(Month(datDate), "00")
                    strDay = Format(Day(datDate), "00")
                    strDate = strYear & strMonth & strDay
                End If
            End If

            Return strDate

        End Function


        Public Function IsAdminTab(ByVal intTabId As Integer, ByVal intParentId As Integer) As Boolean

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            Return (intTabId = _portalSettings.AdminTabId) Or _
                    (intParentId = _portalSettings.AdminTabId) Or _
                    (intTabId = _portalSettings.SuperTabId) Or _
                    (intParentId = _portalSettings.SuperTabId)

        End Function

        Public Function PreventSQLInjection(ByVal strSQL As String) As String

            Dim strCleanSQL As String = strSQL

            Dim BadCommands As Array = Split("select,drop,;,--,insert,delete,xp_")

            ' strip any dangerous SQL commands
            Dim intCommand As Integer
            For intCommand = 0 To BadCommands.Length - 1
                strCleanSQL = Replace(strCleanSQL, BadCommands(intCommand), "")
            Next

            ' convert any single quotes
            strCleanSQL = Replace(strCleanSQL, "'", "''")

            Return strCleanSQL

        End Function

        Public Sub CreateRSS(ByVal dr As SqlDataReader, ByVal TitleField As String, ByVal URLField As String, ByVal CreatedDateField As String, ByVal SyndicateField As String, ByVal DomainName As String, ByVal FileName As String)

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            ' create RSS file
            Dim strRSS As String = ""

            Dim strRelativePath As String = DomainName & Replace(Mid(FileName, InStr(1, FileName, "\Portals")), "\", "/")
            strRelativePath = Left(strRelativePath, InStrRev(strRelativePath, "/"))

            While dr.Read()
                If dr(SyndicateField) Then
                    strRSS += "      <item>" & ControlChars.CrLf
                    strRSS += "         <title>" & dr(TitleField).ToString & "</title>" & ControlChars.CrLf
                    If InStr(1, dr("URL").ToString, "://") = 0 Then
                        If IsNumeric(dr("URL").ToString) Then
                            strRSS += "         <link>" & DomainName & "/DesktopDefault.aspx?tabid=" & dr(URLField).ToString & "</link>" & ControlChars.CrLf
                        Else
                            strRSS += "         <link>" & strRelativePath & dr(URLField).ToString & "</link>" & ControlChars.CrLf
                        End If
                    Else
                        strRSS += "         <link>" & dr(URLField).ToString & "</link>" & ControlChars.CrLf
                    End If
                    strRSS += "         <description>" & _portalSettings.PortalName & " " & GetMediumDate(dr(CreatedDateField).ToString) & "</description>" & ControlChars.CrLf
                    strRSS += "     </item>" & ControlChars.CrLf
                End If
            End While
            dr.Close()

            If strRSS <> "" Then
                strRSS = "<?xml version=""1.0"" encoding=""iso-8859-1""?>" & ControlChars.CrLf & _
                    "<rss version=""0.91"">" & ControlChars.CrLf & _
                    "  <channel>" & ControlChars.CrLf & _
                    "     <title>" & _portalSettings.PortalName & "</title>" & ControlChars.CrLf & _
                    "     <link>" & DomainName & "</link>" & ControlChars.CrLf & _
                    "     <description>" & _portalSettings.PortalName & "</description>" & ControlChars.CrLf & _
                    "     <language>en-us</language>" & ControlChars.CrLf & _
                    "     <copyright>" & _portalSettings.FooterText & "</copyright>" & ControlChars.CrLf & _
                    "     <webMaster>" & _portalSettings.Email & "</webMaster>" & ControlChars.CrLf & _
                    strRSS & _
                    "   </channel>" & ControlChars.CrLf & _
                    "</rss>"

                Dim objStream As StreamWriter
                objStream = File.CreateText(FileName)
                objStream.WriteLine(strRSS)
                objStream.Close()
            Else
                If File.Exists(FileName) Then
                    File.Delete(FileName)
                End If
            End If

        End Sub

    End Module

End Namespace