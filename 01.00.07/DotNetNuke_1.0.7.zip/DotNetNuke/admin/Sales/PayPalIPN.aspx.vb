'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2003
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.Net
Imports System.IO

Namespace DotNetNuke

    Public Class PayPalIPN
        Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            Dim strName As String
            Dim objStream As StreamWriter
            Dim blnValid As Boolean = True
            Dim strTransactionID As String
            Dim intRoleID As Integer
            Dim intPortalID As String
            Dim intUserID As Integer
            Dim intQuantity As Integer
            Dim strDescription As String
            Dim dblAmount As Double
            Dim strEmail As String
            Dim strBody As String

            Dim objUser As New UsersDB()
            Dim objAdmin As New AdminDB()

            Dim strPost As String = "cmd=_notify-validate"
            For Each strName In Request.Form
                Dim strValue As String = Request.Form(strName)
                Select Case strName
                    Case "payment_status" ' verify the status
                        If strValue <> "Completed" Then
                            blnValid = False
                        End If
                    Case "txn_id" ' verify the transaction id for duplicates
                        strTransactionID = strValue
                    Case "receiver_email" ' verify the PayPalId
                    Case "mc_gross" ' verify the price
                        dblAmount = Double.Parse(strValue)
                    Case "item_number" ' get the RoleID
                        intRoleID = Int32.Parse(strValue)
                        Dim dr As SqlDataReader = objUser.GetSingleRole(intRoleID)
                        If dr.Read Then
                            intPortalID = dr("PortalID")
                        End If
                        dr.Close()
                    Case "item_name" ' get the product description
                        strDescription = strValue
                    Case "custom" ' get the UserID
                        intUserID = Int32.Parse(strValue)
                    Case "quantity" ' get the quantity
                        intQuantity = Int32.Parse(strValue)
                    Case "email" ' get the email
                        strEmail = strValue
                End Select
                ' reconstruct post for postback validation
                strPost += String.Format("&{0}={1}", strName, HTTPPOSTEncode(strValue))
            Next

            ' postback to verify the source
            If blnValid Then
                Dim objRequest As HttpWebRequest = WebRequest.Create("https://www.paypal.com/cgi-bin/webscr")
                objRequest.Method = "POST"
                objRequest.ContentLength = strPost.Length
                objRequest.ContentType = "application/x-www-form-urlencoded"

                objStream = New StreamWriter(objRequest.GetRequestStream())
                objStream.Write(strPost)
                objStream.Close()

                Dim objResponse As HttpWebResponse = objRequest.GetResponse()
                Dim sr As StreamReader
                sr = New StreamReader(objResponse.GetResponseStream())
                Dim strResponse As String = sr.ReadToEnd()
                sr.Close()

                Select Case strResponse
                    Case "VERIFIED"
                    Case Else
                        ' possible fraud
                        blnValid = False
                End Select
            End If

            If blnValid Then

                Dim intAdministratorRoleId As String

                Dim dr As SqlDataReader = objAdmin.GetSinglePortal(intPortalID)
                If dr.Read Then
                    intAdministratorRoleId = dr("AdministratorRoleId")
                End If
                dr.Close()

                If intRoleID = intAdministratorRoleId Then
                    ' admin portal renewal
                    objAdmin.UpdatePortalExpiry(intPortalID)
                Else
                    ' user subscription
                    objUser.UpdateService(intUserID, intRoleID, intQuantity)
                End If

            End If

        End Sub

    End Class

End Namespace
