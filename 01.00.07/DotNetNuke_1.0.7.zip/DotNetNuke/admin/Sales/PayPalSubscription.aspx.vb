'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2003
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Namespace DotNetNuke

    Public Class PayPalSubscription
        Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            If Not Request.Params("RoleId") Is Nothing Then

                Dim intRoleId As Integer
                intRoleId = Integer.Parse(Request.Params("RoleId"))

                Dim dr As SqlDataReader

                Dim strProcessorUserId As String

                Dim objAdmin As New AdminDB()
                dr = objAdmin.GetSinglePortal(_portalSettings.PortalId)
                If dr.Read Then
                    strProcessorUserId = dr("ProcessorUserId").ToString
                End If
                dr.Close()

                If strProcessorUserId <> "" Then

                    ' build secure PayPal URL
                    Dim strPayPalURL As String = "https://www.paypal.com/subscriptions/"
                    strPayPalURL += "business=" & HTTPPOSTEncode(strProcessorUserId)

                    Dim objUser As New UsersDB()

                    dr = objUser.GetSingleRole(intRoleId)
                    If dr.Read Then
                        strPayPalURL += "&item_name=" & HTTPPOSTEncode(_portalSettings.PortalName & " - " & dr("Description").ToString & " ( " & Format(dr("ServiceFee"), "0.00") & " " & _portalSettings.Currency & " per " & dr("BillingFrequency") & " )")
                        strPayPalURL += "&item_number=" & HTTPPOSTEncode(intRoleId.ToString)
                        strPayPalURL += "&no_shipping=1&no_note=1"
                        strPayPalURL += "&a1=0" ' free trial - trial period fee should be added to Roles
                        strPayPalURL += "&p1=" & HTTPPOSTEncode(dr("TrialPeriod"))
                        strPayPalURL += "&t1=" & HTTPPOSTEncode(dr("TrialFrequency")) ' convert to code
                        strPayPalURL += "&a3=" & HTTPPOSTEncode(dr("ServiceFee"))
                        strPayPalURL += "&p3=" & "1" ' billing frequency units should be added to Roles
                        strPayPalURL += "&t3=" & HTTPPOSTEncode(dr("BillingFrequency")) ' convert to code
                        If dr("BillingFrequency") <> 1 Then
                            strPayPalURL += "&src=1"
                        End If
                        strPayPalURL += "&currency_code=" & HTTPPOSTEncode(_portalSettings.Currency)
                    End If
                    dr.Close()

                    dr = objUser.GetSingleUser(_portalSettings.PortalId, Integer.Parse(Context.User.Identity.Name))
                    If dr.Read Then
                        strPayPalURL += "&custom=" & HTTPPOSTEncode(Context.User.Identity.Name)
                        strPayPalURL += "&first_name=" & HTTPPOSTEncode(dr("FirstName").ToString)
                        strPayPalURL += "&last_name=" & HTTPPOSTEncode(dr("LastName").ToString)
                        strPayPalURL += "&address1=" & HTTPPOSTEncode(IIf(dr("Unit").ToString <> "", dr("Unit").ToString & " ", "") & dr("Street").ToString)
                        strPayPalURL += "&city=" & HTTPPOSTEncode(dr("City").ToString)
                        strPayPalURL += "&state=" & HTTPPOSTEncode(dr("Region").ToString) ' abbreviation only
                        strPayPalURL += "&zip=" & HTTPPOSTEncode(dr("PostalCode").ToString) ' documentation says numeric only?
                    End If
                    dr.Close()

                    strPayPalURL += "&return=" & HTTPPOSTEncode("http://" & GetDomainName(Request))
                    strPayPalURL += "&cancel_return=" & HTTPPOSTEncode("http://" & GetDomainName(Request))
                    strPayPalURL += "&notify_url=" & HTTPPOSTEncode("http://" & GetDomainName(Request) & "/admin/Sales/PayPalIPN.aspx")
                    strPayPalURL += "&sra=1" ' reattempt on failure

                    ' redirect to PayPal
                    Response.Redirect(strPayPalURL)
                End If

            End If

        End Sub

    End Class

End Namespace
