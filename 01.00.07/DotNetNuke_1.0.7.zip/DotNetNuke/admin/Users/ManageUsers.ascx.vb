'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2003
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Namespace DotNetNuke

    Public Class ManageUsers
        Inherits DotNetNuke.PortalModuleControl

        Protected WithEvents txtFirstName As System.Web.UI.WebControls.TextBox
        Protected WithEvents valFirstName As System.Web.UI.WebControls.RequiredFieldValidator
        Protected WithEvents txtLastName As System.Web.UI.WebControls.TextBox
        Protected WithEvents valLastName As System.Web.UI.WebControls.RequiredFieldValidator
        Protected WithEvents txtUsername As System.Web.UI.WebControls.TextBox
        Protected WithEvents valUsername As System.Web.UI.WebControls.RequiredFieldValidator
        Protected WithEvents txtPassword As System.Web.UI.WebControls.TextBox
        Protected WithEvents valPassword As System.Web.UI.WebControls.RequiredFieldValidator
        Protected WithEvents txtConfirm As System.Web.UI.WebControls.TextBox
        Protected WithEvents valConfirm1 As System.Web.UI.WebControls.RequiredFieldValidator
        Protected WithEvents valConfirm2 As System.Web.UI.WebControls.CompareValidator
        Protected WithEvents txtEmail As System.Web.UI.WebControls.TextBox
        Protected WithEvents valEmail As System.Web.UI.WebControls.RequiredFieldValidator
        Protected WithEvents rowAuthorized As System.Web.UI.HtmlControls.HtmlTableRow
        Protected WithEvents chkAuthorized As System.Web.UI.WebControls.CheckBox
        Protected WithEvents Address1 As Address
        Protected WithEvents Message As System.Web.UI.WebControls.Label

        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdDelete As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdManage As System.Web.UI.WebControls.LinkButton

        Protected WithEvents pnlAudit As System.Web.UI.WebControls.Panel
        Protected WithEvents lblCreatedDate As System.Web.UI.WebControls.Label
        Protected WithEvents lblLastLoginDate As System.Web.UI.WebControls.Label

        Private userId As Integer = -1


#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        '*******************************************************
        '
        ' The Page_Load server event handler on this page is used
        ' to populate the role information for the page
        '
        '*******************************************************

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            ' Calculate userid
            If Not (Request.Params("userid") Is Nothing) Then
                userId = Int32.Parse(Request.Params("userid"))
            End If

            ' If this is the first visit to the page, bind the role data to the datalist
            If Page.IsPostBack = False Then
                cmdDelete.Attributes.Add("onClick", "javascript:return confirm('Are You Sure You Wish To Delete This Item ?');")

                BindData()

                If userId = _portalSettings.SuperUserId Then
                    Address1.Visible = False
                    rowAuthorized.Visible = False
                    cmdDelete.Visible = False
                    cmdManage.Visible = False

                    If Not Request.UrlReferrer Is Nothing Then
                        ViewState("UrlReferrer") = Request.UrlReferrer.ToString()
                    Else
                        ViewState("UrlReferrer") = ""
                    End If
                Else
                    ViewState("UrlReferrer") = "~/DesktopDefault.aspx?tabid=" & TabId & "&tabname=Manage Users"
                End If
            End If

            txtPassword.Attributes.Add("value", txtPassword.Text)
            txtConfirm.Attributes.Add("value", txtConfirm.Text)

        End Sub


        '*******************************************************
        '
        ' The Save_Click server event handler on this page is used
        ' to save the current security settings to the configuration system
        '
        '*******************************************************

        Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click

            Response.Redirect(CType(Viewstate("UrlReferrer"), String))

        End Sub

        Private Sub cmdUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdUpdate.Click

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            ' update the user record in the database
            Dim objUser As New UsersDB()
            Dim objSecurity As New PortalSecurity()
            Dim admin As New AdminDB()
            Dim strBody As String
            Dim strURL As String

            If userId = -1 Then
                userId = objUser.AddUser(PortalId, txtFirstName.Text, txtLastName.Text, Address1.Unit, Address1.Street, Address1.City, Address1.Region, Address1.Postal, Address1.Country, Address1.Telephone, txtEmail.Text, txtUsername.Text, objSecurity.Encrypt(_portalSettings.HostSettings("EncryptionKey"), txtPassword.Text), chkAuthorized.Checked.ToString, userId)

                If userId < 0 Then
                    Message.Text = "Registration Failed! Email <u>" & txtEmail.Text & "</u> is already registered." & "<" & "br" & ">" & "Please register using a different email address."
                Else
                    ' add user to the RegisteredUsers role 
                    objUser.AddUserRole(PortalId, _portalSettings.RegisteredRoleId, userId)

                    strURL = GetPortalDomainName(PortalAlias, Request)
                    strBody = "Dear " & txtFirstName.Text & " " & txtLastName.Text & "," & vbCrLf & vbCrLf
                    strBody = strBody & "We are pleased to advise that you have been added as a Registered User to the " & _portalSettings.PortalName & " portal website. Please read the following information carefully and be sure to save this message in a safe location for future reference." & vbCrLf & vbCrLf
                    strBody = strBody & "Portal Website Address: " & strURL & vbCrLf
                    strBody = strBody & "Username: " & txtUsername.Text & vbCrLf
                    strBody = strBody & "Password: " & txtPassword.Text & vbCrLf
                    If _portalSettings.UserRegistration = 3 Then
                        strBody = strBody & "Verification Code: " & _portalSettings.PortalId.ToString & "-" & userId.ToString & vbCrLf
                    End If
                    strBody = strBody & vbCrLf & "Please take the opportunity to visit the website to review its content and take advantage of its many features." & vbCrLf & vbCrLf

                    Dim objAdmin As New AdminDB()
                    Dim intModuleId As Integer = objAdmin.GetSiteModule("Site Settings", PortalId)
                    Dim settings As Hashtable = _portalSettings.GetModuleSettings(intModuleId)
                    strBody = strBody & CType(settings("signupmessage"), String) & vbCrLf & vbCrLf

                    strBody = strBody & "Thank you, we appreciate your support..." & vbCrLf & vbCrLf
                    strBody = strBody & _portalSettings.PortalName

                    SendNotification(_portalSettings.Email, txtEmail.Text, "", _portalSettings.PortalName & " New User Registration", strBody)

                    Response.Redirect(CType(Viewstate("UrlReferrer"), String))
                End If
            Else
                Message.Text = ""
                If txtPassword.Text <> "" Or txtConfirm.Text <> "" Then
                    If txtPassword.Text <> txtConfirm.Text Then
                        Message.Text = "Password Values Entered Do Not Match."
                    End If
                End If
                If Message.Text = "" Then
                    ' if activating an account, send notification
                    If chkAuthorized.Checked Then
                        Dim dr As SqlDataReader = objUser.GetSingleUser(PortalId, userId)
                        If dr.Read() Then
                            If dr("Authorized") <> chkAuthorized.Checked Then
                                strURL = GetPortalDomainName(PortalAlias, Request)
                                strBody = "Dear " & txtFirstName.Text & " " & txtLastName.Text & "," & vbCrLf & vbCrLf
                                strBody = strBody & "We are pleased to advise that your application to the " & _portalSettings.PortalName & " portal website has been authorized. Please read the following information carefully and be sure to save this message in a safe location for future reference." & vbCrLf & vbCrLf
                                strBody = strBody & "Portal Website Address: " & strURL & vbCrLf
                                strBody = strBody & "Username: " & txtUsername.Text & vbCrLf
                                strBody = strBody & "Password: " & objSecurity.Decrypt(_portalSettings.HostSettings("EncryptionKey"), dr("Password").ToString) & vbCrLf
                                If _portalSettings.UserRegistration = 3 Then
                                    strBody = strBody & "Verification Code: " & _portalSettings.PortalId.ToString & "-" & userId.ToString & vbCrLf
                                End If
                                strBody = strBody & vbCrLf & "Please take the opportunity to visit the website to review its content and take advantage of its many features." & vbCrLf & vbCrLf

                                Dim objAdmin As New AdminDB()
                                Dim intModuleId As Integer = objAdmin.GetSiteModule("Site Settings", PortalId)
                                Dim settings As Hashtable = _portalSettings.GetModuleSettings(intModuleId)
                                strBody = strBody & CType(settings("signupmessage"), String) & vbCrLf & vbCrLf

                                strBody = strBody & "Thank you, we appreciate your support..." & vbCrLf & vbCrLf
                                strBody = strBody & _portalSettings.PortalName

                                SendNotification(_portalSettings.Email, txtEmail.Text, "", _portalSettings.PortalName & " New User Authorization", strBody)
                            End If
                        End If
                    End If

                    objUser.UpdateUser(PortalId, userId, txtFirstName.Text, txtLastName.Text, Address1.Unit, Address1.Street, Address1.City, Address1.Region, Address1.Postal, Address1.Country, Address1.Telephone, txtEmail.Text, txtUsername.Text, IIf(txtPassword.Text <> "", objSecurity.Encrypt(_portalSettings.HostSettings("EncryptionKey"), txtPassword.Text), ""), chkAuthorized.Checked.ToString)

                    Response.Redirect(CType(Viewstate("UrlReferrer"), String))
                End If
            End If

        End Sub

        '*******************************************************
        '
        ' The BindData helper method is used to bind the list of
        ' security roles for this portal to an asp:datalist server control
        '
        '*******************************************************

        Sub BindData()

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(Context.Items("PortalSettings"), PortalSettings)

            Address1.ModuleId = ModuleId

            If userId <> -1 Then
                ' Bind the Email and Password
                Dim objUser As New UsersDB()
                Dim dr As SqlDataReader = objUser.GetSingleUser(PortalId, userId)

                ' Read first row from database
                If dr.Read() Then
                    txtFirstName.Text = dr("FirstName").ToString
                    txtLastName.Text = dr("LastName").ToString
                    txtUsername.Text = dr("Username").ToString
                    txtEmail.Text = dr("Email").ToString
                    If userId <> _portalSettings.SuperUserId Then
                        chkAuthorized.Checked = dr("Authorized")
                    End If

                    Address1.Unit = dr("Unit").ToString
                    Address1.Street = dr("Street").ToString
                    Address1.City = dr("City").ToString
                    Address1.Region = dr("Region").ToString
                    Address1.Country = dr("Country").ToString
                    Address1.Postal = dr("PostalCode").ToString
                    Address1.Telephone = dr("Telephone").ToString

                    lblCreatedDate.Text = dr("CreatedDate").ToString
                    lblLastLoginDate.Text = dr("LastLoginDate").ToString
                End If
                dr.Close()

                valPassword.Enabled = False
                valConfirm1.Enabled = False
                valConfirm2.Enabled = False
            Else
                cmdDelete.Visible = False
                cmdManage.Visible = False
                valPassword.Enabled = True
                valConfirm1.Enabled = True
                valConfirm2.Enabled = True
                pnlAudit.Visible = False
            End If

        End Sub

        Private Sub cmdDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdDelete.Click
            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            ' get user id from dropdownlist of users
            Dim users As New UsersDB()
            users.DeleteUser(PortalId, userId)

            Response.Redirect("~/DesktopDefault.aspx?tabid=" & TabId & "&tabname=Manage Users")
        End Sub

        Private Sub cmdManage_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdManage.Click

            Response.Redirect("~/EditModule.aspx?tabid=" & TabId & "&UserId=" & userId & "&def=User Roles")

        End Sub

    End Class

End Namespace