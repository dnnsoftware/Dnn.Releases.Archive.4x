Imports SolpartWebControls.SolpartLib

Public Class SolpartMenuDataDesignerForm2
    Inherits System.Windows.Forms.Form

    Public ParentID As String
    Public EditNode As Xml.XmlNode
    Private m_bSaved As Boolean

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    Public Sub New(ByVal sParentID As String)
        Me.New()
        ParentID = sParentID
    End Sub

    Public Sub New(ByVal sParentID As String, ByVal objNode As Xml.XmlNode)
        Me.New()
        ParentID = sParentID
        EditNode = objNode
        txtID.Text = GetSafeAttribute(objNode, "id")
        If txtID.Text.Length = 0 Then
            txtID.Text = CStr(objNode.OwnerDocument.SelectNodes("//menuitem").Count + 1)
        End If
        txtTitle.Text = GetSafeAttribute(objNode, "title")
        txtURL.Text = GetSafeAttribute(objNode, "url")
        txtImage.Text = GetSafeAttribute(objNode, "image")
        If objNode.ParentNode Is Nothing Then
            lblParent.Text = ParentID
        Else
            If objNode.ParentNode.Name = "menuitem" Then
                lblParent.Text = GetSafeAttribute(objNode.ParentNode, "title")
            Else
                lblParent.Text = "<Root>"
            End If
        End If
    End Sub


    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtID As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents lblParent As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtImage As System.Windows.Forms.TextBox
    Friend WithEvents txtURL As System.Windows.Forms.TextBox
    Friend WithEvents txtTitle As System.Windows.Forms.TextBox
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents btnOk As System.Windows.Forms.Button
    Friend WithEvents Label6 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtID = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblParent = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtImage = New System.Windows.Forms.TextBox()
        Me.txtURL = New System.Windows.Forms.TextBox()
        Me.txtTitle = New System.Windows.Forms.TextBox()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnOk = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(15, 53)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(44, 22)
        Me.Label2.TabIndex = 22
        Me.Label2.Text = "ID:"
        '
        'txtID
        '
        Me.txtID.Location = New System.Drawing.Point(66, 53)
        Me.txtID.Name = "txtID"
        Me.txtID.Size = New System.Drawing.Size(308, 20)
        Me.txtID.TabIndex = 0
        Me.txtID.Text = ""
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(15, 144)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(44, 22)
        Me.Label5.TabIndex = 20
        Me.Label5.Text = "Image:"
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(15, 114)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(44, 21)
        Me.Label4.TabIndex = 19
        Me.Label4.Text = "URL:"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(15, 83)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(44, 22)
        Me.Label3.TabIndex = 18
        Me.Label3.Text = "Title:"
        '
        'lblParent
        '
        Me.lblParent.Location = New System.Drawing.Point(66, 23)
        Me.lblParent.Name = "lblParent"
        Me.lblParent.Size = New System.Drawing.Size(307, 21)
        Me.lblParent.TabIndex = 17
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(15, 23)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(43, 21)
        Me.Label1.TabIndex = 16
        Me.Label1.Text = "Parent:"
        '
        'txtImage
        '
        Me.txtImage.Location = New System.Drawing.Point(66, 144)
        Me.txtImage.Name = "txtImage"
        Me.txtImage.Size = New System.Drawing.Size(308, 20)
        Me.txtImage.TabIndex = 3
        Me.txtImage.Text = ""
        '
        'txtURL
        '
        Me.txtURL.Location = New System.Drawing.Point(66, 114)
        Me.txtURL.Name = "txtURL"
        Me.txtURL.Size = New System.Drawing.Size(308, 20)
        Me.txtURL.TabIndex = 2
        Me.txtURL.Text = ""
        '
        'txtTitle
        '
        Me.txtTitle.Location = New System.Drawing.Point(66, 83)
        Me.txtTitle.Name = "txtTitle"
        Me.txtTitle.Size = New System.Drawing.Size(308, 20)
        Me.txtTitle.TabIndex = 1
        Me.txtTitle.Text = ""
        '
        'btnCancel
        '
        Me.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnCancel.Location = New System.Drawing.Point(307, 182)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(68, 22)
        Me.btnCancel.TabIndex = 5
        Me.btnCancel.Text = "Cancel"
        '
        'btnOk
        '
        Me.btnOk.Location = New System.Drawing.Point(234, 182)
        Me.btnOk.Name = "btnOk"
        Me.btnOk.Size = New System.Drawing.Size(68, 22)
        Me.btnOk.TabIndex = 4
        Me.btnOk.Text = "Ok"
        '
        'Label6
        '
        Me.Label6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label6.Location = New System.Drawing.Point(5, 171)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(374, 2)
        Me.Label6.TabIndex = 25
        '
        'SolpartMenuDataDesignerForm2
        '
        Me.AcceptButton = Me.btnOk
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.CancelButton = Me.btnCancel
        Me.ClientSize = New System.Drawing.Size(387, 212)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label6, Me.btnCancel, Me.btnOk, Me.Label2, Me.txtID, Me.Label5, Me.Label4, Me.Label3, Me.lblParent, Me.Label1, Me.txtImage, Me.txtURL, Me.txtTitle})
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "SolpartMenuDataDesignerForm2"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "MenuItem Properties"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub btnOk_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOk.Click
        If SaveData() Then
            Me.Hide()
        End If
    End Sub

    Private Sub SolpartMenuDataDesignerForm2_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        If Not EditNode Is Nothing And m_bSaved = False Then
            If MsgBox("Do you wish to save your changes?", CType(MsgBoxStyle.YesNo + MsgBoxStyle.Question, MsgBoxStyle)) = MsgBoxResult.Yes Then
                If SaveData() = False Then
                    e.Cancel = True
                End If
            End If
        End If
    End Sub

    Private Function SaveData() As Boolean
        SetSafeAttribute(EditNode, "id", txtID.Text)
        SetSafeAttribute(EditNode, "title", txtTitle.Text)
        SetSafeAttribute(EditNode, "url", txtURL.Text)
        SetSafeAttribute(EditNode, "image", txtImage.Text)
        m_bSaved = True
        Return True
    End Function

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        EditNode = Nothing
        Me.Close()
    End Sub

End Class
