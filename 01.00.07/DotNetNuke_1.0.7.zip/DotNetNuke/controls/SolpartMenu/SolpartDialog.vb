Imports System.ComponentModel
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Xml

<ToolboxData("<{0}:SolpartDialog runat=server></{0}:SolpartDialog>")> _
Public Class SolpartDialog : Inherits System.Web.UI.UserControl ': Implements System.Web.UI.IPostBackEventHandler
    Dim _text As String

    Private m_objDOM As XmlDocument = New XmlDocument()
    Private m_sMenuDataFileName As String
    Private m_sImagesDir As String
    Private m_sHeaderImageLeft As String
    Private m_sHeaderImageRight As String
    Private m_sHeaderCollapseImage As String
    Private m_sHeaderExpandImage As String

    Private m_sHeaderBackgroundImage As String

    Private m_objRes As System.Resources.ResourceManager = New System.Resources.ResourceManager("SolpartWebControls.solpartwc-script", GetType(SolpartDialog).Assembly)

    Private m_bMoveable As Boolean
    Private m_objColor As System.Drawing.Color
    Private m_objShadowColor As System.Drawing.Color
    Private m_objHighlightColor As System.Drawing.Color
    Private m_iBorderSize As Integer
    Private m_objHeaderColor As System.Drawing.Color
    Private m_objHeaderForeColor As System.Drawing.Color
    Private m_objSelectedBorderColor As System.Drawing.Color
    Private m_objForeColor As System.Drawing.Color
    Private m_sBodyHTML As String
    Private m_sHeaderText As String
    Private m_lWidth As Long
    Private m_sTarget As String

    'Private m_objHeaderFont As SPFont = New SPFont("Arial", "8pt", "black")

    Private m_objHeaderFont As System.Drawing.Font
    Private m_objFont As System.Drawing.Font


#Region "Properties"

    <TypeConverter(GetType(WebColorConverter)), Bindable(True), Category("Appearance"), DefaultValue("gray")> _
    Public Property ShadowColor() As System.Drawing.Color
        Get
            If m_objShadowColor.IsEmpty Then
                Return m_objShadowColor.Gray
            Else
                Return m_objShadowColor
            End If
        End Get
        Set(ByVal Value As System.Drawing.Color)
            If Value.IsKnownColor And Value.IsSystemColor = False Then
                m_objShadowColor = Value
            Else
                Throw New SolpartException("Invalid Color.  Needs to be named color")
            End If
        End Set
    End Property

    <TypeConverter(GetType(WebColorConverter)), Bindable(True), Category("Appearance"), DefaultValue("white")> _
    Public Property HighlightColor() As System.Drawing.Color
        Get
            If m_objHighlightColor.IsEmpty Then
                Return m_objHighlightColor.White()
            Else
                Return m_objHighlightColor
            End If
        End Get
        Set(ByVal Value As System.Drawing.Color)
            If Value.IsKnownColor And Value.IsSystemColor = False Then
                m_objHighlightColor = Value
            Else
                Throw New SolpartException("Invalid Color.  Needs to be named color")
            End If
        End Set
    End Property

    <Bindable(True), Category("Appearance"), DefaultValue(0)> _
    Public Property BorderSize() As Integer
        Get
            Return m_iBorderSize
        End Get
        Set(ByVal Value As Integer)
            m_iBorderSize = Value
        End Set
    End Property

    <TypeConverter(GetType(WebColorConverter)), Bindable(True), Category("Appearance"), DefaultValue("silver")> _
    Public Property Color() As System.Drawing.Color
        Get
            'Return CType(IIf(m_objColor.IsEmpty, CType(m_objColor.Silver, Object), CType(m_objColor, Object)), System.Drawing.Color)
            If m_objColor.IsEmpty Then
                Return m_objColor.Silver
            Else
                Return m_objColor
            End If

        End Get
        Set(ByVal Value As System.Drawing.Color)
            'If Value.IsKnownColor And Value.IsSystemColor = False Then
            m_objColor = Value
            'Else
            '    Throw New SolpartException("Invalid Color.  Needs to be named color")
            'End If
        End Set
    End Property

    <TypeConverter(GetType(WebColorConverter)), Bindable(True), Category("Appearance"), DefaultValue("black")> _
    Public Property ForeColor() As System.Drawing.Color
        Get
            If m_objForeColor.IsEmpty Then
                Return m_objForeColor.Black
            Else
                Return m_objForeColor
            End If
        End Get
        Set(ByVal Value As System.Drawing.Color)
            'If Value.IsKnownColor And Value.IsSystemColor = False Then
            m_objForeColor = Value
            'Else
            '    Throw New SolpartException("Invalid Color.  Needs to be named color")
            'End If
        End Set
    End Property

    <TypeConverter(GetType(WebColorConverter)), Bindable(True), Category("Appearance"), DefaultValue("navy")> _
    Public Property HeaderColor() As System.Drawing.Color
        Get
            If m_objHeaderColor.IsEmpty Then
                Return m_objHeaderColor.Navy
            Else
                Return m_objHeaderColor
            End If
        End Get
        Set(ByVal Value As System.Drawing.Color)
            'If Value.IsKnownColor And Value.IsSystemColor = False Then
            m_objHeaderColor = Value
            'Else
            '    Throw New SolpartException("Invalid Color.  Needs to be named color")
            'End If
        End Set
    End Property

    <TypeConverter(GetType(WebColorConverter)), Bindable(True), Category("Appearance"), DefaultValue("navy")> _
    Public Property HeaderForeColor() As System.Drawing.Color
        Get
            If m_objHeaderForeColor.IsEmpty Then
                Return m_objHeaderForeColor.White
            Else
                Return m_objHeaderForeColor
            End If
        End Get
        Set(ByVal Value As System.Drawing.Color)
            'If Value.IsKnownColor And Value.IsSystemColor = False Then
            m_objHeaderForeColor = Value
            'Else
            '    Throw New SolpartException("Invalid Color.  Needs to be named color")
            'End If
        End Set
    End Property

    <Bindable(True), Category("Appearance"), DefaultValue("True")> _
    Public Property Moveable() As Boolean
        Get
            Return m_bMoveable
        End Get
        Set(ByVal Value As Boolean)
            m_bMoveable = Value
        End Set
    End Property

    <Bindable(True), Category("Appearance")> _
    Public ReadOnly Property DialogStyle() As String
        Get
            Return "color: " & GetColor(ForeColor) & "; background-color: " & GetColor(Color) & "; border-bottom: " & GetColor(ShadowColor) & " " & BorderSize & "px solid; border-left: " & GetColor(HighlightColor) & " " & BorderSize & "px solid; border-top: " & GetColor(HighlightColor) & " " & BorderSize & "px solid; border-right: " & GetColor(ShadowColor) & " " & BorderSize & "px solid;" & DialogFontStyle
        End Get
    End Property

    <Bindable(True), Category("Appearance")> _
    Public ReadOnly Property DialogFontStyle() As String
        Get
            Return "font-family: " & Font.FontFamily.GetName(0) & "; font-size: " & Font.Size.ToString & ";"
        End Get
    End Property

    <Bindable(True), Category("Appearance")> _
    Public Property HeaderFont() As System.Drawing.Font
        Get
            If m_objHeaderFont Is Nothing Then
                Return New System.Drawing.Font("Arial", 20)
            Else
                Return m_objHeaderFont
            End If
        End Get
        Set(ByVal Value As System.Drawing.Font)
            m_objHeaderFont = Value
        End Set
    End Property

    <Bindable(True), Category("Appearance")> _
    Public Property Font() As System.Drawing.Font
        Get
            If m_objFont Is Nothing Then
                Return New System.Drawing.Font("Arial", 12)
            Else
                Return m_objFont
            End If
        End Get
        Set(ByVal Value As System.Drawing.Font)
            m_objFont = Value
        End Set
    End Property

    <Bindable(True), Category("Appearance")> _
    Public ReadOnly Property HeaderStyle() As String
        Get
            Return "color: " & GetColor(HeaderForeColor) & "; background-color: " & GetColor(HeaderColor) & "; font-family: " & HeaderFont.FontFamily.GetName(0) & "; font-size: " & HeaderFont.Size.ToString & ";" & MyIIf(Len(HeaderBackgroundImage) > 0, "background-image:url(" & ImagesDir & HeaderBackgroundImage & ")", "")
        End Get
    End Property


    <Bindable(True), Description("Allows menu to be populated from an XML file"), Category("Data")> _
    Public Property MenuDataXMLFileName() As String
        Get
            Return m_sMenuDataFileName
        End Get
        Set(ByVal Value As String)
            If Len(Value) > 0 Then
                'ideally this value should be validated against a schema
                'm_objDOM.Load(Value)
                m_sMenuDataFileName = Value
            End If
        End Set
    End Property

    <Description("Directory to find the images for the menu.  Need to have spacer.gif here!")> _
    Public Property ImagesDir() As String
        Get
            Return MyIIf(Len(m_sImagesDir) = 0, "images/", m_sImagesDir)
        End Get
        Set(ByVal Value As String)
            m_sImagesDir = Value
        End Set
    End Property

    Public Property HeaderImageLeft() As String
        Get
            Return m_sHeaderImageLeft
        End Get
        Set(ByVal Value As String)
            m_sHeaderImageLeft = Value
        End Set
    End Property

    Public Property HeaderImageRight() As String
        Get
            Return m_sHeaderImageRight
        End Get
        Set(ByVal Value As String)
            m_sHeaderImageRight = Value
        End Set
    End Property

    Public Property HeaderImageCollapse() As String
        Get
            Return m_sHeaderCollapseImage
        End Get
        Set(ByVal Value As String)
            m_sHeaderCollapseImage = Value
        End Set
    End Property

    Public Property HeaderImageExpand() As String
        Get
            Return m_sHeaderExpandImage
        End Get
        Set(ByVal Value As String)
            m_sHeaderExpandImage = Value
        End Set
    End Property

    Public Property HeaderBackgroundImage() As String
        Get
            Return m_sHeaderBackgroundImage
        End Get
        Set(ByVal Value As String)
            m_sHeaderBackgroundImage = Value
        End Set
    End Property

    Public Property HeaderText() As String
        Get
            Return m_sHeaderText
        End Get
        Set(ByVal Value As String)
            m_sHeaderText = Value
        End Set
    End Property

    Public Property BodyHTML() As String
        Get
            Return m_sBodyHTML
        End Get
        Set(ByVal Value As String)
            m_sBodyHTML = Value
        End Set
    End Property

    Public Property Width() As Long
        Get
            Return m_lWidth
        End Get
        Set(ByVal Value As Long)
            m_lWidth = Value
        End Set
    End Property

#End Region

#Region "Overrides Methods"
    Protected Overrides Sub Render(ByVal output As System.Web.UI.HtmlTextWriter)

        If Len(MenuDataXMLFileName) > 0 Then
            'ideally this value should be validated against a schema
            m_objDOM.Load(Server.MapPath(MenuDataXMLFileName))
        End If

        output.Write(GenerateDialogHTML())
        'output.Write(MenuData())
    End Sub

    Protected Overrides Sub OnPreRender(ByVal e As System.EventArgs)
        Dim sScript As String

        If Not Page.IsClientScriptBlockRegistered("solpartdialogscript") Then
            Select Case BrowserType.Browser
                Case "IE"
                    sScript = m_objRes.GetString("spdialog-ie")
                Case "Netscape"
                    If BrowserType.MajorVersion >= 6 Then
                        sScript = m_objRes.GetString("spdialog-ns6")
                    Else
                        '                      sScript = m_objRes.GetString("spmenu-all")
                    End If
            End Select
            If Len(sScript) > 0 Then
                sScript = sScript.Replace("SPD_EXPANDIMAGE", ImagesDir & HeaderImageExpand).Replace("SPD_COLLAPSEIMAGE", ImagesDir & HeaderImageCollapse)
                Page.RegisterClientScriptBlock("solpartdialogscript", "<SCRIPT>" & sScript & "</SCRIPT>")
            End If
        End If
    End Sub
#End Region

#Region "Private Functions"
    Private Function GenerateDialogHTML() As String
        Dim sHTML As String

        Select Case True
            Case BrowserType.Browser = "IE" Or (BrowserType.Browser = "Netscape" And BrowserType.MajorVersion >= 6)
                'netscape renders tables with display: block as having cellpadding!!! therefore using div outside table - LAME!

                sHTML = _
                MyIIf(BrowserType.Browser = "Netscape", "<DIV ID='divDialog' STYLE='position: relative; display: block;'>", "") & vbCrLf & _
                "<TABLE ID='tblDialog' style=""" & MyIIf(BrowserType.Browser = "Netscape", "", "position: relative;") & " filter:progid:DXImageTransform.Microsoft.Alpha(opacity=100)"" CELLPADDING=""0"" CELLSPACING=""0"" BORDER='0' WIDTH=""" & Width & """>" & vbCrLf & _
                "	<TR ID='trHeader'>" & vbCrLf & _
                "       <TD align=""right"">" & vbCrLf & _
                            MyIIf(Len(HeaderImageLeft) > 0, GetImage(HeaderImageLeft, "align=""absbottom"""), "") & vbCrLf & _
                "       </TD><TD WIDTH=""100%"" " & MyIIf(Moveable, "onmousedown=""dialoghook_MouseDown(this)"" onmouseup=""dialoghook_MouseUp(this)"" onmousemove=""dialoghook_MouseMove(event)"" STYLE=""cursor: pointer; cursor: move;" & HeaderStyle & """", "STYLE='" & HeaderStyle & "'") & ">" & _
                            HeaderText & vbCrLf & _
                            MyIIf(Len(HeaderImageCollapse) > 0, "</TD><TD STYLE='" & HeaderStyle & "' ALIGN=""right"">&nbsp;&nbsp;" & GetImage(HeaderImageCollapse, "onclick=""collapseTable(this)"" style=""cursor: hand; cursor: pointer;""", "imgCollapse"), "") & _
                "       </TD>" & vbCrLf & _
                "       <TD>" & vbCrLf & _
                            MyIIf(Len(HeaderImageRight) > 0, GetImage(HeaderImageRight, "align=""absbottom"""), "") & vbCrLf & _
                "       </TD>" & vbCrLf & _
                "   </TR>" & vbCrLf & _
                "	<TR ID='trBody'>" & vbCrLf & _
                "       <TD COLSPAN=""4"" STYLE='" & DialogStyle & "'>" & vbCrLf & _
                            BodyHTML & vbCrLf & _
                "       </TD>" & vbCrLf & _
                "   </TR>" & vbCrLf & _
                "</TABLE>" & vbCrLf & _
                MyIIf(BrowserType.Browser = "Netscape", "</DIV>", "") & vbCrLf
            Case Else
                sHTML = "<TABLE ID='tblDialog' CELLPADDING=""0"" CELLSPACING=""0"" BORDER='0' WIDTH=""" & Width & """ >" & vbCrLf & _
                        "   <TR>" & vbCrLf & _
                        "       <TD BGCOLOR=""" & GetColor(HeaderColor) & """>" & vbCrLf & _
                                "<FONT COLOR=""" & GetColor(HeaderForeColor) & """ FACE=""" & HeaderFont.FontFamily.GetName(0) & """ STYLE=""font-size: " & HeaderFont.Size & "pt"">" & HeaderText & "</FONT>" & vbCrLf & _
                        "       </TD>" & vbCrLf & _
                        "   </TR>" & vbCrLf & _
                        "   <TR>" & vbCrLf & _
                        "       <TD BGCOLOR=""" & GetColor(Color) & """>" & vbCrLf & _
                                "<FONT COLOR=""" & GetColor(ForeColor) & """ FACE=""" & Font.FontFamily.GetName(0) & """ STYLE=""font-size: " & Font.Size & "pt"">" & BodyHTML & "</FONT>" & vbCrLf & _
                        "       </TD>" & vbCrLf & _
                        "   </TR>" & vbCrLf & _
                        "</TABLE>"
                'DialogFontStyle
        End Select

        Return sHTML

    End Function


    Private Function BrowserType() As System.Web.HttpBrowserCapabilities
        Return Request.Browser

    End Function

    Private Function GetSpacer() As String
        Return "<IMG SRC=""" & ImagesDir & "spacer.gif"">"
    End Function

    Private Function GetImage(ByVal sImage As String, Optional ByVal sJS As String = "", Optional ByVal sID As String = "") As String
        If Len(sImage) > 0 Then
            Return "<IMG BORDER=""0"" SRC=""" & ImagesDir & sImage & """ " & sJS & MyIIf(Len(sID) > 0, "ID=""" & sID & """", "") & ">"
        End If
    End Function
    Private Function GetImage(ByVal objAttr As XmlAttribute) As String
        If objAttr Is Nothing Then
            Return GetImage("spacer.gif")
        Else
            Return GetImage(objAttr.Value.ToString)
        End If
    End Function

    Private Function GetColor(ByVal objColor As System.Drawing.Color) As String
        If objColor.IsEmpty Then
            Return ""
        Else
            If objColor.IsNamedColor = False Then
                Return "#" & objColor.R.ToString("X2") & objColor.G.ToString("X2") & objColor.B.ToString("X2")
            Else
                Return objColor.ToKnownColor.ToString
            End If
        End If
    End Function

    Private Function MyIIf(ByVal bFlag As Boolean, ByVal sTrue As String, ByVal sFalse As String) As String
        'to get around option script conversion to object each time I am doing in central place
        Return CType(IIf(bFlag, CType(sTrue, Object), CType(sFalse, Object)), String)
    End Function

#End Region

End Class
