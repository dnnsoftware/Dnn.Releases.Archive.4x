Imports System
Imports System.Configuration
Imports System.Text
Imports System.Web

Namespace DotNetNuke

    Public Class HTTPHandler

        Implements IHttpModule

        Public Sub Init(ByVal app As HttpApplication) Implements IHttpModule.Init
            AddHandler app.BeginRequest, AddressOf Me.OnBeginRequest
        End Sub

        Public Sub Dispose() Implements IHttpModule.Dispose
        End Sub

        Public Delegate Sub MyEventHandler(ByVal s As Object, ByVal e As EventArgs)

        Public Event MyEvent As MyEventHandler

        Public Sub OnBeginRequest(ByVal s As Object, ByVal e As EventArgs)
            Dim app As HttpApplication = CType(s, HttpApplication)

            Dim strTest As String = app.Request.Url.ToString()

            If InStr(1, app.Request.Url.ToString.ToLower, "/default.aspx") <> 0 Then
                Dim DomainName As String = GetDomainName(app.Request)

                Dim ServerPath As String = app.Request.ApplicationPath
                If Not ServerPath.EndsWith("/") Then
                    ServerPath += "/"
                End If

                If app.Request.Browser("IsMobileDevice") = "true" And app.Request.Browser.Crawler = False Then
                    DomainName = ServerPath & "MobileDefault.aspx" & "?alias=" & DomainName
                Else
                    DomainName = ServerPath & "DesktopDefault.aspx" & "?alias=" & DomainName
                End If

                app.Context.RewritePath(DomainName)
            End If

        End Sub

    End Class

End Namespace
