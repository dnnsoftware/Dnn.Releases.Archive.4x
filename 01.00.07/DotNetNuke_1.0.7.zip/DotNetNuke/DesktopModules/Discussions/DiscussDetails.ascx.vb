'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2003
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Namespace DotNetNuke

    Public Class DiscussDetails
        Inherits DotNetNuke.PortalModuleControl

        Protected WithEvents cmdReply As System.Web.UI.WebControls.LinkButton
        Protected WithEvents TitleField As System.Web.UI.WebControls.TextBox
        Protected WithEvents BodyField As System.Web.UI.WebControls.TextBox
        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
        Protected WithEvents EditPanel As System.Web.UI.WebControls.Panel
        Protected WithEvents Subject As System.Web.UI.WebControls.Label
        Protected WithEvents CreatedByUser As System.Web.UI.WebControls.Label
        Protected WithEvents CreatedDate As System.Web.UI.WebControls.Label
        Protected WithEvents Body As System.Web.UI.WebControls.Label
        Protected WithEvents cmdCancel2 As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdEdit As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdDelete As System.Web.UI.WebControls.LinkButton
        Protected WithEvents tblOriginalMessage As System.Web.UI.HtmlControls.HtmlTable
        Protected WithEvents rowOriginalMessage As System.Web.UI.HtmlControls.HtmlTableRow

        Private itemId As Integer = -1
        Private itemIndex As Integer = -1

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            Dim strURLReferrer As String

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            If Not (Request.Params("ItemIndex") Is Nothing) Then
                itemIndex = Int32.Parse(Request.Params("ItemIndex"))
            End If

            If Not (Request.Params("ItemId") Is Nothing) Then
                itemId = Int32.Parse(Request.Params("ItemId"))
            Else
                EditPanel.Visible = True
                cmdReply.Visible = False
                cmdUpdate.Text = "Save"
            End If

            ' Populate message contents if this is the first visit to the page
            If Page.IsPostBack = False Then

                If Not PortalSecurity.IsInRoles(_portalSettings.AdministratorRoleId.ToString) Then
                    cmdEdit.Visible = False
                    cmdDelete.Visible = False
                End If

                If itemId <> -1 Then
                    ' Obtain the selected item from the Discussion table
                    Dim discuss As New DiscussionDB()
                    Dim dr As SqlDataReader = discuss.GetSingleMessage(itemId, ModuleId)

                    ' Load row from database
                    If dr.Read() Then
                        Subject.Text = Server.HtmlDecode(CType(dr("Title"), String))
                        Body.Text = Server.HtmlDecode(CType(dr("Body"), String))
                        CreatedByUser.Text = dr("CreatedByUser").ToString
                        CreatedDate.Text = String.Format("{0:d}", dr("CreatedDate"))
                        TitleField.Text = ReTitle(CType(dr("Title"), String))
                        BodyField.Text = CType(dr("Body"), String)
                        dr.Close()
                    Else ' security violation attempt to access item not related to this Module
                        Response.Redirect("~/desktopdefault.aspx?tabid=" & TabId)
                    End If
                Else
                    tblOriginalMessage.Visible = False
                End If

                ' Store URL Referrer to return to portal
                strURLReferrer = Request.UrlReferrer.ToString()
                If InStr(1, strURLReferrer, "&ItemIndex=") <> 0 Then
                    strURLReferrer = Left(strURLReferrer, InStr(1, strURLReferrer, "&ItemIndex=") - 1)
                End If
                strURLReferrer = strURLReferrer & IIf(itemIndex <> -1, "&ItemIndex=" & itemIndex, "")
                ViewState("UrlReferrer") = strURLReferrer
            End If

            If PortalSecurity.HasEditPermissions(ModuleId) = False Then

                If itemId = -1 Then
                    Response.Redirect("~/EditModule.aspx?tabid=" & TabId & "&def=Edit Access Denied")
                Else
                    cmdReply.Visible = False
                End If

            End If

        End Sub

        Private Sub cmdReply_Click(ByVal Sender As Object, ByVal e As EventArgs) Handles cmdReply.Click

            BodyField.Text = ""
            EditPanel.Visible = True
            rowOriginalMessage.Visible = True
            cmdReply.Visible = False
            cmdCancel2.Visible = False
            cmdEdit.Visible = False
            cmdDelete.Visible = False
            cmdUpdate.Text = "Save"

        End Sub

        Private Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click

            ' Create new discussion database component
            Dim discuss As New DiscussionDB()

            If cmdUpdate.Text = "Update" Then
                discuss.UpdateMessage(itemId, Context.User.Identity.Name, Replace(Server.HtmlEncode(TitleField.Text), vbCrLf, "<br>"), Replace(Server.HtmlEncode(BodyField.Text), vbCrLf, "<br>"))
            Else
                discuss.AddMessage(ModuleId, itemId, Context.User.Identity.Name, Replace(Server.HtmlEncode(TitleField.Text), vbCrLf, "<br>"), Replace(Server.HtmlEncode(BodyField.Text), vbCrLf, "<br>"))
            End If

            Response.Redirect(ViewState("UrlReferrer"))
        End Sub

        Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click, cmdCancel2.Click
            Response.Redirect(ViewState("UrlReferrer"))
        End Sub

        Function ReTitle(ByVal title As String) As String

            If title.Length > 0 And title.IndexOf("Re: ", 0) = -1 Then
                title = "Re: " & title
            End If

            Return title

        End Function

        Private Sub cmdDelete_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDelete.Click
            ' Create new discussion database component
            Dim discuss As New DiscussionDB()

            discuss.DeleteMessage(itemId)

            Response.Redirect(ViewState("UrlReferrer"))

        End Sub

        Private Sub cmdEdit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdEdit.Click

            EditPanel.Visible = True
            rowOriginalMessage.Visible = True
            cmdReply.Visible = False
            cmdCancel2.Visible = False
            cmdEdit.Visible = False
            cmdDelete.Visible = False
            cmdUpdate.Text = "Update"

        End Sub

    End Class

End Namespace