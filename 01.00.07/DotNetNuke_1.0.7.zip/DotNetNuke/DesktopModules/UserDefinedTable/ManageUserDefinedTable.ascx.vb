'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2003
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Namespace DotNetNuke

    Public Class ManageUserDefinedTable
        Inherits DotNetNuke.PortalModuleControl

        Protected WithEvents cmdAddField As System.Web.UI.WebControls.LinkButton
        Protected WithEvents grdFields As System.Web.UI.WebControls.DataGrid
        Protected WithEvents cboSortField As System.Web.UI.WebControls.DropDownList
        Protected WithEvents cboSortOrder As System.Web.UI.WebControls.DropDownList
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            If Page.IsPostBack = False Then

                BindData()

                ' Store URL Referrer to return to portal
                ViewState("UrlReferrer") = Replace(Request.UrlReferrer.ToString(), "insertrow=true&", "")

            End If

        End Sub

        Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click, cmdCancel.Click

            ' Redirect back to the portal home page
            Response.Redirect(CStr(ViewState("UrlReferrer")))

        End Sub

        Public Sub grdFields_CancelEdit(ByVal sender As Object, ByVal e As DataGridCommandEventArgs)
            grdFields.EditItemIndex = -1
            BindData()
        End Sub

        Public Sub grdFields_Edit(ByVal sender As Object, ByVal e As DataGridCommandEventArgs)
            grdFields.EditItemIndex = e.Item.ItemIndex
            grdFields.SelectedIndex = -1
            BindData()
        End Sub

        Public Sub grdFields_Update(ByVal sender As Object, ByVal e As DataGridCommandEventArgs)

            Dim chkVisible As CheckBox = e.Item.Cells(1).Controls(1)
            Dim txtFieldTitle As TextBox = e.Item.Cells(2).Controls(1)
            Dim cboFieldType As DropDownList = e.Item.Cells(3).Controls(1)

            If txtFieldTitle.Text <> "" Then
                Dim objUserDefinedTable As New UserDefinedTableDB()

                If Integer.Parse(grdFields.DataKeys(e.Item.ItemIndex).ToString()) = -1 Then
                    objUserDefinedTable.AddUserDefinedField(ModuleId, txtFieldTitle.Text, chkVisible.Checked, cboFieldType.SelectedItem.Value)
                Else
                    objUserDefinedTable.UpdateUserDefinedField(Integer.Parse(grdFields.DataKeys(e.Item.ItemIndex).ToString()), txtFieldTitle.Text, chkVisible.Checked, cboFieldType.SelectedItem.Value)
                End If

                grdFields.EditItemIndex = -1
                BindData()
            Else
                grdFields.EditItemIndex = -1
                BindData()
            End If
        End Sub

        Public Sub grdFields_Delete(ByVal sender As Object, ByVal e As DataGridCommandEventArgs)
            Dim objUserDefinedTable As New UserDefinedTableDB()

            objUserDefinedTable.DeleteUserDefinedField(Integer.Parse(grdFields.DataKeys(e.Item.ItemIndex).ToString()))

            grdFields.EditItemIndex = -1
            BindData()
        End Sub

        Public Sub grdFields_Move(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs)
            Dim objUserDefinedTable As New UserDefinedTableDB()

            Select Case e.CommandArgument
                Case "Up"
                    objUserDefinedTable.UpdateUserDefinedFieldOrder(Integer.Parse(grdFields.DataKeys(e.Item.ItemIndex).ToString()), -1)
                    BindData()
                Case "Down"
                    objUserDefinedTable.UpdateUserDefinedFieldOrder(Integer.Parse(grdFields.DataKeys(e.Item.ItemIndex).ToString()), 1)
                    BindData()
            End Select

        End Sub

        Private Sub cmdAddField_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdAddField.Click
            grdFields.EditItemIndex = 0
            BindData(True)
        End Sub

        Private Sub BindData(Optional ByVal blnInsertField As Boolean = False)
            Dim objUserDefinedTable As New UserDefinedTableDB()

            Dim dr As SqlDataReader = objUserDefinedTable.GetUserDefinedFields(ModuleId)

            Dim ds As DataSet

            ds = ConvertDataReaderToDataSet(dr)

            ' inserting a new field
            If blnInsertField Then
                Dim row As DataRow
                row = ds.Tables(0).NewRow()
                row("UserDefinedFieldId") = "-1"
                row("FieldTitle") = ""
                row("Visible") = True
                row("FieldType") = "String"
                ds.Tables(0).Rows.InsertAt(row, 0)
                grdFields.EditItemIndex = 0
            End If

            grdFields.DataSource = ds
            grdFields.DataBind()

            cboSortField.DataSource = objUserDefinedTable.GetUserDefinedFields(ModuleId)
            cboSortField.DataBind()
            cboSortField.Items.Insert(0, New ListItem("<Not Specified>", ""))

            ' Get settings from the database
            Dim settings As Hashtable = PortalSettings.GetModuleSettings(ModuleId)

            cboSortField.ClearSelection()
            If Not cboSortField.Items.FindByValue(CType(settings("sortfield"), String)) Is Nothing Then
                cboSortField.Items.FindByValue(CType(settings("sortfield"), String)).Selected = True
            End If
            cboSortOrder.ClearSelection()
            If Not cboSortOrder.Items.FindByValue(CType(settings("sortorder"), String)) Is Nothing Then
                cboSortOrder.Items.FindByValue(CType(settings("sortorder"), String)).Selected = True
            End If
        End Sub

        Private Sub grdFields_ItemCreated(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles grdFields.ItemCreated

            Dim cmdDeleteUserDefinedField As Control = e.Item.FindControl("cmdDeleteUserDefinedField")

            If Not cmdDeleteUserDefinedField Is Nothing Then
                CType(cmdDeleteUserDefinedField, ImageButton).Attributes.Add("onClick", "javascript: return confirm('Are You Sure You Wish To Delete This Item ?')")
            End If

        End Sub

        Private Sub cboSortField_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboSortField.SelectedIndexChanged
            ' Update settings in the database
            Dim admin As New AdminDB()

            If Not cboSortField.SelectedItem Is Nothing Then
                admin.UpdateModuleSetting(ModuleId, "sortfield", cboSortField.SelectedItem.Value)
            End If

            BindData()
        End Sub

        Private Sub cboSortOrder_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboSortOrder.SelectedIndexChanged
            ' Update settings in the database
            Dim admin As New AdminDB()

            If Not cboSortOrder.SelectedItem Is Nothing Then
                admin.UpdateModuleSetting(ModuleId, "sortorder", cboSortOrder.SelectedItem.Value)
            End If

            BindData()
        End Sub

        Public Function GetFieldTypeName(ByVal strFieldType) As String
            Select Case strFieldType
                Case "String" : Return "Text"
                Case "Int32" : Return "Integer"
                Case "Decimal" : Return "Decimal"
                Case "DateTime" : Return "Date"
                Case "Boolean" : Return "True/False"
                Case Else : Return "Text"
            End Select
        End Function

        Public Function GetFieldTypeIndex(ByVal strFieldType) As Integer
            Select Case strFieldType
                Case "String" : Return 0
                Case "Int32" : Return 1
                Case "Decimal" : Return 2
                Case "DateTime" : Return 3
                Case "Boolean" : Return 4
                Case Else : Return 0
            End Select
        End Function

    End Class

End Namespace