Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("DotNetNuke")> 
<Assembly: AssemblyDescription("ASP.NET Open Source Portal Application")> 
<Assembly: AssemblyCompany("Perpetual Motion Interactive Systems Inc.")> 
<Assembly: AssemblyProduct("http://www.dotnetnuke.com")> 
<Assembly: AssemblyCopyright("Portal engine source code is copyright &copy; 2002-YYYY by DotNetNuke. All Rights Reserved")> 
<Assembly: AssemblyTrademark("DotNetNuke")> 
<Assembly: CLSCompliant(True)> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:

<Assembly: AssemblyVersion("1.0.7.*")> 
