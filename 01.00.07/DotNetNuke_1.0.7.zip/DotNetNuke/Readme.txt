DotNetNuke

Clean Installation

- .NET Framework must be installed ( http://www.asp.net/ibuyspy/CheckDotNet.aspx )
- SQL Server 2000 or MSDE 2000 must be installed on a server accessible from the web server ( http://www.asp.net/Tools/redir.aspx?path=msde )
- Mobile Internet Toolkit must already be installed on your system ( http://www.asp.net/Tools/redir.aspx?path=mmit )
- unzip package into C:\
- create Virtual Directory in IIS called DotNetNuke which points to the directory where the DotNetNuke.sln file exists
- manually create SQL Server database named DotNetNuke ( using Enterprise Manager or ... )
- change connectionstring settings in web.config to match your system
- browse to localhost/DotNetNuke
- the application will automatically execute the necessary database scripts

Applications Upgrades

- make sure you always backup your database before upgrading to a new version
- the application will automatically execute the necessary database scripts

Security

- the {Server}/ASPNET user account must have Full Control of the root application directory ( this allows the application to create files/folders ) 

Revisions By

- Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( www.perpetualmotion.ca )

