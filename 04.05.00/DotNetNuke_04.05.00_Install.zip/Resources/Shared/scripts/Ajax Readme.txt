The script files contained in the "MicrosoftAjaxLibrary" sub-folder are intended for use only when the ScriptManager is
not present on the page. An example of this is a module that uses AJAX with pure Javascript calls versus
relying on UpdatePanel. In this case, the developer is responsible for including the appropriate script
references in the page.
