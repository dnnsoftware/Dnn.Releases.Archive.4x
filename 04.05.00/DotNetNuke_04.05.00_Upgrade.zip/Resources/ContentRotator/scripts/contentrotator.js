﻿/*
  DotNetNuke® - http://www.dotnetnuke.com
  Copyright (c) 2002-2007
  by DotNetNuke Corporation
 
  Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
  documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
  the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
  to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 
  The above copyright notice and this permission notice shall be included in all copies or substantial portions 
  of the Software.
 
  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
  THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
  CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
  DEALINGS IN THE SOFTWARE.

	''' -----------------------------------------------------------------------------
	''' <summary>
	''' This script enables client-side rotation of content.
	'''
	''' Ensure that ~/Resources/Shared/scripts/init.js is called from the browser before calling this script
	''' This script will fail if the required AJAX libraries loaded by init.js are not present.
	''' </summary>
	''' <remarks>
	'''	Based on GreyWyvern's HTML Block Scroller & Marquee script
	'''	Portions Copyright GreyWyvern 2007
	'''	Licenced for free distribution under the BSDL
	''' </remarks>
	''' <history>
	'''     Version 1.0.0: Feb. 28, 2007, Nik Kalyani, nik.kalyani@dotnetnuke.com 
	''' </history>
	''' -----------------------------------------------------------------------------
*/

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// C O N T E N T R O T A T O R                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// BEGIN: Namespace management
Type.registerNamespace("DotNetNuke.UI.WebControls.ContentRotator");
// END: Namespace management

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// BEGIN: Rotator class                                                                                       //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
DotNetNuke.UI.WebControls.ContentRotator.Rotator = function(instanceVarName, elementIdPrefix, theme, resourcesFolderUrl)
{
    DotNetNuke.UI.WebControls.ContentRotator.Rotator.initializeBase(this, [instanceVarName, resourcesFolderUrl, theme, elementIdPrefix]);
    this._control = "ContentRotator";
    this._theme = (typeof(theme) == "undefined" ? "Simple" : theme);     
    this._rssProxyUrl = (typeof(rssProxyUrl) == "undefined" ? "http://pipes.yahoo.com/pipes/Aqn6j8_H2xG4_N_1JhOy0Q/run?_render=json&_callback=[CALLBACK]&feedUrl=" : rssProxyUrl);
}

DotNetNuke.UI.WebControls.ContentRotator.Rotator.prototype = 
{
        getRssProxyUrl :
        function(callback)
        {
            return(this._rssProxyUrl.replace("[CALLBACK]", callback));
        },

        setRssProxyUrl :
        function(rssProxyUrl)
        {
            this._rssProxyUrl = rssProxyUrl;
        },

        // BEGIN: scroll
        scroll : 
        function()
        {
            this.addStyleSheet();
        }                
        // END: scroll        
}
DotNetNuke.UI.WebControls.ContentRotator.Rotator.registerClass("DotNetNuke.UI.WebControls.ContentRotator.Rotator", DotNetNuke.UI.WebControls.BaseControl);
// END: Rotator class


function scrollObject(main, width, height, direct, pause) {
  var self = this;
  this.main = main;
  this.block = new Array();
  this.height = height;
  this.width = width;
  this.direct = direct;
  this.pause = pause;
  this.offset = (direct == "up" || direct == "down") ? height : width;
  this.blockprev = 0;
  this.blockcurr = 1;
  this.motion = false;
  this.mouse = false;
  this.scroll = function() {
    if (!document.getElementById) return false;
    this.main = document.getElementById(this.main);
    while (this.main.firstChild) this.main.removeChild(this.main.firstChild);
    for (var x = 0; x < this.block.length; x++) {
      var table = document.createElement('table');
          table.style.position = "absolute";
          table.style.width = this.width + "px";
          table.style.height = this.height + "px";
          table.style.overflow = "hidden";
          table.cellPadding = table.cellSpacing = table.border = "0";
          table.style.left = table.style.top = "0px";
        if (x) {
          switch (direct) {
            case "up": table.style.top = this.height + "px"; break;
            case "down": table.style.top = -(this.height + 2) + "px"; break;
            case "left": table.style.left = this.width + "px"; break;
            case "right": table.style.left = -(this.width + 2) + "px"; break;
          }
        }
        var tbody = document.createElement('tbody');
          var tr = document.createElement('tr');
            var td = document.createElement('td');
                td.innerHTML = this.block[x];
              tr.appendChild(td);
            tbody.appendChild(tr);
          table.appendChild(tbody);
      this.main.appendChild(this.block[x] = table);
    }
    this.main.style.position = "relative";
    this.main.style.width = this.width + "px";
    this.main.style.height = this.height + "px";
    this.main.style.overflow = "hidden";
    if (this.block.length > 1) {
      this.main.onmouseover = function() { self.mouse = true; }
      this.main.onmouseout = function() { self.mouse = false; }
      setInterval(function() { self.scrollLoop(); }, this.pause);
    }
  }
  this.scrollLoop = function() {
    if (!this.motion && this.mouse) return false;
    if (this.offset == 1) {
      this.blockprev = this.blockcurr;
      this.blockcurr = (this.blockcurr + 1 >= this.block.length) ? 0 : this.blockcurr + 1;
      if (this.direct == "up" || this.direct == "down") {
        this.block[this.blockcurr].style.top = ((this.direct == "down") ? "-" : "") + this.height + "px";
        this.block[this.blockprev].style.top = "0px";
        this.offset = this.height;
      } else {
        this.block[this.blockcurr].style.left = ((this.direct == "right") ? "-" : "") + this.width + "px";
        this.block[this.blockprev].style.left = "0px";
        this.offset = this.width;
      } this.motion = false;
    } else {
      if (!this.motion) {
        this.motion = true; var x = -1;
        while (1) { if (Math.abs(this.offset) - Math.pow(2, ++x) <= Math.abs(this.offset) / 2) break; }
        this.offset = (this.direct == "up" || this.direct == "left") ? Math.pow(2, x) : -Math.pow(2, x);
      } else this.offset /= 2;
      if (this.direct == "up" || this.direct == "down") {
        this.block[this.blockcurr].style.top = this.offset + "px";
        this.block[this.blockprev].style.top = (((this.direct == "down") ? this.height : -(this.height + 2)) + this.offset) + "px";
      } else {
        this.block[this.blockcurr].style.left = this.offset + "px";
        this.block[this.blockprev].style.left = (((this.direct == "right") ? this.width : -(this.width + 2)) + this.offset) + "px";
      } setTimeout(function() { self.scrollLoop(); }, 30);
    }
  }
}

