if (typeof(dnn_control) == 'undefined')
	eval('function dnn_control() {}')


dnn_control.prototype.initTextSuggest = function (oCtl) 
{
	dnn.controls.controls[oCtl.id] = new dnn.controls.DNNTextSuggest(oCtl);
	return dnn.controls.controls[oCtl.id];
}


//------- Constructor -------//
dnn_control.prototype.DNNTextSuggest = function (o)
{
	this.ns = o.id;               //stores namespace for menu
	this.container = o;                    //stores container
	this.resultCtr = null;
	this.DOM = null;
	//--- Appearance Properties ---//
	this.tscss = __dm_getAttr(o, 'tscss', '');
	this.css = __dm_getAttr(o, 'css', '');
	this.cssChild = __dm_getAttr(o, 'csschild', '');
	this.cssHover = __dm_getAttr(o, 'csshover', '');
	this.cssSel = __dm_getAttr(o, 'csssel', '');
	this.cssIcon = __dm_getAttr(o, 'cssicon', '');

	this.sysImgPath = __dm_getAttr(o, 'sysimgpath', '');
	//this.imageList = __dm_getAttr(o, 'imagelist', '').split(',');
	this.workImg = 'dnnanim.gif';
		
	this.target = __dm_getAttr(o, 'target', '');	
	this.defaultJS = __dm_getAttr(o, 'js', '');	
	
	this.postBack = __dm_getAttr(o, 'postback', '');
	this.callBack = __dm_getAttr(o, 'callback', '');
	this.callBackStatFunc = __dm_getAttr(o, 'callbackSF', '');
	//if (this.callBackStatFunc != null)
	//	this.callBackStatFunc = eval(this.callBackStatFunc);
		
	this.rootNode=null;
	this.selNode=null;  
	this.selIndex=-1;
	//this.delay = new Array();
	this.moutDelay = __dm_getAttr(o, 'moutdelay', '500');

	this.anim = __dm_getAttr(o, 'anim', '');	//expand
	this.inAnimObj = null;
	this.inAnimType = null;
	this.prevText = '';	
	dnn.dom.addSafeHandler(o, 'onkeyup', this, 'keyUp');
	
}

dnn_control.prototype.DNNTextSuggest.prototype.setText = function (s) 
{
	this.container.value = s;
	this.prevText = s;
}

dnn_control.prototype.DNNTextSuggest.prototype.getText = function () 
{
	return this.container.value;
}

//--- Event Handlers ---//
dnn_control.prototype.DNNTextSuggest.prototype.keyUp = function (e) 
{
	var KEY_UP_ARROW = 38;
	var KEY_DOWN_ARROW = 40;
	var KEY_RETURN = 13;
	var KEY_ESCAPE = 27;
	
	dnn.cancelDelay(this.ns + 'kd');
	if (this.prevText != this.container.value)
		dnn.doDelay(this.ns + 'kd', this.moutDelay, dnn.dom.getObjMethRef(this, 'doLookup'));
	this.prevText = this.container.value;
	if (e.keyCode == KEY_UP_ARROW)
		this.setNodeIndex(this.selIndex - 1);
	else if(e.keyCode == KEY_DOWN_ARROW)
		this.setNodeIndex(this.selIndex + 1);
	else if(e.keyCode == KEY_RETURN)
	{
		if (this.selIndex > -1)
			this.selectNode(new dnn.controls.DNNTextSuggestNode(this.rootNode.childNodes(this.selIndex)));
	}
	else if(e.keyCode == KEY_ESCAPE)
		this.clear();
}

dnn_control.prototype.DNNTextSuggest.prototype.nodeMOver = function(evt, element)
{
	var oNode = this.DOM.findNode('n', 'id', element.nodeid);
	if (oNode != null)
	{
		var oTSNode = new dnn.controls.DNNTextSuggestNode(oNode);
		oTSNode.hover = true;
		this.assignCss(oTSNode);
	}
}

dnn_control.prototype.DNNTextSuggest.prototype.nodeMOut = function(evt, element)
{
	var oNode = this.DOM.findNode('n', 'id', element.nodeid);
	if (oNode != null)
	{
		var oTSNode = new dnn.controls.DNNTextSuggestNode(oNode);
		oTSNode.hover = false;
		this.assignCss(oTSNode);
	}
}

dnn_control.prototype.DNNTextSuggest.prototype.nodeClick = function(evt, element)
{
	var oNode = this.DOM.findNode('n', 'id', element.nodeid);
	if (oNode != null)
	{
		var oTSNode = new dnn.controls.DNNTextSuggestNode(oNode);
		this.selectNode(oTSNode);
	}
}

//
dnn_control.prototype.DNNTextSuggest.prototype.highlightNode = function(iIndex, bHighlight)
{
	if (iIndex > -1)
	{
		var oTSNode = new dnn.controls.DNNTextSuggestNode(this.rootNode.childNodes(this.selIndex));
		oTSNode.hover = bHighlight;
		this.assignCss(oTSNode);				
	}
}

dnn_control.prototype.DNNTextSuggest.prototype.setNodeIndex = function(iIndex)
{
	if (iIndex > -1 && iIndex < this.rootNode.childNodeCount())
	{
		this.highlightNode(this.selIndex, false);
		this.selIndex = iIndex;
		this.highlightNode(this.selIndex, true);
	}
}


dnn_control.prototype.DNNTextSuggest.prototype.selectNode = function (oTSNode) 
{		
	if (this.selNode != null)
	{
		//dnn.dom.getById(__dm_getControlID(this.ns, this.selNode.id, 't')).className = this.nodeCss;
		this.selNode.selected = null;
		this.assignCss(this.selNode);
	}		
	
	if (oTSNode.selected)
	{
		oTSNode.selected = null;
		this.assignCss(oTSNode);
	}
	else
	{
		oTSNode.selected = true;
		this.assignCss(oTSNode);
	}
	
	this.selNode = oTSNode;

	if (oTSNode.selected)
	{
		this.setText(oTSNode.text);
		var sJS = '';
		if (this.defaultJS.length > 0)
			sJS = this.defaultJS;
		if (oTSNode.js.length > 0)
			sJS = oTSNode.js;
		
		if (sJS.length > 0)
		{
			if (eval(sJS) == false)
				return;	//don't do postback if returns false
		}
		
		if (oTSNode.clickAction == null || oTSNode.clickAction == dnn.controls.action.postback)
			eval(this.postBack.replace('[TEXT]', this.getText()));
		else if (oTSNode.clickAction == dnn.controls.action.nav)
			dnn.dom.navigate(oTSNode.url, oTSNode.target.length > 0 ? oTSNode.target : this.target);
	}
	return true;		
}



dnn_control.prototype.DNNTextSuggest.prototype.positionMenu = function ()
{
	var oPDims = new dnn.dom.positioning.dims(this.container);
	this.resultCtr.style.left = oPDims.l - dnn.dom.positioning.bodyScrollLeft();			
	this.resultCtr.style.top = oPDims.t + oPDims.h;
}

dnn_control.prototype.DNNTextSuggest.prototype.clearResults = function () 
{
	if (this.resultCtr != null)
		this.resultCtr.innerHTML = '';
}

dnn_control.prototype.DNNTextSuggest.prototype.clear = function () 
{
	this.clearResults();
	this.setText('');
	this.selIndex = -1;
	this.selNode = null;
}

dnn_control.prototype.DNNTextSuggest.prototype.doLookup = function () 
{
	if (this.getText().length > 0)
		eval(this.callBack.replace('[TEXT]', this.getText()));
	else
		this.clearResults();
}


dnn_control.prototype.DNNTextSuggest.prototype.renderResults = function (sXML) 
{
	this.DOM = new dnn.xml.createDocument();
	this.DOM.loadXml(sXML);
	var oNode;
	for (var i=0; i<this.DOM.childNodeCount(); i++)
	{
		if (this.DOM.childNodes(i).nodeType != 7)
		{
			oNode = this.DOM.childNodes(i);
			break;
		}
	}

	if (oNode != null)
	{
		this.rootNode = oNode;
		if (this.resultCtr == null)
		{
			this.resultCtr = document.createElement('DIV');
			this.container.parentNode.appendChild(this.resultCtr);

			if (dnn.dom.browser.isType(dnn.dom.browser.InternetExplorer))	//if only input control on form is this one IE causes postback on KEY_RETURN whether we want one or not
			{
				var oDummy = document.createElement('INPUT');
				oDummy.type = 'text';
				oDummy.style.display = 'none';
				this.container.parentNode.appendChild(oDummy);
			}
						
			this.resultCtr.className = this.tscss;
			this.resultCtr.style.position = 'absolute';
			this.positionMenu();
		
		}
		this.clearResults();
		for (var i=0; i<oNode.childNodeCount(); i++)
			this.renderNode(oNode.childNodes(i), this.resultCtr);
	}
	
}

dnn_control.prototype.DNNTextSuggest.prototype.renderNode = function (oNode, oCont) 
{
	var oChildCont = oCont;
	var oTSNode;
		
	if (oNode != null)
	{
		//render node
		oTSNode = new dnn.controls.DNNTextSuggestNode(oNode);
		var oNewContainer;
		
		oNewContainer = document.createElement('DIV');	//container for Node
		__dm_assignControlID(oNewContainer, this.ns, oTSNode.id, 'ctr');
		oNewContainer.appendChild(this.renderText(oTSNode));	//render text

		if (oTSNode.enabled)
		{
			dnn.dom.addSafeHandler(oNewContainer, 'onclick', this, 'nodeClick');
			dnn.dom.addSafeHandler(oNewContainer, 'onmouseover', this, 'nodeMOver');
			dnn.dom.addSafeHandler(oNewContainer, 'onmouseout', this, 'nodeMOut');
		}

		if (oTSNode.toolTip.length > 0)
			oNewContainer.title = oTSNode.toolTip;
			
		oCont.appendChild(oNewContainer);
		this.assignCss(oTSNode);
	}
}

dnn_control.prototype.DNNTextSuggest.prototype.renderText = function (oTSNode) 
{
	var oSpan = document.createElement('SPAN');
	__dm_assignControlID(oSpan, this.ns, oTSNode.id, 't');
	oSpan.innerHTML = oTSNode.text;	
	oSpan.style.cursor = 'pointer';
	
	return oSpan;
}

dnn_control.prototype.DNNTextSuggest.prototype.assignCss = function (oTSNode)
{
	var oCtr = dnn.dom.getById(__dm_getControlID(this.ns, oTSNode.id, 'ctr'));//, this.container);
	var sNodeCss = this.css;

	if (oTSNode.css.length > 0)
		sNodeCss = oTSNode.css;

	//oTSNode.hoverCss;

	if (oTSNode.hover)
		sNodeCss += ' ' + (oTSNode.cssHover.length > 0 ? oTSNode.cssHover : this.cssHover);
	if (oTSNode.selected)
		sNodeCss += ' ' + (oTSNode.cssSel.length > 0 ? oTSNode.cssSel : this.cssSel);
	
	oCtr.className = sNodeCss;
}


dnn_control.prototype.DNNTextSuggest.prototype.callBackStatus = function (result, ctx) 
{
	var oText = ctx;
	
	if (oText.callBackStatFunc != null && oText.callBackStatFunc.length > 0)
	{
		var oPointerFunc = eval(oText.callBackStatFunc);
		oPointerFunc(result, ctx);	
	}
	
}

dnn_control.prototype.DNNTextSuggest.prototype.callBackSuccess = function (result, ctx) 
{
	var oText = ctx;
	if (oText.callBackStatFunc != null && oText.callBackStatFunc.length > 0)
	{
		var oPointerFunc = eval(oText.callBackStatFunc);
		oPointerFunc(result, ctx);	
	}
	oText.renderResults(result);

}

dnn_control.prototype.DNNTextSuggest.prototype.callBackFail = function (result, ctx) 
{
	alert(result);
}


dnn_control.prototype.DNNTextSuggestNode = function (oNode)
{
	this.node = oNode; 

	//base attributes 
	this.id = oNode.getAttribute('id', '');
	this.key = oNode.getAttribute('key', '');
	this.text = oNode.getAttribute('txt', '');
	this.url = oNode.getAttribute('url', '');
	this.js = oNode.getAttribute('js', '');
	this.target = oNode.getAttribute('tar', '');
	this.toolTip = oNode.getAttribute('tTip', '');
	this.enabled = oNode.getAttribute('enabled', '1') != '0';
	this.css = oNode.getAttribute('css', '');
	this.cssSel = oNode.getAttribute('cssSel', '');
	this.cssHover = oNode.getAttribute('cssHover', '');
	this.cssIcon = oNode.getAttribute('cssIcon', '');
	this.hasNodes = oNode.childNodeCount() > 0;	

	//menu specific attributes
	this.hover = false;
	this.selected = oNode.getAttribute('selected', '0') == '1' ? true : null;
	this.clickAction = oNode.getAttribute('ca', dnn.controls.action.none);
}

dnn_control.prototype.DNNTextSuggestNode.prototype.childNodeCount = function ()
{
	return this.node.childNodes.length;
}

dnn_control.prototype.DNNTextSuggestNode.prototype.childNodes = function (iIndex)
{
	if (this.node.childNodes[iIndex] != null)
		return new dnn.controls.DNNTextSuggestNode(this.node.childNodes[iIndex]);
}


function __dm_assignControlID(oCtl, sNS, sID, sPrefix)
{
	oCtl.ns = sNS;
	oCtl.nodeid = sID;
	oCtl.id = __dm_getControlID(oCtl.ns, oCtl.nodeid, sPrefix);
}

function __dm_getControlID(sNS, sID, sPrefix)
{
	if (dnn.controls.length == 1)
		return sPrefix + sID;	//inclusion of ns causes issue with old __dm_DNNTextSuggestNode code, so if only one menun then don't use as workaround
	else
		return sNS + sPrefix + sID;	
}

function __dm_getAttr(oNode, sAttr, sDef)
{
	var sVal = oNode.getAttribute(sAttr);
	if (sVal == null || sVal == '')
		return sDef;
	else
		return sVal;
}

if (typeof(dnn_controls) != 'undefined')
{
	dnn_controls.prototype = new dnn_control;
	dnn_controls.prototype.constructor = dnn_control;
	
	dnn.controls = new dnn_controls();

}
