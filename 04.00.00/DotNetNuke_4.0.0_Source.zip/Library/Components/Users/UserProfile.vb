'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Namespace DotNetNuke.Entities.Users

    Public Class UserProfile

        ' Constants for basic user profile properties.
        Private Const cFirstName As String = "FirstName"
        Private Const cLastName As String = "LastName"
        Private Const cStreet As String = "Street"
        Private Const cCity As String = "City"
        Private Const cRegion As String = "Region"
        Private Const cPostalCode As String = "PostalCode"
        Private Const cCountry As String = "Country"
        Private Const cUnit As String = "Unit"
        Private Const cTelephone As String = "Telephone"
        Private Const cCell As String = "Cell"
        Private Const cFax As String = "Fax"
        Private Const cWebsite As String = "Website"
        Private Const cIM As String = "IM"
        Private Const cTimeZone As String = "TimeZone"
        Private Const cPreferredLocale As String = "PreferredLocale"
        Private _ObjectHydrated As Boolean

        ' hashtable to store all profile properties.
        Private _profileProperties As System.Collections.Hashtable

        Public Sub New()
        End Sub


        Public Property FirstName() As String
            Get
                If _profileProperties.ContainsKey(cFirstName) = False OrElse _profileProperties(cFirstName) Is Nothing Then Return Null.NullString

                Return _profileProperties(cFirstName).ToString()
            End Get
            Set(ByVal Value As String)
                SetProfileProperty(cFirstName, Value)
                If Not ObjectHydrated Then
                    ObjectHydrated = True
                End If
            End Set
        End Property
        Public Property LastName() As String
            Get
                If _profileProperties.ContainsKey(cLastName) = False OrElse _profileProperties(cLastName) Is Nothing Then Return Null.NullString

                Return _profileProperties(cLastName).ToString()
            End Get
            Set(ByVal Value As String)
                SetProfileProperty(cLastName, Value)
                If Not ObjectHydrated Then
                    ObjectHydrated = True
                End If
            End Set
        End Property
        Public ReadOnly Property FullName() As String
            Get
                Return FirstName & " " & LastName
            End Get
        End Property
        Public Property Street() As String
            Get
                If _profileProperties.ContainsKey(cStreet) = False OrElse _profileProperties(cStreet) Is Nothing Then Return Null.NullString

                Return _profileProperties(cStreet).ToString()
            End Get
            Set(ByVal Value As String)
                SetProfileProperty(cStreet, Value)
                If Not ObjectHydrated Then
                    ObjectHydrated = True
                End If
            End Set
        End Property
        Public Property City() As String
            Get
                If _profileProperties.ContainsKey(cCity) = False OrElse _profileProperties(cCity) Is Nothing Then Return Null.NullString

                Return _profileProperties(cCity).ToString()
            End Get
            Set(ByVal Value As String)
                SetProfileProperty(cCity, Value)
                If Not ObjectHydrated Then
                    ObjectHydrated = True
                End If
            End Set
        End Property
        Public Property Region() As String
            Get
                If _profileProperties.ContainsKey(cRegion) = False OrElse _profileProperties(cRegion) Is Nothing Then Return Null.NullString

                Return _profileProperties(cRegion).ToString()
            End Get
            Set(ByVal Value As String)
                SetProfileProperty(cRegion, Value)
                If Not ObjectHydrated Then
                    ObjectHydrated = True
                End If
            End Set
        End Property
        Public Property PostalCode() As String
            Get
                If _profileProperties.ContainsKey(cPostalCode) = False OrElse _profileProperties(cPostalCode) Is Nothing Then Return Null.NullString

                Return _profileProperties(cPostalCode).ToString()
            End Get
            Set(ByVal Value As String)
                SetProfileProperty(cPostalCode, Value)
                If Not ObjectHydrated Then
                    ObjectHydrated = True
                End If
            End Set
        End Property
        Public Property Country() As String
            Get
                If _profileProperties.ContainsKey(cCountry) = False OrElse _profileProperties(cCountry) Is Nothing Then Return Null.NullString

                Return _profileProperties(cCountry).ToString()
            End Get
            Set(ByVal Value As String)
                SetProfileProperty(cCountry, Value)
                If Not ObjectHydrated Then
                    ObjectHydrated = True
                End If
            End Set
        End Property
        Public Property Unit() As String
            Get
                If _profileProperties.ContainsKey(cUnit) = False OrElse _profileProperties(cUnit) Is Nothing Then Return Null.NullString

                Return _profileProperties(cUnit).ToString()
            End Get
            Set(ByVal Value As String)
                SetProfileProperty(cUnit, Value)
                If Not ObjectHydrated Then
                    ObjectHydrated = True
                End If
            End Set
        End Property
        Public Property Telephone() As String
            Get
                If _profileProperties.ContainsKey(cTelephone) = False OrElse _profileProperties(cTelephone) Is Nothing Then Return Null.NullString

                Return _profileProperties(cTelephone).ToString()
            End Get
            Set(ByVal Value As String)
                SetProfileProperty(cTelephone, Value)
                If Not ObjectHydrated Then
                    ObjectHydrated = True
                End If
            End Set
        End Property
        Public Property Cell() As String
            Get
                If _profileProperties.ContainsKey(cCell) = False OrElse _profileProperties(cCell) Is Nothing Then Return Null.NullString

                Return _profileProperties(cCell).ToString()
            End Get
            Set(ByVal Value As String)
                SetProfileProperty(cCell, Value)
                If Not ObjectHydrated Then
                    ObjectHydrated = True
                End If
            End Set
        End Property
        Public Property Fax() As String
            Get
                If _profileProperties.ContainsKey(cFax) = False OrElse _profileProperties(cFax) Is Nothing Then Return Null.NullString

                Return _profileProperties(cFax).ToString()
            End Get
            Set(ByVal Value As String)
                SetProfileProperty(cFax, Value)
                If Not ObjectHydrated Then
                    ObjectHydrated = True
                End If
            End Set
        End Property
        Public Property IM() As String
            Get
                If _profileProperties.ContainsKey(cIM) = False OrElse _profileProperties(cIM) Is Nothing Then Return Null.NullString

                Return _profileProperties(cIM).ToString()
            End Get
            Set(ByVal Value As String)
                SetProfileProperty(cIM, Value)
                If Not ObjectHydrated Then
                    ObjectHydrated = True
                End If
            End Set
        End Property
        Public Property Website() As String
            Get
                If _profileProperties.ContainsKey(cWebsite) = False OrElse _profileProperties(cWebsite) Is Nothing Then Return Null.NullString

                Return _profileProperties(cWebsite).ToString()
            End Get
            Set(ByVal Value As String)
                SetProfileProperty(cWebsite, Value)
                If Not ObjectHydrated Then
                    ObjectHydrated = True
                End If
            End Set
        End Property
        Public Property TimeZone() As Integer
            Get
                If _profileProperties.ContainsKey(cTimeZone) = False OrElse _profileProperties(cTimeZone) Is Nothing Then Return Null.NullInteger

                Return CType(_profileProperties(cTimeZone), Integer)
            End Get
            Set(ByVal Value As Integer)
                SetProfileProperty(cTimeZone, Value)
                If Not ObjectHydrated Then
                    ObjectHydrated = True
                End If
            End Set
        End Property
        Public Property PreferredLocale() As String
            Get
                If _profileProperties.ContainsKey(cPreferredLocale) = False OrElse _profileProperties(cPreferredLocale) Is Nothing Then Return Null.NullString

                Return _profileProperties(cPreferredLocale).ToString()
            End Get
            Set(ByVal Value As String)
                SetProfileProperty(cPreferredLocale, Value)
                If Not ObjectHydrated Then
                    ObjectHydrated = True
                End If
            End Set
        End Property
        Public Property ProfileProperties() As System.Collections.Hashtable
            Get
                If _profileProperties Is Nothing Then _profileProperties = New System.Collections.Hashtable
                Return _profileProperties
            End Get
            Set(ByVal Value As System.Collections.Hashtable)
                If _profileProperties Is Nothing Then _profileProperties = New System.Collections.Hashtable
                _profileProperties = Value
            End Set
        End Property
        Public Property ObjectHydrated() As Boolean
            Get
                Return _ObjectHydrated
            End Get
            Set(ByVal Value As Boolean)
                _ObjectHydrated = Value
            End Set
        End Property


        ' helper method to set values in profile propery
        Private Sub SetProfileProperty(ByVal propName As String, ByVal propValue As Object)
            If ProfileProperties.ContainsKey(propName) Then
                _profileProperties(propName) = propValue
            Else
                _profileProperties.Add(propName, propValue)
            End If
        End Sub
    End Class

End Namespace
