'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2006
' by DotNetNuke Corporation
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.IO
Imports System.Web
Imports DotNetNuke.Entities.Portals
Imports DotNetNuke.Common
Imports DotNetNuke.Common.Utilities
Imports DotNetNuke.Framework.Providers
Imports DotNetNuke.Modules.HTMLEditorProvider
Imports DotNetNuke.UI.Utilities
Imports FreeTextBoxControls
Imports FreeTextBoxControls.Support

Namespace DotNetNuke.HtmlEditor

    ''' -----------------------------------------------------------------------------
    ''' Class:  TextEditor
    ''' Project: Provider.FtbHtmlEditorProvider
    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' Ftb3HtmlEditorProvider implements an Html Editor Provider for FTB (FreeTextBox) 3
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[cnurse]	12/13/2004	Documented
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Public Class Ftb3HtmlEditorProvider
        Inherits DotNetNuke.Modules.HTMLEditorProvider.HtmlEditorProvider

#Region "Private Members"

        Private WithEvents cntlFtb As New FreeTextBoxControls.FreeTextBox

        Private Const ProviderType As String = "htmlEditor"

        Private _AdditionalToolbars As New ArrayList
        Private _ControlID As String
        Private _enableProFeatures As Boolean
        Private _providerConfiguration As ProviderConfiguration = ProviderConfiguration.GetProviderConfiguration(ProviderType)
        Private _providerPath As String
        Private _RootImageDirectory As String
        Private _spellCheck As String
        Private _styles As SortedList
        Private _toolbarStyle As String

#End Region

#Region "Constructors"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Creates the Provider
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	11/30/2005	documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub New()

            Dim _portalSettings As PortalSettings = DotNetNuke.Entities.Portals.PortalController.GetCurrentPortalSettings

            ' Read the configuration specific information for this provider
            Dim objProvider As Provider = CType(_providerConfiguration.Providers(_providerConfiguration.DefaultProvider), Provider)

            _providerPath = objProvider.Attributes("providerPath")
            _spellCheck = objProvider.Attributes("spellCheck")
            _enableProFeatures = Boolean.Parse(objProvider.Attributes("enableProFeatures"))
            _toolbarStyle = objProvider.Attributes("toolbarStyle")

        End Sub

#End Region

#Region "Overriden Base Class Properties"

        Public Overrides Property AdditionalToolbars() As ArrayList
            Get
                Return _AdditionalToolbars
            End Get
            Set(ByVal Value As ArrayList)
                _AdditionalToolbars = Value
            End Set
        End Property

        Public Overrides Property ControlID() As String
            Get
                Return _ControlID
            End Get
            Set(ByVal Value As String)
                _ControlID = Value
            End Set
        End Property

        Public Overrides Property Height() As System.Web.UI.WebControls.Unit
            Get
                Return cntlFtb.Height
            End Get
            Set(ByVal Value As System.Web.UI.WebControls.Unit)
                cntlFtb.Height = Value
            End Set
        End Property

        Public Overrides ReadOnly Property HtmlEditorControl() As System.Web.UI.Control
            Get
                Return cntlFtb
            End Get
        End Property

        Public Overrides Property RootImageDirectory() As String
            Get
                If _RootImageDirectory = "" Then
                    Dim _portalSettings As PortalSettings = DotNetNuke.Entities.Portals.PortalController.GetCurrentPortalSettings

                    'Remove the Application Path from the Home Directory
                    If Common.Globals.ApplicationPath <> "" Then
                        'Remove the Application Path from the Home Directory
                        Return _portalSettings.HomeDirectory.Substring(Common.Globals.ApplicationPath.Length)
                    Else
                        Return _portalSettings.HomeDirectory
                    End If
                Else
                    Return _RootImageDirectory
                End If
            End Get
            Set(ByVal Value As String)
                _RootImageDirectory = Value
            End Set
        End Property

        Public Overrides Property Text() As String
            Get
                Return cntlFtb.Text
            End Get
            Set(ByVal Value As String)
                cntlFtb.Text = Value
            End Set
        End Property

        Public Overrides Property Width() As System.Web.UI.WebControls.Unit
            Get
                Return cntlFtb.Width
            End Get
            Set(ByVal Value As System.Web.UI.WebControls.Unit)
                cntlFtb.Width = Value
            End Set
        End Property

#End Region

#Region "Public Properties "

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Returns the provider path
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	11/30/2005	documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public ReadOnly Property ProviderPath() As String
            Get
                Return _providerPath
            End Get
        End Property

#End Region

#Region "Private Helper Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Creates the Color ToolBar
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <returns>A FreeTextBox ToolBar</returns>
        ''' <history>
        ''' 	[cnurse]	12/13/2004	Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function AddColorToolBar() As FreeTextBoxControls.Toolbar

            Dim tb As New FreeTextBoxControls.Toolbar
            tb.Items.Add(New FontForeColorsMenu)
            tb.Items.Add(New FontForeColorPicker)
            tb.Items.Add(New FontBackColorsMenu)
            tb.Items.Add(New FontBackColorPicker)

            Return tb
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Creates the Edit ToolBar
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <returns>A FreeTextBox ToolBar</returns>
        ''' <history>
        ''' 	[cnurse]	12/13/2004	Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function AddEditToolBar() As FreeTextBoxControls.Toolbar

            Dim tb As New FreeTextBoxControls.Toolbar
            tb.Items.Add(New Cut)
            tb.Items.Add(New Copy)
            tb.Items.Add(New Paste)
            tb.Items.Add(New Delete)
            tb.Items.Add(New ToolbarSeparator)
            tb.Items.Add(New Undo)
            tb.Items.Add(New Redo)

            Return tb

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Creates the Form ToolBar in FreeTextBox 
        ''' (Pro edition only)
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <returns>A FreeTextBox ToolBar</returns>
        ''' <history>
        ''' 	[JWhite]	2/27/2005	Added/Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function AddFormToolBar() As FreeTextBoxControls.Toolbar

            Dim tb As New FreeTextBoxControls.Toolbar
            tb.Items.Add(New InsertForm) 'pro only
            tb.Items.Add(New InsertTextBox) 'pro only
            tb.Items.Add(New InsertTextArea) 'pro only
            tb.Items.Add(New InsertRadioButton) 'pro only
            tb.Items.Add(New InsertCheckBox) 'pro only
            tb.Items.Add(New InsertDropDownList) 'pro only
            tb.Items.Add(New InsertButton) 'pro only

            Return tb

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Creates the Format ToolBar
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <returns>A FreeTextBox ToolBar</returns>
        ''' <history>
        ''' 	[cnurse]	12/13/2004	Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function AddFormatToolBar() As FreeTextBoxControls.Toolbar

            Dim tb As New FreeTextBoxControls.Toolbar
            tb.Items.Add(New JustifyLeft)
            tb.Items.Add(New JustifyCenter)
            tb.Items.Add(New JustifyRight)
            tb.Items.Add(New JustifyFull)
            tb.Items.Add(New ToolbarSeparator)
            tb.Items.Add(New BulletedList)
            tb.Items.Add(New NumberedList)
            tb.Items.Add(New Indent)
            tb.Items.Add(New Outdent)

            Return tb

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Creates the Insert ToolBar
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <returns>A FreeTextBox ToolBar</returns>
        ''' <history>
        ''' 	[cnurse]	12/13/2004	Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function AddInsertToolBar() As FreeTextBoxControls.Toolbar

            Dim tb As New FreeTextBoxControls.Toolbar
            tb.Items.Add(New SymbolsMenu)
            tb.Items.Add(New InsertRule)
            tb.Items.Add(New InsertDate)
            tb.Items.Add(New InsertTime)
            tb.Items.Add(New ToolbarSeparator)
            tb.Items.Add(New CreateLink)
            tb.Items.Add(New Unlink)
            tb.Items.Add(InsertSmiley)
            tb.Items.Add(New InsertImageFromGallery)

            Return tb

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Creates the Insert ToolBar
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <returns>A FreeTextBox ToolBar</returns>
        ''' <history>
        ''' 	[cnurse]	12/13/2004	Documented
        ''' 	[JWhite]	2/25/2005	Added SpellCheck
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function AddSpecialToolBar() As FreeTextBoxControls.Toolbar

            Dim tb As New FreeTextBoxControls.Toolbar
            tb.Items.Add(New Preview)
            tb.Items.Add(New SelectAll)
            Select Case _spellCheck
                Case "NetSpell"
                    tb.Items.Add(New NetSpell) 'requires NetSpell library
                Case "IeSpellCheck"
                    tb.Items.Add(New IeSpellCheck)
            End Select
            If _enableProFeatures Then
                tb.Items.Add(New WordClean) 'pro only
            Else
                tb.Items.Add(WordCleanDnn()) ' dnn version for non-pro users
            End If

            Return tb

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Creates the Styles Menu
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <returns>A FreeTextBox StylesMenu</returns>
        ''' <history>
        ''' 	[cnurse]	12/13/2004	Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function AddStylesMenu() As FreeTextBoxControls.StylesMenu

            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)
            Dim styleMenu As New StylesMenu
            Dim i As Integer

            _styles = New SortedList

            'Parse default css
            ParseStyleSheet(Common.Globals.HostPath & "default.css")

            'Parse skin stylesheet(s)
            ParseStyleSheet(PortalSettings.ActiveTab.SkinPath & "skin.css")
            ParseStyleSheet(Replace(PortalSettings.ActiveTab.SkinSrc, ".ascx", ".css"))

            'Parse portal stylesheet
            ParseStyleSheet(PortalSettings.HomeDirectory & "portal.css")

            For i = 0 To _styles.Count - 1
                Dim myListItem As New FreeTextBoxControls.ToolbarListItem
                myListItem.Text = CType(_styles.GetByIndex(i), String)
                myListItem.Value = CType(_styles.GetKey(i), String)
                styleMenu.Items.Add(myListItem)
            Next

            Return styleMenu

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Creates the Style ToolBar
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <returns>A FreeTextBox ToolBar</returns>
        ''' <history>
        ''' 	[cnurse]	12/13/2004	Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function AddStyleToolBar() As FreeTextBoxControls.Toolbar

            Dim tb As New FreeTextBoxControls.Toolbar
            tb.Items.Add(AddStylesMenu)
            tb.Items.Add(New ParagraphMenu)
            tb.Items.Add(New FontFacesMenu)
            tb.Items.Add(New FontSizesMenu)

            Return tb

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Creates the Table ToolBar in FreeTextBox 
        ''' (Pro edition only)
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <returns>A FreeTextBox ToolBar</returns>
        ''' <history>
        ''' 	[JWhite]	2/25/2005	Added/Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function AddTableToolBar() As FreeTextBoxControls.Toolbar

            Dim tb As New FreeTextBoxControls.Toolbar
            tb.Items.Add(New InsertTable)
            tb.Items.Add(New EditTable)
            If _enableProFeatures Then
                tb.Items.Add(New InsertTableColumnAfter) 'pro only
                tb.Items.Add(New InsertTableColumnBefore) 'pro only
                tb.Items.Add(New InsertTableRowBefore) 'pro only
                tb.Items.Add(New InsertTableRowAfter) 'pro only
                tb.Items.Add(New DeleteTableColumn) 'pro only
                tb.Items.Add(New DeleteTableRow) 'pro only
            End If
            Return tb

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Creates the Text ToolBar
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <returns>A FreeTextBox ToolBar</returns>
        ''' <history>
        ''' 	[cnurse]	12/13/2004	Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function AddTextToolBar() As FreeTextBoxControls.Toolbar

            Dim tb As New FreeTextBoxControls.Toolbar
            tb.Items.Add(New Bold)
            tb.Items.Add(New Italic)
            tb.Items.Add(New Underline)
            tb.Items.Add(New StrikeThrough)
            tb.Items.Add(New SuperScript)
            tb.Items.Add(New SubScript)
            tb.Items.Add(New RemoveFormat)
            Return tb

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Provides an insert Smiley Popup
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	01/27/2006  created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function InsertSmiley() As ToolbarButton

            Dim dnnInsertSmiley As New ToolbarButton
            dnnInsertSmiley.Title = DotNetNuke.Services.Localization.Localization.GetString("InsertSmileyButton")
            dnnInsertSmiley.ButtonImage = "insertsmiley"
            dnnInsertSmiley.ScriptBlock = "this.ftb.SelectSmiley();"

            Return dnnInsertSmiley

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Parses the Stylesheet looking for styles
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="strCssFile">Stylesheet to parse</param>
        ''' <history>
        ''' 	[cnurse]	12/13/2004	Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub ParseStyleSheet(ByVal strCssFile As String)

            If File.Exists(HttpContext.Current.Server.MapPath(strCssFile)) Then

                'Use the StyleSheetParser provided by the FreeTextBox control to obtain the styles
                ' this returns all styles including styles with a :hover, :link etc
                If Common.Globals.ApplicationPath <> "" Then
                    strCssFile = strCssFile.Replace(Common.Globals.ApplicationPath, "")
                End If
                Dim styleDefinitions As String() = StyleSheetParser.ParseStyleSheet(strCssFile)

                For Each styleDefinition As String In styleDefinitions
                    'First split single lines that contain multiple styles (separated by ",")
                    Dim styles As String() = styleDefinition.Split(","c)

                    For Each style As String In styles

                        'First strip any white space
                        style = HtmlUtils.StripWhiteSpace(style, False)

                        'Next strip any :active, :hover, :link, :visited modifiers
                        style = style.Replace(":active", "").Replace(":hover", "").Replace(":link", "").Replace(":visited", "")

                        'Next strip any leading "."
                        If style.StartsWith(".") Then
                            style = style.Substring(1)
                        End If

                        'Only add styles that can apply to any content (ie do not add A.CommandButton etc)
                        If style.IndexOf(".") = -1 Then
                            If Not _styles.ContainsKey(style.ToLower) Then
                                _styles.Add(style.ToLower, style)
                            End If
                        End If
                    Next
                Next

            End If
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Sets the Design Mode Css Property, to enable WYSIWYG behaviour for the editor
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	11/29/2005	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub SetDesignModeCss()
            'Note the javascript expects there to be one and only once Css StyleSheet
            ' eg "<link rel='stylesheet' href='" + this.designModeCss + "' type='text/css' />"

            'We typically have more than one stylesheet
            '  default.css
            '  skin.css
            '  portal.css

            Dim DesignModeCss As String = Common.Globals.HostPath & "default.css"

            'Add skin css
            DesignModeCss += "\' type=\'text/css\' /><link rel=\'stylesheet\' href=\'" + PortalSettings.ActiveTab.SkinPath & "skin.css"
            DesignModeCss += "\' type=\'text/css\' /><link rel=\'stylesheet\' href=\'" + Replace(PortalSettings.ActiveTab.SkinSrc, ".ascx", ".css")

            'Add portal css
            DesignModeCss += "\' type=\'text/css\' /><link rel=\'stylesheet\' href=\'" + PortalSettings.HomeDirectory & "portal.css"

            cntlFtb.DesignModeCss = DesignModeCss

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Provides an alternative Word Clean script if Pro Features aren't available
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	11/29/2005	Moved to a separate Method
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function WordCleanDnn() As ToolbarButton

            Dim dnnWordClean As New ToolbarButton
            dnnWordClean.Title = DotNetNuke.Services.Localization.Localization.GetString("WordCleanButton")
            dnnWordClean.ButtonImage = "wordclean"
            dnnWordClean.ScriptBlock = "this.ftb.WordClean();"

            Return dnnWordClean

        End Function

#End Region

#Region "Public Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Adds additional toolbar(s) to the FTB control
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	01/12/2005	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overrides Sub AddToolbar()

            Dim tb As New FreeTextBoxControls.Toolbar

            For Each tb In AdditionalToolbars
                cntlFtb.Toolbars.Add(tb)
            Next

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Initialises the control
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	12/13/2004	Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overrides Sub Initialize()

            'initialize the control
            cntlFtb = New FreeTextBoxControls.FreeTextBox
            cntlFtb.Language = System.Threading.Thread.CurrentThread.CurrentUICulture.Name
            cntlFtb.ButtonImagesLocation = ResourceLocation.ExternalFile
            cntlFtb.JavaScriptLocation = ResourceLocation.ExternalFile

            'Set Design Mode Css for WYSIWYG 
            SetDesignModeCss()

            cntlFtb.ToolbarImagesLocation = ResourceLocation.ExternalFile
            cntlFtb.ID = ControlID
            cntlFtb.AutoGenerateToolbarsFromString = False

            'Build the Standard ToolBar Collection
            cntlFtb.Toolbars.Clear()
            cntlFtb.Toolbars.Add(AddStyleToolBar)
            cntlFtb.Toolbars.Add(AddColorToolBar)

            Dim tb As Toolbar = AddTextToolBar()
            If tb.Items.Count > 0 Then
                cntlFtb.Toolbars.Add(AddTextToolBar)
            End If

            cntlFtb.Toolbars.Add(AddFormatToolBar)
            cntlFtb.Toolbars.Add(AddEditToolBar)
            cntlFtb.Toolbars.Add(AddInsertToolBar)
            cntlFtb.Toolbars.Add(AddTableToolBar)
            If _enableProFeatures Then cntlFtb.Toolbars.Add(AddFormToolBar)
            cntlFtb.Toolbars.Add(AddSpecialToolBar)

            cntlFtb.ImageGalleryUrl = DotNetNuke.Common.Globals.ResolveUrl("~/Providers/HtmlEditorProviders/Ftb3HtmlEditorProvider/ftb3/ftb.imagegallery.aspx?cif=~" & RootImageDirectory & "&rif=~" & RootImageDirectory & "&portalid=" & PortalSettings.PortalId)
            cntlFtb.SupportFolder = DotNetNuke.Common.Globals.ResolveUrl("~/Providers/HtmlEditorProviders/Ftb3HtmlEditorProvider/ftb3/")
            Select Case _toolbarStyle
                Case "OfficeMac"
                    cntlFtb.ToolbarStyleConfiguration = ToolbarStyleConfiguration.OfficeMac
                Case "Office2000"
                    cntlFtb.ToolbarStyleConfiguration = ToolbarStyleConfiguration.Office2000
                Case "OfficeXP"
                    cntlFtb.ToolbarStyleConfiguration = ToolbarStyleConfiguration.OfficeXP
                Case "Office2003"
                    cntlFtb.ToolbarStyleConfiguration = ToolbarStyleConfiguration.Office2003
                Case Else
                    cntlFtb.ToolbarStyleConfiguration = ToolbarStyleConfiguration.NotSet
            End Select

        End Sub

#End Region

#Region "Event Handlers"


        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' cntlFtb_Load runs when the FTB control is loaded
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	12/02/2005	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Protected Sub cntlFtb_PreRender(ByVal sender As Object, ByVal e As EventArgs) Handles cntlFtb.PreRender

            Dim jsFileName As String = "FTB-DotNetNuke.js"
            Dim jsPath As String = cntlFtb.SupportFolder

            'Register the FTB-DotNetNuke.js script file that implements the DNN enhancements
            If Not ClientAPI.IsClientScriptBlockRegistered(cntlFtb.Page, jsFileName) Then
                ClientAPI.RegisterClientScriptBlock(cntlFtb.Page, jsFileName, "<script src=""" & jsPath & jsFileName & """></script>")
            End If

        End Sub

#End Region

    End Class

End Namespace
