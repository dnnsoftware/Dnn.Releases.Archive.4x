'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2006
' by DotNetNuke Corporation
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.Collections.Specialized
Imports System.Web.Security

Imports DotNetNuke.Entities.Modules
Imports DotNetNuke.Entities.Modules.Actions
Imports DotNetNuke.Entities.Profile
Imports DotNetNuke.Modules.Admin.Users
Imports DotNetNuke.Security.Membership
Imports DotNetNuke.Services.Localization
Imports DotNetNuke.Services.Mail
Imports DotNetNuke.UI.Skins.Controls.ModuleMessage
Imports DotNetNuke.UI.WebControls

Namespace DotNetNuke.Modules.Admin.Security

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' The Signin UserModuleBase is used to provide a login for a registered user
    ''' portal.
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[cnurse]	9/24/2004	Updated to reflect design changes for Help, 508 support
    '''                       and localisation
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Partial Class Signin
        Inherits UserModuleBase

#Region "Private Members"

        Private ipAddress As String

#End Region

#Region "Protected Properties"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets the Redirect URL (after successful login)
        ''' </summary>
        ''' <history>
        ''' 	[cnurse]	04/18/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Protected ReadOnly Property RedirectURL() As String
            Get
                Dim _RedirectURL As String = ""

                If Not Request.QueryString("returnurl") Is Nothing Then
                    ' return to the url passed to signin
                    _RedirectURL = HttpUtility.UrlDecode(Request.QueryString("returnurl"))
                Else
                    Dim setting As Object = UserModuleBase.GetSetting(PortalId, "Redirect_AfterLogin")

                    If CType(setting, Integer) = Null.NullInteger Then
                        If PortalSettings.LoginTabId <> -1 And PortalSettings.HomeTabId <> -1 Then
                            ' redirect to portal home page specified
                            _RedirectURL = NavigateURL(PortalSettings.HomeTabId)
                        Else
                            ' redirect to current page 
                            _RedirectURL = NavigateURL(Me.TabId)
                        End If
                    Else ' redirect to after login page
                        _RedirectURL = NavigateURL(CType(setting, Integer))
                    End If
                End If

                Return _RedirectURL

            End Get
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets whether a profile is required on login
        ''' </summary>
        ''' <history>
        ''' 	[cnurse]	08/21/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Protected ReadOnly Property RequireValidProfile() As Boolean
            Get
                Dim setting As Object = UserModuleBase.GetSetting(PortalId, "Security_RequireValidProfileAtLogin")
                Return CType(setting, Boolean)
            End Get
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets whether the Captcha control is used to validate the login
        ''' </summary>
        ''' <history>
        ''' 	[cnurse]	03/17/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Protected ReadOnly Property UseCaptcha() As Boolean
            Get
                Dim setting As Object = GetSetting(PortalId, "Security_CaptchaLogin")
                Return CType(setting, Boolean)
            End Get
        End Property

#End Region

#Region "Public Properties"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets and sets the current Page No
        ''' </summary>
        ''' <history>
        ''' 	[cnurse]	03/09/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Property PageNo() As Integer
            Get
                Dim _PageNo As Integer = 0
                If Not ViewState("PageNo") Is Nothing Then
                    _PageNo = CInt(ViewState("PageNo"))
                End If
                Return _PageNo
            End Get
            Set(ByVal Value As Integer)
                ViewState("PageNo") = Value
            End Set
        End Property

#End Region

#Region "Private Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' AddLocalizedModuleMessage adds a localized module message
        ''' </summary>
        ''' <param name="message">The localized message</param>
        ''' <param name="type">The type of message</param>
        ''' <param name="display">A flag that determines whether the message should be displayed</param>
        ''' <history>
        ''' 	[cnurse]	03/14/2006
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub AddLocalizedModuleMessage(ByVal message As String, ByVal type As ModuleMessageType, ByVal display As Boolean)

            If display Then
                UI.Skins.Skin.AddModuleMessage(Me, message, type)
            End If

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' AddModuleMessage adds a module message
        ''' </summary>
        ''' <param name="message">The message</param>
        ''' <param name="type">The type of message</param>
        ''' <param name="display">A flag that determines whether the message should be displayed</param>
        ''' <history>
        ''' 	[cnurse]	03/14/2006
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub AddModuleMessage(ByVal message As String, ByVal type As ModuleMessageType, ByVal display As Boolean)

            AddLocalizedModuleMessage(Localization.GetString(message, LocalResourceFile), type, display)

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' ShowPanel controls what "panel" is to be displayed
        ''' </summary>
        ''' <history>
        ''' 	[cnurse]	03/21/2006
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub ShowPanel()

            Dim showLogin As Boolean = (PageNo = 0)
            Dim showPassword As Boolean = (PageNo = 1)
            Dim showProfile As Boolean = (PageNo = 2)

            pnlPassword.Visible = showPassword
            pnlProfile.Visible = showProfile
            pnlLogin.Visible = showLogin

            Select Case PageNo
                Case 0
                    If PortalSettings.UserRegistration = PortalRegistrationType.NoRegistration Then
                        tdRegister.Visible = False
                    End If
                    txtPassword.Attributes.Add("value", txtPassword.Text)
                    lblLogin.Text = Localization.GetSystemMessage(PortalSettings, "MESSAGE_LOGIN_INSTRUCTIONS")
                Case 1
                    ctlPassword.UserId = UserId
                    ctlPassword.DataBind()
                Case 2
                    ctlProfile.UserId = UserId
                    ctlProfile.DataBind()
            End Select

            trCaptcha1.Visible = UseCaptcha
            trCaptcha2.Visible = UseCaptcha

            If UseCaptcha Then
                ctlCaptcha.ErrorMessage = Localization.GetString("InvalidCaptcha", Me.LocalResourceFile)
                ctlCaptcha.Text = Localization.GetString("CaptchaText", Me.LocalResourceFile)
            End If

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' UserAuthorized runs when the user has been authorized by the data store
        ''' </summary>
        ''' <param name="objUser">The logged in User</param>
        ''' <history>
        ''' 	[cnurse]	03/15/2006
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub UserAuthorized(ByVal objUser As UserInfo, ByVal canProceed As Boolean)

            Dim updatePassword As Boolean = False
            Dim updateProfile As Boolean = False
            Dim strMessage As String

            UserId = objUser.UserID

            'Set the Page Culture(Language) based on the Users Preferred Locale
            If (Not objUser.Profile Is Nothing) AndAlso (Not objUser.Profile.PreferredLocale Is Nothing) Then
                Localization.SetLanguage(objUser.Profile.PreferredLocale)
            Else
                Localization.SetLanguage(PortalSettings.DefaultLanguage)
            End If

            'Check whether Password needs updating
            If PasswordConfig.PasswordExpiry > 0 Then
                Dim expiryDate As DateTime = objUser.Membership.LastPasswordChangeDate.AddDays(PasswordConfig.PasswordExpiry)
                If expiryDate < Today Then
                    'Password Expired
                    strMessage = String.Format(Localization.GetString("PasswordExpired", Me.LocalResourceFile), expiryDate.ToLongDateString)
                    AddLocalizedModuleMessage(strMessage, ModuleMessageType.YellowWarning, True)
                    updatePassword = True
                    pnlProceed.Visible = False
                End If
                If (Not updatePassword) And expiryDate < Today.AddDays(PasswordConfig.PasswordExpiryReminder) Then
                    'Password update reminder
                    strMessage = String.Format(Localization.GetString("PasswordExpiring", Me.LocalResourceFile), expiryDate.ToLongDateString)
                    AddLocalizedModuleMessage(strMessage, ModuleMessageType.YellowWarning, True)
                    updatePassword = Not canProceed
                    pnlProceed.Visible = True
                End If
            End If
            If (Not updatePassword) And objUser.Membership.UpdatePassword Then
                'Admin has forced password update
                AddModuleMessage("PasswordUpdate", ModuleMessageType.YellowWarning, True)
                updatePassword = True
            End If

            'Check whether Profile needs updating
            If (Not updatePassword And Me.RequireValidProfile) Then
                updateProfile = Not ProfileController.ValidateProfile(PortalId, objUser.Profile)
            End If

            If updatePassword Then
                PageNo = 1
            ElseIf updateProfile Then
                'Admin has forced profile update
                AddModuleMessage("ProfileUpdate", ModuleMessageType.YellowWarning, True)
                PageNo = 2
            Else
                'Complete Login
                UserController.UserLogin(PortalId, objUser, PortalSettings.PortalName, ipAddress, chkCookie.Checked)

                ' redirect browser
                Response.Redirect(RedirectURL, True)
            End If

            ShowPanel()

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' WindowsAuthorization checks whether the user credentials are valid
        ''' Windows credentials
        ''' </summary>
        ''' <param name="loginStatus">The log in status</param>
        ''' <history>
        ''' 	[cnurse]	03/15/2006
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function WindowsAuthorization(ByRef loginStatus As UserLoginStatus) As UserInfo

            Dim strMessage As String = Null.NullString

            Dim objUser As UserInfo = UserController.GetUserByName(PortalSettings.PortalId, txtUsername.Text, False)
            Dim objAuthentication As New DotNetNuke.Security.Authentication.AuthenticationController
            Dim objAuthUser As DotNetNuke.Security.Authentication.UserInfo = objAuthentication.ProcessFormAuthentication(txtUsername.Text, txtPassword.Text)
            Dim _userID As Integer = -1

            If (Not objAuthUser Is Nothing) AndAlso (objUser Is Nothing) Then
                ' Add this user into DNN database for better performance on next logon
                Dim createStatus As UserCreateStatus
                Dim objAuthUsers As New DotNetNuke.Security.Authentication.UserController
                createStatus = objAuthUsers.AddDNNUser(objAuthUser)
                _userID = objAuthUser.UserID

                ' Windows/DNN password validation should be same, check this status here
                strMessage = UserController.GetUserCreateStatus(createStatus)
            ElseIf (Not objAuthUser Is Nothing) AndAlso (Not objUser Is Nothing) Then
                ' User might has been imported by Admin or automatically added with random password
                ' update DNN password to match with authenticated password from AD                            
                If objUser.Membership.Password <> txtPassword.Text Then
                    UserController.ChangePassword(objUser, objUser.Membership.Password, txtPassword.Text)
                End If
                _userID = objUser.UserID
            End If

            If (_userID > 0) Then
                ' Authenticated with DNN
                objUser = UserController.ValidateUser(PortalId, txtUsername.Text, txtPassword.Text, "", PortalSettings.PortalName, ipAddress, loginStatus)
                If loginStatus <> UserLoginStatus.LOGIN_SUCCESS Then
                    strMessage = Localization.GetString("LoginFailed", Me.LocalResourceFile)
                End If
            Else
                objUser = Nothing
            End If

            AddLocalizedModuleMessage(strMessage, ModuleMessageType.RedError, strMessage <> "")

            Return objUser

        End Function

#End Region

#Region "Public Methods"

#End Region

#Region "Event Handlers"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Page_Init runs when the control is initialised
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/8/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'Set the Password Control Properties
            ctlPassword.ID = "Password"

            'Set the Profile Control Properties
            ctlProfile.ID = "Profile"
            
            'Override the redirected page title
            Dim myPage As DotNetNuke.Framework.CDefault
            myPage = CType(Me.Page, CDefault)
            myPage.Title = Localization.GetString("ControlTitle_login", Me.LocalResourceFile)

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Page_Load runs when the control is loaded
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/8/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            ' Verify if portal has a customized login page
            If Not Null.IsNull(PortalSettings.LoginTabId) And IsAdminControl() Then
                ' login page exists and trying to access this control directly with url param -> not allowed
                Response.Redirect(NavigateURL(PortalSettings.LoginTabId))
            End If

            DotNetNuke.UI.Utilities.ClientAPI.RegisterKeyCapture(Me.Parent, Me.cmdLogin, Asc(vbCr))

            If Not Request.UserHostAddress Is Nothing Then
                ipAddress = Request.UserHostAddress
            End If

            If Page.IsPostBack = False Then
                Try
                    If Not Request.QueryString("verificationcode") Is Nothing Then
                        If PortalSettings.UserRegistration = PortalRegistrationType.VerifiedRegistration Then
                            'Display Verification Rows 
                            rowVerification1.Visible = True
                            rowVerification2.Visible = True
                            txtVerification.Text = Request.QueryString("verificationcode")
                        End If
                    End If

                    PageNo = 0
                    If Not Request.QueryString("username") Is Nothing Then
                        txtUsername.Text = Request.QueryString("username")
                        SetFormFocus(txtPassword)
                    Else
                        SetFormFocus(txtUsername)
                    End If
                Catch
                    'control not there or error setting focus
                End Try
            End If

            ShowPanel()

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' cmdLogin_Click runs when the login button is clicked
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/24/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        '''     [cnurse]    12/11/2005  Updated to reflect abstraction of Membership
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdLogin_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdLogin.Click

            If (UseCaptcha And ctlCaptcha.IsValid) OrElse (Not UseCaptcha) Then
                'Try to validate user
                Dim loginStatus As UserLoginStatus
                Dim objUser As UserInfo = UserController.ValidateUser(PortalId, txtUsername.Text, txtPassword.Text, txtVerification.Text, PortalSettings.PortalName, ipAddress, loginStatus)

                If objUser Is Nothing Then  'Some kind of Login failure
                    If loginStatus = UserLoginStatus.LOGIN_FAILURE Then
                        Dim settings As Hashtable = Entities.Portals.PortalSettings.GetSiteSettings(PortalId)
                        If Convert.ToString(settings("WindowsAuthentication")) = "True" Then
                            'Try Windows Authorization (user may be authorized in Windows, but not in DNN yet)
                            objUser = WindowsAuthorization(loginStatus)
                        End If
                    End If
                End If

                If objUser Is Nothing Then
                    Select Case loginStatus
                        Case UserLoginStatus.LOGIN_USERNOTAPPROVED
                            'Check if its the first time logging in to a verified site
                            If PortalSettings.UserRegistration = PortalRegistrationType.VerifiedRegistration Then
                                If Not rowVerification1.Visible Then
                                    'Display Verification Rows so User can enter verification code
                                    rowVerification1.Visible = True
                                    rowVerification2.Visible = True
                                Else
                                    If txtVerification.Text <> "" Then
                                        AddModuleMessage("InvalidCode", ModuleMessageType.RedError, True)
                                    Else
                                        AddModuleMessage("EnterCode", ModuleMessageType.GreenSuccess, True)
                                    End If
                                End If
                            Else
                                AddModuleMessage("UserNotAuthorized", ModuleMessageType.RedError, True)
                            End If
                        Case UserLoginStatus.LOGIN_USERLOCKEDOUT
                            AddModuleMessage("UserLockedOut", ModuleMessageType.RedError, True)
                            ' notify administrator about account lockout ( possible hack attempt )
                            Dim Custom As New ArrayList
                            Custom.Add(txtUsername.Text)
                            Mail.SendMail(PortalSettings.Email, PortalSettings.Email, "", _
                                Localization.GetSystemMessage(PortalSettings, "EMAIL_USER_LOCKOUT_SUBJECT", Localization.GlobalResourceFile, Custom), _
                                Localization.GetSystemMessage(PortalSettings, "EMAIL_USER_LOCKOUT_BODY", Localization.GlobalResourceFile, Custom), _
                                "", "", "", "", "", "")
                        Case UserLoginStatus.LOGIN_FAILURE
                            AddModuleMessage("LoginFailed", ModuleMessageType.RedError, True)
                    End Select
                Else    'Login Success
                    UserAuthorized(objUser, False)
                End If
            End If

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' cmdPassword_Click runs when the Password Reminder button is clicked
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	03/21/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdPassword_Click(ByVal sender As System.Object, ByVal e As EventArgs) Handles cmdPassword.Click
            Response.Redirect(NavigateURL("SendPassword"), True)
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' cmdProceed_Click runs when the Proceed Anyway button is clicked
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	06/30/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdProceed_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdProceed.Click
            Dim _User As UserInfo = ctlPassword.User
            UserAuthorized(_User, True)
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' cmdRegister_Click runs when the register button is clicked
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/24/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        '''     [cnurse]    12/11/2005  Updated to reflect abstraction of Membership
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdRegister_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdRegister.Click

            If PortalSettings.UserRegistration <> PortalRegistrationType.NoRegistration Then
                Dim registerUrl As String
                If PortalSettings.UserTabId <> -1 Then
                    ' user defined tab
                    registerUrl = NavigateURL(PortalSettings.UserTabId)
                Else
                    ' admin tab
                    registerUrl = NavigateURL("Register")
                End If
                Response.Redirect(registerUrl, True)
            End If

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' PasswordUpdated runs when the password is updated
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	03/15/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub PasswordUpdated(ByVal sender As Object, ByVal e As Users.Password.PasswordUpdatedEventArgs) Handles ctlPassword.PasswordUpdated

            Dim status As PasswordUpdateStatus = e.UpdateStatus

            If status = PasswordUpdateStatus.Success Then
                AddModuleMessage("PasswordChanged", ModuleMessageType.GreenSuccess, True)

                'Authorize User
                Dim _User As UserInfo = ctlPassword.User
                _User.Membership.LastPasswordChangeDate = Now()
                _User.Membership.UpdatePassword = False
                UserAuthorized(_User, True)
            Else
                AddModuleMessage(status.ToString(), ModuleMessageType.RedError, True)
            End If

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' ProfileUpdated runs when the profile is updated
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	03/16/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub ProfileUpdated(ByVal sender As Object, ByVal e As System.EventArgs) Handles ctlProfile.ProfileUpdated

            'Authorize User
            UserAuthorized(ctlProfile.User, True)

        End Sub


#End Region

    End Class

End Namespace
