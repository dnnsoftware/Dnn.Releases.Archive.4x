'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.Configuration
Imports System.Data

Namespace DotNetNuke

    Public Class FAQsInfo
        ' local property declarations
        Private _ItemId As Integer
        Private _ModuleId As Integer
        Private _CreatedByUser As String
        Private _CreatedDate As Date
        Private _Question As String
        Private _Answer As String

        ' initialization
        Public Sub New()
        End Sub

        ' public properties
        Public Property ItemId() As Integer
            Get
                Return _ItemId
            End Get
            Set(ByVal Value As Integer)
                _ItemId = Value
            End Set
        End Property

        Public Property ModuleId() As Integer
            Get
                Return _ModuleId
            End Get
            Set(ByVal Value As Integer)
                _ModuleId = Value
            End Set
        End Property
        Public Property CreatedByUser() As String
            Get
                Return _CreatedByUser
            End Get
            Set(ByVal Value As String)
                _CreatedByUser = Value
            End Set
        End Property

        Public Property CreatedDate() As Date
            Get
                Return _CreatedDate
            End Get
            Set(ByVal Value As Date)
                _CreatedDate = Value
            End Set
        End Property
        Public Property Question() As String
            Get
                Return _Question
            End Get
            Set(ByVal Value As String)
                _Question = Value
            End Set
        End Property

        Public Property Answer() As String
            Get
                Return _Answer
            End Get
            Set(ByVal Value As String)
                _Answer = Value
            End Set
        End Property


    End Class
    Public Class FAQsController


        Public Function GetFAQs(ByVal ModuleId As Integer) As ArrayList

            Return CBO.FillCollection(DataProvider.Instance().GetFAQs(ModuleId), GetType(FAQsInfo))

        End Function


        Public Function GetFAQ(ByVal ItemId As Integer, ByVal ModuleId As Integer) As FAQsInfo

            Return CType(CBO.FillObject(DataProvider.Instance().GetFAQ(ItemId, ModuleId), GetType(FAQsInfo)), FAQsInfo)

        End Function


        Public Sub DeleteFAQ(ByVal ItemID As Integer)

            DataProvider.Instance().DeleteFAQ(ItemID)

        End Sub


        Public Sub AddFAQ(ByVal objFAq As FAQsInfo)

            DataProvider.Instance().AddFAQ(objFAq.ModuleId, objFAq.CreatedByUser, objFAq.Question, objFAq.Answer)

        End Sub


        Public Sub UpdateFAQ(ByVal objFAQ As FAQsInfo)

            DataProvider.Instance().UpdateFAQ(objFAQ.ItemId, objFAQ.CreatedByUser, objFAQ.Question, objFAQ.Answer)

        End Sub

    End Class

End Namespace
