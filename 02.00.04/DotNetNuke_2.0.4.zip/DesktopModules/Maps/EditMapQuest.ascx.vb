'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Namespace DotNetNuke

    Public Class EditMapQuest
        Inherits DotNetNuke.PortalModuleControl

        Protected WithEvents txtLocation As System.Web.UI.WebControls.TextBox
        Protected WithEvents Address1 As Address
        Protected WithEvents chkDisplayMap As System.Web.UI.WebControls.CheckBox

        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents valLocation As System.Web.UI.WebControls.RequiredFieldValidator
        Protected WithEvents cboZoom As System.Web.UI.WebControls.DropDownList
        Protected WithEvents cboSize As System.Web.UI.WebControls.DropDownList
        Protected WithEvents trZoom As System.Web.UI.HtmlControls.HtmlTableRow
        Protected WithEvents trSize As System.Web.UI.HtmlControls.HtmlTableRow
        Protected WithEvents CustomSize As System.Web.UI.WebControls.CheckBox
        Protected WithEvents ShowAddress As System.Web.UI.WebControls.CheckBox
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                If Page.IsPostBack = False Then

                    If ModuleId > 0 Then

                        Address1.ModuleId = ModuleId

                        ' Get settings from the database
                        Dim settings As Hashtable = PortalSettings.GetModuleSettings(ModuleId)

                        Address1.ShowTelephone = False
                        txtLocation.Text = CType(settings("location"), String)
                        Address1.Unit = CType(settings("unit"), String)
                        Address1.Street = CType(settings("street"), String)
                        Address1.City = CType(settings("city"), String)
                        Address1.Region = CType(settings("region"), String)
                        Address1.Country = CType(settings("country"), String)
                        Address1.Postal = CType(settings("postalcode"), String)
                        chkDisplayMap.Checked = CType(settings("displaymap"), Boolean)
                        CustomSize.Checked = CType(settings("customsize"), Boolean)
                        ShowAddress.Checked = CType(settings("showaddress"), Boolean)
                        If chkDisplayMap.Checked Then
                            If Not cboZoom.Items.FindByValue(CType(settings("defaultzoom"), String)) Is Nothing Then
                                cboZoom.ClearSelection()
                                cboZoom.Items.FindByValue(CType(settings("defaultzoom"), String)).Selected = True
                            End If
                            If Not cboSize.Items.FindByValue(CType(settings("defaultsize"), String)) Is Nothing Then
                                cboSize.ClearSelection()
                                cboSize.Items.FindByValue(CType(settings("defaultsize"), String)).Selected = True
                            End If
                        End If
                        ShowHideZoomSize()
                    End If
                End If
            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click
            Try

                ' Update settings in the database
                Dim objModules As New ModuleController

                objModules.UpdateModuleSetting(ModuleId, "location", txtLocation.Text)
                objModules.UpdateModuleSetting(ModuleId, "unit", Address1.Unit)
                objModules.UpdateModuleSetting(ModuleId, "street", Address1.Street)
                objModules.UpdateModuleSetting(ModuleId, "city", Address1.City)
                objModules.UpdateModuleSetting(ModuleId, "region", Address1.Region)
                objModules.UpdateModuleSetting(ModuleId, "country", Address1.Country)
                objModules.UpdateModuleSetting(ModuleId, "postalcode", Address1.Postal)
                objModules.UpdateModuleSetting(ModuleId, "displaymap", chkDisplayMap.Checked.ToString)
                objModules.UpdateModuleSetting(ModuleId, "customsize", CustomSize.Checked.ToString)
                objModules.UpdateModuleSetting(ModuleId, "showaddress", ShowAddress.Checked.ToString)
                If chkDisplayMap.Checked Then
                    objModules.UpdateModuleSetting(ModuleId, "defaultsize", cboSize.SelectedItem.Value)
                    objModules.UpdateModuleSetting(ModuleId, "defaultzoom", cboZoom.SelectedItem.Value)
                Else
                    objModules.UpdateModuleSetting(ModuleId, "defaultsize", "")
                    objModules.UpdateModuleSetting(ModuleId, "defaultzoom", "")
                End If

                'Clear Cache for this module
                DataCache.RemoveCache("MapQuestURL" & ModuleId.ToString)

                ' Redirect back to the portal home page
                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click
            Try
                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub chkDisplayMap_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkDisplayMap.CheckedChanged
            Try
                ShowHideZoomSize()
            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub ShowHideZoomSize()
            If chkDisplayMap.Checked Then
                trZoom.Visible = True
                trSize.Visible = True
            Else
                trZoom.Visible = False
                trSize.Visible = False
            End If
        End Sub
    End Class

End Namespace