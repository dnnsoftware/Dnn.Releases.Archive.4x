'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Namespace DotNetNuke

    Public Class ManageUserDefinedTable
        Inherits DotNetNuke.PortalModuleControl

        Protected WithEvents cmdAddField As System.Web.UI.WebControls.LinkButton
        Protected WithEvents grdFields As System.Web.UI.WebControls.DataGrid
        Protected WithEvents cboSortField As System.Web.UI.WebControls.DropDownList
        Protected WithEvents cboSortOrder As System.Web.UI.WebControls.DropDownList
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                ' Obtain PortalSettings from Current Context
                Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

                If Page.IsPostBack = False Then

                    BindData()

                    ' Store URL Referrer to return to portal
                    ViewState("UrlReferrer") = Replace(Convert.ToString(Request.UrlReferrer), "insertrow=true&", "")

                End If
            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click, cmdCancel.Click
            Try
                Response.Redirect(Convert.ToString(ViewState("UrlReferrer")), True)
            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Public Sub grdFields_CancelEdit(ByVal sender As Object, ByVal e As DataGridCommandEventArgs)
            Try
                grdFields.EditItemIndex = -1
                BindData()
            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Public Sub grdFields_Edit(ByVal sender As Object, ByVal e As DataGridCommandEventArgs)
            Try
                grdFields.EditItemIndex = e.Item.ItemIndex
                grdFields.SelectedIndex = -1
                BindData()
            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Sub grdFields_Item_Bound(ByVal sender As Object, ByVal e As DataGridItemEventArgs)
            Try
                Dim itemType As ListItemType
                itemType = CType(e.Item.ItemType, ListItemType)
                If (itemType = ListItemType.EditItem) Then
                    Dim chkCheckbox2 As WebControls.CheckBox
                    Dim lblCheckBox2 As WebControls.Label
                    chkCheckbox2 = CType(e.Item.FindControl("Checkbox2"), WebControls.CheckBox)
                    lblCheckBox2 = CType(e.Item.FindControl("lblCheckBox2"), WebControls.Label)
                    lblCheckBox2.Text = "<label style=""display:none;"" for=""" & chkCheckbox2.ClientID.ToString & """>Visible</label>"

                    Dim txtFieldTitle As WebControls.TextBox
                    Dim lblFieldTitle As WebControls.Label
                    txtFieldTitle = CType(e.Item.FindControl("txtFieldTitle"), WebControls.TextBox)
                    lblFieldTitle = CType(e.Item.FindControl("lblFieldTitle"), WebControls.Label)
                    lblFieldTitle.Text = "<label style=""display:none;"" for=""" & txtFieldTitle.ClientID.ToString & """>Title</label>"

                    Dim cboFieldType As WebControls.DropDownList
                    Dim lblFieldType As WebControls.Label
                    cboFieldType = CType(e.Item.FindControl("cboFieldType"), WebControls.DropDownList)
                    lblFieldType = CType(e.Item.FindControl("lblFieldType"), WebControls.Label)
                    lblFieldType.Text = "<label style=""display:none;"" for=""" & cboFieldType.ClientID.ToString & """>Type</label>"

                End If
            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub
        Public Sub grdFields_Update(ByVal sender As Object, ByVal e As DataGridCommandEventArgs)

            Try
                Dim chkVisible As CheckBox = CType(e.Item.FindControl("Checkbox2"), WebControls.CheckBox)
                Dim txtFieldTitle As TextBox = CType(e.Item.FindControl("txtFieldTitle"), WebControls.TextBox)
                Dim cboFieldType As DropDownList = CType(e.Item.FindControl("cboFieldType"), WebControls.DropDownList)

                If txtFieldTitle.Text <> "" Then
                    Dim objUserDefinedTable As New UserDefinedTableDB

                    If Integer.Parse(Convert.ToString(grdFields.DataKeys(e.Item.ItemIndex))) = -1 Then
                        objUserDefinedTable.AddUserDefinedField(ModuleId, txtFieldTitle.Text, chkVisible.Checked, cboFieldType.SelectedItem.Value)
                    Else
                        objUserDefinedTable.UpdateUserDefinedField(Integer.Parse(Convert.ToString(grdFields.DataKeys(e.Item.ItemIndex))), txtFieldTitle.Text, chkVisible.Checked, cboFieldType.SelectedItem.Value)
                    End If

                    grdFields.EditItemIndex = -1
                    BindData()
                Else
                    grdFields.EditItemIndex = -1
                    BindData()
                End If
            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Public Sub grdFields_Delete(ByVal sender As Object, ByVal e As DataGridCommandEventArgs)
            Try
                Dim objUserDefinedTable As New UserDefinedTableDB

                objUserDefinedTable.DeleteUserDefinedField(ModuleId, Integer.Parse(Convert.ToString(grdFields.DataKeys(e.Item.ItemIndex))))

                grdFields.EditItemIndex = -1
                BindData()
            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Public Sub grdFields_Move(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs)
            Try
                Dim objUserDefinedTable As New UserDefinedTableDB

                Select Case e.CommandArgument
                    Case "Up"
                        objUserDefinedTable.UpdateUserDefinedFieldOrder(ModuleId, Integer.Parse(Convert.ToString(grdFields.DataKeys(e.Item.ItemIndex))), -1)
                        BindData()
                    Case "Down"
                        objUserDefinedTable.UpdateUserDefinedFieldOrder(ModuleId, Integer.Parse(Convert.ToString(grdFields.DataKeys(e.Item.ItemIndex))), 1)
                        BindData()
                End Select
            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdAddField_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdAddField.Click
            Try
                grdFields.EditItemIndex = 0
                BindData(True)
            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub BindData(Optional ByVal blnInsertField As Boolean = False)

            Dim objUserDefinedTable As New UserDefinedTableDB
            Dim dr As IDataReader
            dr = objUserDefinedTable.GetUserDefinedFields(ModuleId)
            Dim ds As DataSet

            ds = ConvertDataReaderToDataSet(dr)
            dr.Close()

            ' inserting a new field
            If blnInsertField Then
                Dim row As DataRow
                row = ds.Tables(0).NewRow()
                row("UserDefinedFieldId") = "-1"
                row("FieldTitle") = ""
                row("Visible") = True
                row("FieldType") = "String"
                ds.Tables(0).Rows.InsertAt(row, 0)
                grdFields.EditItemIndex = 0
            End If

            grdFields.DataSource = ds
            grdFields.DataBind()

            dr = objUserDefinedTable.GetUserDefinedFields(ModuleId)
            cboSortField.DataSource = dr
            cboSortField.DataBind()
            dr.Close()
            cboSortField.Items.Insert(0, New ListItem("<Not Specified>", ""))

            ' Get settings from the database
            Dim settings As Hashtable = PortalSettings.GetModuleSettings(ModuleId)

            cboSortField.ClearSelection()
            If Not cboSortField.Items.FindByValue(CType(settings("sortfield"), String)) Is Nothing Then
                cboSortField.Items.FindByValue(CType(settings("sortfield"), String)).Selected = True
            End If
            cboSortOrder.ClearSelection()
            If Not cboSortOrder.Items.FindByValue(CType(settings("sortorder"), String)) Is Nothing Then
                cboSortOrder.Items.FindByValue(CType(settings("sortorder"), String)).Selected = True
            End If
        End Sub

        Private Sub grdFields_ItemCreated(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles grdFields.ItemCreated
            Try
                Dim cmdDeleteUserDefinedField As Control = e.Item.FindControl("cmdDeleteUserDefinedField")

                If Not cmdDeleteUserDefinedField Is Nothing Then
                    CType(cmdDeleteUserDefinedField, ImageButton).Attributes.Add("onClick", "javascript: return confirm('Are You Sure You Wish To Delete This Column ?')")
                End If

                If e.Item.ItemType = ListItemType.Header Then
                    e.Item.Cells(1).Attributes.Add("Scope", "col")
                    e.Item.Cells(2).Attributes.Add("Scope", "col")
                    e.Item.Cells(3).Attributes.Add("Scope", "col")
                End If
            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try

        End Sub

        Private Sub cboSortField_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboSortField.SelectedIndexChanged
            Try
                ' Update settings in the database
                Dim objModules As New ModuleController

                If Not cboSortField.SelectedItem Is Nothing Then
                    objModules.UpdateModuleSetting(ModuleId, "sortfield", cboSortField.SelectedItem.Value)
                End If

                BindData()
            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cboSortOrder_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboSortOrder.SelectedIndexChanged
            Try
                ' Update settings in the database
                Dim objModules As New ModuleController

                If Not cboSortOrder.SelectedItem Is Nothing Then
                    objModules.UpdateModuleSetting(ModuleId, "sortorder", cboSortOrder.SelectedItem.Value)
                End If

                BindData()
            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Public Function GetFieldTypeName(ByVal strFieldType As String) As String
            Try
                Select Case strFieldType
                    Case "String" : Return "Text"
                    Case "Int32" : Return "Integer"
                    Case "Decimal" : Return "Decimal"
                    Case "DateTime" : Return "Date"
                    Case "Boolean" : Return "True/False"
                    Case Else : Return "Text"
                End Select
            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Function

        Public Function GetFieldTypeIndex(ByVal strFieldType As String) As Integer
            Try
                Select Case strFieldType
                    Case "String" : Return 0
                    Case "Int32" : Return 1
                    Case "Decimal" : Return 2
                    Case "DateTime" : Return 3
                    Case "Boolean" : Return 4
                    Case Else : Return 0
                End Select
            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try

        End Function

    End Class

End Namespace