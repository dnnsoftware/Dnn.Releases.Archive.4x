Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports Microsoft.ApplicationBlocks.Data
Imports DotNetNuke

Namespace YourCompanyName.UsersOnline

    Public Class SqlDataProvider

        Inherits DataProvider

        Private Const ProviderType As String = "data"

        Private _providerConfiguration As ProviderConfiguration = ProviderConfiguration.GetProviderConfiguration(ProviderType)
        Private _connectionString As String
        Private _providerPath As String
        Private _objectQualifier As String
        Private _databaseOwner As String

        Public Sub New()

            ' Read the configuration specific information for this provider
            Dim objProvider As Provider = CType(_providerConfiguration.Providers(_providerConfiguration.DefaultProvider), Provider)

            ' Read the attributes for this provider
            _connectionString = objProvider.Attributes("connectionString")

            _providerPath = objProvider.Attributes("providerPath")

            _objectQualifier = objProvider.Attributes("objectQualifier")
            If _objectQualifier <> "" And _objectQualifier.EndsWith("_") = False Then
                _objectQualifier += "_"
            End If

            _databaseOwner = objProvider.Attributes("databaseOwner")
            If _databaseOwner <> "" And _databaseOwner.EndsWith(".") = False Then
                _databaseOwner += "."
            End If

        End Sub

        Public ReadOnly Property ConnectionString() As String
            Get
                Return _connectionString
            End Get
        End Property

        Public ReadOnly Property ProviderPath() As String
            Get
                Return _providerPath
            End Get
        End Property

        Public ReadOnly Property ObjectQualifier() As String
            Get
                Return _objectQualifier
            End Get
        End Property

        Public ReadOnly Property DatabaseOwner() As String
            Get
                Return _databaseOwner
            End Get
        End Property

        ' general
        Private Function GetNull(ByVal Field As Object) As Object
            Return Null.GetNull(Field, DBNull.Value)
        End Function

        Public Overrides Function GetStatistics(ByVal PortalId As Integer) As Hashtable
            Dim statistics As Hashtable = New Hashtable

            Dim reader As IDataReader = CType(SqlHelper.ExecuteReader(ConnectionString, DatabaseOwner & ObjectQualifier & "GetOnlineUserStatistics", PortalId), IDataReader)

            If (reader.Read()) Then
                statistics.Add("AnonymousUserCount", reader(0))
            End If
            reader.NextResult()

            If (reader.Read()) Then
                statistics.Add("OnlineUserCount", reader(0))
            End If
            reader.NextResult()

            If (reader.Read()) Then
                statistics.Add("LastUsername", reader(0))
                statistics.Add("LastUserId", reader(1))
            End If
            reader.NextResult()

            If (reader.Read()) Then
                statistics.Add("MembershipCount", reader(0))
            End If
            reader.NextResult()

            If (reader.Read()) Then
                statistics.Add("MembershipToday", reader(0))
            End If
            reader.NextResult()

            If (reader.Read()) Then
                statistics.Add("MembershipYesterday", reader(0))
            End If

            reader.Close()

            Return statistics
        End Function

        Public Overrides Function GetOnlineUsers(ByVal PortalId As Integer) As IDataReader
            Return CType(SqlHelper.ExecuteReader(ConnectionString, DatabaseOwner & ObjectQualifier & "GetOnlineUsers", PortalId), IDataReader)
        End Function

    End Class

End Namespace