Imports System
Imports System.Data
Imports System.Data.OleDB
Imports OleDB.ApplicationBlocks.Data
Imports System.Web
Imports DotNetNuke

Namespace YourCompanyName.UsersOnline

    Public Class AccessDataProvider

        Inherits DataProvider

        Private Const ProviderType As String = "data"

        Private _providerConfiguration As ProviderConfiguration = ProviderConfiguration.GetProviderConfiguration(ProviderType)
        Private _connectionString As String
        Private _providerPath As String
        Private _objectQualifier As String
        Private _databaseFilename As String

        Public Sub New()

            ' Read the configuration specific information for this provider
            Dim objProvider As Provider = CType(_providerConfiguration.Providers(_providerConfiguration.DefaultProvider), Provider)

            ' Read the attributes for this provider
            _connectionString = objProvider.Attributes("connectionString")

            _providerPath = objProvider.Attributes("provIderPath")

            _objectQualifier = objProvider.Attributes("objectQualifier")
            If _objectQualifier <> "" And _objectQualifier.EndsWith("_") = False Then
                _objectQualifier += "_"
            End If

            _databaseFilename = objProvider.Attributes("databaseFilename")

            If _connectionString.IndexOf("Data Source=") = -1 Then
                Dim objHttpContext As HttpContext = HttpContext.Current
                _connectionString += "Data Source=" & objHttpContext.Server.MapPath(_providerPath) & _databaseFilename
            End If

        End Sub

        Public ReadOnly Property ConnectionString() As String
            Get
                Return _connectionString
            End Get
        End Property

        Public ReadOnly Property ProviderPath() As String
            Get
                Return _providerPath
            End Get
        End Property

        Public ReadOnly Property ObjectQualifier() As String
            Get
                Return _objectQualifier
            End Get
        End Property

        Public ReadOnly Property DatabaseFilename() As String
            Get
                Return _databaseFilename
            End Get
        End Property

        ' general
        Private Function GetNull(ByVal Field As Object) As Object
            Return Null.GetNull(Field, DBNull.Value)
        End Function

        Public Overrides Function GetStatistics(ByVal PortalId As Integer) As Hashtable
            Dim statistics As Hashtable = New Hashtable

            statistics.Add("AnonymousUserCount", GetAnonymousUserCount(PortalId))
            statistics.Add("OnlineUserCount", GetOnlineUserCount(PortalId))
            statistics.Add("LastUsername", GetLastRegisteredUserName(PortalId))
            statistics.Add("MembershipCount", GetMembershipCount(PortalId))
            statistics.Add("MembershipToday", GetMembershipToday(PortalId))
            statistics.Add("MembershipYesterday", GetMembershipYesterday(PortalId))

            Return statistics
        End Function

        Private Function GetAnonymousUserCount(ByVal PortalId As Integer) As Integer
            Return CType(OleDBHelper.ExecuteScalar(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetAnonymousUserCount", _
                            New OleDbParameter("@PortalId", PortalId)), Integer)
        End Function

        Private Function GetOnlineUserCount(ByVal PortalId As Integer) As Integer
            Return CType(OleDBHelper.ExecuteScalar(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetOnlineUserCount", _
                            New OleDbParameter("@PortalId", PortalId)), Integer)
        End Function

        Private Function GetLastRegisteredUserName(ByVal PortalId As Integer) As String
            Return CType(OleDBHelper.ExecuteScalar(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetLastRegisteredUserName", _
                            New OleDbParameter("@PortalId", PortalId)), String)
        End Function

        Private Function GetMembershipCount(ByVal PortalId As Integer) As Integer
            Return CType(OleDBHelper.ExecuteScalar(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetMembershipCount", _
                            New OleDbParameter("@PortalId", PortalId)), Integer)
        End Function

        Private Function GetMembershipToday(ByVal PortalId As Integer) As Integer
            Return CType(OleDBHelper.ExecuteScalar(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetMembershipToday", _
                            New OleDbParameter("@PortalId", PortalId)), Integer)
        End Function

        Private Function GetMembershipYesterday(ByVal PortalId As Integer) As Integer
            Return CType(OleDBHelper.ExecuteScalar(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetMembershipYesterday", _
                            New OleDbParameter("@PortalId", PortalId)), Integer)
        End Function

        Public Overrides Function GetOnlineUsers(ByVal PortalId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetOnlineUsers", _
                            New OleDbParameter("@PortalId", PortalId)), IDataReader)
        End Function

    End Class

End Namespace