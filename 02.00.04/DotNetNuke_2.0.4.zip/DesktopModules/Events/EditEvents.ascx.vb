'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Namespace DotNetNuke

    Public Class EditEvents
        Inherits DotNetNuke.PortalModuleControl

        ' module options

        Protected WithEvents txtTitle As System.Web.UI.WebControls.TextBox
        Protected WithEvents valTitle As System.Web.UI.WebControls.RequiredFieldValidator
        Protected WithEvents txtDescription As System.Web.UI.WebControls.TextBox
        Protected WithEvents valDescription As System.Web.UI.WebControls.RequiredFieldValidator
        Protected WithEvents cboImage As System.Web.UI.WebControls.DropDownList
        Protected WithEvents cmdUpload As System.Web.UI.WebControls.HyperLink
        Protected WithEvents txtAlt As System.Web.UI.WebControls.TextBox
        Protected WithEvents valAltText As System.Web.UI.WebControls.RequiredFieldValidator
        Protected WithEvents txtEvery As System.Web.UI.WebControls.TextBox
        Protected WithEvents cboPeriod As System.Web.UI.WebControls.DropDownList
        Protected WithEvents txtStartDate As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtTime As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtExpiryDate As System.Web.UI.WebControls.TextBox
        Protected WithEvents valExpiryDate As System.Web.UI.WebControls.CompareValidator

        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdDelete As System.Web.UI.WebControls.LinkButton

        Protected WithEvents pnlAudit As System.Web.UI.WebControls.Panel
        Protected WithEvents CreatedBy As System.Web.UI.WebControls.Label
        Protected WithEvents CreatedDate As System.Web.UI.WebControls.Label
        Protected WithEvents pnlContent As System.Web.UI.WebControls.Panel
        Protected WithEvents cmdStartCalendar As System.Web.UI.WebControls.HyperLink
        Protected WithEvents valStartDate2 As System.Web.UI.WebControls.CompareValidator
        Protected WithEvents cmdExpiryCalendar As System.Web.UI.WebControls.HyperLink
        Protected WithEvents valStartDate As System.Web.UI.WebControls.RequiredFieldValidator

        Private itemId As Integer = -1

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        '****************************************************************
        '
        ' The Page_Load event on this Page is used to obtain the ModuleId
        ' and ItemId of the event to edit.
        '
        ' It then uses the DotNetNuke.EventsDB() data component
        ' to populate the page's edit controls with the event details.
        '
        '****************************************************************

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                Dim objModules As New ModuleController

                ' Determine ItemId of Events to Update
                If Not (Request.Params("ItemId") Is Nothing) Then
                    itemId = Int32.Parse(Request.Params("ItemId"))
                End If

                ' If the page is being requested the first time, determine if an
                ' event itemId value is specified, and if so populate page
                ' contents with the event details
                If Page.IsPostBack = False Then

                    cmdDelete.Attributes.Add("onClick", "javascript:return confirm('Are You Sure You Wish To Delete This Item ?');")
                    cmdStartCalendar.NavigateUrl = CType(AdminDB.InvokePopupCal(txtStartDate), String)
                    cmdExpiryCalendar.NavigateUrl = CType(AdminDB.InvokePopupCal(txtExpiryDate), String)

                    ' load the list of files found in the upload directory
                    Dim FileList As ArrayList = GetFileList(PortalId, glbImageFileTypes)
                    cboImage.DataSource = FileList
                    cboImage.DataBind()
                    cmdUpload.NavigateUrl = NavigateURL("File Manager")

                    If Not Null.IsNull(itemId) Then

                        ' Obtain a single row of event information
                        Dim objEvents As New EventController
                        Dim objEvent As EventInfo = objEvents.GetModuleEvent(itemId, ModuleId)

                        ' Read first row from database
                        If Not objEvent Is Nothing Then
                            txtTitle.Text = objEvent.Title
                            txtDescription.Text = objEvent.Description.ToString
                            If cboImage.Items.Contains(New ListItem(objEvent.IconFile)) Then
                                cboImage.Items.FindByText(objEvent.IconFile).Selected = True
                            End If
                            If cboImage.SelectedIndex = 0 Then
                                valAltText.Visible = False
                            Else
                                valAltText.Visible = True
                            End If
                            txtAlt.Text = objEvent.AltText
                            txtEvery.Text = objEvent.Every.ToString
                            If txtEvery.Text = "1" Then
                                txtEvery.Text = ""
                            End If
                            If objEvent.Period <> "" Then
                                cboPeriod.Items.FindByValue(objEvent.Period).Selected = True
                            Else
                                cboPeriod.Items(0).Selected = True
                            End If
                            txtStartDate.Text = objEvent.DateTime.ToShortDateString
                            txtTime.Text = objEvent.DateTime.ToShortTimeString
                            If objEvent.DateTime.ToString("HH:mm") = "00:00" Then
                                txtTime.Text = ""
                            End If
                            If Not Null.IsNull(objEvent.ExpireDate) Then
                                txtExpiryDate.Text = objEvent.ExpireDate.ToShortDateString
                            Else
                                txtExpiryDate.Text = ""
                            End If

                            CreatedBy.Text = objEvent.CreatedByUser
                            CreatedDate.Text = objEvent.CreatedDate.ToString

                        Else ' security violation attempt to access item not related to this Module

                            Response.Redirect(NavigateURL(), True)
                        End If
                    Else
                        cmdDelete.Visible = False
                        pnlAudit.Visible = False
                        valAltText.Visible = False
                    End If

                End If
            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub


        '****************************************************************
        '
        ' The cmdUpdate_Click event handler on this Page is used to either
        ' create or update an event.  It uses the DotNetNuke.EventsDB()
        ' data component to encapsulate all data functionality.
        '
        '****************************************************************

        Private Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click
            Try
                Dim strDateTime As String
                Dim strIconFile As String

                ' Only Update if the Entered Data is Valid
                If Page.IsValid = True Then

                    strDateTime = txtStartDate.Text
                    If txtTime.Text <> "" Then
                        strDateTime += " " & txtTime.Text
                    End If

                    If Not cboImage.SelectedItem Is Nothing Then
                        strIconFile = cboImage.SelectedItem.Value
                    End If

                    Dim objEvent As New EventInfo
                    objEvent.ItemId = itemId
                    objEvent.ModuleId = ModuleId
                    objEvent.CreatedByUser = Context.User.Identity.Name
                    objEvent.Description = txtDescription.Text
                    objEvent.DateTime = Convert.ToDateTime(strDateTime)
                    objEvent.Title = txtTitle.Text
                    If txtEvery.Text <> "" Then
                        objEvent.Every = Convert.ToInt32(txtEvery.Text)
                    Else
                        objEvent.Every = 1
                    End If
                    objEvent.Period = cboPeriod.SelectedItem.Value
                    objEvent.IconFile = strIconFile
                    objEvent.AltText = txtAlt.Text
                    If txtExpiryDate.Text <> "" Then
                        objEvent.ExpireDate = Convert.ToDateTime(txtExpiryDate.Text)
                    End If
                    ' Create an instance of the Event DB component
                    Dim objEvents As New EventController

                    If Null.IsNull(itemId) Then
                        ' Add the event within the Events table
                        objEvents.AddModuleEvent(objEvent)
                    Else
                        ' Update the event within the Events table
                        objEvents.UpdateModuleEvent(objEvent)
                    End If
                    objEvents = Nothing
                    ' Redirect back to the portal home page
                    Response.Redirect(NavigateURL(), True)

                End If
            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub


        '****************************************************************
        '
        ' The cmdDelete_Click event handler on this Page is used to delete an
        ' an event.  It  uses the DotNetNuke.EventsDB() data component to
        ' encapsulate all data functionality.
        '
        '****************************************************************

        Private Sub cmdDelete_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdDelete.Click
            Try
                Dim objEvents As New EventController
                objEvents.DeleteModuleEvent(itemId)
                objEvents = Nothing
                ' Redirect back to the portal home page
                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub


        '****************************************************************
        '
        ' The cmdCancel_Click event handler on this Page is used to cancel
        ' out of the page, and return the user back to the portal home
        ' page.
        '
        '****************************************************************'

        Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click
            Try
                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub


        '****************************************************************
        '
        ' The cboImage_Changed event handler on this Page is used to 
        ' disable the alternate text validator, since an alternate text
        ' is not necessary when there is no image to show.
        '
        '****************************************************************'
        Private Sub cboImage_Changed(ByVal sender As Object, ByVal e As EventArgs) Handles cboImage.SelectedIndexChanged
            Try
                If cboImage.SelectedIndex = 0 Then
                    valAltText.Visible = False
                Else
                    valAltText.Visible = True
                End If
            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

    End Class
End Namespace