'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2003
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.Net.Sockets
Imports System.Text
Imports System.IO
Imports DotNetNuke

Namespace YourCompanyName.Whois

    Public MustInherit Class Whois

        Inherits PortalModuleControl

        Protected WithEvents txtDomain As System.Web.UI.WebControls.TextBox
        Protected WithEvents cmdGo As System.Web.UI.WebControls.LinkButton
        Protected WithEvents lblResult As System.Web.UI.WebControls.Label

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        Private Sub cmdGo_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdGo.Click

            Dim strResult As String = ""

            If txtDomain.Text <> "" Then

                Dim strExtension As String = ""
                If InStr(1, txtDomain.Text, ".") > 0 Then
                    strExtension = Mid(txtDomain.Text, InStr(1, txtDomain.Text, ".") + 1).ToLower
                End If

                If strExtension <> "" Then

                    Dim objTcpClient As New TcpClient

                    Try

                        Dim strWhoisURL As String = ""

                        Select Case strExtension
                            Case "com", "net", "org"
                                strWhoisURL = "whois.networksolutions.com"
                            Case "ca"
                                strWhoisURL = "whois.cira.ca"
                        End Select

                        If strWhoisURL <> "" Then

                            objTcpClient.Connect(strWhoisURL, 43)

                            Dim objNetworkStream As NetworkStream = objTcpClient.GetStream()

                            Dim objStreamWriter As StreamWriter = New StreamWriter(objNetworkStream)
                            objStreamWriter.Write(txtDomain.Text & ControlChars.CrLf)
                            objStreamWriter.Flush()

                            Dim objStreamReader As StreamReader = New StreamReader(objNetworkStream)
                            strResult = objStreamReader.ReadToEnd()

                            strResult = ParseResult(strResult, strExtension)

                            objNetworkStream.Close()
                            objTcpClient.Close()

                        Else

                            strResult = "Domain Name Not Supported"

                        End If

                    Catch objException As Exception

                        ' connection error
                        strResult = objException.Message

                    End Try

                Else

                    strResult = "Domain Name Structure Is Not Valid"

                End If

            Else

                strResult = "Domain Name Not Specified"

            End If

            lblResult.Text = strResult

        End Sub

        Private Function ParseResult(ByVal strResult As String, ByVal strExtension As String) As String

            ' NOTE: Specific Domain Extensions should be stored in a database with fields for 
            '       WhoisURL, Delimiter, FixedLength, StartText, EndText, PreferredRegistrarName, PreferredRegistrarURL
            '       This module would then be able to support any number of domain extensions

            Dim strDisplay As String
            Dim intPos As Integer
            Dim blnRegistered As Boolean

            Dim intFixedLength As Integer = 0
            Dim strDelimiter As String = ""
            Dim strStartText As String = ""
            Dim strEndText As String = ""
            Dim strRegistrarName As String = ""
            Dim strRegistrarURL As String = ""

            Select Case strExtension
                Case "com", "net", "org"
                    strDelimiter = ControlChars.Lf
                    strStartText = "<br>Registra"
                    strEndText = "The previous information"
                    strRegistrarName = CType(Settings("registrarname"), String)
                    strRegistrarURL = AddHTTP(CType(Settings("registrarurl"), String))
                Case "ca"
                    intFixedLength = 66
                    strStartText = "Status:         EXIST"
            End Select

            ' format WHOIS result
            If intFixedLength <> 0 Then
                Dim intCounter As Integer
                Dim strTemp As String = ""
                For intCounter = 1 To Len(strResult) Step intFixedLength
                    strTemp += "<br>" & Trim(Mid(strResult, intCounter, intFixedLength))
                Next
                strResult = strTemp
            End If
            If strDelimiter <> "" Then
                strResult = Replace(strResult, strDelimiter, "<br>")
            End If

            ' registered
            If InStr(1, strResult, strStartText) > 0 Or strStartText = "" Then
                blnRegistered = True
            Else
                blnRegistered = False
            End If

            If blnRegistered Then
                strDisplay = "Domain Name <a href=""http://www." & txtDomain.Text & """>www." & txtDomain.Text & "</a> Has Already Been Registered."

                If CType(Settings("results"), String) = "F" Then
                    ' full
                    If strStartText <> "" Then
                        intPos = InStr(1, strResult, strStartText)
                        If intPos > 0 Then
                            strResult = Mid(strResult, intPos)
                        End If
                    End If
                    If strEndText <> "" Then
                        intPos = InStr(1, strResult, strEndText)
                        If intPos > 0 Then
                            strResult = Left(strResult, intPos - 1)
                        End If
                    End If
                    strDisplay += "<br><br>" & strResult
                End If
            Else
                strDisplay = "Domain Name Is Available."
                If strRegistrarName <> "" And strRegistrarURL <> "" Then
                    strDisplay += "Please Click <a href=""" & strRegistrarURL & """>Here</a> To Register The Domain At " & strRegistrarName & "."
                End If
            End If

            Return strDisplay

        End Function

    End Class

End Namespace
