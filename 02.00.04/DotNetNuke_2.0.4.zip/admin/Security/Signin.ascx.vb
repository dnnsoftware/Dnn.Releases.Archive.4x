'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.Web.Security

Namespace DotNetNuke

    Public MustInherit Class Signin
        Inherits DotNetNuke.PortalModuleControl

        Protected WithEvents txtUsername As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtPassword As System.Web.UI.WebControls.TextBox
        Protected WithEvents rowVerification1 As System.Web.UI.HtmlControls.HtmlTableRow
        Protected WithEvents rowVerification2 As System.Web.UI.HtmlControls.HtmlTableRow
        Protected WithEvents txtVerification As System.Web.UI.WebControls.TextBox
        Protected WithEvents chkCookie As System.Web.UI.WebControls.CheckBox
        Protected WithEvents cmdLogin As System.Web.UI.WebControls.ImageButton
        Protected WithEvents cmdRegister As System.Web.UI.WebControls.ImageButton
        Protected WithEvents cmdSendPassword As System.Web.UI.WebControls.ImageButton
        Protected WithEvents lblLogin As System.Web.UI.WebControls.Label

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            If _portalSettings.UserRegistration = 0 Then
                cmdRegister.Visible = False
            End If

            txtPassword.Attributes.Add("value", txtPassword.Text)

            If Page.IsPostBack = False Then
                Try
                    SetFormFocus(txtUsername)
                Catch
                    'control not there or error setting focus
                End Try
            End If

            Dim objModules As New ModuleController

            Dim intModuleId As Integer = objModules.GetSiteModule("Site Settings", PortalId)
            Dim settings As Hashtable = _portalSettings.GetModuleSettings(intModuleId)
            lblLogin.Text = CType(settings("loginmessage"), String)

        End Sub

        Private Sub cmdLogin_Click(ByVal sender As Object, ByVal e As ImageClickEventArgs) Handles cmdLogin.Click

            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            Dim objUsers As New UserController
            Dim objSecurity As New PortalSecurity()

            Dim blnLogin As Boolean = True

            If _portalSettings.UserRegistration = 3 Then ' verified
                Dim objUser As UserInfo = objUsers.GetUserByUsername(_portalSettings.PortalId, txtUsername.Text)
                'If Not objUser.UserID = -1 Then
                If Not objUser Is Nothing Then
                    If objUser.LastLoginDate = Date.MinValue And objUser.IsSuperUser = False Then
                        blnLogin = False
                        If rowVerification1.Visible Then
                            If txtVerification.Text <> "" Then
                                If txtVerification.Text = (_portalSettings.PortalId.ToString & "-" & objUser.UserID) Then
                                    blnLogin = True
                                Else
                                    Skin.AddModuleMessage(Me, "Invalid Verification Code", Skins.ModuleMessage.ModuleMessageType.RedError)
                                End If
                            Else
                                Skin.AddModuleMessage(Me, "Enter Your Verification Code", Skins.ModuleMessage.ModuleMessageType.GreenSuccess)
                            End If
                        Else
                            rowVerification1.Visible = True
                            rowVerification2.Visible = True
                        End If
                    End If
                End If
            End If

            If blnLogin Then
                ' Attempt to Validate User Credentials
                Dim userId As Integer = objSecurity.UserLogin(txtUsername.Text, txtPassword.Text, _portalSettings.PortalId)

                If userId >= 0 Then
                    ' Use security system to set the UserID within a client-side Cookie
                    FormsAuthentication.SetAuthCookie(Convert.ToString(userId), chkCookie.Checked)

                    ' redirect browser - override is used if the user defined login tab has no signin control
                    If _portalSettings.HomeTabId <> -1 And Request.QueryString("override") Is Nothing Then
                        ' user defined tab
                        Response.Redirect("~/" & glbDefaultPage & "?tabid=" & _portalSettings.HomeTabId.ToString, True)
                    Else
                        ' admin tab
                        Response.Redirect("~/" & glbDefaultPage & "?tabid=" & _portalSettings.ActiveTab.TabId.ToString, True)
                    End If
                Else
                    Skin.AddModuleMessage(Me, "Login Failed", Skins.ModuleMessage.ModuleMessageType.RedError)
                End If
            End If

        End Sub

        Private Sub cmdSendPassword_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles cmdSendPassword.Click

            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            If Trim(txtUsername.Text) <> "" Then
                Dim objUsers As New UserController
                Dim objSecurity As New PortalSecurity()

                Dim objUser As UserInfo = objUsers.GetUserByUsername(_portalSettings.PortalId, txtUsername.Text)

                If Not objUser Is Nothing Then
                    Dim strBody As String

                    strBody = "Dear " & objUser.FullName & "," & vbCrLf & vbCrLf
                    strBody = strBody & "You have requested a Password Reminder from our " & _portalSettings.PortalName & " website." & vbCrLf & vbCrLf
                    strBody = strBody & "Please login using the following information:" & vbCrLf & vbCrLf
                    strBody = strBody & "Portal Website Address: " & GetPortalDomainName(PortalAlias, Request) & vbCrLf
                    strBody = strBody & "Username:   " & objUser.Username & vbCrLf
                    strBody = strBody & "Password: " & objSecurity.Decrypt(Convert.ToString(_portalSettings.HostSettings("EncryptionKey")), objUser.Password) & vbCrLf
                    If _portalSettings.UserRegistration = 3 And objUser.LastLoginDate = Date.MinValue And objUser.IsSuperUser = False Then
                        strBody = strBody & "Verification Code: " & _portalSettings.PortalId.ToString & "-" & objUser.UserID & vbCrLf
                    End If
                    If Not IsDBNull(objUser.Authorized) Then
                        If Not objUser.Authorized Then
                            strBody = strBody & "Status: Not Authorized" & vbCrLf
                        End If
                    End If
                    strBody = strBody & vbCrLf

                    strBody = strBody & vbCrLf & "Sincerely," & vbCrLf
                    strBody = strBody & "Portal Administrator" & vbCrLf & vbCrLf
                    strBody = strBody & "*Note: If you did not request a Password Reminder, please disregard this Message."

                    SendNotification(_portalSettings.Email, objUser.Email, "", _portalSettings.PortalName & " Password Reminder", strBody)
                    Skin.AddModuleMessage(Me, "Password Has Been Sent To<br>Your Email Address.", Skins.ModuleMessage.ModuleMessageType.GreenSuccess)
                Else
                    Skin.AddModuleMessage(Me, "Username Does Not Exist", Skins.ModuleMessage.ModuleMessageType.RedError)
                End If

            Else
                Skin.AddModuleMessage(Me, "Please Enter Your Username", Skins.ModuleMessage.ModuleMessageType.RedError)
            End If

        End Sub

        Private Sub cmdRegister_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles cmdRegister.Click
            If PortalSettings.UserTabId <> -1 Then
                ' user defined tab
                Response.Redirect("~/" & glbDefaultPage & "?tabid=" & PortalSettings.UserTabId.ToString, True)
            Else
                ' admin tab
                Response.Redirect("~/" & glbDefaultPage & "?tabid=" & PortalSettings.ActiveTab.TabId & "&ctl=Register", True)
            End If
        End Sub

    End Class

End Namespace
