DotNetNuke

Clean Installation

- .NET Framework must be installed ( http://www.asp.net/ibuyspy/CheckDotNet.aspx )
- unzip package into C:\DotNetNuke
- create Virtual Directory in IIS called DotNetNuke which points to the directory where the DotNetNuke.sln file exists
- depending on your choice of database you must have the necessary software installed on your server and you must create the database:
  - MS Access ( default )
    - you need to ensure you have the latest Microsoft JET 4.0 Database Engine installed
      - browse to http://support.microsoft.com/default.aspx?kbid=239114
    - the database file ( DotNetNuke.mdb.resources ) will be created automatically
  - SQL Server 2000 or MSDE 2000 ( MSDE can be acquired from http://www.asp.net/Tools/redir.aspx?path=msde )
    - manually create SQL Server database named DotNetNuke ( using Enterprise Manager or your tool of choice )
    - specify the default data provider setting in web.config ( <data defaultProvider="SqlDataProvider" > )
    - set the properties for the SqlDataProvider in web.config to match your server ( ie. connectionString )
- browse to localhost/DotNetNuke in your web browser
- the application will automatically execute the necessary database scripts

Applications Upgrades

- make sure you always backup your database before upgrading to a new version
- the application will automatically execute the necessary database scripts

Security ( details in /403-3.htm file )

If using Windows 2000 - IIS5
- the {Server}/ASPNET user account must have Read, Write, and Change Control of the root application directory ( this allows the application to create files/folders ) 
If using Windows 2003 - IIS6
- the {Server}/NetworkService user account must have Read, Write, and Change Control of the root application directory ( this allows the application to create files/folders ) 

Compatibility

If using .NET Framework 1.1 and you enter HTML into a textbox you will get an error "A potentially dangerous Request.Form value was detected..."
- modify the web.config file and change the following node:
  <pages enableViewStateMac="true" validateRequest="false" />	