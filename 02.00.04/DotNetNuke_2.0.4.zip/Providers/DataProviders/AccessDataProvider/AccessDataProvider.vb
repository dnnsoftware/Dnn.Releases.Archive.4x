Imports System
Imports System.Data
Imports System.Data.OleDB
Imports OleDB.ApplicationBlocks.Data
Imports System.IO
Imports System.Web
Imports DotNetNuke
Imports System.Threading

Namespace DotNetNuke.Data

    Public Class AccessDataProvider

        Inherits DataProvider

        Private Const ProviderType As String = "data"

        Private _providerConfiguration As ProviderConfiguration = ProviderConfiguration.GetProviderConfiguration(ProviderType)
        Private _connectionString As String
        Private _providerPath As String
        Private _objectQualifier As String
        Private _databaseFilename As String

        Public Sub New()

            ' Read the configuration specific information for this provider
            Dim objProvider As Provider = CType(_provIderConfiguration.Providers(_provIderConfiguration.DefaultProvider), Provider)

            ' Read the attributes for this provider
            _connectionString = objProvider.Attributes("connectionString")

            _provIderPath = objProvider.Attributes("provIderPath")

            _objectQualifier = objProvider.Attributes("objectQualifier")
            If _objectQualifier <> "" And _objectQualifier.EndsWith("_") = False Then
                _objectQualifier += "_"
            End If

            _databaseFilename = objProvider.Attributes("databaseFilename")

            If _connectionString.IndexOf("Data Source=") = -1 Then

                _connectionString += "Data Source=" & HttpRuntime.AppDomainAppPath & _providerPath.Replace("~\", "") & _databaseFilename

            End If

        End Sub

        Public ReadOnly Property ConnectionString() As String
            Get
                Return _connectionString
            End Get
        End Property

        Public ReadOnly Property ProviderPath() As String
            Get
                Return _providerPath
            End Get
        End Property

        Public ReadOnly Property ObjectQualifier() As String
            Get
                Return _objectQualifier
            End Get
        End Property

        Public ReadOnly Property DatabaseFilename() As String
            Get
                Return _databaseFilename
            End Get
        End Property

        ' general
        Private Function GetNull(ByVal Field As Object) As Object
            Return Null.GetNull(Field, DBNull.Value)
        End Function

        ' upgrade
        Public Overrides Function GetProviderPath() As String

            Dim TemplateDatabase As String = "Template.mdb.resources"

            Dim objHttpContext As HttpContext = HttpContext.Current

            GetProviderPath = ProviderPath

            If GetProviderPath <> "" Then
                GetProviderPath = objHttpContext.Server.MapPath(GetProviderPath)
                If Directory.Exists(GetProviderPath) Then
                    If DatabaseFilename = TemplateDatabase Then
                        GetProviderPath = "ERROR: databaseFileName can not be " & TemplateDatabase
                    Else
                        If File.Exists(GetProviderPath & DatabaseFilename) = False Then
                            ' created DB based on Template
                            File.Copy(GetProviderPath & TemplateDatabase, GetProviderPath & DatabaseFilename)
                            File.SetAttributes(GetProviderPath & DatabaseFilename, FileAttributes.Normal)
                        End If

                        Try
                            ' check if database is initialized
                            Dim dr As IDataReader = GetDatabaseVersion()
                            dr.Close()
                        Catch
                            ' initialize the database
                            Dim objStreamReader As StreamReader
                            objStreamReader = File.OpenText(GetProviderPath & "00.00.00." & _providerConfiguration.DefaultProvider)
                            Dim strScript As String = objStreamReader.ReadToEnd
                            objStreamReader.Close()

                            If ExecuteScript(strScript) <> "" Then
                                GetProviderPath = "ERROR: Could not open database specified in connectionString for AccessDataProvider"
                            End If
                        End Try

                    End If
                Else
                    GetProviderPath = "ERROR: providerPath folder " & GetProviderPath & " specified for AccessDataProvider does not exist on web server"
                End If
            Else
                GetProviderPath = "ERROR: providerPath folder value not specified in web.config for AccessDataProvider"
            End If
        End Function
        Public Overloads Overrides Function ExecuteScript(ByVal Script As String) As String
            Return ExecuteScript(Script, False)
        End Function
        Public Overloads Overrides Function ExecuteScript(ByVal Script As String, ByVal UseTransactions As Boolean) As String
            Dim SQL As String
            Dim Exceptions As String
            Dim Delimiter As String = "GO" & ControlChars.CrLf

            Dim arrSQL As String() = Split(Script, Delimiter, , CompareMethod.Text)

            If UseTransactions Then
                Dim Conn As New OleDbConnection(ConnectionString)
                Conn.Open()
                Try
                    Dim Trans As OleDbTransaction = Conn.BeginTransaction

                    For Each SQL In arrSQL
                        If Trim(SQL) <> "" Then
                            ' script dynamic substitution
                            SQL = SQL.Replace("{objectQualifier}", ObjectQualifier)

                            Try
                                OleDBHelper.ExecuteNonQuery(Trans, CommandType.Text, SQL)
                            Catch objException As OleDbException
                                Exceptions += objException.ToString & vbCrLf & vbCrLf & SQL & vbCrLf & vbCrLf
                            End Try
                        End If
                    Next
                    If Exceptions.Length = 0 Then
                        'No exceptions so go ahead and commit
                        Trans.Commit()
                    Else
                        'Found exceptions, so rollback db
                        Trans.Rollback()
                        Exceptions += "SQL Execution failed.  Database was rolled back" & vbCrLf & vbCrLf & SQL & vbCrLf & vbCrLf
                    End If
                Finally
                    Conn.Close()
                End Try
            Else
                For Each SQL In arrSQL
                    SQL = FormatSQL(SQL)
                    If Trim(SQL) <> "" Then
                        ' script dynamic substitution
                        SQL = SQL.Replace("{objectQualifier}", ObjectQualifier)

                        Try
                            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.Text, SQL)
                        Catch objException As OleDbException
                            Exceptions += objException.ToString & vbCrLf & vbCrLf & SQL & vbCrLf & vbCrLf
                        End Try
                    End If
                Next
            End If

            Return Exceptions
        End Function
        Private Function FormatSQL(ByVal SQL As String) As String
            SQL = SQL.Replace(vbTab, " ")
            If Trim(SQL.Replace(vbCrLf, "")) = "" Then
                SQL = SQL.Replace(vbCrLf, "")
            End If
            Return SQL
        End Function

        Public Overrides Function GetDatabaseVersion() As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetDatabaseVersion"), IDataReader)
        End Function
        Public Overrides Sub UpdateDatabaseVersion(ByVal Major As Integer, ByVal Minor As Integer, ByVal Build As Integer)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "UpdateDatabaseVersion", _
                New OleDbParameter("@Major", Major), _
                New OleDbParameter("@Minor", Minor), _
                New OleDbParameter("@Build", Build))
        End Sub
        Public Overrides Function FindDatabaseVersion(ByVal Major As Integer, ByVal Minor As Integer, ByVal Build As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "FindDatabaseVersion", _
                New OleDbParameter("@Major", Major), _
                New OleDbParameter("@Minor", Minor), _
                New OleDbParameter("@Build", Build)), IDataReader)
        End Function
        Public Overrides Sub UpgradeDatabaseSchema(ByVal Major As Integer, ByVal Minor As Integer, ByVal Build As Integer)
            ' add your database schema upgrade logic related to a specific version. This is used for data stores which do not have a rich scripting language.
            Dim strVersion As String = Major.ToString & "." & Minor.ToString & "." & Build.ToString
            Select Case strVersion
                Case ""
            End Select
        End Sub

        ' host
        Public Overrides Function GetHostSettings() As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetHostSettings"), IDataReader)
        End Function
        Public Overrides Function GetHostSetting(ByVal SettingName As String) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetHostSetting", _
                New OleDbParameter("@SettingName", SettingName)), IDataReader)
        End Function
        Public Overrides Sub AddHostSetting(ByVal SettingName As String, ByVal SettingValue As String)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "AddHostSetting", _
                New OleDbParameter("@SettingName", SettingName), _
                New OleDbParameter("@SettingValue", SettingValue))
        End Sub
        Public Overrides Sub UpdateHostSetting(ByVal SettingName As String, ByVal SettingValue As String)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "UpdateHostSetting", _
                New OleDbParameter("@SettingName", SettingName), _
                New OleDbParameter("@SettingValue", SettingValue))
        End Sub

        ' portal
        Public Overrides Function GetPortalSettings(ByVal PortalId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetPortalSettings", _
                New OleDbParameter("@PortalId", PortalId)), IDataReader)
        End Function
        Public Overrides Function GetPortalByAlias(ByVal PortalAlias As String) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetPortalByAlias", _
                New OleDbParameter("@PortalAlias", PortalAlias)), IDataReader)
        End Function
        Public Overrides Sub UpdatePortalAlias(ByVal PortalAlias As String)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "UpdatePortalAlias", _
                New OleDbParameter("@PortalAlias", PortalAlias))
        End Sub
        Public Overrides Function GetPortalByTab(ByVal TabId As Integer, ByVal PortalAlias As String) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetPortalByTab", _
                New OleDbParameter("@TabId", TabId), _
                New OleDbParameter("@PortalAlias", PortalAlias)), IDataReader)
        End Function
        Public Overrides Function AddPortalInfo(ByVal PortalName As String, ByVal PortalAlias As String, ByVal Currency As String, ByVal FirstName As String, ByVal LastName As String, ByVal Username As String, ByVal Password As String, ByVal Email As String, ByVal ExpiryDate As Date, ByVal HostFee As Double, ByVal HostSpace As Double, ByVal SiteLogHistory As Integer) As Integer
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "AddPortalInfo", _
                New OleDbParameter("@PortalName", PortalName), _
                New OleDbParameter("@PortalAlias", PortalAlias), _
                New OleDbParameter("@Currency", Currency), _
                New OleDbParameter("@FirstName", FirstName), _
                New OleDbParameter("@LastName", LastName), _
                New OleDbParameter("@Username", Username), _
                New OleDbParameter("@Password", Password), _
                New OleDbParameter("@Email", Email), _
                New OleDbParameter("@ExpiryDate", OleDbType.DBDate, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "ExpiryDate", DataRowVersion.Original, GetNull(ExpiryDate)), _
                New OleDbParameter("@HostFee", HostFee), _
                New OleDbParameter("@HostSpace", HostSpace), _
                New OleDbParameter("@SiteLogHistory", GetNull(SiteLogHistory)))

            Return CType(OleDBHelper.ExecuteScalar(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetPortalIdentity", _
                New OleDbParameter("@PortalAlias", PortalAlias)), Integer)
        End Function
        Public Overrides Sub UpdatePortalInfo(ByVal PortalId As Integer, ByVal PortalName As String, ByVal PortalAlias As String, ByVal LogoFile As String, ByVal FooterText As String, ByVal ExpiryDate As Date, ByVal UserRegistration As Integer, ByVal BannerAdvertising As Integer, ByVal Currency As String, ByVal AdministratorId As Integer, ByVal HostFee As Double, ByVal HostSpace As Double, ByVal PaymentProcessor As String, ByVal ProcessorUserId As String, ByVal ProcessorPassword As String, ByVal Description As String, ByVal KeyWords As String, ByVal BackgroundFile As String, ByVal SiteLogHistory As Integer, ByVal HomeTabId As Integer, ByVal LoginTabId As Integer, ByVal UserTabId As Integer)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "UpdatePortalInfo", _
                New OleDbParameter("@PortalId", PortalId), _
                New OleDbParameter("@PortalName", PortalName), _
                New OleDbParameter("@PortalAlias", PortalAlias), _
                New OleDbParameter("@LogoFile", GetNull(LogoFile)), _
                New OleDbParameter("@FooterText", GetNull(FooterText)), _
                New OleDbParameter("@ExpiryDate", OleDbType.DBDate, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "ExpiryDate", DataRowVersion.Original, GetNull(ExpiryDate)), _
                New OleDbParameter("@UserRegistration", UserRegistration), _
                New OleDbParameter("@BannerAdvertising", BannerAdvertising), _
                New OleDbParameter("@Currency", Currency), _
                New OleDbParameter("@AdministratorId", GetNull(AdministratorId)), _
                New OleDbParameter("@HostFee", HostFee), _
                New OleDbParameter("@HostSpace", HostSpace), _
                New OleDbParameter("@PaymentProcessor", GetNull(PaymentProcessor)), _
                New OleDbParameter("@ProcessorUserId", GetNull(ProcessorUserId)), _
                New OleDbParameter("@ProcessorPassword", GetNull(ProcessorPassword)), _
                New OleDbParameter("@Description", GetNull(Description)), _
                New OleDbParameter("@KeyWords", GetNull(KeyWords)), _
                New OleDbParameter("@BackgroundFile", GetNull(BackgroundFile)), _
                New OleDbParameter("@SiteLogHistory", GetNull(SiteLogHistory)), _
                New OleDbParameter("@HomeTabId", GetNull(HomeTabId)), _
                New OleDbParameter("@LoginTabId", GetNull(LoginTabId)), _
                New OleDbParameter("@UserTabId", GetNull(UserTabId)))
        End Sub
        Public Overrides Sub UpdatePortalSetup(ByVal PortalId As Integer, ByVal AdministratorId As Integer, ByVal AdministratorRoleId As Integer, ByVal RegisteredRoleId As Integer, ByVal HomeTabId As Integer, ByVal LoginTabId As Integer, ByVal UserTabId As Integer)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "UpdatePortalSetup", _
                New OleDbParameter("@PortalId", PortalId), _
                New OleDbParameter("@AdministratorId", AdministratorId), _
                New OleDbParameter("@AdministratorRoleId", AdministratorRoleId), _
                New OleDbParameter("@RegisteredRoleId", RegisteredRoleId), _
                New OleDbParameter("@HomeTabId", GetNull(HomeTabId)), _
                New OleDbParameter("@LoginTabId", GetNull(LoginTabId)), _
                New OleDbParameter("@UserTabId", GetNull(UserTabId)))
        End Sub
        Public Overrides Sub DeletePortalInfo(ByVal PortalId As Integer)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "DeletePortalInfo", _
                New OleDbParameter("@PortalId", PortalId))
        End Sub
        Public Overrides Function GetPortals() As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetPortals"), IDataReader)
        End Function
        Public Overrides Function GetPortal(ByVal PortalId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetPortal", _
                New OleDbParameter("@PortalId", PortalId)), IDataReader)
        End Function
        Public Overrides Function GetPortalSpaceUsed(ByVal PortalId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetPortalSpaceUsed", _
                New OleDbParameter("@PortalId", GetNull(PortalId))), IDataReader)
        End Function
        Public Overrides Function VerifyPortalTab(ByVal PortalId As Integer, ByVal TabId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "VerifyPortalTab", _
                New OleDbParameter("@PortalId", PortalId), _
                New OleDbParameter("@TabId", TabId)), IDataReader)
        End Function
        Public Overrides Function VerifyPortal(ByVal PortalId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "VerifyPortal", _
                New OleDbParameter("@PortalId", PortalId)), IDataReader)
        End Function
        ' tab
        Public Overrides Function AddTab(ByVal PortalId As Integer, ByVal TabName As String, ByVal AuthorizedRoles As String, ByVal IsVisible As Boolean, ByVal DisableLink As Boolean, ByVal ParentId As Integer, ByVal IconFile As String, ByVal AdministratorRoles As String, ByVal Title As String, ByVal Description As String, ByVal KeyWords As String) As Integer
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "AddTab", _
                New OleDbParameter("@PortalId", PortalId), _
                New OleDbParameter("@TabName", TabName), _
                New OleDbParameter("@AuthorizedRoles", AuthorizedRoles), _
                New OleDbParameter("@IsVisible", IsVisible), _
                New OleDbParameter("@DisableLink", DisableLink), _
                New OleDbParameter("@ParentId", GetNull(ParentId)), _
                New OleDbParameter("@IconFile", IconFile), _
                New OleDbParameter("@AdministratorRoles", AdministratorRoles), _
                New OleDbParameter("@Title", Title), _
                New OleDbParameter("@Description", Description), _
                New OleDbParameter("@KeyWords", KeyWords))

            Return CType(OleDBHelper.ExecuteScalar(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetTabIdentity", _
                New OleDbParameter("@PortalId", PortalId), _
                New OleDbParameter("@TabName", TabName)), Integer)
        End Function
        Public Overrides Sub UpdateTab(ByVal TabId As Integer, ByVal TabName As String, ByVal AuthorizedRoles As String, ByVal IsVisible As Boolean, ByVal DisableLink As Boolean, ByVal ParentId As Integer, ByVal IconFile As String, ByVal AdministratorRoles As String, ByVal Title As String, ByVal Description As String, ByVal KeyWords As String, ByVal IsDeleted As Boolean)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "UpdateTab", _
                New OleDbParameter("@TabId", TabId), _
                New OleDbParameter("@TabName", TabName), _
                New OleDbParameter("@AuthorizedRoles", AuthorizedRoles), _
                New OleDbParameter("@IsVisible", IsVisible), _
                New OleDbParameter("@DisableLink", DisableLink), _
                New OleDbParameter("@ParentId", GetNull(ParentId)), _
                New OleDbParameter("@IconFile", IconFile), _
                New OleDbParameter("@AdministratorRoles", AdministratorRoles), _
                New OleDbParameter("@Title", Title), _
                New OleDbParameter("@Description", Description), _
                New OleDbParameter("@KeyWords", KeyWords), _
                New OleDbParameter("@IsDeleted", IsDeleted))
        End Sub
        Public Overrides Sub UpdateTabOrder(ByVal TabId As Integer, ByVal TabOrder As Integer, ByVal Level As Integer, ByVal ParentId As Integer)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "UpdateTabOrder", _
                New OleDbParameter("@TabId", TabId), _
                New OleDbParameter("@TabOrder", TabOrder), _
                New OleDbParameter("@Level", Level), _
                New OleDbParameter("@ParentId", GetNull(ParentId)))
        End Sub
        Public Overrides Sub DeleteTab(ByVal TabId As Integer)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "DeleteTab", _
                New OleDbParameter("@TabId", TabId))
        End Sub
        Public Overrides Function GetTabs(ByVal PortalId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetTabs", _
                New OleDbParameter("@PortalId", PortalId)), IDataReader)
        End Function
        Public Overrides Function GetTab(ByVal TabId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetTab", _
                New OleDbParameter("@TabId", TabId)), IDataReader)
        End Function
        Public Overrides Function GetTabByName(ByVal TabName As String, ByVal PortalId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetTabByName", _
                New OleDbParameter("@TabName", TabName), _
                New OleDbParameter("@PortalId", GetNull(PortalId))), IDataReader)
        End Function
        Public Overrides Function GetTabsByParentId(ByVal ParentId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetTabsByParentId", _
                New OleDbParameter("@ParentId", ParentId)), IDataReader)
        End Function
        Public Overrides Function GetTabPanes(ByVal TabId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetTabPanes", _
                New OleDbParameter("@TabId", TabId)), IDataReader)
        End Function
        Public Overrides Sub UpdateTabModuleOrder(ByVal TabId As Integer, ByVal PaneName As String, ByVal OldModuleOrder As Integer, ByVal NewModuleOrder As Integer)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "UpdateTabModuleOrder", _
                New OleDbParameter("@TabId", TabId), _
                New OleDbParameter("@PaneName", PaneName), _
                New OleDbParameter("@OldModuleOrder", OldModuleOrder), _
                New OleDbParameter("@NewModuleOrder", NewModuleOrder))
        End Sub
        Public Overrides Function GetPortalTabModules(ByVal PortalId As Integer, ByVal TabId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetPortalTabModules", _
                New OleDbParameter("@PortalId", PortalId), _
                New OleDbParameter("@TabId", TabId)), IDataReader)
        End Function
        Public Overrides Function GetTabModules(ByVal TabId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetTabModules", _
                New OleDbParameter("@TabId", TabId)), IDataReader)
        End Function
        Public Overrides Function GetTabModuleOrder(ByVal TabId As Integer, ByVal PaneName As String) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetTabModuleOrder", _
                New OleDbParameter("@TabId", TabId), _
                New OleDbParameter("@PaneName", PaneName)), IDataReader)
        End Function

        ' module
        Public Overrides Function GetModule(ByVal ModuleId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetModule", _
                New OleDbParameter("@ModuleId", ModuleId)), IDataReader)
        End Function
        Public Overrides Function GetModules(ByVal PortalId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetModules", _
                New OleDbParameter("@PortalId", PortalId)), IDataReader)
        End Function
        Public Overrides Sub UpdateModuleOrder(ByVal ModuleId As Integer, ByVal ModuleOrder As Integer, ByVal PaneName As String)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "UpdateModuleOrder", _
                New OleDbParameter("@ModuleId", ModuleId), _
                New OleDbParameter("@ModuleOrder", ModuleOrder), _
                New OleDbParameter("@PaneName", PaneName))
        End Sub
        Public Overrides Function AddModule(ByVal TabID As Integer, ByVal ModuleDefID As Integer, ByVal ModuleOrder As Integer, ByVal PaneName As String, ByVal ModuleTitle As String, ByVal AuthorizedEditRoles As String, ByVal CacheTime As Integer, ByVal AuthorizedViewRoles As String, ByVal Alignment As String, ByVal Color As String, ByVal Border As String, ByVal IconFile As String, ByVal AllTabs As Boolean, ByVal ShowTitle As Boolean, ByVal Personalize As Integer) As Integer
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "AddModule", _
                New OleDbParameter("@TabId", TabID), _
                New OleDbParameter("@ModuleDefId", ModuleDefID), _
                New OleDbParameter("@ModuleOrder", ModuleOrder), _
                New OleDbParameter("@PaneName", PaneName), _
                New OleDbParameter("@ModuleTitle", ModuleTitle), _
                New OleDbParameter("@AuthorizedEditRoles", AuthorizedEditRoles), _
                New OleDbParameter("@CacheTime", CacheTime), _
                New OleDbParameter("@AuthorizedViewRoles", GetNull(AuthorizedViewRoles)), _
                New OleDbParameter("@Alignment", GetNull(Alignment)), _
                New OleDbParameter("@Color", GetNull(Color)), _
                New OleDbParameter("@Border", GetNull(Border)), _
                New OleDbParameter("@IconFile", GetNull(IconFile)), _
                New OleDbParameter("@AllTabs", AllTabs), _
                New OleDbParameter("@ShowTitle", ShowTitle), _
                New OleDbParameter("@Personalize", Personalize))

            Return CType(OleDBHelper.ExecuteScalar(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetModuleIdentity", _
                New OleDbParameter("@TabId", TabID), _
                New OleDbParameter("@ModuleTitle", ModuleTitle)), Integer)
        End Function
        Public Overrides Sub UpdateModule(ByVal ModuleId As Integer, ByVal ModuleOrder As Integer, ByVal ModuleTitle As String, ByVal Alignment As String, ByVal Color As String, ByVal Border As String, ByVal IconFile As String, ByVal CacheTime As Integer, ByVal AuthorizedViewRoles As String, ByVal AuthorizedEditRoles As String, ByVal TabId As Integer, ByVal AllTabs As Boolean, ByVal ShowTitle As Boolean, ByVal Personalize As Integer, ByVal IsDeleted As Boolean)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "UpdateModule", _
                New OleDbParameter("@ModuleId", ModuleId), _
                New OleDbParameter("@ModuleOrder", ModuleOrder), _
                New OleDbParameter("@ModuleTitle", ModuleTitle), _
                New OleDbParameter("@Alignment", Alignment), _
                New OleDbParameter("@Color", Color), _
                New OleDbParameter("@Border", Border), _
                New OleDbParameter("@IconFile", GetNull(IconFile)), _
                New OleDbParameter("@CacheTime", CacheTime), _
                New OleDbParameter("@AuthorizedViewRoles", AuthorizedViewRoles), _
                New OleDbParameter("@AuthorizedEditRoles", AuthorizedEditRoles), _
                New OleDbParameter("@TabId", TabId), _
                New OleDbParameter("@AllTabs", AllTabs), _
                New OleDbParameter("@ShowTitle", ShowTitle), _
                New OleDbParameter("@Personalize", Personalize), _
                New OleDbParameter("@IsDeleted", IsDeleted))

        End Sub
        Public Overrides Sub DeleteModule(ByVal ModuleId As Integer)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "DeleteModule", _
                New OleDbParameter("@ModuleId", ModuleId))
        End Sub
        Public Overrides Function GetModuleSettings(ByVal ModuleId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetModuleSettings", _
                New OleDbParameter("@ModuleId", ModuleId)), IDataReader)
        End Function
        Public Overrides Function GetModuleSetting(ByVal ModuleId As Integer, ByVal SettingName As String) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetModuleSetting", _
                New OleDbParameter("@ModuleId", ModuleId), _
                New OleDbParameter("@SettingName", SettingName)), IDataReader)
        End Function
        Public Overrides Sub AddModuleSetting(ByVal ModuleId As Integer, ByVal SettingName As String, ByVal SettingValue As String)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "AddModuleSetting", _
                New OleDbParameter("@ModuleId", ModuleId), _
                New OleDbParameter("@SettingName", SettingName), _
                New OleDbParameter("@SettingValue", SettingValue))
        End Sub
        Public Overrides Sub UpdateModuleSetting(ByVal ModuleId As Integer, ByVal SettingName As String, ByVal SettingValue As String)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "UpdateModuleSetting", _
                New OleDbParameter("@ModuleId", ModuleId), _
                New OleDbParameter("@SettingName", SettingName), _
                New OleDbParameter("@SettingValue", SettingValue))
        End Sub
        Public Overrides Function GetSiteModule(ByVal FriendlyName As String, ByVal PortalId As Integer) As Integer
            Return CType(OleDBHelper.ExecuteScalar(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetSiteModule", _
                New OleDbParameter("@FriendlyName", FriendlyName), _
                New OleDbParameter("@PortalId", GetNull(PortalId))), Integer)
        End Function

        ' module definition
        Public Overrides Function GetDesktopModule(ByVal DesktopModuleId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetDesktopModule", _
                New OleDbParameter("@DesktopModuleId", DesktopModuleId)), IDataReader)
        End Function
        Public Overrides Function GetDesktopModuleByName(ByVal FriendlyName As String) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetDesktopModuleByName", _
                New OleDbParameter("@FriendlyName", FriendlyName)), IDataReader)
        End Function
        Public Overrides Function GetDesktopModules() As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetDesktopModules"), IDataReader)
        End Function
        Public Overrides Function GetPortalDesktopModules(ByVal PortalId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetPortalDesktopModules", _
                New OleDbParameter("@PortalId", PortalId)), IDataReader)
        End Function
        Public Overrides Function GetPremiumDesktopModules(ByVal PortalId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetPremiumDesktopModules", _
                New OleDbParameter("@PortalId", PortalId)), IDataReader)
        End Function
        Public Overrides Function AddDesktopModule(ByVal FriendlyName As String, ByVal Description As String, ByVal Version As String, ByVal IsPremium As Boolean) As Integer
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "AddDesktopModule", _
                New OleDbParameter("@FriendlyName", FriendlyName), _
                New OleDbParameter("@Description", GetNull(Description)), _
                New OleDbParameter("@Version", GetNull(Version)), _
                New OleDbParameter("@IsPremium", IsPremium))

            Return CType(OleDBHelper.ExecuteScalar(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetDesktopModuleIdentity", _
                New OleDbParameter("@FriendlyName", FriendlyName)), Integer)
        End Function
        Public Overrides Sub UpdateDesktopModule(ByVal DesktopModuleId As Integer, ByVal FriendlyName As String, ByVal Description As String, ByVal Version As String, ByVal IsPremium As Boolean)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "UpdateDesktopModule", _
                New OleDbParameter("@DesktopModuleId", DesktopModuleId), _
                New OleDbParameter("@FriendlyName", FriendlyName), _
                New OleDbParameter("@Description", GetNull(Description)), _
                New OleDbParameter("@Version", GetNull(Version)), _
                New OleDbParameter("@IsPremium", IsPremium))
        End Sub
        Public Overrides Sub DeleteDesktopModule(ByVal DesktopModuleId As Integer)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "DeleteDesktopModule", _
                New OleDbParameter("@DesktopModuleId", DesktopModuleId))
        End Sub
        Public Overrides Function GetPortalModuleDefinition(ByVal PortalId As Integer, ByVal DesktopModuleId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetPortalModuleDefinition", _
                New OleDbParameter("@PortalId", PortalId), _
                New OleDbParameter("@DesktopModuleId", DesktopModuleId)), IDataReader)
        End Function
        Public Overrides Function AddPortalModuleDefinition(ByVal PortalId As Integer, ByVal DesktopModuleId As Integer, ByVal HostFee As Double) As Integer
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "AddPortalModuleDefinition", _
                New OleDbParameter("@PortalId", PortalId), _
                New OleDbParameter("@DesktopModuleId", DesktopModuleId), _
                New OleDbParameter("@HostFee", HostFee))

            Return CType(OleDBHelper.ExecuteScalar(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetPortalModuleDefinitionIdentity", _
                New OleDbParameter("@PortalId", PortalId), _
                New OleDbParameter("@DesktopModuleId", DesktopModuleId)), Integer)
        End Function
        Public Overrides Sub UpdatePortalModuleDefinition(ByVal PortalId As Integer, ByVal DesktopModuleId As Integer, ByVal HostFee As Double)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "UpdatePortalModuleDefinition", _
                New OleDbParameter("@PortalId", PortalId), _
                New OleDbParameter("@DesktopModuleId", DesktopModuleId), _
                New OleDbParameter("@HostFee", HostFee))
        End Sub
        Public Overrides Sub DeletePortalModuleDefinition(ByVal PortalId As Integer, ByVal DesktopModuleId As Integer)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "DeletePortalModuleDefinition", _
                New OleDbParameter("@PortalId", PortalId), _
                New OleDbParameter("@DesktopModuleId", DesktopModuleId))
        End Sub
        Public Overrides Function GetModuleDefinitions(ByVal DesktopModuleId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetModuleDefinitions", _
                New OleDbParameter("@DesktopModuleId", DesktopModuleId)), IDataReader)
        End Function
        Public Overrides Function GetModuleDefinition(ByVal ModuleDefId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetModuleDefinition", _
                New OleDbParameter("@ModuleDefId", ModuleDefId)), IDataReader)
        End Function
        Public Overrides Function GetModuleDefinitionByName(ByVal DesktopModuleId As Integer, ByVal FriendlyName As String) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetModuleDefinitionByName", _
                New OleDbParameter("@DesktopModuleId", DesktopModuleId), _
                New OleDbParameter("@FriendlyName", FriendlyName)), IDataReader)
        End Function
        Public Overrides Function AddModuleDefinition(ByVal DesktopModuleId As Integer, ByVal FriendlyName As String) As Integer
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "AddModuleDefinition", _
                New OleDbParameter("@DesktopModuleId", DesktopModuleId), _
                New OleDbParameter("@FriendlyName", FriendlyName))

            Return CType(OleDBHelper.ExecuteScalar(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetModuleDefinitionIdentity", _
                New OleDbParameter("@DesktopModuleId", DesktopModuleId), _
                New OleDbParameter("@FriendlyName", FriendlyName)), Integer)
        End Function
        Public Overrides Sub DeleteModuleDefinition(ByVal ModuleDefId As Integer)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "DeleteModuleDefinition", _
                New OleDbParameter("@ModuleDefId", ModuleDefId))
        End Sub
        Public Overrides Function GetModuleControl(ByVal ModuleControlId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetModuleControl", _
                New OleDbParameter("@ModuleControlId", ModuleControlId)), IDataReader)
        End Function
        Public Overrides Function GetModuleControls(ByVal ModuleDefId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetModuleControls", _
                New OleDbParameter("@ModuleDefId", GetNull(ModuleDefId))), IDataReader)
        End Function
        Public Overrides Function GetModuleControlsByKey(ByVal ControlKey As String, ByVal ModuleDefId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetModuleControlsByKey", _
                New OleDbParameter("@ControlKey", GetNull(ControlKey)), _
                New OleDbParameter("@ModuleDefId", GetNull(ModuleDefId))), IDataReader)
        End Function
        Public Overrides Function GetModuleControlByKeyAndSrc(ByVal ModuleDefID As Integer, ByVal ControlKey As String, ByVal ControlSrc As String) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetModuleControlByKeyAndSrc", _
                New OleDbParameter("@ModuleDefId", GetNull(ModuleDefID)), _
                New OleDbParameter("@ControlKey", GetNull(ControlKey)), _
                New OleDbParameter("@ControlSrc", GetNull(ControlSrc))), IDataReader)
        End Function
        Public Overrides Function AddModuleControl(ByVal ModuleDefId As Integer, ByVal ControlKey As String, ByVal ControlTitle As String, ByVal ControlSrc As String, ByVal IconFile As String, ByVal ControlType As Integer, ByVal ViewOrder As Integer) As Integer
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "AddModuleControl", _
                New OleDbParameter("@ModuleDefId", GetNull(ModuleDefId)), _
                New OleDbParameter("@ControlKey", GetNull(ControlKey)), _
                New OleDbParameter("@ControlTitle", GetNull(ControlTitle)), _
                New OleDbParameter("@ControlSrc", ControlSrc), _
                New OleDbParameter("@IconFile", GetNull(IconFile)), _
                New OleDbParameter("@ControlType", ControlType), _
                New OleDbParameter("@ViewOrder", GetNull(ViewOrder)))

            Return CType(OleDBHelper.ExecuteScalar(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetModuleControlIdentity", _
                New OleDbParameter("@ModuleDefId", GetNull(ModuleDefId)), _
                New OleDbParameter("@ControlKey", GetNull(ControlKey)), _
                New OleDbParameter("@ControlSrc", ControlSrc)), Integer)
        End Function
        Public Overrides Sub UpdateModuleControl(ByVal ModuleControlId As Integer, ByVal ModuleDefId As Integer, ByVal ControlKey As String, ByVal ControlTitle As String, ByVal ControlSrc As String, ByVal IconFile As String, ByVal ControlType As Integer, ByVal ViewOrder As Integer)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "UpdateModuleControl", _
                New OleDbParameter("@ModuleControlId", ModuleControlId), _
                New OleDbParameter("@ModuleDefId", GetNull(ModuleDefId)), _
                New OleDbParameter("@ControlKey", GetNull(ControlKey)), _
                New OleDbParameter("@ControlTitle", GetNull(ControlTitle)), _
                New OleDbParameter("@ControlSrc", ControlSrc), _
                New OleDbParameter("@IconFile", GetNull(IconFile)), _
                New OleDbParameter("@ControlType", ControlType), _
                New OleDbParameter("@ViewOrder", GetNull(ViewOrder)))
        End Sub
        Public Overrides Sub DeleteModuleControl(ByVal ModuleControlId As Integer)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "DeleteModuleControl", _
                New OleDbParameter("@ModuleControlId", ModuleControlId))
        End Sub

        ' files
        Public Overrides Function GetFiles(ByVal PortalId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetFiles", _
                New OleDbParameter("@PortalId", GetNull(PortalId))), IDataReader)
        End Function
        Public Overrides Function GetFile(ByVal FileName As String, ByVal PortalId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetFile", _
                New OleDbParameter("@FileName", FileName), _
                New OleDbParameter("@PortalId", GetNull(PortalId))), IDataReader)
        End Function
        Public Overrides Sub DeleteFile(ByVal FileName As String, ByVal PortalId As Integer)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "DeleteFile", _
                New OleDbParameter("@FileName", FileName), _
                New OleDbParameter("@PortalId", GetNull(PortalId)))
        End Sub
        Public Overrides Sub DeleteFiles(ByVal PortalId As Integer)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "DeleteFiles", _
                New OleDbParameter("@PortalId", GetNull(PortalId)))
        End Sub
        Public Overrides Function AddFile(ByVal PortalId As Integer, ByVal FileName As String, ByVal Extension As String, ByVal Size As String, ByVal Width As String, ByVal Height As String, ByVal ContentType As String) As Integer
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "AddFile", _
                New OleDbParameter("@PortalId", GetNull(PortalId)), _
                New OleDbParameter("@FileName", FileName), _
                New OleDbParameter("@Extension", Extension), _
                New OleDbParameter("@Size", Size), _
                New OleDbParameter("@WIdth", GetNull(Width)), _
                New OleDbParameter("@Height", GetNull(Height)), _
                New OleDbParameter("@ContentType", ContentType))

            'Fix for bug #253 DNN 2.0.3
            Dim FileId As Object
            FileId = OleDBHelper.ExecuteScalar(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetFileIdentity", _
                            New OleDbParameter("@PortalId", GetNull(PortalId)), _
                            New OleDbParameter("@FileName", FileName))
            If FileId Is DBNull.Value Then
                Return Null.NullInteger
            Else
                Return CType(FileId, Integer)
            End If

        End Function

        Public Overrides Sub UpdateFile(ByVal FileId As Integer, ByVal FileName As String, ByVal Extension As String, ByVal Size As String, ByVal Width As String, ByVal Height As String, ByVal ContentType As String)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "UpdateFile", _
                New OleDbParameter("@FileId", FileId), _
                New OleDbParameter("@FileName", FileName), _
                New OleDbParameter("@Extension", Extension), _
                New OleDbParameter("@Size", Size), _
                New OleDbParameter("@WIdth", GetNull(Width)), _
                New OleDbParameter("@Height", GetNull(Height)), _
                New OleDbParameter("@ContentType", ContentType))
        End Sub

        ' codes
        Public Overrides Function GetCountryCodes() As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetCountryCodes"), IDataReader)
        End Function
        Public Overrides Function GetCountry(ByVal Code As String, ByVal Description As String) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetCountry", _
                New OleDbParameter("@Code", GetNull(Code)), _
                New OleDbParameter("@Description", GetNull(Description))), IDataReader)
        End Function
        Public Overrides Function GetRegionCodes(ByVal Country As String) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetRegionCodes", _
                New OleDbParameter("@Country", Country)), IDataReader)
        End Function
        Public Overrides Function GetRegion(ByVal Code As String, ByVal Description As String) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetRegion", _
                New OleDbParameter("@Code", GetNull(Code)), _
                New OleDbParameter("@Description", GetNull(Description))), IDataReader)
        End Function
        Public Overrides Function GetCurrencies() As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetCurrencies"), IDataReader)
        End Function
        Public Overrides Function GetBillingFrequencyCodes() As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetBillingFrequencyCodes"), IDataReader)
        End Function
        Public Overrides Function GetBillingFrequencyCode(ByVal Code As String) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetBillingFrequencyCode", _
                New OleDbParameter("@Code", Code)), IDataReader)
        End Function
        Public Overrides Function GetProcessorCodes() As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetProcessorCodes"), IDataReader)
        End Function

        ' clicks
        Public Overrides Sub UpdateClicks(ByVal TableName As String, ByVal KeyField As String, ByVal ItemId As Integer, ByVal UserId As Integer)
            Dim SQL As String
            SQL += "UPDATE " & ObjectQualifier & TableName & " "
            SQL += "SET Clicks = Clicks + 1 "
            SQL += "WHERE " & KeyField & " = " & ItemId.ToString
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.Text, SQL)

            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "UpdateClicks", _
                New OleDbParameter("@TableName", ObjectQualifier & TableName), _
                New OleDbParameter("@ItemId", ItemId), _
                New OleDbParameter("@UserId", GetNull(UserId)))
        End Sub
        Public Overrides Function GetClicks(ByVal TableName As String, ByVal ItemId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetClicks", _
                New OleDbParameter("@TableName", ObjectQualifier & TableName), _
                New OleDbParameter("@ItemId", ItemId)), IDataReader)
        End Function

        ' site log
        Public Overrides Sub AddSiteLog(ByVal DateTime As Date, ByVal PortalId As Integer, ByVal UserId As Integer, ByVal Referrer As String, ByVal URL As String, ByVal UserAgent As String, ByVal UserHostAddress As String, ByVal UserHostName As String, ByVal TabId As Integer, ByVal AffiliateId As Integer)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "AddSiteLog", _
                New OleDbParameter("@DateTime", OleDbType.DBDate, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "DateTime", DataRowVersion.Original, DateTime), _
                New OleDbParameter("@PortalId", PortalId), _
                New OleDbParameter("@UserId", GetNull(UserId)), _
                New OleDbParameter("@Referrer", GetNull(Referrer)), _
                New OleDbParameter("@Url", GetNull(URL)), _
                New OleDbParameter("@UserAgent", GetNull(UserAgent)), _
                New OleDbParameter("@UserHostAddress", GetNull(UserHostAddress)), _
                New OleDbParameter("@UserHostName", GetNull(UserHostName)), _
                New OleDbParameter("@TabId", GetNull(TabId)), _
                New OleDbParameter("@AffiliateId", GetNull(AffiliateId)))
        End Sub
        Public Overrides Function GetSiteLog(ByVal PortalId As Integer, ByVal PortalAlias As String, ByVal ReportName As String, ByVal StartDate As Date, ByVal EndDate As Date) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & ReportName, _
                New OleDbParameter("@PortalId", PortalId), _
                New OleDbParameter("@PortalAlias", PortalAlias), _
                New OleDbParameter("@StartDate", OleDbType.DBDate, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "StartDate", DataRowVersion.Original, GetNull(StartDate)), _
                New OleDbParameter("@EndDate", OleDbType.DBDate, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "EndDate", DataRowVersion.Original, GetNull(EndDate))), IDataReader)
        End Function
        Public Overrides Function GetSiteLogReports() As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetSiteLogReports"), IDataReader)
        End Function
        Public Overrides Sub DeleteSiteLog(ByVal DateTime As Date, ByVal PortalId As Integer)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "DeleteSiteLog", _
                New OleDbParameter("@DateTime", OleDbType.DBDate, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "DateTime", DataRowVersion.Original, DateTime), _
                New OleDbParameter("@PortalId", PortalId))
        End Sub

        ' database
        Public Overrides Function ExecuteSQL(ByVal SQL As String) As IDataReader
            SQL = SQL.Replace("{objectQualifier}", ObjectQualifier)
            Try
                Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.Text, SQL), IDataReader)
            Catch
                ' error in SQL query
                Return Nothing
            End Try
        End Function
        Public Overrides Function GetTables() As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetTables"), IDataReader)
        End Function
        Public Overrides Function GetFields(ByVal TableName As String) As IDataReader
            Dim SQL As String = "SELECT * FROM {objectQualifier}" & TableName & " WHERE 1 = 0"
            Return ExecuteSQL(SQL)
        End Function

        ' announcements module
        Public Overrides Function GetAnnouncements(ByVal ModuleId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetAnnouncements", _
                New OleDbParameter("@ModuleId", ModuleId)), IDataReader)
        End Function
        Public Overrides Function GetAnnouncement(ByVal ItemId As Integer, ByVal ModuleId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetAnnouncement", _
                New OleDbParameter("@ItemId", ItemId), _
                New OleDbParameter("@ModuleId", ModuleId)), IDataReader)
        End Function
        Public Overrides Sub DeleteAnnouncement(ByVal ItemId As Integer)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "DeleteAnnouncement", _
                New OleDbParameter("@ItemId", ItemId))
        End Sub
        Public Overrides Function AddAnnouncement(ByVal ModuleId As Integer, ByVal UserName As String, ByVal Title As String, ByVal URL As String, ByVal Syndicate As Boolean, ByVal ExpireDate As Date, ByVal Description As String, ByVal ViewOrder As Integer) As Integer
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "AddAnnouncement", _
                New OleDbParameter("@ModuleId", ModuleId), _
                New OleDbParameter("@UserName", UserName), _
                New OleDbParameter("@Title", Title), _
                New OleDbParameter("@URL", URL), _
                New OleDbParameter("@Syndicate", Syndicate), _
                New OleDbParameter("@ExpireDate", OleDbType.DBDate, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "ExpireDate", DataRowVersion.Original, GetNull(ExpireDate)), _
                New OleDbParameter("@Description", Description), _
                New OleDbParameter("@ViewOrder", GetNull(ViewOrder)))

            Return CType(OleDBHelper.ExecuteScalar(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetAnnouncementIdentity", _
                New OleDbParameter("@ModuleId", ModuleId), _
                New OleDbParameter("@Title", Title)), Integer)
        End Function
        Public Overrides Sub UpdateAnnouncement(ByVal ItemId As Integer, ByVal UserName As String, ByVal Title As String, ByVal URL As String, ByVal Syndicate As Boolean, ByVal ExpireDate As Date, ByVal Description As String, ByVal ViewOrder As Integer)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "UpdateAnnouncement", _
                New OleDbParameter("@ItemId", ItemId), _
                New OleDbParameter("@UserName", UserName), _
                New OleDbParameter("@Title", Title), _
                New OleDbParameter("@URL", URL), _
                New OleDbParameter("@Syndicate", Syndicate), _
                New OleDbParameter("@ExpireDate", OleDbType.DBDate, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "ExpireDate", DataRowVersion.Original, GetNull(ExpireDate)), _
                New OleDbParameter("@Description", Description), _
                New OleDbParameter("@ViewOrder", GetNull(ViewOrder)))
        End Sub

        ' contacts module
        Public Overrides Function GetContacts(ByVal ModuleId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetContacts", _
                New OleDbParameter("@ModuleId", ModuleId)), IDataReader)
        End Function
        Public Overrides Function GetContact(ByVal ItemId As Integer, ByVal ModuleId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetContact", _
                New OleDbParameter("@ItemId", ItemId), _
                New OleDbParameter("@ModuleId", ModuleId)), IDataReader)
        End Function
        Public Overrides Sub DeleteContact(ByVal ItemId As Integer)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "DeleteContact", _
                New OleDbParameter("@ItemId", ItemId))
        End Sub
        Public Overrides Function AddContact(ByVal ModuleId As Integer, ByVal UserName As String, ByVal Name As String, ByVal Role As String, ByVal Email As String, ByVal Contact1 As String, ByVal Contact2 As String) As Integer
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "AddContact", _
                New OleDbParameter("@ModuleId", ModuleId), _
                New OleDbParameter("@UserName", UserName), _
                New OleDbParameter("@Name", Name), _
                New OleDbParameter("@Role", Role), _
                New OleDbParameter("@Email", Email), _
                New OleDbParameter("@Contact1", Contact1), _
                New OleDbParameter("@Contact2", Contact2))

            Return CType(OleDBHelper.ExecuteScalar(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetContactIdentity", _
                New OleDbParameter("@ModuleId", ModuleId), _
                New OleDbParameter("@Name", Name)), Integer)
        End Function
        Public Overrides Sub UpdateContact(ByVal ItemId As Integer, ByVal UserName As String, ByVal Name As String, ByVal Role As String, ByVal Email As String, ByVal Contact1 As String, ByVal Contact2 As String)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "UpdateContact", _
                New OleDbParameter("@ItemId", ItemId), _
                New OleDbParameter("@UserName", UserName), _
                New OleDbParameter("@Name", Name), _
                New OleDbParameter("@Role", Role), _
                New OleDbParameter("@Email", Email), _
                New OleDbParameter("@Contact1", Contact1), _
                New OleDbParameter("@Contact2", Contact2))
        End Sub

        ' discussions module
        Public Overrides Function GetTopLevelMessages(ByVal ModuleId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetTopLevelMessages", _
                New OleDbParameter("@ModuleId", ModuleId)), IDataReader)
        End Function
        Public Overrides Function GetThreadMessages(ByVal Parent As String) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetThreadMessages", _
                New OleDbParameter("@Parent", Parent)), IDataReader)
        End Function
        Public Overrides Function GetMessage(ByVal ItemId As Integer, ByVal ModuleId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetMessage", _
                New OleDbParameter("@ItemId", ItemId), _
                New OleDbParameter("@ModuleId", ModuleId)), IDataReader)
        End Function
        Public Overrides Sub DeleteMessage(ByVal ModuleId As Integer, ByVal Start As Integer, ByVal Parent As String)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "DeleteMessage", _
                New OleDbParameter("@ModuleId", ModuleId), _
                New OleDbParameter("@Start", Start), _
                New OleDbParameter("@Parent", Parent))
        End Sub
        Public Overrides Function AddMessage(ByVal Title As String, ByVal Body As String, ByVal DisplayOrder As String, ByVal UserName As String, ByVal ModuleId As Integer) As Integer
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "AddMessage", _
                New OleDbParameter("@Title", Title), _
                New OleDbParameter("@Body", Body), _
                New OleDbParameter("@DisplayOrder", DisplayOrder), _
                New OleDbParameter("@UserName", UserName), _
                New OleDbParameter("@ModuleId", ModuleId))

            Return CType(OleDBHelper.ExecuteScalar(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetMessageIdentity", _
                New OleDbParameter("@ModuleId", ModuleId), _
                New OleDbParameter("@Title", Title)), Integer)
        End Function
        Public Overrides Sub UpdateMessage(ByVal ItemId As Integer, ByVal Title As String, ByVal Body As String, ByVal UserName As String)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "UpdateMessage", _
                New OleDbParameter("@ItemId", ItemId), _
                New OleDbParameter("@Title", Title), _
                New OleDbParameter("@Body", Body), _
                New OleDbParameter("@UserName", UserName))
        End Sub
        Public Overrides Function GetMessageByParentId(ByVal ParentId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetMessageByParentId", _
                New OleDbParameter("@ParentId", ParentId)), IDataReader)
        End Function

        ' documents module
        Public Overrides Function GetDocuments(ByVal ModuleId As Integer, ByVal PortalId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetDocuments", _
                New OleDbParameter("@ModuleId", ModuleId), _
                New OleDbParameter("@PortalId", PortalId)), IDataReader)
        End Function
        Public Overrides Function GetDocument(ByVal ItemId As Integer, ByVal ModuleId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetDocument", _
                New OleDbParameter("@ItemId", ItemId), _
                New OleDbParameter("@ModuleId", ModuleId)), IDataReader)
        End Function
        Public Overrides Sub DeleteDocument(ByVal ItemId As Integer)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "DeleteDocument", _
                New OleDbParameter("@ItemId", ItemId))
        End Sub
        Public Overrides Function AddDocument(ByVal ModuleId As Integer, ByVal Title As String, ByVal URL As String, ByVal UserName As String, ByVal Category As String, ByVal Syndicate As Boolean) As Integer
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "AddDocument", _
                New OleDbParameter("@ModuleId", ModuleId), _
                New OleDbParameter("@Title", Title), _
                New OleDbParameter("@URL", URL), _
                New OleDbParameter("@UserName", UserName), _
                New OleDbParameter("@Category", Category), _
                New OleDbParameter("@Syndicate", Syndicate))

            Return CType(OleDBHelper.ExecuteScalar(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetDocumentIdentity", _
                New OleDbParameter("@ModuleId", ModuleId), _
                New OleDbParameter("@Title", Title)), Integer)
        End Function
        Public Overrides Sub UpdateDocument(ByVal ItemId As Integer, ByVal Title As String, ByVal URL As String, ByVal UserName As String, ByVal Category As String, ByVal Syndicate As Boolean)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "UpdateDocument", _
                New OleDbParameter("@ItemId", ItemId), _
                New OleDbParameter("@Title", Title), _
                New OleDbParameter("@URL", URL), _
                New OleDbParameter("@UserName", UserName), _
                New OleDbParameter("@Category", Category), _
                New OleDbParameter("@Syndicate", Syndicate))
        End Sub

        ' events module
        Public Overrides Function GetModuleEvents(ByVal ModuleId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetModuleEvents", _
                New OleDbParameter("@ModuleId", ModuleId)), IDataReader)
        End Function
        Public Overrides Function GetModuleEventsByDate(ByVal ModuleId As Integer, ByVal StartDate As Date, ByVal EndDate As Date) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetModuleEventsByDate", _
                New OleDbParameter("@ModuleId", ModuleId), _
                New OleDbParameter("@StartDate", OleDbType.DBDate, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "StartDate", DataRowVersion.Original, GetNull(StartDate)), _
                New OleDbParameter("@EndDate", OleDbType.DBDate, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "EndDate", DataRowVersion.Original, GetNull(EndDate))), IDataReader)
        End Function
        Public Overrides Function GetModuleEvent(ByVal ItemId As Integer, ByVal ModuleId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetModuleEvent", _
                New OleDbParameter("@ItemId", ItemId), _
                New OleDbParameter("@ModuleId", ModuleId)), IDataReader)
        End Function
        Public Overrides Sub DeleteModuleEvent(ByVal ItemId As Integer)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "DeleteModuleEvent", _
                New OleDbParameter("@ItemId", ItemId))
        End Sub
        Public Overrides Function AddModuleEvent(ByVal ModuleId As Integer, ByVal Description As String, ByVal DateTime As Date, ByVal Title As String, ByVal ExpireDate As Date, ByVal UserName As String, ByVal Every As Integer, ByVal Period As String, ByVal IconFile As String, ByVal AltText As String) As Integer
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "AddModuleEvent", _
                New OleDbParameter("@ModuleId", ModuleId), _
                New OleDbParameter("@Description", Description), _
                New OleDbParameter("@DateTime", OleDbType.DBDate, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "DateTime", DataRowVersion.Original, DateTime), _
                New OleDbParameter("@Title", Title), _
                New OleDbParameter("@ExpireDate", OleDbType.DBDate, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "Expiredate", DataRowVersion.Original, GetNull(ExpireDate)), _
                New OleDbParameter("@UserName", UserName), _
                New OleDbParameter("@Every", GetNull(Every)), _
                New OleDbParameter("@Period", GetNull(Period)), _
                New OleDbParameter("@IconFile", GetNull(IconFile)), _
                New OleDbParameter("@AltText", GetNull(AltText)))

            Return CType(OleDBHelper.ExecuteScalar(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetModuleEventIdentity", _
                New OleDbParameter("@ModuleId", ModuleId), _
                New OleDbParameter("@Title", Title)), Integer)
        End Function
        Public Overrides Sub UpdateModuleEvent(ByVal ItemId As Integer, ByVal Description As String, ByVal DateTime As Date, ByVal Title As String, ByVal ExpireDate As Date, ByVal UserName As String, ByVal Every As Integer, ByVal Period As String, ByVal IconFile As String, ByVal AltText As String)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "UpdateModuleEvent", _
                New OleDbParameter("@ItemId", ItemId), _
                New OleDbParameter("@Description", Description), _
                New OleDbParameter("@DateTime", OleDbType.DBDate, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "DateTime", DataRowVersion.Original, DateTime), _
                New OleDbParameter("@Title", Title), _
                New OleDbParameter("@ExpireDate", OleDbType.DBDate, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "Expiredate", DataRowVersion.Original, GetNull(ExpireDate)), _
                New OleDbParameter("@UserName", UserName), _
                New OleDbParameter("@Every", GetNull(Every)), _
                New OleDbParameter("@Period", GetNull(Period)), _
                New OleDbParameter("@IconFile", GetNull(IconFile)), _
                New OleDbParameter("@AltText", GetNull(AltText)))
        End Sub

        ' FAQ module
        Public Overrides Function GetFAQs(ByVal ModuleId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetFAQs", _
                New OleDbParameter("@ModuleId", ModuleId)), IDataReader)
        End Function
        Public Overrides Function GetFAQ(ByVal ItemId As Integer, ByVal ModuleId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetFAQ", _
                New OleDbParameter("@ItemId", ItemId), _
                New OleDbParameter("@ModuleId", ModuleId)), IDataReader)
        End Function
        Public Overrides Sub DeleteFAQ(ByVal ItemId As Integer)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "DeleteFAQ", _
                New OleDbParameter("@ItemId", ItemId))
        End Sub
        Public Overrides Function AddFAQ(ByVal ModuleId As Integer, ByVal UserName As String, ByVal Question As String, ByVal Answer As String) As Integer
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "AddFAQ", _
                New OleDbParameter("@ModuleId", ModuleId), _
                New OleDbParameter("@UserName", UserName), _
                New OleDbParameter("@Question", Question), _
                New OleDbParameter("@Answer", Answer))

            Return CType(OleDBHelper.ExecuteScalar(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetFAQIdentity", _
                New OleDbParameter("@ModuleId", ModuleId), _
                New OleDbParameter("@Question", Question)), Integer)
        End Function
        Public Overrides Sub UpdateFAQ(ByVal ItemId As Integer, ByVal UserName As String, ByVal Question As String, ByVal Answer As String)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "UpdateFAQ", _
                New OleDbParameter("@ItemId", ItemId), _
                New OleDbParameter("@UserName", UserName), _
                New OleDbParameter("@Question", Question), _
                New OleDbParameter("@Answer", Answer))
        End Sub

        ' HTML module
        Public Overrides Function GetHtmlText(ByVal moduleId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetHtmlText", _
                New OleDbParameter("@ModuleId", moduleId)), IDataReader)
        End Function
        Public Overrides Sub AddHtmlText(ByVal moduleId As Integer, ByVal desktopHtml As String, ByVal mobileSummary As String, ByVal mobileDetails As String)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "AddHtmlText", _
                New OleDbParameter("@ModuleId", moduleId), _
                New OleDbParameter("@DesktopHtml", desktopHtml), _
                New OleDbParameter("@MobileSummary", mobileSummary), _
                New OleDbParameter("@MobileDetails", mobileDetails))
        End Sub
        Public Overrides Sub UpdateHtmlText(ByVal moduleId As Integer, ByVal desktopHtml As String, ByVal mobileSummary As String, ByVal mobileDetails As String)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "UpdateHtmlText", _
                New OleDbParameter("@ModuleId", moduleId), _
                New OleDbParameter("@DesktopHtml", desktopHtml), _
                New OleDbParameter("@MobileSummary", mobileSummary), _
                New OleDbParameter("@MobileDetails", mobileDetails))
        End Sub

        ' links module
        Public Overrides Function GetLinks(ByVal ModuleId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetLinks", _
                New OleDbParameter("@ModuleId", ModuleId)), IDataReader)
        End Function
        Public Overrides Function GetLink(ByVal ItemId As Integer, ByVal ModuleId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetLink", _
                New OleDbParameter("@ItemId", ItemId), _
                New OleDbParameter("@ModuleId", ModuleId)), IDataReader)
        End Function
        Public Overrides Sub DeleteLink(ByVal ItemId As Integer)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "DeleteLink", _
                New OleDbParameter("@ItemId", ItemId))
        End Sub
        Public Overrides Function AddLink(ByVal ModuleId As Integer, ByVal UserName As String, ByVal Title As String, ByVal Url As String, ByVal MobileUrl As String, ByVal ViewOrder As String, ByVal Description As String, ByVal NewWindow As Boolean) As Integer
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "AddLink", _
                New OleDbParameter("@ModuleId", ModuleId), _
                New OleDbParameter("@UserName", UserName), _
                New OleDbParameter("@Title", Title), _
                New OleDbParameter("@Url", Url), _
                New OleDbParameter("@MobileUrl", MobileUrl), _
                New OleDbParameter("@ViewOrder", GetNull(ViewOrder)), _
                New OleDbParameter("@Description", Description), _
                New OleDbParameter("@NewWindow", NewWindow))

            Return CType(OleDBHelper.ExecuteScalar(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetLinkIdentity", _
                New OleDbParameter("@ModuleId", ModuleId), _
                New OleDbParameter("@Title", Title)), Integer)
        End Function
        Public Overrides Sub UpdateLink(ByVal ItemId As Integer, ByVal UserName As String, ByVal Title As String, ByVal Url As String, ByVal MobileUrl As String, ByVal ViewOrder As String, ByVal Description As String, ByVal NewWindow As Boolean)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "UpdateLink", _
                New OleDbParameter("@ItemId", ItemId), _
                New OleDbParameter("@UserName", UserName), _
                New OleDbParameter("@Title", Title), _
                New OleDbParameter("@Url", Url), _
                New OleDbParameter("@MobileUrl", MobileUrl), _
                New OleDbParameter("@ViewOrder", GetNull(ViewOrder)), _
                New OleDbParameter("@Description", Description), _
                New OleDbParameter("@NewWindow", NewWindow))
        End Sub

        ' search module
        Public Overrides Function GetSearchModule(ByVal ModuleId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetSearch", _
                New OleDbParameter("@ModuleId", ModuleId)), IDataReader)
        End Function
        Public Overrides Function AddSearch(ByVal ModuleId As Integer, ByVal TableName As String) As Integer
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "AddSearch", _
                New OleDbParameter("@ModuleId", ModuleId), _
                New OleDbParameter("@TableName", TableName))

            Return CType(OleDBHelper.ExecuteScalar(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetSearchIdentity", _
                New OleDbParameter("@ModuleId", ModuleId), _
                New OleDbParameter("@TableName", TableName)), Integer)
        End Function
        Public Overrides Function GetSearch(ByVal SearchId As Integer, ByVal ModuleId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetSearch", _
                New OleDbParameter("@SearchId", SearchId), _
                New OleDbParameter("@ModuleId", ModuleId)), IDataReader)
        End Function
        Public Overrides Sub UpdateSearch(ByVal SearchId As Integer, ByVal TitleField As String, ByVal DescriptionField As String, ByVal CreatedDateField As String, ByVal CreatedByUserField As String)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "UpdateSearch", _
                New OleDbParameter("@SearchId", SearchId), _
                New OleDbParameter("@TitleField", TitleField), _
                New OleDbParameter("@DescriptionField", DescriptionField), _
                New OleDbParameter("@CreatedDateField", CreatedDateField), _
                New OleDbParameter("@CreatedByUserField", CreatedByUserField))
        End Sub
        Public Overrides Sub DeleteSearch(ByVal SearchId As Integer)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "DeleteSearch", _
                New OleDbParameter("@SearchId", SearchId))
        End Sub
        Public Overrides Function GetSearchResults(ByVal PortalId As Integer, ByVal TableName As String, ByVal TitleField As String, ByVal DescriptionField As String, ByVal CreatedDateField As String, ByVal CreatedByUserField As String, ByVal Search As String) As IDataReader
            Dim SQL As String
            If PortalId = -1 Then
                SQL = "SELECT {objectQualifier}Tabs.TabId, {objectQualifier}Tabs.TabName, {objectQualifier}Tabs.AuthorizedRoles, {objectQualifier}Modules.ModuleId, {objectQualifier}Modules.ModuleTitle, {objectQualifier}Modules.AuthorizedViewRoles, NULL AS TitleField, NULL AS DescriptionField, NULL AS CreatedDateField, NULL AS CreatedByUserField "
                SQL += "FROM {objectQualifier}Modules "
                SQL += "INNER JOIN {objectQualifier}Tabs ON {objectQualifier}Modules.TabId = {objectQualifier}Tabs.TabId "
                SQL += "WHERE 1 = 0;"
            Else
                SQL = "SELECT {objectQualifier}Tabs.TabId, {objectQualifier}Tabs.TabName, {objectQualifier}Tabs.AuthorizedRoles, "
                SQL += "{objectQualifier}Modules.ModuleId, {objectQualifier}Modules.ModuleTitle, {objectQualifier}Modules.AuthorizedViewRoles, "
                SQL += String.Concat(IIf(TitleField = "", "NULL", TitleField), " AS TitleField, ")
                SQL += String.Concat(IIf(DescriptionField = "", "NULL", DescriptionField), " AS DescriptionField, ")
                SQL += String.Concat(IIf(CreatedDateField = "", "NULL", CreatedDateField), " AS CreatedDateField, ")
                If CreatedByUserField <> "" Then
                    SQL += "{objectQualifier}Users.FirstName + ' ' + {objectQualifier}Users.LastName AS CreatedByUserField"
                Else
                    SQL += "NULL AS CreatedByUserField"
                End If
                SQL += "FROM {objectQualifier}" & TableName & " "
                SQL += "inner join {objectQualifier}Modules on {objectQualifier}" & TableName & ".ModuleId = {objectQualifier}Modules.ModuleId "
                SQL += "inner join {objectQualifier}Tabs on {objectQualifier}Modules.TabId = {objectQualifier}Tabs.TabId "
                If CreatedByUserField <> "" Then
                    SQL += "left outer join {objectQualifier}Users on {objectQualifier}" & TableName & "." & CreatedByUserField & " = {objectQualifier}Users.UserId "
                End If
                SQL += "WHERE {objectQualifier}Tabs.PortalId = " & PortalId & " AND ( "
                SQL += String.Concat(IIf(TitleField = "", "''", TitleField), " LIKE '%" & Search & "%' OR ")
                SQL += String.Concat(IIf(DescriptionField = "", "''", DescriptionField), " LIKE '%" & Search & "%' )")
            End If
            Return ExecuteSQL(SQL)
        End Function

        ' security
        Public Overrides Function UserLogin(ByVal Username As String, ByVal Password As String) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "UserLogin", _
                New OleDbParameter("@Username", Username), _
                New OleDbParameter("@Password", Password)), IDataReader)
        End Function
        Public Overrides Function GetAuthRoles(ByVal PortalId As Integer, ByVal ModuleId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetAuthRoles", _
                New OleDbParameter("@PortalId", PortalId), _
                New OleDbParameter("@ModuleId", ModuleId)), IDataReader)
        End Function

        ' user defined table
        Public Overrides Function GetUserDefinedFields(ByVal ModuleId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetUserDefinedFields", _
                New OleDbParameter("@ModuleId", ModuleId)), IDataReader)
        End Function
        Public Overrides Function GetUserDefinedField(ByVal UserDefinedFieldId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetUserDefinedField", _
                New OleDbParameter("@UserDefinedFieldId", UserDefinedFieldId)), IDataReader)
        End Function
        Public Overrides Function GetUserDefinedRow(ByVal UserDefinedRowId As Integer, ByVal ModuleId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetUserDefinedRow", _
                New OleDbParameter("@UserDefinedRowId", UserDefinedRowId), _
                New OleDbParameter("@ModuleId", ModuleId)), IDataReader)
        End Function
        Public Overrides Sub DeleteUserDefinedField(ByVal UserDefinedFieldId As Integer)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "DeleteUserDefinedField", _
                New OleDbParameter("@UserDefinedFieldId", UserDefinedFieldId))
        End Sub
        Public Overrides Function AddUserDefinedField(ByVal ModuleId As Integer, ByVal FieldTitle As String, ByVal Visible As Boolean, ByVal FieldType As String) As Integer
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "AddUserDefinedField", _
                New OleDbParameter("@ModuleId", ModuleId), _
                New OleDbParameter("@FieldTitle", FieldTitle), _
                New OleDbParameter("@Visible", Visible), _
                New OleDbParameter("@FieldType", FieldType))

            Return CType(OleDBHelper.ExecuteScalar(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetUserDefinedFieldIdentity", _
                New OleDbParameter("@ModuleId", ModuleId), _
                New OleDbParameter("@FieldTitle", FieldTitle)), Integer)
        End Function
        Public Overrides Sub UpdateUserDefinedField(ByVal UserDefinedFieldId As Integer, ByVal FieldTitle As String, ByVal Visible As Boolean, ByVal FieldType As String)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "UpdateUserDefinedField", _
                New OleDbParameter("@UserDefinedFieldId", UserDefinedFieldId), _
                New OleDbParameter("@FieldTitle", FieldTitle), _
                New OleDbParameter("@Visible", Visible), _
                New OleDbParameter("@FieldType", FieldType))
        End Sub
        Public Overrides Function GetUserDefinedRows(ByVal ModuleId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetUserDefinedRows", _
                New OleDbParameter("@ModuleId", ModuleId)), IDataReader)
        End Function
        Public Overrides Sub DeleteUserDefinedRow(ByVal UserDefinedRowId As Integer)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "DeleteUserDefinedRow", _
                New OleDbParameter("@UserDefinedRowId", UserDefinedRowId))
        End Sub
        Public Overrides Function AddUserDefinedRow(ByVal ModuleId As Integer) As Integer
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "AddUserDefinedRow", _
                New OleDbParameter("@ModuleId", ModuleId))

            Return CType(OleDBHelper.ExecuteScalar(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetUserDefinedRowIdentity", _
                New OleDbParameter("@ModuleId", ModuleId)), Integer)
        End Function
        Public Overrides Function GetUserDefinedData(ByVal UserDefinedRowId As Integer, ByVal UserDefinedFieldId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetUserDefinedData", _
                New OleDbParameter("@UserDefinedRowId", UserDefinedRowId), _
                New OleDbParameter("@UserDefinedFieldId", UserDefinedFieldId)), IDataReader)
        End Function
        Public Overrides Function AddUserDefinedData(ByVal UserDefinedRowId As Integer, ByVal UserDefinedFieldId As Integer, ByVal FieldValue As String) As Integer
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "AddUserDefinedData", _
                New OleDbParameter("@UserDefinedRowId", UserDefinedRowId), _
                New OleDbParameter("@UserDefinedFieldId", UserDefinedFieldId), _
                New OleDbParameter("@FieldValue", FieldValue))

            Return CType(OleDBHelper.ExecuteScalar(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetUserDefinedDataIdentity", _
                New OleDbParameter("@UserDefinedRowId", UserDefinedRowId), _
                New OleDbParameter("@UserDefinedFieldId", UserDefinedFieldId)), Integer)
        End Function
        Public Overrides Sub UpdateUserDefinedData(ByVal UserDefinedRowId As Integer, ByVal UserDefinedFieldId As Integer, ByVal FieldValue As String)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "UpdateUserDefinedData", _
                New OleDbParameter("@UserDefinedRowId", UserDefinedRowId), _
                New OleDbParameter("@UserDefinedFieldId", UserDefinedFieldId), _
                New OleDbParameter("@FieldValue", GetNull(FieldValue)))
        End Sub
        Public Overrides Sub UpdateUserDefinedFieldOrder(ByVal UserDefinedFieldId As Integer, ByVal FieldOrder As Integer)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "UpdateUserDefinedFieldOrder", _
                New OleDbParameter("@UserDefinedFieldId", UserDefinedFieldId), _
                New OleDbParameter("@FieldOrder", FieldOrder))
        End Sub
        Public Overrides Sub DeleteUserDefinedData(ByVal UserDefinedRowId As Integer, ByVal UserDefinedFieldId As Integer)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "DeleteUserDefinedData", _
                New OleDbParameter("@UserDefinedRowId", UserDefinedRowId), _
                New OleDbParameter("@UserDefinedFieldId", UserDefinedFieldId))
        End Sub

        ' users
        Public Overrides Function AddUser(ByVal FirstName As String, ByVal LastName As String, ByVal Unit As String, ByVal Street As String, ByVal City As String, ByVal Region As String, ByVal PostalCode As String, ByVal Country As String, ByVal Telephone As String, ByVal Email As String, ByVal Username As String, ByVal Password As String, ByVal AffiliateId As Integer) As Integer
            Try
                OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "AddUser", _
                    New OleDbParameter("@FirstName", FirstName), _
                    New OleDbParameter("@LastName", LastName), _
                    New OleDbParameter("@Unit", Unit), _
                    New OleDbParameter("@Street", Street), _
                    New OleDbParameter("@City", City), _
                    New OleDbParameter("@Region", Region), _
                    New OleDbParameter("@PostalCode", PostalCode), _
                    New OleDbParameter("@Country", Country), _
                    New OleDbParameter("@Telephone", Telephone), _
                    New OleDbParameter("@Email", Email), _
                    New OleDbParameter("@Username", Username), _
                    New OleDbParameter("@Password", Password), _
                    New OleDbParameter("@AffiliateId", GetNull(AffiliateId)))

                Return CType(OleDBHelper.ExecuteScalar(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetUserIdentity", _
                    New OleDbParameter("@Username", Username), _
                    New OleDbParameter("@Password", Password)), Integer)
            Catch ' duplicate
                Return -1
            End Try
        End Function
        Public Overrides Function AddPortalUser(ByVal PortalId As Integer, ByVal UserId As Integer, ByVal Authorized As Boolean) As Integer
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "AddPortalUser", _
                New OleDbParameter("@PortalId", PortalId), _
                New OleDbParameter("@UserId", UserId), _
                New OleDbParameter("@Authorized", Authorized))

            Return CType(OleDBHelper.ExecuteScalar(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetPortalUserIdentity", _
                New OleDbParameter("@PortalId", PortalId), _
                New OleDbParameter("@UserId", UserId)), Integer)
        End Function
        Public Overrides Sub DeletePortalUser(ByVal PortalId As Integer, ByVal UserId As Integer)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "DeletePortalUser", _
                New OleDbParameter("@PortalId", PortalId), _
                New OleDbParameter("@UserId", UserId))
        End Sub
        Public Overrides Sub UpdatePortalUser(ByVal PortalId As Integer, ByVal UserId As Integer, ByVal Authorized As Boolean, ByVal LastLoginDate As Date)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "UpdatePortalUser", _
                New OleDbParameter("@PortalId", PortalId), _
                New OleDbParameter("@UserId", UserId), _
                New OleDbParameter("@Authorized", Authorized), _
                New OleDbParameter("@LastLoginDate", OleDbType.DBDate, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "LastLoginDate", DataRowVersion.Original, GetNull(LastLoginDate)))
        End Sub
        Public Overrides Sub DeleteUser(ByVal UserId As Integer)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "DeleteUser", _
                New OleDbParameter("@UserId", UserId))
        End Sub
        Public Overrides Sub UpdateUser(ByVal UserId As Integer, ByVal FirstName As String, ByVal LastName As String, ByVal Unit As String, ByVal Street As String, ByVal City As String, ByVal Region As String, ByVal PostalCode As String, ByVal Country As String, ByVal Telephone As String, ByVal Email As String, ByVal Username As String, ByVal Password As String)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "UpdateUser", _
                New OleDbParameter("@UserId", UserId), _
                New OleDbParameter("@FirstName", FirstName), _
                New OleDbParameter("@LastName", LastName), _
                New OleDbParameter("@Unit", Unit), _
                New OleDbParameter("@Street", Street), _
                New OleDbParameter("@City", City), _
                New OleDbParameter("@Region", Region), _
                New OleDbParameter("@PostalCode", PostalCode), _
                New OleDbParameter("@Country", Country), _
                New OleDbParameter("@Telephone", Telephone), _
                New OleDbParameter("@Email", Email), _
                New OleDbParameter("@Username", Username), _
                New OleDbParameter("@Password", GetNull(Password)))
        End Sub
        Public Overrides Function GetUser(ByVal PortalId As Integer, ByVal UserId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetUser", _
                New OleDbParameter("@PortalId", PortalId), _
                New OleDbParameter("@UserId", UserId)), IDataReader)
        End Function
        Public Overrides Function GetUserByUsername(ByVal PortalId As Integer, ByVal Username As String) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetUserByUsername", _
                New OleDbParameter("@PortalId", GetNull(PortalId)), _
                New OleDbParameter("@Username", Username)), IDataReader)
        End Function
        Public Overrides Function GetRolesByUser(ByVal UserId As Integer, ByVal PortalId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetRolesByUser", _
                New OleDbParameter("@UserId", UserId), _
                New OleDbParameter("@PortalId", PortalId)), IDataReader)
        End Function
        Public Overrides Function GetPortalRoles(ByVal PortalId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetPortalRoles", _
                New OleDbParameter("@PortalId", PortalId)), IDataReader)
        End Function
        Public Overrides Function GetRole(ByVal RoleId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetRole", _
                New OleDbParameter("@RoleId", RoleId)), IDataReader)
        End Function
        Public Overrides Function AddRole(ByVal PortalId As Integer, ByVal RoleName As String, ByVal Description As String, ByVal ServiceFee As Double, ByVal BillingPeriod As String, ByVal BillingFrequency As String, ByVal TrialFee As Double, ByVal TrialPeriod As Integer, ByVal TrialFrequency As String, ByVal IsPublic As Boolean, ByVal AutoAssignment As Boolean) As Integer
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "AddRole", _
                New OleDbParameter("@PortalId", PortalId), _
                New OleDbParameter("@RoleName", RoleName), _
                New OleDbParameter("@Description", Description), _
                New OleDbParameter("@ServiceFee", ServiceFee), _
                New OleDbParameter("@BillingPeriod", BillingPeriod), _
                New OleDbParameter("@BillingFrequency", GetNull(BillingFrequency)), _
                New OleDbParameter("@TrialFee", TrialFee), _
                New OleDbParameter("@TrialPeriod", TrialPeriod), _
                New OleDbParameter("@TrialFrequency", GetNull(TrialFrequency)), _
                New OleDbParameter("@IsPublic", IsPublic), _
                New OleDbParameter("@AutoAssignment", AutoAssignment))

            Return CType(OleDBHelper.ExecuteScalar(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetRoleIdentity", _
                New OleDbParameter("@PortalId", PortalId), _
                New OleDbParameter("@RoleName", RoleName)), Integer)
        End Function
        Public Overrides Sub DeleteRole(ByVal RoleId As Integer)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "DeleteRole", _
                New OleDbParameter("@RoleId", RoleId))
        End Sub
        Public Overrides Sub UpdateRole(ByVal RoleId As Integer, ByVal RoleName As String, ByVal Description As String, ByVal ServiceFee As Double, ByVal BillingPeriod As String, ByVal BillingFrequency As String, ByVal TrialFee As Double, ByVal TrialPeriod As Integer, ByVal TrialFrequency As String, ByVal IsPublic As Boolean, ByVal AutoAssignment As Boolean)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "UpdateRole", _
                New OleDbParameter("@RoleId", RoleId), _
                New OleDbParameter("@RoleName", RoleName), _
                New OleDbParameter("@Description", Description), _
                New OleDbParameter("@ServiceFee", ServiceFee), _
                New OleDbParameter("@BillingPeriod", BillingPeriod), _
                New OleDbParameter("@BillingFrequency", GetNull(BillingFrequency)), _
                New OleDbParameter("@TrialFee", TrialFee), _
                New OleDbParameter("@TrialPeriod", TrialPeriod), _
                New OleDbParameter("@TrialFrequency", GetNull(TrialFrequency)), _
                New OleDbParameter("@IsPublic", IsPublic), _
                New OleDbParameter("@AutoAssignment", AutoAssignment))
        End Sub
        Public Overrides Function GetRoleMembership(ByVal PortalId As Integer, ByVal RoleId As Integer, ByVal UserId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetRoleMembership", _
                New OleDbParameter("@PortalId", PortalId), _
                New OleDbParameter("@RoleId", GetNull(RoleId)), _
                New OleDbParameter("@UserId", GetNull(UserId))), IDataReader)
        End Function
        Public Overrides Function IsUserInRole(ByVal UserId As Integer, ByVal RoleId As Integer, ByVal PortalId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "IsUserInRole", _
                New OleDbParameter("@UserId", UserId), _
                New OleDbParameter("@RoleId", RoleId), _
                New OleDbParameter("@PortalId", PortalId)), IDataReader)
        End Function
        Public Overrides Function GetUserRole(ByVal PortalId As Integer, ByVal UserId As Integer, ByVal RoleId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetUserRole", _
                New OleDbParameter("@PortalId", PortalId), _
                New OleDbParameter("@UserId", UserId), _
                New OleDbParameter("@RoleId", RoleId)), IDataReader)
        End Function
        Public Overrides Function AddUserRole(ByVal PortalId As Integer, ByVal UserId As Integer, ByVal RoleId As Integer, ByVal ExpiryDate As Date) As Integer
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "AddUserRole", _
                New OleDbParameter("@PortalId", PortalId), _
                New OleDbParameter("@UserId", UserId), _
                New OleDbParameter("@RoleId", RoleId), _
                New OleDbParameter("@ExpiryDate", OleDbType.DBDate, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "Expirydate", DataRowVersion.Original, GetNull(ExpiryDate)))

            Return CType(OleDBHelper.ExecuteScalar(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetUserRoleIdentity", _
                New OleDbParameter("@UserId", UserId), _
                New OleDbParameter("@RoleId", RoleId)), Integer)
        End Function
        Public Overrides Sub UpdateUserRole(ByVal UserRoleId As Integer, ByVal ExpiryDate As Date)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "UpdateUserRole", _
                New OleDbParameter("@UserRoleId", UserRoleId), _
                New OleDbParameter("@ExpiryDate", OleDbType.DBDate, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "Expirydate", DataRowVersion.Original, GetNull(ExpiryDate)))
        End Sub
        Public Overrides Sub DeleteUserRole(ByVal UserId As Integer, ByVal RoleId As Integer)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "DeleteUserRole", _
                New OleDbParameter("@UserId", UserId), _
                New OleDbParameter("@RoleId", RoleId))
        End Sub
        Public Overrides Function GetServices(ByVal PortalId As Integer, ByVal UserId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetServices", _
                New OleDbParameter("@PortalId", PortalId), _
                New OleDbParameter("@UserId", GetNull(UserId))), IDataReader)
        End Function
        Public Overrides Function GetUsers(ByVal PortalId As Integer, ByVal Filter As String) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetUsers", _
                New OleDbParameter("@PortalId", GetNull(PortalId)), _
                New OleDbParameter("@Filter", Filter)), IDataReader)
        End Function
        Public Overrides Function GetPortalUsers(ByVal PortalId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetPortalUsers", _
                New OleDbParameter("@PortalId", PortalId)), IDataReader)
        End Function
        Public Overrides Function GetPortalUser(ByVal PortalId As Integer, ByVal UserId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetPortalUser", _
                New OleDbParameter("@PortalId", PortalId), _
                New OleDbParameter("@UserId", UserId)), IDataReader)
        End Function
        Public Overrides Function GetUserPortals(ByVal UserId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetUserPortals", _
                New OleDbParameter("@UserId", UserId)), IDataReader)
        End Function

        ' vendors
        Public Overrides Function GetVendors(ByVal PortalId As Integer, ByVal Filter As String) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetVendors", _
                New OleDbParameter("@PortalId", GetNull(PortalId)), _
                New OleDbParameter("@Filter", Filter)), IDataReader)
        End Function
        Public Overrides Function GetVendor(ByVal VendorId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetVendor", _
                New OleDbParameter("@VendorId", VendorId)), IDataReader)
        End Function
        Public Overrides Sub DeleteVendor(ByVal VendorId As Integer)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "DeleteVendor", _
                New OleDbParameter("@VendorId", VendorId))
        End Sub
        Public Overrides Function AddVendor(ByVal PortalId As Integer, ByVal VendorName As String, ByVal Unit As String, ByVal Street As String, ByVal City As String, ByVal Region As String, ByVal Country As String, ByVal PostalCode As String, ByVal Telephone As String, ByVal Fax As String, ByVal Email As String, ByVal Website As String, ByVal FirstName As String, ByVal LastName As String, ByVal UserName As String, ByVal LogoFile As String, ByVal KeyWords As String, ByVal Authorized As String) As Integer
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "AddVendor", _
                New OleDbParameter("@PortalId", GetNull(PortalId)), _
                New OleDbParameter("@VendorName", VendorName), _
                New OleDbParameter("@Unit", Unit), _
                New OleDbParameter("@Street", Street), _
                New OleDbParameter("@City", City), _
                New OleDbParameter("@Region", Region), _
                New OleDbParameter("@Country", Country), _
                New OleDbParameter("@PostalCode", PostalCode), _
                New OleDbParameter("@Telephone", Telephone), _
                New OleDbParameter("@Fax", Fax), _
                New OleDbParameter("@Email", Email), _
                New OleDbParameter("@Website", Website), _
                New OleDbParameter("@FirstName", FirstName), _
                New OleDbParameter("@LastName", LastName), _
                New OleDbParameter("@UserName", UserName), _
                New OleDbParameter("@LogoFile", LogoFile), _
                New OleDbParameter("@KeyWords", KeyWords), _
                New OleDbParameter("@Authorized", Boolean.Parse(Authorized)))

            Return CType(OleDBHelper.ExecuteScalar(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetVendorIdentity", _
                New OleDbParameter("@PortalId", GetNull(PortalId)), _
                New OleDbParameter("@VendorName", VendorName)), Integer)
        End Function
        Public Overrides Sub UpdateVendor(ByVal VendorId As Integer, ByVal VendorName As String, ByVal Unit As String, ByVal Street As String, ByVal City As String, ByVal Region As String, ByVal Country As String, ByVal PostalCode As String, ByVal Telephone As String, ByVal Fax As String, ByVal Email As String, ByVal Website As String, ByVal FirstName As String, ByVal LastName As String, ByVal UserName As String, ByVal LogoFile As String, ByVal KeyWords As String, ByVal Authorized As String)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "UpdateVendor", _
                New OleDbParameter("@VendorId", VendorId), _
                New OleDbParameter("@VendorName", VendorName), _
                New OleDbParameter("@Unit", Unit), _
                New OleDbParameter("@Street", Street), _
                New OleDbParameter("@City", City), _
                New OleDbParameter("@Region", Region), _
                New OleDbParameter("@Country", Country), _
                New OleDbParameter("@PostalCode", PostalCode), _
                New OleDbParameter("@Telephone", Telephone), _
                New OleDbParameter("@Fax", Fax), _
                New OleDbParameter("@Email", Email), _
                New OleDbParameter("@Website", Website), _
                New OleDbParameter("@FirstName", FirstName), _
                New OleDbParameter("@LastName", LastName), _
                New OleDbParameter("@UserName", UserName), _
                New OleDbParameter("@LogoFile", LogoFile), _
                New OleDbParameter("@KeyWords", KeyWords), _
                New OleDbParameter("@Authorized", Boolean.Parse(Authorized)))
        End Sub
        Public Overrides Function FindBanners(ByVal PortalId As Integer, ByVal BannerTypeId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "FindBanners", _
                New OleDbParameter("@PortalId", GetNull(PortalId)), _
                New OleDbParameter("@BannerTypeId", BannerTypeId)), IDataReader)
        End Function
        Public Overrides Sub UpdateBannerViews(ByVal BannerId As Integer, ByVal Views As Integer, ByVal StartDate As Date, ByVal EndDate As Date)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "UpdateBannerViews", _
                New OleDbParameter("@BannerId", BannerId), _
                New OleDbParameter("@Views", Views), _
                New OleDbParameter("@StartDate", OleDbType.DBDate, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "StartDate", DataRowVersion.Original, GetNull(StartDate)), _
                New OleDbParameter("@EndDate", OleDbType.DBDate, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "EndDate", DataRowVersion.Original, GetNull(EndDate)))
        End Sub
        Public Overrides Sub UpdateBannerClickThrough(ByVal BannerId As Integer, ByVal VendorId As Integer)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "UpdateBannerClickThrough", _
                New OleDbParameter("@BannerId", BannerId), _
                New OleDbParameter("@VendorId", VendorId))
        End Sub
        Public Overrides Function GetBanners(ByVal VendorId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetBanners", _
                New OleDbParameter("@VendorId", VendorId)), IDataReader)
        End Function
        Public Overrides Function GetBanner(ByVal BannerId As Integer, ByVal VendorId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetBanner", _
                New OleDbParameter("@BannerId", BannerId), _
                New OleDbParameter("@VendorId", VendorId)), IDataReader)
        End Function
        Public Overrides Sub DeleteBanner(ByVal BannerId As Integer)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "DeleteBanner", _
                New OleDbParameter("@BannerId", BannerId))
        End Sub
        Public Overrides Function AddBanner(ByVal BannerName As String, ByVal VendorId As Integer, ByVal ImageFile As String, ByVal URL As String, ByVal Impressions As Integer, ByVal CPM As Double, ByVal StartDate As Date, ByVal EndDate As Date, ByVal UserName As String, ByVal BannerTypeId As Integer) As Integer
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "AddBanner", _
                New OleDbParameter("@BannerName", BannerName), _
                New OleDbParameter("@VendorId", VendorId), _
                New OleDbParameter("@ImageFile", ImageFile), _
                New OleDbParameter("@URL", GetNull(URL)), _
                New OleDbParameter("@Impressions", Impressions), _
                New OleDbParameter("@CPM", CPM), _
                New OleDbParameter("@StartDate", OleDbType.DBDate, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "StartDate", DataRowVersion.Original, GetNull(StartDate)), _
                New OleDbParameter("@EndDate", OleDbType.DBDate, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "EndDate", DataRowVersion.Original, GetNull(EndDate)), _
                New OleDbParameter("@UserName", UserName), _
                New OleDbParameter("@BannerTypeId", BannerTypeId))

            Return CType(OleDBHelper.ExecuteScalar(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetBannerIdentity", _
                New OleDbParameter("@VendorId", VendorId), _
                New OleDbParameter("@BannerName", BannerName)), Integer)
        End Function
        Public Overrides Sub UpdateBanner(ByVal BannerId As Integer, ByVal BannerName As String, ByVal ImageFile As String, ByVal URL As String, ByVal Impressions As Integer, ByVal CPM As Double, ByVal StartDate As Date, ByVal EndDate As Date, ByVal UserName As String, ByVal BannerTypeId As Integer)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "UpdateBanner", _
                New OleDbParameter("@BannerId", BannerId), _
                New OleDbParameter("@BannerName", BannerName), _
                New OleDbParameter("@ImageFile", ImageFile), _
                New OleDbParameter("@URL", GetNull(URL)), _
                New OleDbParameter("@Impressions", Impressions), _
                New OleDbParameter("@CPM", CPM), _
                New OleDbParameter("@StartDate", OleDbType.DBDate, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "StartDate", DataRowVersion.Original, GetNull(StartDate)), _
                New OleDbParameter("@EndDate", OleDbType.DBDate, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "EndDate", DataRowVersion.Original, GetNull(EndDate)), _
                New OleDbParameter("@UserName", UserName), _
                New OleDbParameter("@BannerTypeId", BannerTypeId))
        End Sub
        Public Overrides Function GetBannerTypes() As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetBannerTypes"), IDataReader)
        End Function
        Public Overrides Function GetVendorClassifications(ByVal VendorId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetVendorClassifications", _
                New OleDbParameter("@VendorId", GetNull(VendorId))), IDataReader)
        End Function
        Public Overrides Sub DeleteVendorClassifications(ByVal VendorId As Integer)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "DeleteVendorClassifications", _
                New OleDbParameter("@VendorId", VendorId))
        End Sub
        Public Overrides Function AddVendorClassification(ByVal VendorId As Integer, ByVal ClassificationId As Integer) As Integer
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "AddVendorClassification", _
                New OleDbParameter("@VendorId", VendorId), _
                New OleDbParameter("@ClassificationId", ClassificationId))

            Return CType(OleDBHelper.ExecuteScalar(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetVendorClassificationIdentity", _
                New OleDbParameter("@VendorId", VendorId), _
                New OleDbParameter("@ClassificationId", ClassificationId)), Integer)
        End Function
        Public Overrides Function GetAffiliates(ByVal VendorId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetAffiliates", _
                New OleDbParameter("@VendorId", VendorId)), IDataReader)
        End Function
        Public Overrides Function GetAffiliate(ByVal AffiliateId As Integer, ByVal VendorId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetAffiliate", _
                New OleDbParameter("@AffiliateId", AffiliateId)), IDataReader)
        End Function
        Public Overrides Sub DeleteAffiliate(ByVal AffiliateId As Integer)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "DeleteAffiliate", _
                New OleDbParameter("@AffiliateId", AffiliateId))
        End Sub
        Public Overrides Function AddAffiliate(ByVal VendorId As Integer, ByVal StartDate As Date, ByVal EndDate As Date, ByVal CPC As Double, ByVal CPA As Double) As Integer
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "AddAffiliate", _
                New OleDbParameter("@VendorId", VendorId), _
                New OleDbParameter("@StartDate", OleDbType.DBDate, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "StartDate", DataRowVersion.Original, GetNull(StartDate)), _
                New OleDbParameter("@EndDate", OleDbType.DBDate, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "EndDate", DataRowVersion.Original, GetNull(EndDate)), _
                New OleDbParameter("@CPC", CPC), _
                New OleDbParameter("@CPA", CPA))

            Return CType(OleDBHelper.ExecuteScalar(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetAffiliateIdentity", _
                New OleDbParameter("@VendorId", VendorId)), Integer)
        End Function
        Public Overrides Sub UpdateAffiliate(ByVal AffiliateId As Integer, ByVal StartDate As Date, ByVal EndDate As Date, ByVal CPC As Double, ByVal CPA As Double)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "UpdateAffiliate", _
                New OleDbParameter("@AffiliateId", AffiliateId), _
                New OleDbParameter("@StartDate", OleDbType.DBDate, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "StartDate", DataRowVersion.Original, GetNull(StartDate)), _
                New OleDbParameter("@EndDate", OleDbType.DBDate, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "EndDate", DataRowVersion.Original, GetNull(EndDate)), _
                New OleDbParameter("@CPC", CPC), _
                New OleDbParameter("@CPA", CPA))
        End Sub
        Public Overrides Sub UpdateAffiliateStats(ByVal AffiliateId As Integer, ByVal Clicks As Integer, ByVal Acquisitions As Integer)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "UpdateAffiliateStats", _
                New OleDbParameter("@AffiliateId", AffiliateId), _
                New OleDbParameter("@Clicks", Clicks), _
                New OleDbParameter("@Acquisitions", Acquisitions))
        End Sub

        ' skins/containers
        Public Overrides Function GetSkin(ByVal SkinRoot As String, ByVal PortalId As Integer, ByVal TabId As Integer, ByVal ModuleId As Integer, ByVal IsAdmin As Boolean) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetSkin", _
                New OleDbParameter("@SkinRoot", SkinRoot), _
                New OleDbParameter("@PortalId", GetNull(PortalId)), _
                New OleDbParameter("@TabId", GetNull(TabId)), _
                New OleDbParameter("@ModuleId", GetNull(ModuleId)), _
                New OleDbParameter("@IsAdmin", IsAdmin)), IDataReader)
        End Function
        Public Overrides Sub DeleteSkin(ByVal SkinRoot As String, ByVal PortalId As Integer, ByVal TabId As Integer, ByVal ModuleId As Integer, ByVal IsAdmin As Boolean)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "DeleteSkin", _
                New OleDbParameter("@SkinRoot", SkinRoot), _
                New OleDbParameter("@PortalId", GetNull(PortalId)), _
                New OleDbParameter("@TabId", GetNull(TabId)), _
                New OleDbParameter("@ModuleId", GetNull(ModuleId)), _
                New OleDbParameter("@IsAdmin", IsAdmin))
        End Sub
        Public Overrides Function AddSkin(ByVal SkinRoot As String, ByVal PortalId As Integer, ByVal TabId As Integer, ByVal ModuleId As Integer, ByVal IsAdmin As Boolean, ByVal SkinType As String, ByVal SkinName As String, ByVal SkinSrc As String) As Integer
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "AddSkin", _
                New OleDbParameter("@SkinRoot", SkinRoot), _
                New OleDbParameter("@PortalId", GetNull(PortalId)), _
                New OleDbParameter("@TabId", GetNull(TabId)), _
                New OleDbParameter("@ModuleId", GetNull(ModuleId)), _
                New OleDbParameter("@IsAdmin", IsAdmin), _
                New OleDbParameter("@SkinType", SkinType), _
                New OleDbParameter("@SkinName", SkinName), _
                New OleDbParameter("@SkinSrc", SkinSrc))

            Return CType(OleDBHelper.ExecuteScalar(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetSkinIdentity", _
                New OleDbParameter("@SkinRoot", SkinRoot), _
                New OleDbParameter("@PortalId", GetNull(PortalId)), _
                New OleDbParameter("@TabId", GetNull(TabId)), _
                New OleDbParameter("@ModuleId", GetNull(ModuleId)), _
                New OleDbParameter("@IsAdmin", IsAdmin)), Integer)
        End Function

        ' personalization
        Public Overrides Function GetProfile(ByVal UserId As Integer, ByVal PortalId As Integer) As IDataReader
            Return CType(OleDBHelper.ExecuteReader(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetProfile", _
                New OleDbParameter("@UserId", UserId), _
                New OleDbParameter("@PortalId", PortalId)), IDataReader)
        End Function
        Public Overrides Sub AddProfile(ByVal UserId As Integer, ByVal PortalId As Integer)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "AddProfile", _
                New OleDbParameter("@UserId", UserId), _
                New OleDbParameter("@PortalId", PortalId))
        End Sub
        Public Overrides Sub UpdateProfile(ByVal UserId As Integer, ByVal PortalId As Integer, ByVal ProfileData As String)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "UpdateProfile", _
                New OleDbParameter("@UserId", UserId), _
                New OleDbParameter("@PortalId", PortalId), _
                New OleDbParameter("@ProfileData", ProfileData))
        End Sub

        ' users online
        Public Overrides Sub UpdateUsersOnline(ByVal UserList As Hashtable)

            If (UserList.Count = 0) Then
                'No users to process, quit method
                Return
            End If
            For Each key As String In UserList.Keys
                If TypeOf UserList(key) Is AnonymousUserInfo Then
                    Dim user As AnonymousUserInfo = CType(UserList(key), AnonymousUserInfo)
                    Dim queryName As String = "UpdateAnonymousUser"
                    If Not (IsAnonymousUserCreated(user.UserID, user.PortalID)) Then
                        queryName = "AddAnonymousUser"
                    End If
                    OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & queryName, _
                        New OleDbParameter("@UserId", user.UserID), _
                        New OleDbParameter("@PortalId", user.PortalID), _
                        New OleDbParameter("@TabId", user.TabID), _
                        New OleDbParameter("@LastActiveDate", OleDbType.Date, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "LastActiveDate", DataRowVersion.Original, User.LastActiveDate))
                ElseIf TypeOf UserList(key) Is OnlineUserInfo Then
                    Dim user As OnlineUserInfo = CType(UserList(key), OnlineUserInfo)
                    Dim queryName As String = "UpdateOnlineUser"
                    If Not (IsOnlineUserCreated(user.UserID, user.PortalID)) Then
                        queryName = "AddOnlineUser"
                    End If
                    OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & queryName, _
                        New OleDbParameter("@UserId", user.UserID), _
                        New OleDbParameter("@PortalId", user.PortalID), _
                        New OleDbParameter("@TabId", user.TabID), _
                        New OleDbParameter("@LastActiveDate", OleDbType.Date, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "LastActiveDate", DataRowVersion.Original, User.LastActiveDate))
                End If
            Next
        End Sub
        Private Function IsOnlineUserCreated(ByVal userId As Integer, ByVal portalId As Integer) As Boolean
            If (CType(OleDBHelper.ExecuteScalar(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetOnlineUser", _
                New OleDbParameter("@UserId", userId), New OleDbParameter("@PortalId", portalId)), Integer) > 0) Then
                Return True
            Else
                Return False
            End If
        End Function
        Private Function IsAnonymousUserCreated(ByVal userId As String, ByVal portalId As Integer) As Boolean
            If (CType(OleDBHelper.ExecuteScalar(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "GetAnonymousUser", _
                New OleDbParameter("@UserId", userId), New OleDbParameter("@PortalId", portalId)), Integer) > 0) Then
                Return True
            Else
                Return False
            End If
        End Function
        Public Overrides Sub DeleteUsersOnline(ByVal TimeWindow As Integer)
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "DeleteAnonymousUsers", _
                New OleDbParameter("@LastActiveDate", OleDbType.Date, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "LastActiveDate", DataRowVersion.Original, DateTime.Now.AddMinutes(TimeWindow * -1)))
            OleDBHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, ObjectQualifier & "DeleteUsersOnline", _
               New OleDbParameter("@LastActiveDate", OleDbType.Date, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "LastActiveDate", DataRowVersion.Original, DateTime.Now.AddMinutes(TimeWindow * -1)))
        End Sub

    End Class

End Namespace