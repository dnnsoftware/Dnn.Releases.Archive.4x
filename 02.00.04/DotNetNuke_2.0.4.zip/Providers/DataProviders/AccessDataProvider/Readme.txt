AccessDataProvider

To be used with MS Access.

Static Attributes:

name = "AccessDataProvider" 
type = "DotNetNuke.Data.AccessDataProvider, DotNetNuke.AccessDataProvider" 

Dynamic Attributes:

connectionString = "PROVIDER=Microsoft.Jet.OLEDB.4.0;"

- identifies the provider to be used for connecting to the database. The other connection string properties will be appended at runtime.

providerPath = "~\Providers\DataProviders\AccessDataProvider\"

- the path which identifies the location of the database file and SQL script files.

objectQualifier = "DotNetNuke" 

- the unique qualifier for database objects ( tables, queries, etc... )

databaseFilename = "DotNetNuke.mdb.resources"

- the filename of the database. The ".resources" extension is used to secure the file from anonymous download.
