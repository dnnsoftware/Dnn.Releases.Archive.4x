'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2008
' by DotNetNuke Corporation
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.IO
Imports System.Web
Imports System.Reflection
Imports System.Threading
Imports DotNetNuke.Common.Utilities
Imports DotNetNuke.Framework.Providers
Imports DotNetNuke.Common
Imports DotNetNuke.Services.Exceptions
Imports System.Web.Caching
Imports System.Xml.Serialization
Imports System.Text

Namespace DotNetNuke.Services.Cache.FileBasedCachingProvider

    Public Class FBCachingProvider
        Inherits CachingProvider

        Private Const ProviderType As String = "caching"
        Private _providerConfiguration As ProviderConfiguration = ProviderConfiguration.GetProviderConfiguration(ProviderType)

        Friend Shared CachingDirectory As String = "Cache\"
        Friend Const CacheFileExtension As String = ".resources"
        Private Shared _objCache As System.Web.Caching.Cache

        Private Shared ReadOnly Property objCache() As System.Web.Caching.Cache
            Get
                'create singleton of the cache object
                If _objCache Is Nothing Then
                    _objCache = HttpRuntime.Cache
                End If
                Return _objCache
            End Get
        End Property

#Region "Abstract Method Implementation"

        Public Overrides Function Add(ByVal Key As String, ByVal Value As Object, ByVal Dependencies As CacheDependency, ByVal AbsoluteExpiration As DateTime, ByVal SlidingExpiration As TimeSpan, ByVal Priority As CacheItemPriority, ByVal OnRemoveCallback As CacheItemRemovedCallback) As Object

            Return objCache.Add(Key, Value, Dependencies, AbsoluteExpiration, SlidingExpiration, Priority, OnRemoveCallback)

        End Function

        Public Overrides Function GetEnumerator() As IDictionaryEnumerator

            Return objCache.GetEnumerator

        End Function

        Public Overrides Function GetItem(ByVal CacheKey As String) As Object

            Return objCache(CacheKey)

        End Function

        Public Overrides Function GetPersistentCacheItem(ByVal CacheKey As String, ByVal objType As Type) As Object

            Dim obj As Object = objCache(CacheKey)
            If Not obj Is Nothing Then
                Return objCache(CacheKey)
            ElseIf DataCache.CachePersistenceEnabled Then
                Dim objStream As Stream = Nothing
                Dim f As String = GetFileName(CacheKey)
                If File.Exists(f) Then
                    Try
                        objStream = File.OpenRead(f)
                        obj = XmlUtils.Deserialize(objStream, objType)
                        If Not obj Is Nothing Then
                            Insert(CacheKey, obj, True)
                        End If
                        If Not objStream Is Nothing Then
                            objStream.Close()
                        End If
                    Catch ex As Exception
                        'Delete file if deseialization failed
                        If Not objStream Is Nothing Then
                            objStream.Close()
                        End If
                        DeleteCacheFile(f)
                    End Try
                End If
            End If
            Return obj

        End Function

        Public Overloads Overrides Sub Insert(ByVal CacheKey As String, ByVal objObject As Object, ByVal PersistAppRestart As Boolean)

            If PersistAppRestart Then
                'remove the cache key which
                'will remove the serialized
                'file before creating a new one
                Remove(CacheKey)
            End If

            Dim f As String = GetFileName(CacheKey)

            Dim d As Caching.CacheDependency = Nothing
            If PersistAppRestart And DataCache.CachePersistenceEnabled And Not objObject Is Nothing Then
                d = New Caching.CacheDependency(f)
                CreateCacheFile(f, objObject)
            ElseIf WebFarmEnabled() Then
                d = New Caching.CacheDependency(f)
                CreateCacheFile(f)
            Else
                d = Nothing
            End If

            objCache.Insert(CacheKey, objObject, d)

        End Sub

        Public Overloads Overrides Sub Insert(ByVal CacheKey As String, ByVal objObject As Object, ByVal objDependency As CacheDependency, ByVal PersistAppRestart As Boolean)

            If PersistAppRestart Then
                'remove the cache key which
                'will remove the serialized
                'file before creating a new one
                Remove(CacheKey)
            End If

            Dim f(0) As String
            f(0) = GetFileName(CacheKey)

            Dim d As New Caching.CacheDependency(f, Nothing, objDependency)
            If PersistAppRestart And DataCache.CachePersistenceEnabled Then
                CreateCacheFile(f(0), objObject)
            ElseIf WebFarmEnabled() Then
                CreateCacheFile(f(0))
            Else
                d = objDependency
            End If

            objCache.Insert(CacheKey, objObject, d)

        End Sub

        Public Overloads Overrides Sub Insert(ByVal CacheKey As String, ByVal objObject As Object, ByVal objDependency As CacheDependency, ByVal AbsoluteExpiration As Date, ByVal SlidingExpiration As System.TimeSpan, ByVal PersistAppRestart As Boolean)

            If PersistAppRestart Then
                'remove the cache key which
                'will remove the serialized
                'file before creating a new one
                Remove(CacheKey)
            End If

            Dim f(0) As String
            f(0) = GetFileName(CacheKey)

            Dim d As Caching.CacheDependency = Nothing
            If PersistAppRestart And DataCache.CachePersistenceEnabled Then
                d = New Caching.CacheDependency(f, Nothing, objDependency)
                CreateCacheFile(f(0), objObject)
            ElseIf WebFarmEnabled() Then
                d = New Caching.CacheDependency(f, Nothing, objDependency)
                CreateCacheFile(f(0))
            Else
                d = objDependency
            End If

            objCache.Insert(CacheKey, objObject, d, AbsoluteExpiration, SlidingExpiration)

        End Sub

        Public Overloads Overrides Sub Insert(ByVal CacheKey As String, ByVal objObject As Object, ByVal objDependency As CacheDependency, ByVal AbsoluteExpiration As Date, ByVal SlidingExpiration As System.TimeSpan, ByVal Priority As CacheItemPriority, ByVal OnRemoveCallback As CacheItemRemovedCallback, ByVal PersistAppRestart As Boolean)

            If PersistAppRestart Then
                'remove the cache key which
                'will remove the serialized
                'file before creating a new one
                Remove(CacheKey)
            End If

            Dim f(0) As String
            f(0) = GetFileName(CacheKey)

            Dim d As Caching.CacheDependency = Nothing
            If PersistAppRestart And DataCache.CachePersistenceEnabled Then
                d = New Caching.CacheDependency(f, Nothing, objDependency)
                CreateCacheFile(f(0), objObject)
            ElseIf WebFarmEnabled() Then
                d = New Caching.CacheDependency(f, Nothing, objDependency)
                CreateCacheFile(f(0))
            Else
                d = objDependency
            End If

            objCache.Insert(CacheKey, objObject, d, AbsoluteExpiration, SlidingExpiration, Priority, OnRemoveCallback)

        End Sub

        Public Overrides Sub Remove(ByVal CacheKey As String)

            If Not objCache(CacheKey) Is Nothing Then
                objCache.Remove(CacheKey)
            End If

            Dim f As String = GetFileName(CacheKey)
            DeleteCacheFile(f)
        End Sub

        Public Overrides Sub RemovePersistentCacheItem(ByVal CacheKey As String)

            If Not objCache(CacheKey) Is Nothing Then
                objCache.Remove(CacheKey)
            End If

            Dim f As String = GetFileName(CacheKey)
            DeleteCacheFile(f)
        End Sub

        Public Overrides Function PurgeCache() As String
            Dim f() As String
            f = Directory.GetFiles(HostMapPath + CachingDirectory)
            Dim TotalFiles As Integer = f.Length
            Dim PurgedFiles As Integer
            PurgedFiles = PurgeCacheFiles(f)
            Return String.Format("Purged " + PurgedFiles.ToString + " of " + TotalFiles.ToString + " cache synchronization files.")
        End Function

        Private Function PurgeCacheFiles(ByVal strFiles() As String) As Integer
            Dim PurgedFiles As Integer = 0
            Dim i As Integer
            For i = 0 To strFiles.Length - 1
                Dim dtLastWrite As Date
                dtLastWrite = File.GetLastWriteTime(strFiles(i))
                If dtLastWrite < Now.Subtract(New TimeSpan(2, 0, 0)) Then
                    Dim strFileName As String
                    strFileName = strFiles(i).Substring(strFiles(i).LastIndexOf("\"))
                    Dim strCacheKey As String
                    strCacheKey = strFileName.Substring(0, strFileName.Length - FBCachingProvider.CacheFileExtension.Length)
                    If DataCache.GetCache(strCacheKey) Is Nothing Then
                        File.Delete(strFiles(i))
                        PurgedFiles += 1
                    End If
                End If
            Next
            Return PurgedFiles
        End Function


#End Region

#Region "Private Methods"

        Private Shared Function ByteArrayToString(ByVal arrInput() As Byte) As String
            Dim i As Integer
            Dim sOutput As New StringBuilder(arrInput.Length)
            For i = 0 To arrInput.Length - 1
                sOutput.Append(arrInput(i).ToString("X2"))
            Next
            Return sOutput.ToString()
        End Function

        Private Shared Function GetFileName(ByVal FileName As String) As String
            Dim FileNameBytes As Byte() = Text.ASCIIEncoding.ASCII.GetBytes(FileName)
            Dim md5 As System.Security.Cryptography.MD5CryptoServiceProvider = New System.Security.Cryptography.MD5CryptoServiceProvider()
            FileNameBytes = md5.ComputeHash(FileNameBytes)
            Dim FinalFileName As String = ByteArrayToString(FileNameBytes)
            Return Path.GetFullPath(HostMapPath + CachingDirectory + FinalFileName + CacheFileExtension)
        End Function

        Private Shared Sub CreateCacheFile(ByVal FileName As String)

            Dim s As StreamWriter
            If Not File.Exists(FileName) Then
                s = File.CreateText(FileName)
                If Not s Is Nothing Then
                    s.Close()
                End If
            End If

        End Sub

        Private Shared Sub CreateCacheFile(ByVal FileName As String, ByVal ObjectToPersist As Object)
            Try
                Dim s As StreamWriter
                If Not File.Exists(FileName) Then
                    s = File.CreateText(FileName)
                    'If we get the file locking error no need to serialise the object.
                    Dim str As String = XmlUtils.Serialize(ObjectToPersist)
                    s.Write(str)
                    If Not s Is Nothing Then
                        s.Close()
                    End If
                End If
            Catch ex As Exception
                'Multiple servers were trying to create the file caausing a File Lock.
                'Only one server needs to write the file so no need to do anything about the error
            End Try
        End Sub

        Private Shared Sub DeleteCacheFile(ByVal FileName As String)

            If File.Exists(FileName) Then
                File.Delete(FileName)
            End If

        End Sub

#End Region


    End Class

End Namespace
