﻿
// Fallback for Medium Trust when the main OPML file cannot be retrieved.
function defaultFeedBrowser()
{

    var tabs = [];

    with(DotNetNuke.UI.WebControls.FeedBrowser)
    {
        var marketTab = new TabInfo("Marketplace", "http://marketplace.dotnetnuke.com/rssfeed.aspx?channel=marketplacesolutions&affiliateid=10054", "marketplace");
        var moduleSection = marketTab.addSection(new SectionInfo("Modules", "http://marketplace.dotnetnuke.com/feed-sp-2.aspx?affiliateid=10054"));
        var skinSection = marketTab.addSection(new SectionInfo("Skins", "http://marketplace.dotnetnuke.com/feed-sp-3.aspx?affiliateid=10054"));

        moduleSection.addCategory(new CategoryInfo("Community Management","http://marketplace.dotnetnuke.com/feed-sc-2-18.aspx?affiliateid=10054",0));
        moduleSection.addCategory(new CategoryInfo("Discussion/Forum","http://marketplace.dotnetnuke.com/feed-sc-2-19.aspx?affiliateid=10054" ,1));
        moduleSection.addCategory(new CategoryInfo("Content Management","http://marketplace.dotnetnuke.com/feed-sc-2-2.aspx?affiliateid=10054",0));
     	moduleSection.addCategory(new CategoryInfo("Data Management","http://marketplace.dotnetnuke.com/feed-sc-2-11.aspx?affiliateid=10054",1));
     	moduleSection.addCategory(new CategoryInfo("Document Management","http://marketplace.dotnetnuke.com/feed-sc-2-3.aspx?affiliateid=10054",1));
     	moduleSection.addCategory(new CategoryInfo("File Management","http://marketplace.dotnetnuke.com/feed-sc-2-6.aspx?affiliateid=10054",1));
     	moduleSection.addCategory(new CategoryInfo("eCommerce","http://marketplace.dotnetnuke.com/feed-sc-2-4.aspx?affiliateid=10054",0));
     	moduleSection.addCategory(new CategoryInfo("Media Management","http://marketplace.dotnetnuke.com/feed-sc-2-5.aspx?affiliateid=10054",0));
     	moduleSection.addCategory(new CategoryInfo("Image Viewer","http://marketplace.dotnetnuke.com/feed-sc-2-9.aspx?affiliateid=10054",1));
     	moduleSection.addCategory(new CategoryInfo("Photo Albums","http://marketplace.dotnetnuke.com/feed-sc-2-7.aspx?affiliateid=10054",1));
     	moduleSection.addCategory(new CategoryInfo("Multi-Language","http://marketplace.dotnetnuke.com/feed-sc-2-14.aspx?affiliateid=10054",0));
     	moduleSection.addCategory(new CategoryInfo("Navigation","http://marketplace.dotnetnuke.com/feed-sc-2-10.aspx?affiliateid=10054",0));
     	moduleSection.addCategory(new CategoryInfo("Skinning/CSS Management","http://marketplace.dotnetnuke.com/feed-sc-2-16.aspx?affiliateid=10054",0));
     	moduleSection.addCategory(new CategoryInfo("Time Management","http://marketplace.dotnetnuke.com/feed-sc-2-17.aspx?affiliateid=10054",0));
     	moduleSection.addCategory(new CategoryInfo("Project Management","http://marketplace.dotnetnuke.com/feed-sc-2-8.aspx?affiliateid=10054",1));
     	moduleSection.setDefaultCategory(7);

        skinSection.addCategory(new CategoryInfo("Skins", "http://marketplace.dotnetnuke.com/feed-sc-3-20.aspx?affiliateid=10054", 0));
        skinSection.setDefaultCategory(0);
                
        tabs[tabs.length] = marketTab;
                
        var hostingTab = new TabInfo('Hosting','http://www.dotnetnuke.com/Portals/25/SolutionsExplorer/Hosting.opml','hosting');
        var hostingSection = hostingTab.addSection(new SectionInfo('Hosting Solutions','http://www.dotnetnuke.com/Portals/25/SolutionsExplorer/Hosting.xml'));

        tabs[tabs.length] = hostingTab;
        
        var aboutTab = new TabInfo("About", "");
        var aboutSection = aboutTab.addSection(new SectionInfo("General Information","http://www.dotnetnuke.com/portals/25/SolutionsExplorer/info.xml"));
        var marketSection = aboutTab.addSection(new SectionInfo("Marketplace Information","http://www.dotnetnuke.com/portals/25/SolutionsExplorer/marketplace.xml"));
        var soonSection = aboutTab.addSection(new SectionInfo("Coming Soon","http://www.dotnetnuke.com/portals/25/SolutionsExplorer/comingsoon.xml"));

        tabs[tabs.length] = aboutTab;
        
        return(tabs);                
    }        

}
