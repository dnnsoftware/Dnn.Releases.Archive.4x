'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2007 by DotNetNuke Corp. 
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports DotNetNuke
Imports DotNetNuke.Entities.Host.HostSettings
Imports DotNetNuke.Entities.Modules
Imports DotNetNuke.Entities.Portals
Imports DotNetNuke.Entities.Tabs
Imports DotNetNuke.Entities.Users
Imports DotNetNuke.Services.Localization
Imports System.Globalization
Imports System.Web
Imports System.Text
Imports System.Text.RegularExpressions


Namespace DotNetNuke.Services.Localization

    Public Enum TokenAccessLevel
        NoSettings
        DefaultSettings
        FullSettings
    End Enum

    Public Class TokenReplace

#Region " Private Fields "
        Private Shared _Tokenizer As Regex
        Private _Language As String
        Private _PortalSettings As PortalSettings
        Private _Hostsettings As Hashtable
        Private _ModuleInfo As Entities.Modules.ModuleInfo
        Private _User As Entities.Users.UserInfo
        Private _Tab As Entities.Tabs.TabInfo
        Private _ModuleId As Integer
        Private _formatProvider As IFormatProvider
        Private _AccessLevel As TokenAccessLevel
#End Region

#Region " Properties "

        Private Shared ReadOnly Property TokenizerRegex() As Regex
            Get
                If _Tokenizer Is Nothing Then
                    Dim exp As String = "(?:\[((?<object>[^\]\[:]+):(?<property>[^\]\[\|]+))(?:\|(?<format>[^\]\[]+))*\])|(?<text>\[[^\]\[]+\])|(?<text>[^\]\[]+)"
                    _Tokenizer = New Regex(exp, RegexOptions.Compiled)
                End If
                Return _Tokenizer
            End Get
        End Property

        Private ReadOnly Property FormatProvider() As IFormatProvider
            Get
                If _formatProvider Is Nothing Then
                    If Not Language Is Nothing Then
                        _formatProvider = New CultureInfo(Language)
                    Else
                        _formatProvider = System.Threading.Thread.CurrentThread.CurrentCulture
                    End If
                End If
                Return _formatProvider
            End Get
        End Property

        Private ReadOnly Property HostSettings() As Hashtable
            Get
                If _Hostsettings Is Nothing Then
                    _Hostsettings = GetSecureHostSettings()
                End If
                Return _Hostsettings
            End Get
        End Property

        Private Property CurrentAccessLevel() As TokenAccessLevel
            Get
                Return _AccessLevel
            End Get
            Set(ByVal value As TokenAccessLevel)

                _AccessLevel = value
            End Set
        End Property

        Public Property Language() As String
            Get
                Return _Language
            End Get
            Set(ByVal value As String)
                _Language = value
            End Set
        End Property

        Public Property PortalSettings() As PortalSettings
            Get
                Return _PortalSettings
            End Get
            Set(ByVal value As PortalSettings)
                _PortalSettings = value
            End Set
        End Property

        Public Property ModuleInfo() As Entities.Modules.ModuleInfo
            Get
                If _ModuleInfo Is Nothing OrElse _ModuleInfo.ModuleID <> ModuleId Then
                    Dim mc As New DotNetNuke.Entities.Modules.ModuleController
                    _ModuleInfo = mc.GetModule(ModuleId, PortalSettings.ActiveTab.TabID)
                End If
                Return _ModuleInfo
            End Get
            Set(ByVal value As Entities.Modules.ModuleInfo)
                _ModuleInfo = value
            End Set
        End Property

        Public Property User() As Entities.Users.UserInfo
            Get
                Return _User
            End Get
            Set(ByVal value As Entities.Users.UserInfo)
                _User = value
            End Set
        End Property

        Public Property ModuleId() As Integer
            Get
                Return _ModuleId
            End Get
            Set(ByVal value As Integer)

                _ModuleId = value
            End Set
        End Property

#End Region

#Region " Constructor and fabric methods "
        Private Sub New()
        End Sub

        Public Shared Function Create(ByVal ModuleID As Integer) As TokenReplace
            Dim tr As TokenReplace = Create(TokenAccessLevel.DefaultSettings)
            tr.ModuleId = ModuleID
            Return tr
        End Function

        Public Shared Function Create(ByVal objModuleInfo As ModuleInfo) As TokenReplace
            Dim tr As TokenReplace = Create(TokenAccessLevel.DefaultSettings)
            tr.ModuleId = objModuleInfo.ModuleID
            tr.ModuleInfo = objModuleInfo
            Return tr
        End Function

        Public Shared Function Create() As TokenReplace
            Return Create(TokenAccessLevel.DefaultSettings)
        End Function

        Public Shared Function Create(ByVal Language As String) As TokenReplace
            Return Create(TokenAccessLevel.DefaultSettings, Language, Nothing, Nothing)
        End Function

        Public Shared Function Create(ByVal AccessLevel As TokenAccessLevel) As TokenReplace
            Return Create(AccessLevel, Nothing, Nothing, Nothing)
        End Function

        Public Shared Function Create(ByVal AccessLevel As TokenAccessLevel, ByVal Language As String) As TokenReplace
            Return Create(AccessLevel, Language, Nothing, Nothing)
        End Function

        Public Shared Function Create(ByVal AccessLevel As TokenAccessLevel, ByVal Language As String, ByVal PortalSettings As PortalSettings, ByVal User As UserInfo) As TokenReplace
            Dim tr As TokenReplace = New TokenReplace
            tr.CurrentAccessLevel = AccessLevel
            If AccessLevel <> TokenAccessLevel.NoSettings Then
                If PortalSettings Is Nothing Then
                    tr.PortalSettings = Entities.Portals.PortalController.GetCurrentPortalSettings
                Else
                    tr.PortalSettings = PortalSettings
                End If
                If User Is Nothing Then
                    tr.User = CType(HttpContext.Current.Items("UserInfo"), UserInfo)
                Else
                    tr.User = User
                End If
                If String.IsNullOrEmpty(Language) Then
                    tr.Language = New Localization().CurrentCulture
                Else
                    tr.Language = Language
                End If
            End If
            Return tr
        End Function

#End Region

#Region " Public Methods "

        Public Function ReplaceEnvironmentTokens(ByVal strSourceText As String) As String
            Return ReplaceEnvironmentTokens(strSourceText, Nothing, Nothing)
        End Function

        Public Function ReplaceEnvironmentTokens(ByVal strSourceText As String, ByVal row As DataRow) As String
            Return ReplaceEnvironmentTokens(strSourceText, Nothing, row)
        End Function

        Public Function ReplaceEnvironmentTokens(ByVal strSourceText As String, ByVal Custom As ArrayList) As String
            Return ReplaceEnvironmentTokens(strSourceText, Custom, Nothing)
        End Function

        Public Function ReplaceEnvironmentTokens(ByVal strSourceText As String, ByVal Custom As ArrayList, ByVal Row As System.Data.DataRow) As String

            If strSourceText Is Nothing Then Return String.Empty

            Dim Result As New System.Text.StringBuilder
            For Each m As Match In TokenizerRegex.Matches(strSourceText)
                Dim strObjectName As String = m.Result("${object}")
                If strObjectName.Length > 0 Then
                    Dim strPropertyName As String = m.Result("${property}")
                    Dim strFormat As String = m.Result("${format}")

                    Result.Append(calc(strObjectName, strPropertyName, strFormat, Custom, Row))
                Else
                    Result.Append(m.Result("${text}"))
                End If
            Next

            Return Result.ToString()
        End Function

#End Region

#Region " Private Methods "

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        '''     calculates the replaced string
        ''' </summary>
        ''' <history>
        '''     [scullmann]    01/02/2007  newly created based on method from DNN localization
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function calc(ByVal strObjectName As String, ByVal strPropertyName As String, ByVal strFormat As String, _
                     ByVal Custom As ArrayList, ByVal Row As System.Data.DataRow) As String

            Dim isSecure As Boolean = (CurrentAccessLevel = TokenAccessLevel.FullSettings)

            Select Case strObjectName.ToLower
                Case "host"
                    If HostSettings.ContainsKey(strPropertyName) Then Return HostSettings(strPropertyName).ToString()
                Case "portal"
                    If strPropertyName.ToLower = "url" Then
                        Return PortalSettings.PortalAlias.HTTPAlias()
                    Else
                        Return GetProperty(PortalSettings, strPropertyName, strFormat, FormatProvider)
                    End If
                Case "tab"
                    Return GetProperty(PortalSettings.ActiveTab, strPropertyName, strFormat, FormatProvider)
                Case "module"
                    Return GetProperty(ModuleInfo, strPropertyName, strFormat, FormatProvider)
                Case "user"
                    If strPropertyName.ToLower = "verificationcode" Then
                        Return PortalSettings.PortalId.ToString & "-" & User.UserID.ToString
                    Else
                        Return GetProperty(User, strPropertyName, strFormat, FormatProvider)
                    End If
                Case "membership"
                    If strPropertyName Like "Password*" Then
                        If Not isSecure OrElse User.IsSuperUser Then
                            Return "*******"
                        End If
                    End If
                    Return GetProperty(User.Membership, strPropertyName, strFormat, FormatProvider)
                Case "profile"
                    If Not isSecure Then Return String.Empty
                    Return GetProperty(User.Profile, strPropertyName, strFormat, FormatProvider)
                Case "custom"
                    If IsNumeric(strPropertyName) Then
                        Dim intIndex As Integer = Integer.Parse(strPropertyName)
                        Return Custom(intIndex).ToString()
                    End If
                Case "datetime", "date"
                    If strFormat = String.Empty Then
                        If strPropertyName.ToLower = "current" Then Return DateTime.Now.ToString("D", FormatProvider)
                        If strPropertyName.ToLower = "now" Then Return DateTime.Now.ToString("g", FormatProvider)
                    Else
                        Return DateTime.Now.ToString(strFormat, FormatProvider)
                    End If
                Case "row", "field"
                    If Not Row Is Nothing Then Return CStr(Row(strPropertyName))
                Case "ticks"
                    Select Case strPropertyName.ToLower
                        Case "now"
                            Return DateTime.Now.Ticks.ToString()
                        Case "today"
                            Return DateTime.Today.Ticks.ToString()
                        Case "ticksperday"
                            Return TimeSpan.TicksPerDay.ToString()
                    End Select
            End Select
            If strFormat.Length > 0 Then
                Return String.Format("[{0}:{1}|{3]]", strObjectName, strPropertyName, strFormat)
            Else
                Return String.Format("[{0}:{1}]", strObjectName, strPropertyName)
            End If

        End Function

#Region "Property Access"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        '''     Returns the localized property of the PortalSettings object as string
        ''' </summary>
        ''' <param name="objPortal"></param>
        ''' <param name="strPropertyName">Name of property</param>
        ''' <param name="strFormat">Format String</param>
        ''' <param name="formatProvider">IFormatProvider (e.g. CultureInfo)</param>
        ''' <returns>Localized Property</returns>
        ''' <history>
        '''     [Generator]    01/04/2007 Generated by a tool
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Shared Function GetProperty(ByVal objPortal As PortalSettings, ByVal strPropertyName As String, ByVal strFormat As String, ByVal formatProvider As IFormatProvider) As String
            If strFormat = String.Empty Then strFormat = "g"
            If Not objPortal Is Nothing Then
                Select Case strPropertyName.ToLower()
                    Case "portalid"
                        Return (objPortal.PortalId.ToString(strFormat, formatProvider))
                    Case "portalname"
                        Return (objPortal.PortalName)
                    Case "homedirectory"
                        Return (objPortal.HomeDirectory)
                    Case "homedirectorymappath"
                        Return (objPortal.HomeDirectoryMapPath)
                    Case "logofile"
                        Return (objPortal.LogoFile)
                    Case "footertext"
                        Return (objPortal.FooterText)
                    Case "expirydate"
                        Return (objPortal.ExpiryDate.ToString(strFormat, formatProvider))
                    Case "userregistration"
                        Return (objPortal.UserRegistration.ToString(strFormat, formatProvider))
                    Case "banneradvertising"
                        Return (objPortal.BannerAdvertising.ToString(strFormat, formatProvider))
                    Case "currency"
                        Return (objPortal.Currency)
                    Case "administratorid"
                        Return (objPortal.AdministratorId.ToString(strFormat, formatProvider))
                    Case "email"
                        Return (objPortal.Email)
                    Case "hostfee"
                        Return (objPortal.HostFee.ToString(strFormat, formatProvider))
                    Case "hostspace"
                        Return (objPortal.HostSpace.ToString(strFormat, formatProvider))
                    Case "administratorroleid"
                        Return (objPortal.AdministratorRoleId.ToString(strFormat, formatProvider))
                    Case "administratorrolename"
                        Return (objPortal.AdministratorRoleName)
                    Case "registeredroleid"
                        Return (objPortal.RegisteredRoleId.ToString(strFormat, formatProvider))
                    Case "registeredrolename"
                        Return (objPortal.RegisteredRoleName)
                    Case "description"
                        Return (objPortal.Description)
                    Case "keywords"
                        Return (objPortal.KeyWords)
                    Case "backgroundfile"
                        Return (objPortal.BackgroundFile)
                    Case "siteloghistory"
                        Return (objPortal.SiteLogHistory.ToString(strFormat, formatProvider))
                    Case "admintabid"
                        Return (objPortal.AdminTabId.ToString(strFormat, formatProvider))
                    Case "supertabid"
                        Return (objPortal.SuperTabId.ToString(strFormat, formatProvider))
                    Case "splashtabid"
                        Return (objPortal.SplashTabId.ToString(strFormat, formatProvider))
                    Case "hometabid"
                        Return (objPortal.HomeTabId.ToString(strFormat, formatProvider))
                    Case "logintabid"
                        Return (objPortal.LoginTabId.ToString(strFormat, formatProvider))
                    Case "usertabid"
                        Return (objPortal.UserTabId.ToString(strFormat, formatProvider))
                    Case "defaultlanguage"
                        Return (objPortal.DefaultLanguage)
                    Case "timezoneoffset"
                        Return (objPortal.TimeZoneOffset.ToString(strFormat, formatProvider))
                    Case "version"
                        Return (objPortal.Version)
                End Select
            End If
            Return "[Portal:" + strPropertyName + "]"
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        '''     Returns the localized property of the TabInfo object as string
        ''' </summary>
        ''' <param name="objTab"></param>
        ''' <param name="strPropertyName">Name of property</param>
        ''' <param name="strFormat">Format String</param>
        ''' <param name="formatProvider">IFormatProvider (e.g. CultureInfo)</param>
        ''' <returns>Localized Property</returns>
        ''' <history>
        '''     [Generator]    01/04/2007 Generated by a tool
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Shared Function GetProperty(ByVal objTab As TabInfo, ByVal strPropertyName As String, ByVal strFormat As String, ByVal formatProvider As IFormatProvider) As String
            If strFormat = String.Empty Then strFormat = "g"
            If Not objTab Is Nothing Then
                Select Case strPropertyName.ToLower()
                    Case "tabid"
                        Return (objTab.TabID.ToString(strFormat, formatProvider))
                    Case "taborder"
                        Return (objTab.TabOrder.ToString(strFormat, formatProvider))
                    Case "portalid"
                        Return (objTab.PortalID.ToString(strFormat, formatProvider))
                    Case "tabname"
                        Return (objTab.TabName)
                    Case "parentid"
                        Return (objTab.ParentId.ToString(strFormat, formatProvider))
                    Case "level"
                        Return (objTab.Level.ToString(strFormat, formatProvider))
                    Case "iconfile"
                        Return (objTab.IconFile)
                    Case "title"
                        Return (objTab.Title)
                    Case "description"
                        Return (objTab.Description)
                    Case "keywords"
                        Return (objTab.KeyWords)
                    Case "url"
                        Return (objTab.Url)
                    Case "skinsrc"
                        Return (objTab.SkinSrc)
                    Case "containersrc"
                        Return (objTab.ContainerSrc)
                    Case "tabpath"
                        Return (objTab.TabPath)
                    Case "startdate"
                        Return (objTab.StartDate.ToString(strFormat, formatProvider))
                    Case "enddate"
                        Return (objTab.EndDate.ToString(strFormat, formatProvider))
                    Case "skinpath"
                        Return (objTab.SkinPath)
                    Case "containerpath"
                        Return (objTab.ContainerPath)
                    Case "fullurl"
                        Return (objTab.FullUrl)
                    Case "refreshinterval"
                        Return (objTab.RefreshInterval.ToString(strFormat, formatProvider))
                    Case "pageheadtext"
                        Return (objTab.PageHeadText)
                    Case "authorizedroles"
                        Return (objTab.AuthorizedRoles)
                    Case "administratorroles"
                        Return (objTab.AdministratorRoles)
                End Select
            End If
            Return "[Tab:" + strPropertyName + "]"
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        '''     Returns the localized property of the ModuleInfo object as string
        ''' </summary>
        ''' <param name="objModule"></param>
        ''' <param name="strPropertyName">Name of property</param>
        ''' <param name="strFormat">Format String</param>
        ''' <param name="formatProvider">IFormatProvider (e.g. CultureInfo)</param>
        ''' <returns>Localized Property</returns>
        ''' <history>
        '''     [Generator]    01/04/2007 Generated by a tool
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Shared Function GetProperty(ByVal objModule As ModuleInfo, ByVal strPropertyName As String, ByVal strFormat As String, ByVal formatProvider As IFormatProvider) As String
            If strFormat = String.Empty Then strFormat = "g"
            If Not objModule Is Nothing Then
                Select Case strPropertyName.ToLower()
                    Case "portalid"
                        Return (objModule.PortalID.ToString(strFormat, formatProvider))
                    Case "tabid"
                        Return (objModule.TabID.ToString(strFormat, formatProvider))
                    Case "tabmoduleid"
                        Return (objModule.TabModuleID.ToString(strFormat, formatProvider))
                    Case "moduleid"
                        Return (objModule.ModuleID.ToString(strFormat, formatProvider))
                    Case "moduledefid"
                        Return (objModule.ModuleDefID.ToString(strFormat, formatProvider))
                    Case "moduleorder"
                        Return (objModule.ModuleOrder.ToString(strFormat, formatProvider))
                    Case "panename"
                        Return (objModule.PaneName)
                    Case "moduletitle"
                        Return (objModule.ModuleTitle)
                    Case "authorizededitroles"
                        Return (objModule.AuthorizedEditRoles)
                    Case "cachetime"
                        Return (objModule.CacheTime.ToString(strFormat, formatProvider))
                    Case "authorizedviewroles"
                        Return (objModule.AuthorizedViewRoles)
                    Case "alignment"
                        Return (objModule.Alignment)
                    Case "color"
                        Return (objModule.Color)
                    Case "border"
                        Return (objModule.Border)
                    Case "iconfile"
                        Return (objModule.IconFile)
                    Case "authorizedroles"
                        Return (objModule.AuthorizedRoles)
                    Case "header"
                        Return (objModule.Header)
                    Case "footer"
                        Return (objModule.Footer)
                    Case "startdate"
                        Return (objModule.StartDate.ToString(strFormat, formatProvider))
                    Case "enddate"
                        Return (objModule.EndDate.ToString(strFormat, formatProvider))
                    Case "containersrc"
                        Return (objModule.ContainerSrc)
                    Case "desktopmoduleid"
                        Return (objModule.DesktopModuleID.ToString(strFormat, formatProvider))
                    Case "friendlyname"
                        Return (objModule.FriendlyName)
                    Case "description"
                        Return (objModule.Description)
                    Case "version"
                        Return (objModule.Version)
                    Case "businesscontrollerclass"
                        Return (objModule.BusinessControllerClass)
                    Case "modulename"
                        Return (objModule.ModuleName)
                    Case "supportedfeatures"
                        Return (objModule.SupportedFeatures.ToString(strFormat, formatProvider))
                    Case "defaultcachetime"
                        Return (objModule.DefaultCacheTime.ToString(strFormat, formatProvider))
                    Case "modulecontrolid"
                        Return (objModule.ModuleControlId.ToString(strFormat, formatProvider))
                    Case "controlsrc"
                        Return (objModule.ControlSrc)
                    Case "controltitle"
                        Return (objModule.ControlTitle)
                    Case "helpurl"
                        Return (objModule.HelpUrl)
                    Case "containerpath"
                        Return (objModule.ContainerPath)
                    Case "panemoduleindex"
                        Return (objModule.PaneModuleIndex.ToString(strFormat, formatProvider))
                    Case "panemodulecount"
                        Return (objModule.PaneModuleCount.ToString(strFormat, formatProvider))
                    Case "defaultcachetime"
                        Return (objModule.DefaultCacheTime.ToString(strFormat, formatProvider))
                    Case "modulename"
                        Return objModule.ModuleName
                End Select
            End If
            Return "[Module:" + strPropertyName + "]"
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        '''     Returns the localized property of the UserInfo object as string
        ''' </summary>
        ''' <param name="objUser"></param>
        ''' <param name="strPropertyName">Name of property</param>
        ''' <param name="strFormat">Format String</param>
        ''' <param name="formatProvider">IFormatProvider (e.g. CultureInfo)</param>
        ''' <returns>Localized Property</returns>
        ''' <history>
        '''     [Generator]    01/04/2007 Generated by a tool
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Shared Function GetProperty(ByVal objUser As UserInfo, ByVal strPropertyName As String, ByVal strFormat As String, ByVal formatProvider As IFormatProvider) As String
            If strFormat = String.Empty Then strFormat = "g"
            If Not objUser Is Nothing Then
                Select Case strPropertyName.ToLower()
                    Case "affiliateid"
                        Return (objUser.AffiliateID.ToString(strFormat, formatProvider))
                    Case "displayname"
                        Return (objUser.DisplayName)
                    Case "email"
                        Return (objUser.Email)
                    Case "firstname"
                        Return (objUser.FirstName)
                    Case "lastname"
                        Return (objUser.LastName)
                    Case "portalid"
                        Return (objUser.PortalID.ToString(strFormat, formatProvider))
                    Case "userid"
                        Return (objUser.UserID.ToString(strFormat, formatProvider))
                    Case "username"
                        Return (objUser.Username)
                    Case "fullname"
                        Return (objUser.FullName)
                End Select
            End If
            Return "[User:" + strPropertyName + "]"
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        '''     Returns the localized property of the UserMembership object as string
        ''' </summary>
        ''' <param name="objMembership"></param>
        ''' <param name="strPropertyName">Name of property</param>
        ''' <param name="strFormat">Format String</param>
        ''' <param name="formatProvider">IFormatProvider (e.g. CultureInfo)</param>
        ''' <returns>Localized Property</returns>
        ''' <history>
        '''     [Generator]    01/04/2007 Generated by a tool
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Shared Function GetProperty(ByVal objMembership As UserMembership, ByVal strPropertyName As String, ByVal strFormat As String, ByVal formatProvider As IFormatProvider) As String
            If strFormat = String.Empty Then strFormat = "g"
            If Not objMembership Is Nothing Then
                Select Case strPropertyName.ToLower()
                    Case "createddate"
                        Return (objMembership.CreatedDate.ToString(strFormat, formatProvider))
                    Case "lastactivitydate"
                        Return (objMembership.LastActivityDate.ToString(strFormat, formatProvider))
                    Case "lastlockoutdate"
                        Return (objMembership.LastLockoutDate.ToString(strFormat, formatProvider))
                    Case "lastlogindate"
                        Return (objMembership.LastLoginDate.ToString(strFormat, formatProvider))
                    Case "lastpasswordchangedate"
                        Return (objMembership.LastPasswordChangeDate.ToString(strFormat, formatProvider))
                    Case "password"
                        Return (objMembership.Password)
                    Case "passwordanswer"
                        Return (objMembership.PasswordAnswer)
                    Case "passwordquestion"
                        Return (objMembership.PasswordQuestion)
                    Case "email"
                        Return (objMembership.Email)
                    Case "username"
                        Return (objMembership.Username)
                End Select
            End If
            Return "[Membership:" + strPropertyName + "]"
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        '''     Returns the localized property of the UserProfile object as string
        ''' </summary>
        ''' <param name="objProfile"></param>
        ''' <param name="strPropertyName">Name of property</param>
        ''' <param name="strFormat">Format String</param>
        ''' <param name="formatProvider">IFormatProvider (e.g. CultureInfo)</param>
        ''' <returns>Localized Property</returns>
        ''' <history>
        '''     [Generator]    01/04/2007 Generated by a tool
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Shared Function GetProperty(ByVal objProfile As UserProfile, ByVal strPropertyName As String, ByVal strFormat As String, ByVal formatProvider As IFormatProvider) As String
            If strFormat = String.Empty Then strFormat = "g"
            If Not objProfile Is Nothing Then
                Select Case strPropertyName.ToLower()
                    Case "cell"
                        Return (objProfile.Cell)
                    Case "city"
                        Return (objProfile.City)
                    Case "country"
                        Return (objProfile.Country)
                    Case "fax"
                        Return (objProfile.Fax)
                    Case "firstname"
                        Return (objProfile.FirstName)
                    Case "fullname"
                        Return (objProfile.FullName)
                    Case "im"
                        Return (objProfile.IM)
                    Case "lastname"
                        Return (objProfile.LastName)
                    Case "postalcode"
                        Return (objProfile.PostalCode)
                    Case "preferredlocale"
                        Return (objProfile.PreferredLocale)
                    Case "region"
                        Return (objProfile.Region)
                    Case "street"
                        Return (objProfile.Street)
                    Case "telephone"
                        Return (objProfile.Telephone)
                    Case "unit"
                        Return (objProfile.Unit)
                    Case "timezone"
                        Return (objProfile.TimeZone.ToString(strFormat, formatProvider))
                    Case "website"
                        Return (objProfile.Website)
                End Select
            End If
            Return "[Profile:" + strPropertyName + "]"
        End Function

#End Region

#End Region

    End Class
End Namespace
