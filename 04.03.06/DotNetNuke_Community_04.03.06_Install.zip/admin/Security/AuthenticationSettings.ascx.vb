'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2006
' by DotNetNuke Corporation
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports DotNetNuke.Entities.Portals
Imports DotNetNuke.Entities.Modules
Imports DotNetNuke.Entities.Modules.Actions
Imports DotNetNuke.Framework.Providers
Imports DotNetNuke.Services.Localization
Imports DotNetNuke.Services.Exceptions

Imports DotNetNuke.Security.Authentication
Imports DotNetNuke.Security.Authentication.Configuration

Namespace DotNetNuke.Modules.Authentication

    Partial Class AuthenticationSettings
        Inherits DotNetNuke.Entities.Modules.PortalModuleBase

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            'Put user code to initialize the page here
            Try
                ' Obtain PortalSettings from Current Context
                Dim _portalSettings As PortalSettings = PortalController.GetCurrentPortalSettings
                Dim objAuthenticationController As New AuthenticationController

                ' Reset config
                Configuration.ResetConfig()
                Dim config As DotNetNuke.Security.Authentication.Configuration = Configuration.GetConfig()

                If UserInfo.Username.IndexOf("\") > 0 Then
                    Dim strDomain As String = GetUserDomainName(UserInfo.Username)
                    If strDomain.ToLower = Request.ServerVariables("SERVER_NAME").ToLower Then
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, String.Format(Localization.GetString("SameDomainError", Me.LocalResourceFile), strDomain, Request.ServerVariables("SERVER_NAME")), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                        DisableScreen()
                        Exit Sub
                    End If
                End If

                If Not Page.IsPostBack Then
                    Dim objProviderConfiguration As ProviderConfiguration = ProviderConfiguration.GetProviderConfiguration(Configuration.AUTHENTICATION_KEY)

                    chkAuthentication.Checked = config.WindowsAuthentication
                    chkSynchronizeRole.Checked = config.SynchronizeRole
                    chkSynchronizePassword.Checked = config.SynchronizePassword
                    txtRootDomain.Text = config.RootDomain
                    txtUserName.Text = config.UserName
                    txtEmailDomain.Text = config.EmailDomain

                    Dim _Provider As Object
                    ' Bind Authentication provider list, this allows each portal could use different provider for authentication
                    For Each _Provider In objProviderConfiguration.Providers
                        Dim objProvider As Collections.DictionaryEntry = CType(_Provider, Collections.DictionaryEntry)
                        Dim ProviderName As String = CType(objProvider.Key, String)
                        Dim ProviderType As String = CType(objProvider.Value, Provider).Type

                        Me.cboProviders.Items.Add(New ListItem(ProviderName, ProviderType))
                    Next

                    ' Bind AuthenticationTypes list, on first configure, it could obtains only from default authentication provider
                    Try
                        Me.cboAuthenticationType.DataSource = objAuthenticationController.AuthenticationTypes
                    Catch exc As System.TypeInitializationException
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("AuthProviderError", Me.LocalResourceFile), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                        DisableScreen()
                        Exit Sub
                    End Try
                    Me.cboAuthenticationType.DataBind()
                    Me.cboAuthenticationType.Items.FindByText(config.AuthenticationType).Selected = True

                End If

                valConfirm.ErrorMessage = Localization.GetString("PasswordMatchFailure", Me.LocalResourceFile)

            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Function GetUserDomainName(ByVal UserName As String) As String
            Dim strReturn As String = ""
            If UserName.IndexOf("\") > 0 Then
                strReturn = Left(UserName, (UserName.IndexOf("\")))
            End If
            Return strReturn
        End Function

        Private Sub DisableScreen()
            chkSynchronizeRole.Enabled = False
            cmdUpdate.Visible = False
            chkAuthentication.Enabled = False
            cboProviders.Enabled = False
            txtUserName.Enabled = False
            txtPassword.Enabled = False
            txtConfirm.Enabled = False
            valConfirm.Enabled = False
            cboAuthenticationType.Enabled = False
            chkSynchronizePassword.Enabled = False
            txtRootDomain.Enabled = False
            txtEmailDomain.Enabled = False
        End Sub

        Private Sub cmdAuthenticationUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdUpdate.Click
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)
            Try
                Dim providerTypeName As String = Me.cboProviders.SelectedItem.Value
                Dim authenticationType As String = Me.cboAuthenticationType.SelectedItem.Value

                Configuration.UpdateConfig(_portalSettings.PortalId, Me.chkAuthentication.Checked, Me.txtRootDomain.Text, Me.txtEmailDomain.Text, Me.txtUserName.Text, Me.txtPassword.Text, Me.chkSynchronizeRole.Checked, Me.chkSynchronizePassword.Checked, providerTypeName, authenticationType)
                Configuration.ResetConfig()

                Dim objAuthenticationController As New AuthenticationController
                Dim statusMessage As String = objAuthenticationController.NetworkStatus

                If statusMessage.ToLower.IndexOf("fail") > -1 Then
                    MessageCell.Controls.Add(UI.Skins.Skin.GetModuleMessageControl("", LocalizedStatus(statusMessage), DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.RedError))
                Else
                    MessageCell.Controls.Add(UI.Skins.Skin.GetModuleMessageControl("", LocalizedStatus(statusMessage), DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.GreenSuccess))
                End If

            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Function LocalizedStatus(ByVal InputText As String) As String
            'Return InputText
            Dim strReturn As String = InputText
            strReturn = strReturn.Replace("[Global Catalog Status]", Localization.GetString("[Global Catalog Status]", Me.LocalResourceFile))
            strReturn = strReturn.Replace("[Root Domain Status]", Localization.GetString("[Root Domain Status]", Me.LocalResourceFile))
            strReturn = strReturn.Replace("[LDAP Status]", Localization.GetString("[LDAP Status]", Me.LocalResourceFile))
            strReturn = strReturn.Replace("[Network Domains Status]", Localization.GetString("[Network Domains Status]", Me.LocalResourceFile))
            strReturn = strReturn.Replace("[LDAP Error Message]", Localization.GetString("[LDAP Error Message]", Me.LocalResourceFile))
            strReturn = strReturn.Replace("OK", Localization.GetString("OK", Me.LocalResourceFile))
            strReturn = strReturn.Replace("FAIL", Localization.GetString("FAIL", Me.LocalResourceFile))
            '
            Return strReturn

        End Function


    End Class

End Namespace
