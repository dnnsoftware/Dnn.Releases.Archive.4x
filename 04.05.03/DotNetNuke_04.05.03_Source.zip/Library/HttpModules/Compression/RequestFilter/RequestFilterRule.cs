using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;

namespace DotNetNuke.HttpModules.Compression.RequestFilter
{
    public class RequestFilterRule
    {
        public void SetValues(string values, RequestFilterOperatorType op)
        {
            _Values.Clear();
            if (op != RequestFilterOperatorType.Regex)
            {
                string[] vals = values.Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries);
                foreach (string value in vals)
                {
                    _Values.Add(value.ToUpperInvariant());
                }
            }
            else
            {
                // we do not want to split a regex string
                _Values.Add(values);
            }
        }

        /// <summary>
        /// Initializes a new instance of the RequestFilterRule class.
        /// </summary>
        /// <param name="serverVariable"></param>
        /// <param name="values"></param>
        /// <param name="action"></param>
        /// <param name="location"></param>
        public RequestFilterRule(string serverVariable, string values, RequestFilterOperatorType op, RequestFilterRuleType action, string location)
        {
            _ServerVariable = serverVariable;
            SetValues(values, op);
            _Operator = op;
            _Action = action;
            _Location = location;
        }

        /// <summary>
        /// Initializes a new instance of the RequestFilterRule class.
        /// </summary>
        public RequestFilterRule()
        {
        }
        
        private string _ServerVariable;
        public string ServerVariable
        {
            get { return _ServerVariable; }
            set { _ServerVariable = value; }
        }

        private List<string> _Values = new List<string>();
        public List<string> Values
        {
            get { return _Values; }
            set { _Values = value; }
        }

        public string RawValue
        {
            get { return string.Join(";", _Values.ToArray()); }
        }

        private RequestFilterRuleType _Action;
        public RequestFilterRuleType Action
        {
            get { return _Action; }
            set { _Action = value; }
        }

        private RequestFilterOperatorType _Operator;
        public RequestFilterOperatorType Operator
        {
            get { return _Operator; }
            set { _Operator = value; }
        }

        private string _Location;
        public string Location
        {
            get { return _Location; }
            set { _Location = value; }
        }

        public bool Matches(string ServerVariableValue)
        {
            switch (Operator)
            {
                case RequestFilterOperatorType.Equal:
                    return Values.Contains(ServerVariableValue.ToUpperInvariant());
                    break;
                case RequestFilterOperatorType.NotEqual:
                    return !Values.Contains(ServerVariableValue.ToUpperInvariant());
                    break;
                case RequestFilterOperatorType.Regex:
                    return Regex.IsMatch(ServerVariableValue, Values[0]);
                    break;
            }
            return false;   
        }

        public void Execute()
        {
            HttpResponse response = HttpContext.Current.Response;
            switch (this.Action)
            {
                case RequestFilterRuleType.Redirect:
                    response.Redirect(Location, true);
                    break;
                case RequestFilterRuleType.PermanentRedirect:
                    response.StatusCode = 301;
                    response.Status = "301 Moved Permanently";
                    response.Redirect(Location, true);
                    break;
                case RequestFilterRuleType.NotFound:
                    response.StatusCode = 404;
                    response.SuppressContent = true;
                    response.End();
                    break;
            }
        }

    }
}
