using System;
using System.Collections.Generic;
using System.Text;

namespace DotNetNuke.HttpModules.Compression.RequestFilter
{
    public enum RequestFilterRuleType
    { Redirect, PermanentRedirect, NotFound}

    public enum RequestFilterOperatorType
    { Equal, NotEqual, Regex }
}
