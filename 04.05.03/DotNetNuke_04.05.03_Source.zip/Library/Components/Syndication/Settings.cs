using System;
using System.Collections.Generic;
using System.Text;

namespace DotNetNuke.Services.Syndication
{
    static class Settings
    {
        internal static string CacheRoot = "Portals/_default/Cache";
    }
}
