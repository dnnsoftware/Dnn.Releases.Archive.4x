using System;
using System.Collections.Generic;
using System.Text;

namespace DotNetNuke.HttpModules.Compression.RequestFilter
{
    class RequestFilter
    {
    }
}
