Public Class About
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnOK As System.Windows.Forms.Button
    Friend WithEvents lnkSolpart As System.Windows.Forms.LinkLabel
    Friend WithEvents lnkUpdate As System.Windows.Forms.LinkLabel
    Friend WithEvents Label6 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(About))
        Me.lnkSolpart = New System.Windows.Forms.LinkLabel()
        Me.lnkUpdate = New System.Windows.Forms.LinkLabel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lnkSolpart
        '
        Me.lnkSolpart.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lnkSolpart.Image = CType(resources.GetObject("lnkSolpart.Image"), System.Drawing.Bitmap)
        Me.lnkSolpart.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.lnkSolpart.Location = New System.Drawing.Point(46, 23)
        Me.lnkSolpart.Name = "lnkSolpart"
        Me.lnkSolpart.Size = New System.Drawing.Size(149, 83)
        Me.lnkSolpart.TabIndex = 0
        Me.lnkSolpart.TabStop = True
        Me.lnkSolpart.Text = "http://www.solpart.com"
        Me.lnkSolpart.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        '
        'lnkUpdate
        '
        Me.lnkUpdate.Location = New System.Drawing.Point(93, 114)
        Me.lnkUpdate.Name = "lnkUpdate"
        Me.lnkUpdate.Size = New System.Drawing.Size(51, 15)
        Me.lnkUpdate.TabIndex = 1
        Me.lnkUpdate.TabStop = True
        Me.lnkUpdate.Text = "Updates"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(9, 5)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(219, 15)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Brought to you by:"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnOK
        '
        Me.btnOK.Location = New System.Drawing.Point(83, 147)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(69, 22)
        Me.btnOK.TabIndex = 4
        Me.btnOK.Text = "Ok"
        '
        'Label6
        '
        Me.Label6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label6.Location = New System.Drawing.Point(4, 136)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(228, 2)
        Me.Label6.TabIndex = 27
        '
        'About
        '
        Me.AcceptButton = Me.btnOK
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(235, 174)
        Me.ControlBox = False
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label6, Me.btnOK, Me.Label1, Me.lnkUpdate, Me.lnkSolpart})
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "About"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "About"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
        Me.Hide()
    End Sub

    Private Sub About_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    End Sub

    Private Sub lnkSolpart_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lnkSolpart.LinkClicked
        System.Diagnostics.Process.Start("http://www.solpart.com")
    End Sub

    Private Sub lnkUpdate_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lnkUpdate.LinkClicked
        System.Diagnostics.Process.Start("http://www.solpart.com/techcorner/solpartmenuhistory.aspx")
    End Sub
End Class
