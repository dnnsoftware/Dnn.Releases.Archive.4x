Public Class SolpartLib
  'shared functions are cool!
  'allow you to call them without the instantiation of an object

  Public Shared Function GetColor(ByVal objColor As System.Drawing.Color) As String
    If objColor.IsEmpty Then
      Return ""
    Else
      Return System.Drawing.ColorTranslator.ToHtml(objColor)  'Thanks for pointing this one out ido
      'If objColor.IsNamedColor = False Then
      '  Return "#" & objColor.R.ToString("X2") & objColor.G.ToString("X2") & objColor.B.ToString("X2")
      'Else
      '  Return objColor.ToKnownColor.ToString
      'End If
    End If
  End Function

  Public Shared Function GetColor(ByVal sColor As String) As System.Drawing.Color
    Dim objColor As System.Drawing.Color
    Dim objConvert As System.Drawing.ColorConverter = New System.Drawing.ColorConverter()
    objColor = CType(objConvert.ConvertFromString(sColor), System.Drawing.Color)

    Return objColor

  End Function

  Public Shared Function GetSafeAttribute(ByVal objNode As Xml.XmlNode, ByVal sAttr As String) As String
    If objNode.Attributes(sAttr) Is Nothing Then
      Return ""
    Else
      Return objNode.Attributes(sAttr).Value.ToString
    End If
  End Function

  Public Shared Sub SetSafeAttribute(ByVal objNode As Xml.XmlNode, ByVal sAttr As String, ByVal sValue As String)
    If Len(sValue) > 0 Then
      If objNode.Attributes(sAttr) Is Nothing Then
        objNode.Attributes.Append(objNode.OwnerDocument.CreateAttribute(sAttr))
      End If
      objNode.Attributes(sAttr).Value = sValue
    Else
      If Not objNode.Attributes(sAttr) Is Nothing Then
        Dim objElement As Xml.XmlElement = CType(objNode, Xml.XmlElement)
        objElement.RemoveAttribute(sAttr)
        'objNode.RemoveChild(objNode.Attributes(sAttr))
        MsgBox(objNode.OuterXml)
      End If
    End If
  End Sub

End Class
