/*HM_Loader.js*/

function findPosX(obj) {
  var curleft = 0;
  if (obj.offsetParent) {
    while (obj.offsetParent) {
      curleft += obj.offsetLeft
      obj = obj.offsetParent;
    }
  }
  else if (obj.x)
    curleft += obj.x;

  return curleft;
}

function findPosY(obj) {
  var curtop = 0;
  if (obj.offsetParent) {
    while (obj.offsetParent) {
      curtop += obj.offsetTop
      obj = obj.offsetParent;
    }
  }
  else if (obj.y)
    curtop += obj.y;

  return curtop;
}

HM_DOM = (document.getElementById) ? true : false;
HM_NS4 = (document.layers) ? true : false;
HM_IE = (document.all) ? true : false;
HM_IE4 = HM_IE && !HM_DOM;
HM_Mac = (navigator.appVersion.indexOf("Mac") != -1);
HM_IE4M = HM_IE4 && HM_Mac;
HM_IsMenu = (HM_DOM || HM_NS4 || (HM_IE4 && !HM_IE4M));

HM_BrowserString = HM_NS4 ? "NS4" : HM_DOM ? "DOM" : "IE4";

if(window.event + "" == "undefined") event = null;
function HM_f_PopUp(){return false};
function HM_f_PopDown(){return false};
popUp = HM_f_PopUp;
popDown = HM_f_PopDown;

HM_PG_MenuWidth = 150;
HM_PG_FontFamily = "Arial,sans-serif";
HM_PG_FontSize = 8;
HM_PG_FontBold = 1;
HM_PG_FontItalic = 0;
HM_PG_FontColor = "#FFFFFF";
HM_PG_FontColorOver = "#CCCCCC";
HM_PG_BGColor = "#333333";
HM_PG_BGColorOver = "#333333";
HM_PG_ItemPadding = 3;
HM_PG_BorderWidth = 1;
HM_PG_BorderColor = "#CCCCCC";
HM_PG_BorderStyle = "solid";
HM_PG_SeparatorSize = 1;
HM_PG_SeparatorColor = "#CCCCCC";
HM_PG_ImageSrc = "images/menu_right.gif";
HM_PG_ImageSrcLeft = "";
HM_PG_ImageSize = 9;
HM_PG_ImageHorizSpace = 0;
HM_PG_ImageVertSpace = 2;
HM_PG_KeepHilite = true; 
HM_PG_ClickStart = 0;
HM_PG_ClickKill = true;
HM_PG_ChildOverlap = 20;
HM_PG_ChildOffset = 0;
HM_PG_ChildPerCentOver = 0;
HM_PG_TopSecondsVisible = .5;
HM_PG_StatusDisplayBuild =0;
HM_PG_StatusDisplayLink = 0;
HM_PG_UponDisplay = null;
HM_PG_UponHide = null;
HM_PG_RightToLeft = false;
HM_PG_ShowLinkCursor = 1;

if(HM_IsMenu) {
  document.write("<SCR" + "IPT LANGUAGE='JavaScript1.2' SRC='controls/HM_Arrays.js' TYPE='text/javascript'><\/SCR" + "IPT>");
  document.write("<SCR" + "IPT LANGUAGE='JavaScript1.2' SRC='controls/HM_Script"+ HM_BrowserString +".js' TYPE='text/javascript'><\/SCR" + "IPT>");
}

//end