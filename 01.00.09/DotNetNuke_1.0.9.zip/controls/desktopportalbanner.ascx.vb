'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2003
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.IO

Namespace DotNetNuke

    Public MustInherit Class DesktopPortalBanner
        Inherits System.Web.UI.UserControl

        Protected WithEvents hypLogo As System.Web.UI.WebControls.HyperLink
        Protected WithEvents hypBanner As System.Web.UI.WebControls.HyperLink
        Protected WithEvents ctlMenu As SolpartWebControls.SolpartMenu
        Protected WithEvents lblDate As System.Web.UI.WebControls.Label
        Protected WithEvents hypUser As System.Web.UI.WebControls.HyperLink
        Protected WithEvents imgSpacer1 As System.Web.UI.WebControls.Image
        Protected WithEvents imgSpacer2 As System.Web.UI.WebControls.Image
        Protected WithEvents imgSpacer3 As System.Web.UI.WebControls.Image
        Protected WithEvents imgTabImage As System.Web.UI.WebControls.Image
        Protected WithEvents imgBevel As System.Web.UI.WebControls.Image
        Protected WithEvents hypHelp As System.Web.UI.WebControls.HyperLink
        Protected WithEvents lblSeparator As System.Web.UI.WebControls.Label
        Protected WithEvents hypLogin As System.Web.UI.WebControls.HyperLink
        Protected WithEvents lblBreadCrumbs As System.Web.UI.WebControls.Label

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            Dim ServerPath As String
            Dim BannerId As Integer

            ' format the Request.ApplicationPath
            ServerPath = Request.ApplicationPath
            If Not ServerPath.EndsWith("/") Then
                ServerPath += "/"
            End If

            ' set page title and stylesheet
            If Not Me.Parent.FindControl("Title") Is Nothing Then
                Dim strTitle As String = _portalSettings.PortalName
                Dim tab As TabStripDetails
                For Each tab In _portalSettings.BreadCrumbs
                    strTitle += " > " & tab.TabName
                Next
                strTitle += " ( DNN " & _portalSettings.Version & " )"
                CType(Me.Parent.FindControl("Title"), HtmlGenericControl).InnerText = strTitle
            End If
            If Not Me.Parent.FindControl("StyleSheet") Is Nothing Then
                CType(Me.Parent.FindControl("StyleSheet"), HtmlGenericControl).Attributes("href") = _portalSettings.UploadDirectory & "portal.css"
            End If
            If Not Me.Parent.FindControl("Body") Is Nothing Then
                If _portalSettings.BackgroundFile <> "" Then
                    CType(Me.Parent.FindControl("Body"), HtmlGenericControl).Attributes("background") = _portalSettings.UploadDirectory & _portalSettings.BackgroundFile
                End If
            End If

            ' dynamically populate the portal settings
            If _portalSettings.LogoFile <> "" Then
                hypLogo.ImageUrl = _portalSettings.UploadDirectory & _portalSettings.LogoFile
            End If
            hypLogo.ToolTip = _portalSettings.PortalName
            hypLogo.NavigateUrl = GetPortalDomainName(_portalSettings.PortalAlias, Request)
            hypHelp.Visible = False
            lblSeparator.Visible = False
            If _portalSettings.UserRegistration <> 0 Then
                hypHelp.Text = "Register"
                hypHelp.NavigateUrl = "~/EditModule.aspx?tabid=" & _portalSettings.ActiveTab.TabId & "&def=Register"
                hypHelp.Visible = True
                lblSeparator.Visible = True
            End If
            hypLogin.Text = "Login"
            hypLogin.NavigateUrl = "~/DesktopDefault.aspx?tabid=" & _portalSettings.ActiveTab.TabId & "&showlogin=1"
            lblDate.Text = Format(Now(), "MMMM dd, yyyy")

            Dim objUser As New UsersDB()
            Dim dr As SqlDataReader

            hypUser.Text = ""
            dr = objUser.GetServices(_portalSettings.PortalId)
            If dr.Read Then
                hypUser.Text = "Member Services"
                hypUser.ToolTip = "Click Here To View Our Membership Services"
                hypUser.NavigateUrl = "~/EditModule.aspx?tabid=" & _portalSettings.ActiveTab.TabId & "&def=Register&services=1"
            End If
            dr.Close()

            ' banner advertising
            If _portalSettings.BannerAdvertising <> 0 Then

                Dim objVendor As New VendorsDB()
                Dim result As SqlDataReader
                Select Case _portalSettings.BannerAdvertising
                    Case 1 ' local
                        result = objVendor.FindBanners(_portalSettings.PortalId, , _portalSettings.PortalId)
                    Case 2 ' global
                        result = objVendor.FindBanners(_portalSettings.PortalId)
                End Select
                If result.Read() Then
                    BannerId = result("BannerId")
                    hypBanner.Visible = True
                    Select Case _portalSettings.BannerAdvertising
                        Case 1 ' local
                            hypBanner.ImageUrl = _portalSettings.UploadDirectory & CStr(result("ImageFile"))
                        Case 2 ' global
                            hypBanner.ImageUrl = "~/Site/" & CStr(result("ImageFile"))
                    End Select
                    hypBanner.ToolTip = CStr(result("BannerName"))
                Else ' no banners defined
                    BannerId = -1
                    hypBanner.ImageUrl = "~/images/nobanner.gif"
                End If
                result.Close()

                hypBanner.NavigateUrl = ServerPath & "DesktopModules/Banners/BannerClickThrough.aspx?BannerId=" & CStr(BannerId)
            Else
                hypBanner.Visible = False
                BannerId = -1
            End If

            Dim UserId As Integer = -1
            If Request.IsAuthenticated Then
                UserId = CType(Context.User.Identity.Name, Integer)
            End If

            ' log visit to site
            If _portalSettings.SiteLogHistory <> 0 Then
                Dim URLReferrer As String = ""
                If Not Request.UrlReferrer Is Nothing Then
                    URLReferrer = Request.UrlReferrer.ToString()
                End If
                Dim AffiliateId As Integer = -1
                If Not Request.Params("AffiliateId") Is Nothing Then
                    If IsNumeric(Request.Params("AffiliateId")) Then
                        AffiliateId = Int32.Parse(Request.QueryString("AffiliateId"))
                    End If
                End If
                Dim objAdmin As New AdminDB()
                objAdmin.AddSiteLog(_portalSettings.PortalId, UserId, URLReferrer, Request.Url.ToString(), Request.UserAgent, Request.UserHostAddress, Request.UserHostName, _portalSettings.ActiveTab.TabId, AffiliateId)
            End If

            ' If user logged in, customize welcome message
            If Request.IsAuthenticated = True Then
                dr = objUser.GetSingleUser(_portalSettings.PortalId, UserId)
                If dr.Read() Then
                    hypUser.Text = dr("FullName")
                    hypUser.ToolTip = "Click Here To Edit Your Account Profile"
                End If
                dr.Close()

                If Context.User.Identity.Name = _portalSettings.SuperUserId Then
                    hypUser.NavigateUrl = "~/EditModule.aspx?tabid=" & _portalSettings.ActiveTab.TabId & "&UserId=" & _portalSettings.SuperUserId & "&def=User Accounts"
                Else
                    hypUser.NavigateUrl = "~/EditModule.aspx?tabid=" & _portalSettings.ActiveTab.TabId & "&def=Register"
                End If

                If PortalSecurity.IsInRoles(_portalSettings.AdministratorRoleId.ToString) Then
                    hypHelp.Text = "Help"
                    hypHelp.NavigateUrl = "mailto:" & _portalSettings.HostSettings("HostEmail") & "?subject=" & _portalSettings.PortalName & " Support Request"
                    hypHelp.Visible = True
                    lblSeparator.Visible = True
                Else ' registered user
                    hypHelp.Text = "Help"
                    hypHelp.NavigateUrl = "mailto:" & _portalSettings.Email & "?subject=" & _portalSettings.PortalName & " Support Request"
                    hypHelp.Visible = True
                    lblSeparator.Visible = True
                End If

                hypLogin.Text = "Logoff"
                hypLogin.NavigateUrl = "~/Admin/Security/Logoff.aspx?tabid=" & _portalSettings.ActiveTab.TabId
            End If

            ' process bread crumbs
            Dim strBreadCrumbs = ""
            Dim intTab As Integer
            For intTab = 1 To _portalSettings.BreadCrumbs.Count - 1
                strBreadCrumbs += "&nbsp;<img src=""" & IIf(Request.ApplicationPath = "/", "", Request.ApplicationPath) & "/images/breadcrumb.gif"">&nbsp;<a href=""" & FormatURL() & "?tabid=" & CType(_portalSettings.BreadCrumbs(intTab), TabStripDetails).TabId & """ class=""SelectedTab"">" & CType(_portalSettings.BreadCrumbs(intTab), TabStripDetails).TabName & "</a>"
            Next
            lblBreadCrumbs.Text = strBreadCrumbs

            ' Build list of tabs to be shown to user
            Dim authorizedTabs As New ArrayList()
            Dim addedTabs As Integer = 0

            Dim i As Integer
            For i = 0 To _portalSettings.DesktopTabs.Count - 1

                Dim tab As TabStripDetails = CType(_portalSettings.DesktopTabs(i), TabStripDetails)

                Dim strTest As String = tab.TabName
                If tab.IsVisible Then
                    If PortalSecurity.IsInRoles(tab.AuthorizedRoles) = True Then
                        authorizedTabs.Add(tab)
                        addedTabs += 1
                    End If
                End If

            Next i

            If Request.IsAuthenticated Then
                ' append super tab
                If Context.User.Identity.Name = _portalSettings.SuperUserId Then
                    Dim SuperTab As TabStripDetails

                    SuperTab = New TabStripDetails()
                    SuperTab.TabName = "Host"
                    SuperTab.TabId = _portalSettings.SuperTabId
                    SuperTab.TabOrder = 999
                    SuperTab.AuthorizedRoles = ""
                    SuperTab.ParentId = -1
                    SuperTab.IsVisible = True
                    SuperTab.IconFile = ""
                    SuperTab.Level = 0
                    SuperTab.HasChildren = True
                    authorizedTabs.Add(SuperTab)

                    Dim objAdmin As New AdminDB()
                    dr = objAdmin.GetTabsByParentId(_portalSettings.SuperTabId)
                    While dr.Read
                        SuperTab = New TabStripDetails()
                        SuperTab.TabName = dr("TabName").ToString
                        SuperTab.TabId = dr("TabId")
                        SuperTab.TabOrder = 999
                        SuperTab.AuthorizedRoles = ""
                        SuperTab.ParentId = _portalSettings.SuperTabId
                        SuperTab.IsVisible = True
                        SuperTab.IconFile = ""
                        SuperTab.Level = 1
                        SuperTab.HasChildren = False
                        SuperTab.AdminTabIcon = dr("AdminTabIcon").ToString
                        authorizedTabs.Add(SuperTab)
                    End While
                    dr.Close()
                End If
            End If

            ' generate dynamic menu
            ctlMenu.SystemImagesPath = IIf(Request.ApplicationPath = "/", Request.ApplicationPath, Request.ApplicationPath & "/")
            ctlMenu.ArrowImage = "images/breadcrumb.gif"
            ctlMenu.SystemScriptPath = IIf(Request.ApplicationPath = "/", "", Request.ApplicationPath) & "/Controls/SolpartMenu/"

            Dim strTab As String
            Dim objTab As TabStripDetails
            Dim objNode As System.Xml.XmlNode
            Dim objAttribute As System.Xml.XmlAttribute
            For Each objTab In authorizedTabs
                strTab = objTab.TabName
                If objTab.ParentId = -1 Then ' root menu
                    If objTab.TabId = CType(_portalSettings.BreadCrumbs(0), TabStripDetails).TabId Then
                        strTab = "<img src=""" & IIf(Request.ApplicationPath = "/", "", Request.ApplicationPath) & "/images/breadcrumb.gif"">&nbsp;" & strTab
                    End If
                    If objTab.HasChildren Then
                        strTab = strTab & "<img src=""" & IIf(Request.ApplicationPath = "/", "", Request.ApplicationPath) & "/images/menu_down.gif"">"
                    End If
                    objNode = ctlMenu.AddMenuItem(objTab.TabId, strTab, FormatURL() & "?tabid=" & objTab.TabId)
                Else
                    Try
                        objNode = ctlMenu.AddMenuItem(objTab.ParentId, objTab.TabId, "&nbsp;" & strTab, FormatURL() & "?tabid=" & objTab.TabId)
                    Catch
                        ' throws exception if the parent tab has not been loaded ( may be related to user role security not allowing access to a parent tab )
                        objNode = Nothing
                    End Try
                End If

                ' menu icon
                If Not objNode Is Nothing Then
                    objAttribute = objNode.OwnerDocument.CreateAttribute("image")
                    If IsAdminTab(objTab.TabId, objTab.ParentId) Then
                        If objTab.AdminTabIcon <> "" Then
                            objAttribute.Value = "images/" & objTab.AdminTabIcon
                        End If
                    Else
                        If objTab.IconFile <> "" Then
                            If ctlMenu.SystemImagesPath <> "/" Then
                                objAttribute.Value = Replace(_portalSettings.UploadDirectory, ctlMenu.SystemImagesPath, "") & objTab.IconFile
                            Else
                                objAttribute.Value = Mid(_portalSettings.UploadDirectory, 2) & objTab.IconFile
                            End If
                        End If
                    End If
                    If objAttribute.Value <> "" Then
                        objNode.Attributes.Append(objAttribute)
                    End If
                End If
            Next

        End Sub

        Function MenuDropDown(ByVal blnHasChildren As Boolean) As String

            If blnHasChildren Then
                Return "<img src=""images/menu_down.gif"" border=""0"">"
            Else
                Return ""
            End If

        End Function

        Function FormatURL() As String

            Dim ServerPath As String

            ServerPath = Request.ApplicationPath
            If Not ServerPath.EndsWith("/") Then
                ServerPath += "/"
            End If

            Return ServerPath & "DesktopDefault.aspx"

        End Function

    End Class

End Namespace
