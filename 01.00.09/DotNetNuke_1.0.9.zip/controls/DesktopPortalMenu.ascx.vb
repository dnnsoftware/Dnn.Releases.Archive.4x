Imports System
Imports System.Xml
Imports System.Collections
Imports System.IO

Namespace ASPNetPortal

    Public MustInherit Class DesktopPortalMenu
        Inherits System.Web.UI.UserControl

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Response.Write(CreateMenu("HM_Array1", "150", Server.MapPath("controls/menuItems1.xml")))
        End Sub

        Public _menuStyle As String
        Private _arrayHolderArray As New ArrayList()
        Private _arrayNamesArray As New ArrayList()
        Private _strImage As String = "<img align=""right"" vspace=""2"" height=""10"" width=""10"" border=""0"" src=""images/tri.gif"">"
        Private _strCurrentMenu As String = ""
        Private _intLevel As Integer = 1
        Private _blnStaticMenus As Boolean
        Private _strSaveToFile As String

        Public Function CreateMenu(ByVal startMenu As String, ByVal menuStyle As String, ByVal file As String) As String
            _menuStyle = menuStyle
            Dim strOutput As String = ""
            Dim i As Integer = 0
            Dim startArray As New ArrayList()
            Dim strVariable As String = ""
            Dim strTemp As String = ""

            Dim XMLDoc As New XmlDocument()
            Try
                XMLDoc.Load(file)
            Catch e As Exception
                strOutput = e.GetBaseException().ToString()
                Return strOutput
            End Try

            Dim nodeList As XmlNodeList = XMLDoc.DocumentElement.ChildNodes

            startArray.Add((startMenu + " = [ " + ControlChars.Lf))
            startArray.Add(("[" + menuStyle + "], " + ControlChars.Lf))
            Dim node As XmlNode
            For Each node In nodeList

                Dim currentNode As XmlNode = node
                If currentNode.HasChildNodes = True And currentNode.ChildNodes.Count > 1 Then
                    _strCurrentMenu = startMenu + "_" + CStr(i + 1)

                    Dim thisMenu As String = startMenu

                    If currentNode.ChildNodes.Count > 4 Then
                        strVariable = "[""" + currentNode.ChildNodes(0).InnerText + """,""" + currentNode.ChildNodes(1).InnerText + """," + currentNode.ChildNodes(2).InnerText + "," + currentNode.ChildNodes(3).InnerText + ",1]"
                        If nodeList.Count - 1 > i Then
                            strVariable += ","
                        End If
                        startArray.Add((strVariable + ControlChars.Lf))
                        WalkTree(currentNode)
                    Else
                        strVariable = "[""" + currentNode.ChildNodes(0).InnerText + """,""" + currentNode.ChildNodes(1).InnerText + """," + currentNode.ChildNodes(2).InnerText + "," + currentNode.ChildNodes(3).InnerText + ",0]"
                        If nodeList.Count - 1 > i Then
                            strVariable += ","
                        End If
                        startArray.Add((strVariable + ControlChars.Lf))
                    End If
                End If
                i += 1
            Next node
            startArray.Add("] " + ControlChars.Lf + ControlChars.Lf)

            startArray.TrimToSize()
            _arrayNamesArray.Add(startMenu)
            For i = 0 To startArray.Count - 1
                strTemp += startArray(i)
            Next i
            _arrayHolderArray.Add(strTemp)

            'Reverse Array order 
            _arrayHolderArray.Reverse()
            _arrayNamesArray.Reverse()

            'Loop through arrays and write items
            For i = 0 To _arrayNamesArray.Count - 1
                strOutput += _arrayHolderArray(i).ToString()
            Next i
            _arrayHolderArray.Clear()
            _arrayNamesArray.Clear()

            If _blnStaticMenus Then
                Dim writer As New StreamWriter(System.IO.File.Open(_strSaveToFile, FileMode.OpenOrCreate, FileAccess.Write))
                writer.Write(strOutput)
                writer.Flush()
                If Not (writer Is Nothing) Then
                    writer.Close()
                End If
            End If
            Return strOutput
        End Function

        Private Sub WalkTree(ByVal node As XmlNode)
            _intLevel += 1
            Dim strVariable As String = ""
            Dim strTemp As String = ""
            Dim tempArray As New ArrayList()

            tempArray.Add((_strCurrentMenu + " = [ " + ControlChars.Lf))
            tempArray.Add("[], " + ControlChars.Lf)

            Dim j As Integer
            For j = 4 To node.ChildNodes.Count - 1
                Dim newNode As XmlNode = node.ChildNodes(j)

                If newNode.HasChildNodes = True And newNode.ChildNodes.Count > 4 Then ' Each node should have a 0=hyperlink and 1=text node so don't call the function again if there are just these children
                    _strCurrentMenu += "_" + CStr(j - 3)
                    Dim thisMenu As String = _strCurrentMenu.Substring(0, _strCurrentMenu.Length - 4)
                    strVariable = "[""" + newNode.ChildNodes(0).InnerText + """,""" + newNode.ChildNodes(1).InnerText + """," + newNode.ChildNodes(2).InnerText + "," + newNode.ChildNodes(3).InnerText + ",1]"
                    If node.ChildNodes.Count - 1 > j Then
                        strVariable += ","
                    End If
                    tempArray.Add((strVariable + ControlChars.Lf))
                    WalkTree(newNode)
                Else
                    strVariable = "[""" + newNode.ChildNodes(0).InnerText + """,""" + newNode.ChildNodes(1).InnerText + """," + newNode.ChildNodes(2).InnerText + "," + newNode.ChildNodes(3).InnerText + ",0]"
                    If node.ChildNodes.Count - 1 > j Then
                        strVariable += ","
                    End If
                    tempArray.Add((strVariable + ControlChars.Lf))
                End If
            Next j

            tempArray.Add("] " + ControlChars.Lf + ControlChars.Lf)

            tempArray.TrimToSize()
            _arrayNamesArray.Add(_strCurrentMenu)
            Dim i As Integer
            For i = 0 To tempArray.Count - 1
                strTemp += tempArray(i)
            Next i
            _arrayHolderArray.Add(strTemp)
            _strCurrentMenu = _strCurrentMenu.Substring(0, _strCurrentMenu.Length - 2) 'Exiting function so go back to previous menu version
            _intLevel -= 1
            tempArray.Clear()
        End Sub

    End Class

End Namespace
