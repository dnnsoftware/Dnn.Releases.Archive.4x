'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2003
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Namespace DotNetNuke

    Public MustInherit Class Events
        Inherits DotNetNuke.PortalModuleControl

        Protected WithEvents lstEvents As System.Web.UI.WebControls.DataList
        Protected WithEvents calEvents As System.Web.UI.WebControls.Calendar

        Dim arrEvents(31) As String
        Dim intMonth As Integer

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        '*******************************************************
        '
        ' The Page_Load event handler on this User Control is used to
        ' obtain a DataReader of event information from the Events
        ' table, and then databind the results to a templated DataList
        ' server control.  It uses the DotNetNuke.EventDB()
        ' data component to encapsulate all data functionality.
        '
        '*******************************************************'

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            Dim EventView As String = CType(Settings("eventview"), String)
            If EventView Is Nothing Then
                EventView = "C" ' calendar
            End If

            Dim events As New EventsDB()

            Select Case EventView
                Case "L" ' list
                    lstEvents.Visible = True
                    calEvents.Visible = False

                    lstEvents.DataSource = events.GetModuleEvents(ModuleId)
                    lstEvents.DataBind()
                Case "C" ' calendar
                    lstEvents.Visible = False
                    calEvents.Visible = True

                    If Not Page.IsPostBack Then
                        If Not Request.Params("VisibleDate") Is Nothing Then
                            calEvents.VisibleDate = Request.Params("VisibleDate")
                        Else
                            calEvents.VisibleDate = Now
                        End If

                        If CType(Settings("eventcalendarcellwidth"), String) <> "" Then
                            calEvents.Width = System.Web.UI.WebControls.Unit.Parse(CType(Settings("eventcalendarcellwidth"), String) & "px")
                        End If
                        If CType(Settings("eventcalendarcellheight"), String) <> "" Then
                            calEvents.Height = System.Web.UI.WebControls.Unit.Parse(CType(Settings("eventcalendarcellheight"), String) & "px")
                        End If
                    Else
                        If calEvents.VisibleDate = #12:00:00 AM# Then
                            calEvents.VisibleDate = Now
                        End If
                    End If

                    Dim StartDate As String = Format(calEvents.VisibleDate, "MMM 1, yyyy") & " 00:00"
                    Dim EndDate As String = Format(DateAdd(DateInterval.Day, Date.DaysInMonth(calEvents.VisibleDate.Year, calEvents.VisibleDate.Month) - 1, CDate(StartDate)), "MMM dd, yyyy") & " 23:59"

                    GetCalendarEvents(StartDate, EndDate)
                    calEvents.DataBind()
            End Select

        End Sub

        Private Sub calEvents_DayRender(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DayRenderEventArgs) Handles calEvents.DayRender

            If e.Day.Date.Month = intMonth Then
                Dim ctlLabel As Label = New Label()
                ctlLabel.Text = arrEvents(e.Day.Date.Day)
                e.Cell.Controls.Add(ctlLabel)
            End If

        End Sub

        Private Sub calEvents_VisibleMonthChanged(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.MonthChangedEventArgs) Handles calEvents.VisibleMonthChanged

            Dim StartDate As String = Format(e.NewDate.Date, "MMM 1, yyyy") & " 00:00"
            Dim EndDate As String = Format(DateAdd(DateInterval.Day, Date.DaysInMonth(e.NewDate.Year, e.NewDate.Month) - 1, CDate(StartDate)), "MMM dd, yyyy") & " 23:59"

            GetCalendarEvents(StartDate, EndDate)

        End Sub

        Private Sub GetCalendarEvents(ByVal StartDate As String, ByVal EndDate As String)
            Dim events As New EventsDB()
            Dim strDayText As String
            Dim datTargetDate As Date
            Dim datDate As Date
            Dim blnDisplay As Boolean

            Array.Clear(arrEvents, 0, 31)

            Dim dr As SqlDataReader = events.GetModuleEvents(ModuleId, StartDate, EndDate)
            While dr.Read()
                If dr("Period").ToString = "" Then
                    strDayText = "<br>"
                    If FormatImage(dr("IconFile")) <> "" Then
                        strDayText += "<img src=""" & FormatImage(dr("IconFile")) & """ border=""0""><br>"
                    End If
                    If IsEditable Then
                        strDayText += "<a href=""" & IIf(Request.ApplicationPath = "/", "", Request.ApplicationPath) & "/EditModule.aspx?tabid=" & TabId & "&mid=" & ModuleId & "&ItemID=" & dr("ItemID") & "&VisibleDate=" & calEvents.VisibleDate.ToShortDateString & """><img src=""" & IIf(Request.ApplicationPath = "/", "", Request.ApplicationPath) & "/images/edit.gif"" border=""0""></a>&nbsp;"
                    End If
                    strDayText += "<span class=""ItemTitle"">" & dr("Title") & "</span>"
                    If Format(dr("DateTime"), "hh:mm tt") <> "12:00 AM" Then
                        strDayText += "<br><span class=""Normal"">" & Format(dr("DateTime"), "hh:mm tt") & "</span>"
                    End If
                    strDayText += "<br><span class=""Normal"">" & dr("Description") & "</span>"

                    arrEvents(CDate(dr("DateTime")).Day) += strDayText
                Else ' recurring event
                    datTargetDate = CType(dr("DateTime"), Date).ToLongDateString
                    datDate = Date.Parse(StartDate)
                    While datDate <= Date.Parse(EndDate)
                        blnDisplay = False
                        Select Case dr("Period")
                            Case "D" ' day
                                If DateDiff(DateInterval.Day, datTargetDate, datDate) Mod dr("Every") = 0 Then
                                    blnDisplay = True
                                End If
                            Case "W" ' week
                                If DateAdd(DateInterval.WeekOfYear, DateDiff(DateInterval.WeekOfYear, datTargetDate, datDate), datTargetDate) = datDate Then
                                    If DateDiff(DateInterval.WeekOfYear, datTargetDate, datDate) Mod dr("Every") = 0 Then
                                        blnDisplay = True
                                    End If
                                End If
                            Case "M" ' month
                                If DateAdd(DateInterval.Month, DateDiff(DateInterval.Month, datTargetDate, datDate), datTargetDate) = datDate Then
                                    If DateDiff(DateInterval.Month, datTargetDate, datDate) Mod dr("Every") = 0 Then
                                        blnDisplay = True
                                    End If
                                End If
                            Case "Y" ' year
                                If DateAdd(DateInterval.Year, DateDiff(DateInterval.Year, datTargetDate, datDate), datTargetDate) = datDate Then
                                    If DateDiff(DateInterval.Year, datTargetDate, datDate) Mod dr("Every") = 0 Then
                                        blnDisplay = True
                                    End If
                                End If
                        End Select
                        If blnDisplay Then
                            If datDate < datTargetDate Then
                                blnDisplay = False
                            End If
                        End If
                        If blnDisplay Then
                            If Not IsDBNull(dr("ExpireDate")) Then
                                If datDate > CType(dr("ExpireDate"), Date).ToLongDateString Then
                                    blnDisplay = False
                                End If
                            End If
                        End If
                        If blnDisplay Then
                            strDayText = "<br>"
                            If FormatImage(dr("IconFile")) <> "" Then
                                strDayText += "<img src=""" & FormatImage(dr("IconFile")) & """ border=""0""><br>"
                            End If
                            If IsEditable Then
                                strDayText += "<a href=""" & IIf(Request.ApplicationPath = "/", "", Request.ApplicationPath) & "/EditModule.aspx?tabid=" & TabId & "&mid=" & ModuleId & "&ItemID=" & dr("ItemID") & "&VisibleDate=" & calEvents.VisibleDate.ToShortDateString & """><img src=""" & IIf(Request.ApplicationPath = "/", "", Request.ApplicationPath) & "/images/edit.gif"" border=""0""></a>&nbsp;"
                            End If
                            strDayText += "<span class=""ItemTitle"">" & dr("Title") & "</span>"
                            If Format(dr("DateTime"), "hh:mm tt") <> "12:00 AM" Then
                                strDayText += "<br><span class=""Normal"">" & Format(dr("DateTime"), "hh:mm tt") & "</span>"
                            End If
                            strDayText += "<br><span class=""Normal"">" & dr("Description") & "</span>"

                            arrEvents(datDate.Day) += strDayText
                        End If
                        datDate = DateAdd(DateInterval.Day, 1, datDate)
                    End While
                End If
            End While
            dr.Close()

            intMonth = CDate(StartDate).Month

        End Sub

        Function FormatDateTime(ByVal DateTime As Date) As String

            FormatDateTime = Format(DateTime, "dddd, MMM d, yyyy")
            If DatePart(DateInterval.Hour, DateTime) <> 0 Or DatePart(DateInterval.Minute, DateTime) <> 0 Or DatePart(DateInterval.Second, DateTime) <> 0 Then
                FormatDateTime = FormatDateTime & " at " & Format(DateTime, "hh:mm tt")
            End If

        End Function

        Function FormatImage(ByVal IconFile As Object) As String

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            If Not IsDBNull(IconFile) Then
                FormatImage = _portalSettings.UploadDirectory & IconFile.ToString
            End If

        End Function

    End Class

End Namespace
