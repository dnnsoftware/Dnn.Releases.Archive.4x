'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2003
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Namespace DotNetNuke

    Public Class ModuleSettingsPage
        Inherits DotNetNuke.PortalModuleControl

        Protected WithEvents txtTitle As System.Web.UI.WebControls.TextBox
        Protected WithEvents cboIcon As System.Web.UI.WebControls.DropDownList
        Protected WithEvents cmdUpload As System.Web.UI.WebControls.HyperLink
        Protected WithEvents chkShowTitle As System.Web.UI.WebControls.CheckBox
        Protected WithEvents chkAllTabs As System.Web.UI.WebControls.CheckBox
        Protected WithEvents chkShowMobile As System.Web.UI.WebControls.CheckBox
        Protected WithEvents cboPersonalize As System.Web.UI.WebControls.DropDownList
        Protected WithEvents txtCacheTime As System.Web.UI.WebControls.TextBox
        Protected WithEvents chkAuthViewRoles As System.Web.UI.WebControls.CheckBoxList
        Protected WithEvents chkAuthEditRoles As System.Web.UI.WebControls.CheckBoxList
        Protected WithEvents cboAlign As System.Web.UI.WebControls.DropDownList
        Protected WithEvents txtColor As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtBorder As System.Web.UI.WebControls.TextBox
        Protected WithEvents lblPreview As System.Web.UI.WebControls.Label
        Protected WithEvents cmdEdit As System.Web.UI.WebControls.LinkButton
        Protected WithEvents rowContainer As System.Web.UI.HtmlControls.HtmlTableRow
        Protected WithEvents txtContainer As System.Web.UI.WebControls.TextBox
        Protected WithEvents chkDefault As System.Web.UI.WebControls.CheckBox
        Protected WithEvents chkGlobal As System.Web.UI.WebControls.CheckBox
        Protected WithEvents lblMessage As System.Web.UI.WebControls.Label
        Protected WithEvents cboTab As System.Web.UI.WebControls.DropDownList
        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdDelete As System.Web.UI.WebControls.LinkButton

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        '*******************************************************
        '
        ' The Page_Load server event handler on this page is used
        ' to populate the module settings on the page
        '
        '*******************************************************

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            ' Verify that the current user has access to edit this module
            If PortalSecurity.IsInRoles(_portalSettings.AdministratorRoleId.ToString) = False And PortalSecurity.IsInRoles(_portalSettings.ActiveTab.AdministratorRoles.ToString) = False Then
                Response.Redirect("~/EditModule.aspx?tabid=" & TabId & "&def=Edit Access Denied")
            End If

            If Page.IsPostBack = False Then

                cmdDelete.Attributes.Add("onClick", "javascript:return confirm('Are You Sure You Wish To Delete This Item ?');")

                ' load the list of files found in the upload directory
                cmdUpload.NavigateUrl = "~/EditModule.aspx?tabid=" & TabId & "&def=File Manager"
                Dim LogoFileList As ArrayList = GetFileList(PortalId, glbImageFileTypes)
                cboIcon.DataSource = LogoFileList
                cboIcon.DataBind()

                cboTab.DataSource = GetPortalTabs(_portalSettings.DesktopTabs, , True)
                cboTab.DataBind()

                ' tab administrators can only manage their own tab
                If PortalSecurity.IsInRoles(_portalSettings.AdministratorRoleId.ToString) = False Then
                    cboTab.Enabled = False
                End If

                rowContainer.Visible = False

                If ModuleId <> -1 Then
                    BindData()
                Else
                    'cboAlignment.Items.FindByValue("left").Selected = True
                    chkShowTitle.Checked = True
                    cboPersonalize.SelectedIndex = 0 ' maximized
                    chkAllTabs.Checked = False
                    cmdDelete.Visible = False
                End If

                ' Store URL Referrer to return to portal
                ViewState("UrlReferrer") = "~/DesktopDefault.aspx?tabid=" & TabId
            End If

        End Sub


        '*******************************************************
        '
        ' The ApplyChanges_Click server event handler on this page is used
        ' to save the module settings into the portal configuration system
        '
        '*******************************************************

        Private Sub ApplyChanges_Click(ByVal Sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click

            Dim admin As New AdminDB()

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            Dim strMessage As String = ""

            If txtContainer.Text <> "" Then
                Dim settings As Hashtable = PortalSettings.GetModuleSettings(admin.GetSiteModule("Site Settings", PortalId))
                If txtContainer.Text <> settings("container") Then
                    If InStr(1, txtContainer.Text, "[MODULE]") = 0 Then
                        strMessage = "<br>The Module Container Must Contain A [MODULE] Placeholder"
                    End If
                    If (UBound(Split(txtContainer.Text.ToLower, "<table")) <> UBound(Split(txtContainer.Text.ToLower, "</table"))) Or _
                       (UBound(Split(txtContainer.Text.ToLower, "<tr")) <> UBound(Split(txtContainer.Text.ToLower, "</tr"))) Or _
                       (UBound(Split(txtContainer.Text.ToLower, "<td")) <> UBound(Split(txtContainer.Text.ToLower, "</td"))) Or _
                       (UBound(Split(txtContainer.Text.ToLower, """")) Mod 2 <> 0) Or _
                       (UBound(Split(txtContainer.Text.ToLower, "<")) <> UBound(Split(txtContainer.Text.ToLower, ">"))) Then
                        strMessage = "<br>An HTML Script Error Exists In The Module Container"
                    End If
                End If
            End If

            If strMessage <> "" Then
                lblMessage.Text = strMessage
            Else

                If chkDefault.Checked Then
                    Dim intModuleId As Integer = admin.GetSiteModule("Site Settings", PortalId)
                    admin.UpdateModuleSetting(intModuleId, "container", txtContainer.Text)
                    txtContainer.Text = ""
                End If

                If chkGlobal.Checked Then
                    admin.UpdatePortalModules(PortalId)
                End If

                Dim item As ListItem

                ' Construct Authorized View Roles 
                Dim viewRoles As String = ""
                For Each item In chkAuthViewRoles.Items
                    If item.Selected Then
                        viewRoles = viewRoles & item.Value & ";"
                    End If
                Next item
                If viewRoles <> "" Then
                    If InStr(1, viewRoles, _portalSettings.AdministratorRoleId.ToString & ";") = 0 Then
                        viewRoles += _portalSettings.AdministratorRoleId.ToString & ";"
                    End If
                End If

                ' Construct Authorized Edit Roles
                Dim editRoles As String = ""
                For Each item In chkAuthEditRoles.Items
                    If item.Selected = True Or item.Value = _portalSettings.AdministratorRoleId.ToString Then
                        editRoles = editRoles & item.Value & ";"
                    End If
                Next item

                Dim strIcon As String = ""
                If Not cboIcon.SelectedItem Is Nothing Then
                    strIcon = cboIcon.SelectedItem.Value
                End If

                ' update module
                admin.UpdateModule(ModuleId, txtTitle.Text, cboAlign.SelectedItem.Value, txtColor.Text, txtBorder.Text, strIcon, Int32.Parse(txtCacheTime.Text), viewRoles, editRoles, chkShowMobile.Checked, Int32.Parse(cboTab.SelectedItem.Value), chkAllTabs.Checked, chkShowTitle.Checked, Int32.Parse(cboPersonalize.SelectedItem.Value), txtContainer.Text)

                ' update tab module order ( in case module was moved to another tab )
                admin.UpdateTabModuleOrder(TabId)

                ' Navigate back to admin page
                Response.Redirect(CType(Viewstate("UrlReferrer"), String))
            End If

        End Sub


        '*******************************************************
        '
        ' The BindData helper method is used to populate a asp:datalist
        ' server control with the current "edit access" permissions
        ' set within the portal configuration system
        '
        '*******************************************************

        Sub BindData()

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            Dim objAdmin As New AdminDB()
            Dim objUser As New UsersDB()

            Dim ViewRoles As SqlDataReader = objUser.GetPortalRoles(PortalId)

            ' Clear existing items in checkboxlist
            chkAuthViewRoles.Items.Clear()

            Dim allViewItems As New ListItem()
            allViewItems.Text = "All Users"
            allViewItems.Value = glbRoleAllUsers

            Dim EditRoles As SqlDataReader = objUser.GetPortalRoles(PortalId)

            ' Clear existing items in checkboxlist
            chkAuthEditRoles.Items.Clear()

            Dim allEditItems As New ListItem()
            allEditItems.Text = "All Users"
            allEditItems.Value = glbRoleAllUsers

            Dim result As SqlDataReader = objAdmin.GetModule(ModuleId)
            If result.Read() Then
                txtTitle.Text = result("ModuleTitle").ToString
                If cboIcon.Items.Contains(New ListItem(result("IconFile").ToString)) Then
                    cboIcon.Items.FindByText(result("IconFile").ToString).Selected = True
                End If

                chkShowTitle.Checked = result("ShowTitle")
                chkAllTabs.Checked = result("AllTabs")
                chkShowMobile.Checked = result("ShowMobile")

                txtCacheTime.Text = result("CacheTime")
                cboPersonalize.SelectedIndex = result("Personalize")
                cboTab.Items.FindByValue(result("TabId").ToString).Selected = True

                If InStr(1, IIf(IsDBNull(result("AuthorizedViewRoles")), "", result("AuthorizedViewRoles")), allViewItems.Value & ";") Then
                    allViewItems.Selected = True
                End If

                chkAuthViewRoles.Items.Add(allViewItems)

                While ViewRoles.Read()

                    Dim item As New ListItem()
                    item.Text = CType(ViewRoles("RoleName"), String)
                    item.Value = ViewRoles("RoleID").ToString()

                    If InStr(1, IIf(IsDBNull(result("AuthorizedViewRoles")), "", result("AuthorizedViewRoles")), item.Value & ";") Then
                        item.Selected = True
                    End If

                    chkAuthViewRoles.Items.Add(item)

                End While

                If InStr(1, IIf(IsDBNull(result("AuthorizedEditRoles")), "", result("AuthorizedEditRoles")), allEditItems.Value & ";") Then
                    allEditItems.Selected = True
                End If

                chkAuthEditRoles.Items.Add(allEditItems)

                While EditRoles.Read()

                    Dim item As New ListItem()
                    item.Text = CType(EditRoles("RoleName"), String)
                    item.Value = EditRoles("RoleID").ToString()

                    If InStr(1, IIf(IsDBNull(result("AuthorizedEditRoles")), "", result("AuthorizedEditRoles")), item.Value & ";") Then
                        item.Selected = True
                    End If

                    chkAuthEditRoles.Items.Add(item)

                End While

                If result("Alignment").ToString <> "" Then
                    cboAlign.Items.FindByValue(result("Alignment").ToString).Selected = True
                End If
                txtColor.Text = result("Color").ToString
                txtBorder.Text = result("Border").ToString

                txtContainer.Text = result("Container").ToString
            End If
            result.Close()

            Dim strContainer As String = txtContainer.Text
            If strContainer = "" Then
                Dim settings As Hashtable = PortalSettings.GetModuleSettings(objAdmin.GetSiteModule("Site Settings", PortalId))
                strContainer = settings("container")
            End If
            strContainer = Replace(strContainer, "[ALIGN]", IIf(cboAlign.SelectedItem.Value <> "", " align=""" & cboAlign.SelectedItem.Value & """", ""))
            strContainer = Replace(strContainer, "[COLOR]", IIf(txtColor.Text <> "", " bgcolor=""" & txtColor.Text & """", ""))
            strContainer = Replace(strContainer, "[BORDER]", IIf(txtBorder.Text <> "", " border=""" & txtBorder.Text & """", ""))
            strContainer = ManageUploadDirectory(strContainer, _portalSettings.UploadDirectory)
            lblPreview.Text = strContainer

        End Sub

        Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click

            Response.Redirect(CType(Viewstate("UrlReferrer"), String))

        End Sub

        Private Sub cmdDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdDelete.Click

            Dim objAdmin As New AdminDB()

            objAdmin.DeleteModule(ModuleId)
            objAdmin.UpdateTabModuleOrder(TabId)

            Response.Redirect(CType(Viewstate("UrlReferrer"), String))

        End Sub

        Private Sub cmdEdit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdEdit.Click

            If txtContainer.Text = "" Then
                Dim objAdmin As New AdminDB()
                Dim settings As Hashtable = PortalSettings.GetModuleSettings(objAdmin.GetSiteModule("Site Settings", PortalId))
                txtContainer.Text = settings("container")
            End If

            rowContainer.Visible = True

            'Dim P1 As Integer = InStr(1, txtContainer.Text, "[MODULE]")
            'Dim P2 As Integer = InStrRev(txtContainer.Text, "<td", P1)
            'Dim strTD As String = Mid(txtContainer.Text, P1, (P2 - P1) + 1)

            'If cboAlign.SelectedItem.Value <> "" Then
            'End If
            'If cboVAlign.SelectedItem.Value <> "" Then
            'End If
            'If txtColor.Text <> "" Then
            'End If
            'If txtBorder.Text <> "" Then
            'End If
        End Sub

    End Class

End Namespace
