'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2003
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports ICSharpCode.SharpZipLib.Zip
Imports System.IO

Namespace DotNetNuke

    Public Class WebUpload
        Inherits DotNetNuke.PortalModuleControl

        Protected WithEvents cmdBrowse As System.Web.UI.HtmlControls.HtmlInputFile
        Protected WithEvents lstFiles As System.Web.UI.WebControls.ListBox
        Protected WithEvents cmdAdd As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdRemove As System.Web.UI.WebControls.LinkButton
        Protected WithEvents chkUnzip As System.Web.UI.WebControls.CheckBox
        Protected WithEvents cmdUpload As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
        Protected WithEvents lblMessage As System.Web.UI.WebControls.Label

        Public Shared arrFiles As ArrayList = New ArrayList()

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        '*******************************************************
        '
        ' The Page_Load server event handler on this page is used
        ' to populate the role information for the page
        '
        '*******************************************************

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            Dim objAdmin As New AdminDB()
            Dim intModuleId As Integer = objAdmin.GetSiteModule("File Manager", PortalId)
            Dim settings As Hashtable = _portalSettings.GetModuleSettings(intModuleId)
            Dim UploadRoles As String = ""
            If Not CType(settings("uploadroles"), String) Is Nothing Then
                UploadRoles = CType(settings("uploadroles"), String)
            End If

            If PortalSecurity.IsInRole(_portalSettings.AdministratorRoleId.ToString) = False And PortalSecurity.IsInRoles(UploadRoles) = False Then
                Response.Redirect("~/EditModule.aspx?tabid=" & _portalSettings.ActiveTab.TabId & "&def=Edit Access Denied")
            End If

            If Page.IsPostBack = False Then
                ' initialize file list
                arrFiles.Clear()
                chkUnzip.Checked = True

                ' Store URL Referrer to return to portal
                If Not Request.UrlReferrer Is Nothing Then
                    ViewState("UrlReferrer") = Request.UrlReferrer.ToString()
                Else
                    ViewState("UrlReferrer") = ""
                End If
            End If

        End Sub

        Private Sub cmdAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdAdd.Click
            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            If Page.IsPostBack Then
                If cmdBrowse.PostedFile.FileName <> "" Then
                    arrFiles.Add(cmdBrowse)
                    lstFiles.Items.Add(cmdBrowse.PostedFile.FileName)
                End If
            End If
        End Sub

        Private Sub cmdRemove_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRemove.Click
            If lstFiles.Items.Count <> 0 Then
                arrFiles.RemoveAt(lstFiles.SelectedIndex)
                lstFiles.Items.Remove(lstFiles.SelectedItem.Text)
            End If
        End Sub

        Private Sub cmdUpload_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdUpload.Click
            Dim strFileName As String
            Dim strFileNamePath As String
            Dim strExtension As String = ""
            Dim strMessage As String = ""

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            Dim objAdmin As New AdminDB()
            Dim objHtmlInputFile As System.Web.UI.HtmlControls.HtmlInputFile

            For Each objHtmlInputFile In arrFiles
                'Gets the file name
                strFileName = System.IO.Path.GetFileName(objHtmlInputFile.PostedFile.FileName)

                If ((((objAdmin.GetPortalSpaceUsed(PortalId) + objHtmlInputFile.PostedFile.ContentLength) / 1000000) <= _portalSettings.HostSpace) Or _portalSettings.HostSpace = 0) Or (_portalSettings.ActiveTab.ParentId = _portalSettings.SuperTabId) Then

                    If _portalSettings.ActiveTab.ParentId = _portalSettings.SuperTabId Then
                        strFileNamePath = Request.MapPath(glbSiteDirectory) & strFileName
                    Else
                        strFileNamePath = Request.MapPath(_portalSettings.UploadDirectory) & strFileName
                    End If

                    strExtension = ""
                    If InStr(1, strFileNamePath, ".") Then
                        strExtension = Mid(strFileNamePath, InStrRev(strFileNamePath, ".") + 1).ToLower
                    End If

                    If InStr(1, "," & _portalSettings.HostSettings("FileExtensions").ToString, "," & strExtension) <> 0 Or _portalSettings.ActiveTab.ParentId = _portalSettings.SuperTabId Then
                        'Save Uploaded file to server
                        Try
                            If File.Exists(strFileNamePath) Then
                                File.Delete(strFileNamePath)
                            End If
                            objHtmlInputFile.PostedFile.SaveAs(strFileNamePath)

                            If strExtension = "zip" And chkUnzip.Checked = True Then
                                ' save zip file name
                                Dim strSaveFileNamePath As String = strFileNamePath

                                Dim objZipEntry As ZipEntry
                                Dim objZipInputStream As New ZipInputStream(File.OpenRead(strFileNamePath))
                                objZipEntry = objZipInputStream.GetNextEntry
                                While Not objZipEntry Is Nothing
                                    If ((((objAdmin.GetPortalSpaceUsed(PortalId) + objZipEntry.Size) / 1000000) <= _portalSettings.HostSpace) Or _portalSettings.HostSpace = 0) Or (_portalSettings.ActiveTab.ParentId = _portalSettings.SuperTabId) Then
                                        strFileName = Path.GetFileName(objZipEntry.Name)

                                        If strFileName <> "" Then
                                            If _portalSettings.ActiveTab.ParentId = _portalSettings.SuperTabId Then
                                                strFileNamePath = Request.MapPath(glbSiteDirectory) & strFileName
                                            Else
                                                strFileNamePath = Request.MapPath(_portalSettings.UploadDirectory) & strFileName
                                            End If

                                            strExtension = ""
                                            If InStr(1, strFileNamePath, ".") Then
                                                strExtension = Mid(strFileNamePath, InStrRev(strFileNamePath, ".") + 1).ToLower
                                            End If

                                            If InStr(1, "," & _portalSettings.HostSettings("FileExtensions").ToString, "," & strExtension) <> 0 Or _portalSettings.ActiveTab.ParentId = _portalSettings.SuperTabId Then
                                                If File.Exists(strFileNamePath) Then
                                                    File.Delete(strFileNamePath)
                                                End If
                                                Dim objFileStream As FileStream = File.Create(strFileNamePath)

                                                Dim intSize As Integer = 2048
                                                Dim arrData(2048) As Byte

                                                intSize = objZipInputStream.Read(arrData, 0, arrData.Length)
                                                While intSize > 0
                                                    objFileStream.Write(arrData, 0, intSize)
                                                    intSize = objZipInputStream.Read(arrData, 0, arrData.Length)
                                                End While

                                                objFileStream.Close()

                                                AddFile(strFileNamePath, strExtension)
                                            Else
                                                ' restricted file type
                                                strMessage += "<br>The File " & strFileName & " Is A Restricted File Type. Valid File Types Include ( *." & Replace(_portalSettings.HostSettings("FileExtensions").ToString, ",", ", *.") & " ). Please Contact Your Hosting Provider If You Need To Upload A File Type Which Is Not Supported."
                                            End If
                                        End If
                                    Else ' file too large
                                        strMessage += "<br>The File " & strFileName & " Exceeds The Amount Of Disk Space You Currently Have Available. Please Contact Your Hosting Provider For Inquiries Related To Increasing Your Portal Disk Space."
                                    End If

                                    objZipEntry = objZipInputStream.GetNextEntry
                                End While
                                objZipInputStream.Close()

                                ' delete the zip file
                                File.Delete(strSaveFileNamePath)
                            Else
                                AddFile(strFileNamePath, strExtension, objHtmlInputFile.PostedFile.ContentType)
                            End If
                        Catch
                            ' save error - can happen if the security settings are incorrect
                            strMessage += "<br>An Error Has Occurred When Attempting To Save The File " & strFileName & ". Please Contact Your Hosting Provider To Ensure The Appropriate Security Settings Have Been Enabled On The Server."
                        End Try
                    Else
                        ' restricted file type
                        strMessage += "<br>The File " & strFileName & " Is A Restricted File Type. Valid File Types Include ( *." & Replace(_portalSettings.HostSettings("FileExtensions").ToString, ",", ", *.") & " ). Please Contact Your Hosting Provider If You Need To Upload A File Type Which Is Not Supported."
                    End If
                Else ' file too large
                    strMessage += "<br>The File " & strFileName & " Exceeds The Amount Of Disk Space You Currently Have Available. Please Contact Your Hosting Provider For Inquiries Related To Increasing Your Portal Disk Space."
                End If
            Next

            If strMessage = "" Then
                Response.Redirect(CType(Viewstate("UrlReferrer"), String))
            Else
                lblMessage.Text = strMessage
            End If

        End Sub

        Private Sub AddFile(ByVal strFileNamePath As String, ByVal strExtension As String, Optional ByVal strContentType As String = "")

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            Dim strFileName As String = Path.GetFileName(strFileNamePath)

            If strContentType = "" Then
                Select Case strExtension
                    Case "txt" : strContentType = "text/plain"
                    Case "htm", "html" : strContentType = "text/html"
                    Case "rtf" : strContentType = "text/richtext"
                    Case "jpg", "jpeg" : strContentType = "image/jpeg"
                    Case "gif" : strContentType = "image/gif"
                    Case "bmp" : strContentType = "image/bmp"
                    Case "mpg", "mpeg" : strContentType = "video/mpeg"
                    Case "avi" : strContentType = "video/avi"
                    Case "pdf" : strContentType = "application/pdf"
                    Case "doc", "dot" : strContentType = "application/msword"
                    Case "csv", "xls", "xlt" : strContentType = "application/x-msexcel"
                    Case Else : strContentType = "application/octet-stream"
                End Select
            End If

            Dim imgImage As System.Drawing.Image
            Dim strWidth As String = ""
            Dim strHeight As String = ""

            If InStr(1, glbImageFileTypes, strExtension) Then
                Try
                    imgImage = imgImage.FromFile(strFileNamePath)
                    strHeight = imgImage.Height
                    strWidth = imgImage.Width
                    imgImage.Dispose()
                Catch
                    ' error loading image file
                    strContentType = "application/octet-stream"
                End Try
            End If

            Dim objAdmin As New AdminDB()

            If _portalSettings.ActiveTab.ParentId = _portalSettings.SuperTabId Then
                objAdmin.AddFile(-1, strFileName, strExtension, FileLen(strFileNamePath), strWidth, strHeight, strContentType)
            Else
                objAdmin.AddFile(PortalId, strFileName, strExtension, FileLen(strFileNamePath), strWidth, strHeight, strContentType)
            End If

        End Sub

        Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
            Response.Redirect(CType(Viewstate("UrlReferrer"), String))
        End Sub

    End Class

End Namespace