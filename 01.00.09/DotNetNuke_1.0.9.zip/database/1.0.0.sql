/************************************************************/
/*****                 Create Tables                    *****/
/************************************************************/

CREATE TABLE [dbo].[BannerTypes] (
	[BannerTypeId] [int] IDENTITY (1, 1) NOT NULL ,
	[BannerTypeName] [nvarchar] (50) NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[Classification] (
	[ClassificationId] [int] IDENTITY (1, 1) NOT NULL ,
	[ClassificationName] [nvarchar] (200) NOT NULL ,
	[ParentId] [int] NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[CodeCountry] (
	[Code] [char] (2) NOT NULL ,
	[Description] [varchar] (100) NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[CodeCurrency] (
	[Code] [char] (3) NOT NULL ,
	[Description] [varchar] (100) NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[CodeFrequency] (
	[Code] [char] (1) NOT NULL ,
	[Description] [nvarchar] (50) NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[CodeRegion] (
	[Code] [char] (2) NOT NULL ,
	[Description] [varchar] (100) NOT NULL ,
	[Country] [char] (2) NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[FAQs] (
	[ItemID] [int] IDENTITY (0, 1) NOT NULL ,
	[ModuleID] [int] NOT NULL ,
	[CreatedByUser] [nvarchar] (100) NULL ,
	[CreatedDate] [datetime] NULL ,
	[Question] [text] NULL ,
	[Answer] [text] NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE TABLE [dbo].[Files] (
	[FileId] [int] IDENTITY (1, 1) NOT NULL ,
	[PortalId] [int] NULL ,
	[FileName] [nvarchar] (100) NOT NULL ,
	[Extension] [nvarchar] (100) NOT NULL ,
	[Size] [int] NOT NULL ,
	[Width] [int] NULL ,
	[Height] [int] NULL ,
	[ContentType] [nvarchar] (200) NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[ModuleDefinitions] (
	[ModuleDefID] [int] IDENTITY (1, 1) NOT NULL ,
	[FriendlyName] [nvarchar] (128) NOT NULL ,
	[DesktopSrc] [nvarchar] (256) NULL ,
	[MobileSrc] [nvarchar] (256) NULL ,
	[AdminOrder] [int] NULL ,
	[EditSrc] [nvarchar] (256) NULL ,
	[Secure] [bit] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[Portals] (
	[PortalID] [int] IDENTITY (-1, 1) NOT NULL ,
	[PortalAlias] [nvarchar] (200) NOT NULL ,
	[PortalName] [nvarchar] (128) NOT NULL ,
	[UploadDirectory] [nvarchar] (100) NOT NULL ,
	[LogoFile] [nvarchar] (50) NULL ,
	[FooterText] [nvarchar] (100) NULL ,
	[ExpiryDate] [datetime] NULL ,
	[UserRegistration] [int] NULL ,
	[BannerAdvertising] [int] NULL ,
	[AdministratorId] [int] NULL ,
	[PayPalId] [nvarchar] (50) NULL ,
	[Currency] [char] (3) NULL ,
	[HostFee] [nvarchar] (10) NULL ,
	[HostSpace] [int] NULL ,
	[AdministratorRoleId] [int] NULL ,
	[RegisteredRoleId] [int] NULL ,
	[GUID] [uniqueidentifier] NOT NULL CONSTRAINT DF_Portals_GUID DEFAULT newid()
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[Users] (
	[UserID] [int] IDENTITY (1, 1) NOT NULL ,
	[FirstName] [nvarchar] (50) NOT NULL ,
	[LastName] [nvarchar] (50) NULL ,
	[Street] [nvarchar] (20) NULL ,
	[City] [nvarchar] (20) NULL ,
	[Region] [nvarchar] (20) NULL ,
	[PostalCode] [nvarchar] (10) NULL ,
	[Country] [nvarchar] (20) NULL ,
	[Password] [nvarchar] (20) NOT NULL ,
	[Email] [nvarchar] (100) NOT NULL ,
	[CreatedDate] [datetime] NULL ,
	[LastLoginDate] [datetime] NULL ,
	[Unit] [nvarchar] (50) NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[Version] (
	[VersionId] [int] IDENTITY (1, 1) NOT NULL ,
	[Major] [int] NOT NULL ,
	[Minor] [int] NOT NULL ,
	[Build] [int] NOT NULL ,
	[Comment] [varchar] (100) NOT NULL ,
	[CreatedDate] [datetime] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[Roles] (
	[RoleID] [int] IDENTITY (0, 1) NOT NULL ,
	[PortalID] [int] NULL ,
	[RoleName] [nvarchar] (50) NOT NULL ,
	[Description] [nvarchar] (1000) NULL ,
	[ServiceFee] [decimal](5, 2) NULL ,
	[BillingFrequency] [char] (1) NULL ,
	[TrialPeriod] [int] NULL ,
	[TrialFrequency] [char] (1) NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[SiteLog] (
	[SiteLogId] [int] IDENTITY (1, 1) NOT NULL ,
	[DateTime] [smalldatetime] NOT NULL ,
	[PortalId] [int] NOT NULL ,
	[UserId] [int] NULL ,
	[Referrer] [nvarchar] (255) NULL ,
	[Url] [nvarchar] (255) NULL ,
	[UserAgent] [nvarchar] (255) NULL ,
	[UserHostAddress] [nvarchar] (255) NULL ,
	[UserHostName] [nvarchar] (255) NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[Tabs] (
	[TabID] [int] IDENTITY (0, 1) NOT NULL ,
	[TabOrder] [int] NOT NULL ,
	[PortalID] [int] NULL ,
	[TabName] [nvarchar] (50) NOT NULL ,
	[MobileTabName] [nvarchar] (50) NOT NULL ,
	[AuthorizedRoles] [nvarchar] (256) NULL ,
	[ShowMobile] [bit] NOT NULL ,
	[LeftPaneWidth] [nvarchar] (5) NOT NULL ,
	[RightPaneWidth] [nvarchar] (5) NOT NULL ,
	[IsVisible] [bit] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[UserPortals] (
	[UserId] [int] NOT NULL ,
	[PortalId] [int] NOT NULL ,
	[Authorized] [bit] NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[VendorLog] (
	[VendorLogId] [int] IDENTITY (1, 1) NOT NULL ,
	[DateTime] [datetime] NOT NULL ,
	[PortalId] [int] NOT NULL ,
	[VendorId] [int] NOT NULL ,
	[BannerId] [int] NULL ,
	[Search] [nvarchar] (200) NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[VendorSearch] (
	[VendorSearchId] [int] IDENTITY (1, 1) NOT NULL ,
	[PortalId] [int] NULL ,
	[DateTime] [datetime] NOT NULL ,
	[Search] [nvarchar] (200) NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[Vendors] (
	[VendorId] [int] IDENTITY (1, 1) NOT NULL ,
	[VendorName] [nvarchar] (50) NOT NULL ,
	[Street] [nvarchar] (50) NULL ,
	[City] [nvarchar] (50) NULL ,
	[Region] [nvarchar] (50) NULL ,
	[Country] [nvarchar] (50) NULL ,
	[PostalCode] [nvarchar] (50) NULL ,
	[Telephone] [nvarchar] (50) NULL ,
	[PortalId] [int] NULL ,
	[Fax] [nvarchar] (50) NULL ,
	[Email] [nvarchar] (50) NULL ,
	[Website] [nvarchar] (100) NULL ,
	[Contact] [nvarchar] (50) NULL ,
	[ClickThroughs] [int] NOT NULL ,
	[Views] [int] NOT NULL ,
	[CreatedByUser] [nvarchar] (100) NULL ,
	[CreatedDate] [datetime] NULL ,
	[LogoFile] [nvarchar] (100) NULL ,
	[KeyWords] [text] NULL ,
	[Unit] [nvarchar] (50) NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE TABLE [dbo].[Banners] (
	[BannerId] [int] IDENTITY (1, 1) NOT NULL ,
	[VendorId] [int] NOT NULL ,
	[ImageFile] [nvarchar] (100) NOT NULL ,
	[BannerName] [nvarchar] (100) NOT NULL ,
	[URL] [nvarchar] (100) NULL ,
	[Impressions] [int] NOT NULL ,
	[CPM] [float] NOT NULL ,
	[Views] [int] NOT NULL ,
	[ClickThroughs] [int] NOT NULL ,
	[StartDate] [datetime] NULL ,
	[EndDate] [datetime] NULL ,
	[CreatedByUser] [nvarchar] (100) NOT NULL ,
	[CreatedDate] [datetime] NOT NULL ,
	[BannerTypeId] [int] NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[Modules] (
	[ModuleID] [int] IDENTITY (0, 1) NOT NULL ,
	[TabID] [int] NOT NULL ,
	[ModuleDefID] [int] NOT NULL ,
	[ModuleOrder] [int] NOT NULL ,
	[PaneName] [nvarchar] (50) NOT NULL ,
	[ModuleTitle] [nvarchar] (256) NULL ,
	[AuthorizedEditRoles] [nvarchar] (256) NULL ,
	[CacheTime] [int] NOT NULL ,
	[ShowMobile] [bit] NULL ,
	[AuthorizedViewRoles] [nvarchar] (256) NULL ,
	[Alignment] [nvarchar] (10) NULL ,
	[Color] [nvarchar] (20) NULL ,
	[Border] [nvarchar] (1) NULL ,
	[IconFile] [nvarchar] (100) NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[UserRoles] (
	[UserRoleID] [int] IDENTITY (1, 1) NOT NULL ,
	[UserID] [int] NOT NULL ,
	[RoleID] [int] NOT NULL ,
	[ExpiryDate] [datetime] NULL ,
	[IsTrialUsed] [bit] NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[VendorClassification] (
	[VendorClassificationId] [int] IDENTITY (1, 1) NOT NULL ,
	[VendorId] [int] NOT NULL ,
	[ClassificationId] [int] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[VendorFeedback] (
	[VendorFeedbackId] [int] IDENTITY (1, 1) NOT NULL ,
	[VendorId] [int] NOT NULL ,
	[UserId] [int] NOT NULL ,
	[Date] [datetime] NOT NULL ,
	[Comment] [nvarchar] (4000) NOT NULL ,
	[Value] [int] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[Announcements] (
	[ItemID] [int] IDENTITY (0, 1) NOT NULL ,
	[ModuleID] [int] NOT NULL ,
	[CreatedByUser] [nvarchar] (100) NULL ,
	[CreatedDate] [datetime] NULL ,
	[Title] [nvarchar] (150) NULL ,
	[URL] [nvarchar] (150) NULL ,
	[ExpireDate] [datetime] NULL ,
	[Description] [nvarchar] (2000) NULL ,
	[Syndicate] [bit] NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[Contacts] (
	[ItemID] [int] IDENTITY (0, 1) NOT NULL ,
	[ModuleID] [int] NOT NULL ,
	[CreatedByUser] [nvarchar] (100) NULL ,
	[CreatedDate] [datetime] NULL ,
	[Name] [nvarchar] (50) NULL ,
	[Role] [nvarchar] (100) NULL ,
	[Email] [nvarchar] (100) NULL ,
	[Contact1] [nvarchar] (250) NULL ,
	[Contact2] [nvarchar] (250) NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[Discussion] (
	[ItemID] [int] IDENTITY (0, 1) NOT NULL ,
	[ModuleID] [int] NOT NULL ,
	[Title] [nvarchar] (100) NULL ,
	[CreatedDate] [datetime] NULL ,
	[Body] [nvarchar] (3000) NULL ,
	[DisplayOrder] [nvarchar] (750) NULL ,
	[CreatedByUser] [nvarchar] (100) NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[Documents] (
	[ItemID] [int] IDENTITY (0, 1) NOT NULL ,
	[ModuleID] [int] NOT NULL ,
	[CreatedByUser] [nvarchar] (100) NULL ,
	[CreatedDate] [datetime] NULL ,
	[URL] [nvarchar] (250) NULL ,
	[Title] [nvarchar] (150) NULL ,
	[Category] [nvarchar] (50) NULL ,
	[Syndicate] [bit] NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[HtmlText] (
	[ModuleID] [int] NOT NULL ,
	[DesktopHtml] [ntext] NOT NULL ,
	[MobileSummary] [ntext] NOT NULL ,
	[MobileDetails] [ntext] NOT NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE TABLE [dbo].[Links] (
	[ItemID] [int] IDENTITY (0, 1) NOT NULL ,
	[ModuleID] [int] NOT NULL ,
	[CreatedByUser] [nvarchar] (100) NULL ,
	[CreatedDate] [datetime] NULL ,
	[Title] [nvarchar] (100) NULL ,
	[Url] [nvarchar] (250) NULL ,
	[MobileUrl] [nvarchar] (250) NULL ,
	[ViewOrder] [int] NULL ,
	[Description] [nvarchar] (2000) NULL ,
	[NewWindow] [bit] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[ModuleEvents] (
	[ItemID] [int] IDENTITY (0, 1) NOT NULL ,
	[ModuleID] [int] NOT NULL ,
	[Description] [nvarchar] (2000) NOT NULL ,
	[DateTime] [datetime] NOT NULL ,
	[Title] [nvarchar] (100) NOT NULL ,
	[ExpireDate] [datetime] NULL ,
	[CreatedByUser] [nvarchar] (200) NOT NULL ,
	[CreatedDate] [datetime] NOT NULL ,
	[Every] [int] NULL ,
	[Period] [char] (1) NULL ,
	[IconFile] [nvarchar] (256) NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[ModuleSettings] (
	[ModuleID] [int] NOT NULL ,
	[SettingName] [nvarchar] (50) NOT NULL ,
	[SettingValue] [nvarchar] (256) NOT NULL 
) ON [PRIMARY]
GO


/************************************************************/
/*****   Create Primary Keys, Foreign Key Constraints   *****/
/************************************************************/


ALTER TABLE [dbo].[BannerTypes] WITH NOCHECK ADD 
	CONSTRAINT [PK_BannerType] PRIMARY KEY  CLUSTERED 
	(
		[BannerTypeId]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Classification] WITH NOCHECK ADD 
	CONSTRAINT [PK_VendorCategory] PRIMARY KEY  CLUSTERED 
	(
		[ClassificationId]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[CodeCurrency] WITH NOCHECK ADD 
	CONSTRAINT [PK_CodeCurrency] PRIMARY KEY  CLUSTERED 
	(
		[Code]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[CodeFrequency] WITH NOCHECK ADD 
	CONSTRAINT [PK_CodeFrequency] PRIMARY KEY  CLUSTERED 
	(
		[Code]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Files] WITH NOCHECK ADD 
	CONSTRAINT [PK_File] PRIMARY KEY  CLUSTERED 
	(
		[FileId]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Version] WITH NOCHECK ADD 
	CONSTRAINT [PK_Version] PRIMARY KEY  CLUSTERED 
	(
		[VersionId]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[SiteLog] WITH NOCHECK ADD 
	CONSTRAINT [PK_SiteLog] PRIMARY KEY  CLUSTERED 
	(
		[SiteLogId]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[UserPortals] WITH NOCHECK ADD 
	CONSTRAINT [PK_UserPortals] PRIMARY KEY  CLUSTERED 
	(
		[UserId],
		[PortalId]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[VendorLog] WITH NOCHECK ADD 
	CONSTRAINT [PK_VendorLog] PRIMARY KEY  CLUSTERED 
	(
		[VendorLogId]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[VendorSearch] WITH NOCHECK ADD 
	CONSTRAINT [PK_VendorSearch] PRIMARY KEY  CLUSTERED 
	(
		[VendorSearchId]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Vendors] WITH NOCHECK ADD 
	CONSTRAINT [PK_Vendor] PRIMARY KEY  CLUSTERED 
	(
		[VendorId]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Banners] WITH NOCHECK ADD 
	CONSTRAINT [PK_Banner] PRIMARY KEY  CLUSTERED 
	(
		[BannerId]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[UserRoles] WITH NOCHECK ADD 
	CONSTRAINT [PK_UserRoles] PRIMARY KEY  CLUSTERED 
	(
		[UserRoleID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[VendorClassification] WITH NOCHECK ADD 
	CONSTRAINT [PK_VendorClassification] PRIMARY KEY  CLUSTERED 
	(
		[VendorClassificationId]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[VendorFeedback] WITH NOCHECK ADD 
	CONSTRAINT [PK_VendorFeedback] PRIMARY KEY  CLUSTERED 
	(
		[VendorFeedbackId]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[ModuleDefinitions] WITH NOCHECK ADD 
	CONSTRAINT [DF_ModuleDefinitions_Secure] DEFAULT (1) FOR [Secure],
	CONSTRAINT [PK_ModuleDefinitions] PRIMARY KEY  NONCLUSTERED 
	(
		[ModuleDefID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Portals] WITH NOCHECK ADD 
	CONSTRAINT [PK_Portals] PRIMARY KEY  NONCLUSTERED 
	(
		[PortalID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Users] WITH NOCHECK ADD 
	CONSTRAINT [PK_Users] PRIMARY KEY  NONCLUSTERED 
	(
		[UserID]
	)  ON [PRIMARY] ,
	CONSTRAINT [IX_Users] UNIQUE  NONCLUSTERED 
	(
		[Email]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Roles] WITH NOCHECK ADD 
	CONSTRAINT [DF_Roles_ServiceFee] DEFAULT (0) FOR [ServiceFee],
	CONSTRAINT [PK_Roles] PRIMARY KEY  NONCLUSTERED 
	(
		[RoleID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Tabs] WITH NOCHECK ADD 
	CONSTRAINT [DF_Tabs_IsVisible] DEFAULT (1) FOR [IsVisible],
	CONSTRAINT [PK_Tabs] PRIMARY KEY  NONCLUSTERED 
	(
		[TabID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Vendors] WITH NOCHECK ADD 
	CONSTRAINT [DF_Vendors_ClickThroughs] DEFAULT (0) FOR [ClickThroughs],
	CONSTRAINT [DF_Vendors_Views] DEFAULT (0) FOR [Views]
GO

ALTER TABLE [dbo].[Banners] WITH NOCHECK ADD 
	CONSTRAINT [DF_Banners_Views] DEFAULT (0) FOR [Views],
	CONSTRAINT [DF_Banners_ClickThroughs] DEFAULT (0) FOR [ClickThroughs]
GO

ALTER TABLE [dbo].[Modules] WITH NOCHECK ADD 
	CONSTRAINT [PK_Modules] PRIMARY KEY  NONCLUSTERED 
	(
		[ModuleID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Announcements] WITH NOCHECK ADD 
	CONSTRAINT [PK_Announcements] PRIMARY KEY  NONCLUSTERED 
	(
		[ItemID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Contacts] WITH NOCHECK ADD 
	CONSTRAINT [PK_Contacts] PRIMARY KEY  NONCLUSTERED 
	(
		[ItemID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Discussion] WITH NOCHECK ADD 
	CONSTRAINT [PK_Discussion] PRIMARY KEY  NONCLUSTERED 
	(
		[ItemID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Documents] WITH NOCHECK ADD 
	CONSTRAINT [PK_Documents] PRIMARY KEY  NONCLUSTERED 
	(
		[ItemID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[HtmlText] WITH NOCHECK ADD 
	CONSTRAINT [PK_HtmlText] PRIMARY KEY  NONCLUSTERED 
	(
		[ModuleID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Links] WITH NOCHECK ADD 
	CONSTRAINT [DF_Links_NewWindow] DEFAULT (0) FOR [NewWindow],
	CONSTRAINT [PK_Links] PRIMARY KEY  NONCLUSTERED 
	(
		[ItemID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[ModuleEvents] WITH NOCHECK ADD 
	CONSTRAINT [PK_Events] PRIMARY KEY  NONCLUSTERED 
	(
		[ItemID]
	)  ON [PRIMARY] 
GO

 CREATE  INDEX [IX_ModuleSettings] ON [dbo].[ModuleSettings]([ModuleID], [SettingName]) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Classification] ADD 
	CONSTRAINT [FK_Classification_Classification] FOREIGN KEY 
	(
		[ParentId]
	) REFERENCES [dbo].[Classification] (
		[ClassificationId]
	) NOT FOR REPLICATION 
GO

ALTER TABLE [dbo].[Roles] ADD 
	CONSTRAINT [FK_Roles_CodeFrequency] FOREIGN KEY 
	(
		[BillingFrequency]
	) REFERENCES [dbo].[CodeFrequency] (
		[Code]
	) NOT FOR REPLICATION ,
	CONSTRAINT [FK_Roles_Portals] FOREIGN KEY 
	(
		[PortalID]
	) REFERENCES [dbo].[Portals] (
		[PortalID]
	) ON DELETE CASCADE  NOT FOR REPLICATION 
GO

ALTER TABLE [dbo].[SiteLog] ADD 
	CONSTRAINT [FK_SiteLog_Portals] FOREIGN KEY 
	(
		[PortalId]
	) REFERENCES [dbo].[Portals] (
		[PortalID]
	) ON DELETE CASCADE  NOT FOR REPLICATION 
GO

ALTER TABLE [dbo].[Tabs] ADD 
	CONSTRAINT [FK_Tabs_Portals] FOREIGN KEY 
	(
		[PortalID]
	) REFERENCES [dbo].[Portals] (
		[PortalID]
	) ON DELETE CASCADE  NOT FOR REPLICATION 
GO

ALTER TABLE [dbo].[UserPortals] ADD 
	CONSTRAINT [FK_UserPortals_Portals] FOREIGN KEY 
	(
		[PortalId]
	) REFERENCES [dbo].[Portals] (
		[PortalID]
	) ON DELETE CASCADE  NOT FOR REPLICATION ,
	CONSTRAINT [FK_UserPortals_Users] FOREIGN KEY 
	(
		[UserId]
	) REFERENCES [dbo].[Users] (
		[UserID]
	) NOT FOR REPLICATION 
GO

ALTER TABLE [dbo].[VendorLog] ADD 
	CONSTRAINT [FK_VendorLog_Portals] FOREIGN KEY 
	(
		[PortalId]
	) REFERENCES [dbo].[Portals] (
		[PortalID]
	) ON DELETE CASCADE  NOT FOR REPLICATION 
GO

ALTER TABLE [dbo].[VendorSearch] ADD 
	CONSTRAINT [FK_VendorSearch_Portals] FOREIGN KEY 
	(
		[PortalId]
	) REFERENCES [dbo].[Portals] (
		[PortalID]
	) ON DELETE CASCADE  NOT FOR REPLICATION 
GO

ALTER TABLE [dbo].[Vendors] ADD 
	CONSTRAINT [FK_Vendor_Portals] FOREIGN KEY 
	(
		[PortalId]
	) REFERENCES [dbo].[Portals] (
		[PortalID]
	) ON DELETE CASCADE  NOT FOR REPLICATION 
GO

ALTER TABLE [dbo].[Banners] ADD 
	CONSTRAINT [FK_Banner_Vendor] FOREIGN KEY 
	(
		[VendorId]
	) REFERENCES [dbo].[Vendors] (
		[VendorId]
	) ON DELETE CASCADE  NOT FOR REPLICATION ,
	CONSTRAINT [FK_Banners_BannerType] FOREIGN KEY 
	(
		[BannerTypeId]
	) REFERENCES [dbo].[BannerTypes] (
		[BannerTypeId]
	) NOT FOR REPLICATION 
GO

ALTER TABLE [dbo].[Modules] ADD 
	CONSTRAINT [FK_Modules_ModuleDefinitions] FOREIGN KEY 
	(
		[ModuleDefID]
	) REFERENCES [dbo].[ModuleDefinitions] (
		[ModuleDefID]
	) ON DELETE CASCADE  NOT FOR REPLICATION ,
	CONSTRAINT [FK_Modules_Tabs] FOREIGN KEY 
	(
		[TabID]
	) REFERENCES [dbo].[Tabs] (
		[TabID]
	) ON DELETE CASCADE  NOT FOR REPLICATION 
GO

ALTER TABLE [dbo].[UserRoles] ADD 
	CONSTRAINT [FK_UserRoles_Roles] FOREIGN KEY 
	(
		[RoleID]
	) REFERENCES [dbo].[Roles] (
		[RoleID]
	) ON DELETE CASCADE  NOT FOR REPLICATION ,
	CONSTRAINT [FK_UserRoles_Users] FOREIGN KEY 
	(
		[UserID]
	) REFERENCES [dbo].[Users] (
		[UserID]
	) ON DELETE CASCADE  NOT FOR REPLICATION 
GO

ALTER TABLE [dbo].[VendorClassification] ADD 
	CONSTRAINT [FK_VendorClassification_Classification] FOREIGN KEY 
	(
		[ClassificationId]
	) REFERENCES [dbo].[Classification] (
		[ClassificationId]
	) NOT FOR REPLICATION ,
	CONSTRAINT [FK_VendorClassification_Vendors] FOREIGN KEY 
	(
		[VendorId]
	) REFERENCES [dbo].[Vendors] (
		[VendorId]
	) NOT FOR REPLICATION 
GO

ALTER TABLE [dbo].[VendorFeedback] ADD 
	CONSTRAINT [FK_VendorFeedback_Vendors] FOREIGN KEY 
	(
		[VendorId]
	) REFERENCES [dbo].[Vendors] (
		[VendorId]
	) ON DELETE CASCADE  NOT FOR REPLICATION 
GO

ALTER TABLE [dbo].[Announcements] ADD 
	CONSTRAINT [FK_Announcements_Modules] FOREIGN KEY 
	(
		[ModuleID]
	) REFERENCES [dbo].[Modules] (
		[ModuleID]
	) ON DELETE CASCADE  NOT FOR REPLICATION 
GO

ALTER TABLE [dbo].[Contacts] ADD 
	CONSTRAINT [FK_Contacts_Modules] FOREIGN KEY 
	(
		[ModuleID]
	) REFERENCES [dbo].[Modules] (
		[ModuleID]
	) ON DELETE CASCADE  NOT FOR REPLICATION 
GO

ALTER TABLE [dbo].[Discussion] ADD 
	CONSTRAINT [FK_Discussion_Modules] FOREIGN KEY 
	(
		[ModuleID]
	) REFERENCES [dbo].[Modules] (
		[ModuleID]
	) ON DELETE CASCADE  NOT FOR REPLICATION 
GO

ALTER TABLE [dbo].[Documents] ADD 
	CONSTRAINT [FK_Documents_Modules] FOREIGN KEY 
	(
		[ModuleID]
	) REFERENCES [dbo].[Modules] (
		[ModuleID]
	) ON DELETE CASCADE  NOT FOR REPLICATION 
GO

ALTER TABLE [dbo].[HtmlText] ADD 
	CONSTRAINT [FK_HtmlText_Modules] FOREIGN KEY 
	(
		[ModuleID]
	) REFERENCES [dbo].[Modules] (
		[ModuleID]
	) ON DELETE CASCADE  NOT FOR REPLICATION 
GO

ALTER TABLE [dbo].[Links] ADD 
	CONSTRAINT [FK_Links_Modules] FOREIGN KEY 
	(
		[ModuleID]
	) REFERENCES [dbo].[Modules] (
		[ModuleID]
	) ON DELETE CASCADE  NOT FOR REPLICATION 
GO

ALTER TABLE [dbo].[ModuleEvents] ADD 
	CONSTRAINT [FK_Events_Modules] FOREIGN KEY 
	(
		[ModuleID]
	) REFERENCES [dbo].[Modules] (
		[ModuleID]
	) ON DELETE CASCADE  NOT FOR REPLICATION 
GO

ALTER TABLE [dbo].[ModuleSettings] ADD 
	CONSTRAINT [FK_ModuleSettings_Modules] FOREIGN KEY 
	(
		[ModuleID]
	) REFERENCES [dbo].[Modules] (
		[ModuleID]
	) ON DELETE CASCADE  NOT FOR REPLICATION 
GO

/************************************************************/
/*****          Create Stored Procedures                *****/
/************************************************************/

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

create procedure AddTab

@PortalID        int,
@TabName         nvarchar(50),
@ShowMobile      bit,
@MobileTabName   nvarchar(50),
@AuthorizedRoles nvarchar (256),
@LeftPaneWidth   nvarchar(5),
@RightPaneWidth  nvarchar(5),
@IsVisible       bit,
@TabID           int OUTPUT

as

insert into Tabs (
    PortalID,
    TabName,
    TabOrder,
    ShowMobile,
    MobileTabName,
    AuthorizedRoles,
    LeftPaneWidth,
    RightPaneWidth,
    IsVisible
)
values (
    @PortalID,
    @TabName,
    0,
    @ShowMobile,
    @MobileTabName,
    @AuthorizedRoles,
    @LeftPaneWidth,
    @RightPaneWidth,
    @IsVisible
)

select @TabID = @@IDENTITY


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO




CREATE PROCEDURE DeleteAnnouncement
(
    @ItemID int
)
AS

DELETE FROM
    Announcements

WHERE
    ItemID = @ItemID



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO



create procedure DeleteBanner
(
    @BannerId int
)

as

delete
from   Banners
where  BannerId = @BannerId


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO



CREATE PROCEDURE DeleteContact
(
    @ItemID int
)
AS

DELETE FROM
    Contacts

WHERE
    ItemID = @ItemID



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO



CREATE PROCEDURE DeleteDocument
(
    @ItemID int
)
AS

DELETE FROM
    Documents

WHERE
    ItemID = @ItemID



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO



CREATE PROCEDURE DeleteFAQ
(
    @ItemID int
)
AS

DELETE FROM
    FAQs

WHERE
    ItemID = @ItemID

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO



CREATE PROCEDURE DeleteLink
(
    @ItemID int
)
AS

DELETE FROM
    Links

WHERE
    ItemID = @ItemID



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO



CREATE PROCEDURE DeleteModule
(
    @ModuleID       int
)
AS

DELETE FROM 
    Modules 
WHERE 
    ModuleID = @ModuleID



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO



CREATE PROCEDURE DeleteModuleDefinition
(
    @ModuleDefID int
)
AS

DELETE FROM
    ModuleDefinitions

WHERE
    ModuleDefID = @ModuleDefID



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure DeleteModuleEvent

@ItemID int

AS

delete
from   ModuleEvents
where  ItemID = @ItemID


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure DeletePortalInfo

@PortalID int

as

delete
from   Portals
where  PortalID = @PortalID


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO




CREATE PROCEDURE DeleteTab
(
    @TabID int
)
AS

DELETE FROM
    Tabs

WHERE
    TabID = @TabID



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure DeleteVendor

@VendorID int

as

delete
from   Vendors
where  VendorID = @VendorID


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO




create procedure GetBannerClickThrough

@BannerId int

as

update Banners
set    ClickThroughs = ClickThroughs + 1
where  BannerId = @BannerId

select URL,
       VendorId
from   Banners
where  BannerId = @BannerId

return 1


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure GetBanners

@VendorId int

as

select BannerId,
       BannerName,
       BannerTypeName,
       URL,
       Impressions,
       CPM,
       Views,
       ClickThroughs,
       StartDate,
       EndDate
from   Banners
inner join BannerTypes on Banners.BannerTypeId = BannerTypes.BannerTypeId
where  VendorId = @VendorId
order  by CreatedDate desc

return 1


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure GetBillingFrequencyCode
    
@Code char(1)

as

select Description
from   CodeFrequency
where  Code = @Code


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure GetBillingFrequencyCodes
    
as

select *
from   CodeFrequency


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO



CREATE PROCEDURE GetFAQs
(
    @ModuleID int
)
AS

SELECT
    ItemID,
    CreatedDate,
    CreatedByUser,
    Question,
    Answer

FROM
    FAQs

WHERE
    ModuleID = @ModuleID

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO



CREATE PROCEDURE GetHtmlText
(
    @ModuleID int
)
AS

SELECT
    *

FROM
    HtmlText

WHERE
    ModuleID = @ModuleID



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO



CREATE PROCEDURE GetModuleSettings
(
    @ModuleID int
)
AS

SELECT
    SettingName,
    SettingValue

FROM
    ModuleSettings

WHERE
    ModuleID = @ModuleID



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure GetSingleUserDefinedRow

@UserDefinedRowID   int,
@ModuleId           int

as

select UserDefinedFields.FieldTitle,
       UserDefinedData.FieldValue
from   UserDefinedData
inner join UserDefinedFields on UserDefinedData.UserDefinedFieldId = UserDefinedFields.UserDefinedFieldId
where  UserDefinedData.UserDefinedRowID = @UserDefinedRowID
and    UserDefinedFields.ModuleId = @ModuleId


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure GetTabById

@TabId int

as

select TabID,
       TabOrder,
       TabName,
       MobileTabName,
       AuthorizedRoles,
       ShowMobile,
       LeftPaneWidth,
       RightPaneWidth,
       IsVisible
from   Tabs
where  TabId = @TabId


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure GetTabByName

@PortalID int,
@TabName  nvarchar(50)

as

select TabID,
       TabOrder
from   Tabs
where  PortalID = @PortalID
and    TabName = @TabName


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO



CREATE PROCEDURE UpdateContact
(
    @ItemID   int,
    @UserName nvarchar(100),
    @Name     nvarchar(50),
    @Role     nvarchar(100),
    @Email    nvarchar(100),
    @Contact1 nvarchar(250),
    @Contact2 nvarchar(250)
)
AS

UPDATE
    Contacts

SET
    CreatedByUser = @UserName,
    CreatedDate   = GetDate(),
    Name          = @Name,
    Role          = @Role,
    Email         = @Email,
    Contact1      = @Contact1,
    Contact2      = @Contact2

WHERE
    ItemID = @ItemID



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure UpdateFAQ

@ItemID   int,
@UserName nvarchar(100),
@Question  text,
@Answer    text

as

update FAQs
set    Question = @Question,
       Answer = @Answer,
       CreatedByUser = @UserName,
       CreatedDate = getdate()
where  ItemID = @ItemID


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE UpdateHtmlText
(
    @ModuleID      int,
    @DesktopHtml   ntext,
    @MobileSummary ntext,
    @MobileDetails ntext
)
AS

IF NOT EXISTS (
    SELECT 
        * 
    FROM 
        HtmlText 
    WHERE 
        ModuleID = @ModuleID
)
INSERT INTO HtmlText (
    ModuleID,
    DesktopHtml,
    MobileSummary,
    MobileDetails
) 
VALUES (
    @ModuleID,
    @DesktopHtml,
    @MobileSummary,
    @MobileDetails
)
ELSE
UPDATE
    HtmlText

SET
    DesktopHtml   = @DesktopHtml,
    MobileSummary = @MobileSummary,
    MobileDetails = @MobileDetails

WHERE
    ModuleID = @ModuleID



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure UpdateImage

@EntityType nvarchar(20), 
@EntityId int, 
@ImagePath varchar(50),
@ImageWidth int,
@ImageHeight int

as

declare @ImageId int

if @EntityType = 'Group'
begin
  select @ImageId = GroupImageId
  from   GroupsImages
  where  GroupId = @EntityId
  and    ImagePath = @ImagePath

  if @ImageId is null
  begin
    insert into GroupsImages (
      GroupId,
      ImagePath,
      ImageWidth,
      ImageHeight
    )
    values (
      @EntityId,
      @ImagePath,
      @ImageWidth,
      @ImageHeight
    )
  end
  else
  begin
    update GroupsImages
    set    ImageWidth = @ImageWidth,
           ImageHeight = @ImageHeight
    where  GroupImageId = @ImageId
  end
end

if @EntityType = 'Participant'
begin
  select @ImageId = ParticipantImageId
  from   ParticipantsImages
  where  ParticipantId = @EntityId
  and    ImagePath = @ImagePath

  if @ImageId is null
  begin
    insert into ParticipantsImages (
      ParticipantId,
      ImagePath,
      ImageWidth,
      ImageHeight
    )
    values (
      @EntityId,
      @ImagePath,
      @ImageWidth,
      @ImageHeight
    )
  end
  else
  begin
    update ParticipantsImages
    set    ImageWidth = @ImageWidth,
           ImageHeight = @ImageHeight
    where  ParticipantImageId = @ImageId
  end
end

if @EntityType = 'Event'
begin
  select @ImageId = EventImageId
  from   EventsImages
  where  EventId = @EntityId
  and    ImagePath = @ImagePath

  if @ImageId is null
  begin
    insert into EventsImages (
      EventId,
      ImagePath,
      ImageWidth,
      ImageHeight
    )
    values (
      @EntityId,
      @ImagePath,
      @ImageWidth,
      @ImageHeight
    )
  end
  else
  begin
    update EventsImages
    set    ImageWidth = @ImageWidth,
           ImageHeight = @ImageHeight
    where  EventImageId = @ImageId
  end
end

return 1


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO



CREATE PROCEDURE UpdateModuleOrder
(
    @ModuleID           int,
    @ModuleOrder        int,
    @PaneName           nvarchar(50)
)
AS

UPDATE
    Modules

SET
    ModuleOrder = @ModuleOrder,
    PaneName    = @PaneName

WHERE
    ModuleID = @ModuleID



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO



CREATE PROCEDURE UpdateModuleSetting
(
    @ModuleID      int,
    @SettingName   nvarchar(50),
    @SettingValue  nvarchar(256)
)
AS

IF NOT EXISTS (
    SELECT 
        * 
    FROM 
        ModuleSettings 
    WHERE 
        ModuleID = @ModuleID
      AND
        SettingName = @SettingName
)
INSERT INTO ModuleSettings (
    ModuleID,
    SettingName,
    SettingValue
) 
VALUES (
    @ModuleID,
    @SettingName,
    @SettingValue
)
ELSE
UPDATE
    ModuleSettings

SET
    SettingValue = @SettingValue

WHERE
    ModuleID = @ModuleID
  AND
    SettingName = @SettingName



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure UpdateRole

@RoleID           int,
@RoleName         nvarchar(50),
@Description      nvarchar(1000) = null,
@ServiceFee       decimal = null,
@BillingFrequency char(1),
@TrialPeriod      int = null,
@TrialFrequency   char(1)

as

update Roles
set    RoleName = @RoleName,
       Description = @Description,
       ServiceFee = @ServiceFee,
       BillingFrequency = @BillingFrequency,
       TrialPeriod = @TrialPeriod,
       TrialFrequency = @TrialFrequency
where  RoleID = @RoleID


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure UpdateService
    
@UserId       int,
@RoleId       int,
@Units        int

as

declare @Frequency char(1)
declare @ExpiryDate datetime
declare @IsTrialUsed bit

select @ExpiryDate = ExpiryDate,
       @IsTrialUsed = IsTrialUsed
from   UserRoles
where  UserId = @UserId
and    RoleId = @RoleId

if @Units = 0
begin
  if @IsTrialUsed is null /* trial period not used */
  begin
    select @Frequency = TrialFrequency,
           @Units = TrialPeriod
    from   Roles
    where  RoleId = @RoleId

    if @Units is null /* no trial period for role */
    begin
      select @Frequency = '0'
    end
    else
    begin
      if @ExpiryDate is null or @ExpiryDate < getdate()
        select @ExpiryDate = getdate()
    end
  end
  else
  begin
    select @Frequency = '0'
  end
end
else
begin
  select @Frequency = BillingFrequency
  from   Roles
  where  RoleId = @RoleId

  if @ExpiryDate is null or @ExpiryDate < getdate()
    select @ExpiryDate = getdate()
end

select @ExpiryDate =
  case
    when @Frequency = '0' then @ExpiryDate
    when @Frequency = '1' then convert(datetime,'12/31/9999')
    when @Frequency = '2' then dateadd(Day,@Units,@ExpiryDate)
    when @Frequency = '3' then dateadd(Week,@Units,@ExpiryDate)
    when @Frequency = '4' then dateadd(Month,@Units,@ExpiryDate)
    when @Frequency = '5' then dateadd(Year,@Units,@ExpiryDate)
  end

if exists ( select 1 from UserRoles where UserId = @UserId and RoleId = @RoleId )
begin
  update UserRoles
  set    ExpiryDate = @ExpiryDate,
         IsTrialUsed = 1
  where  UserId = @UserId
  and    RoleId = @RoleId
end
else
begin
  insert UserRoles (
    UserId,
    RoleId,
    ExpiryDate,
    IsTrialUsed
  )
  values (
    @UserId,
    @RoleId,
    @ExpiryDate,
    1
  )
end


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure UpdateTab

@TabID           int,
@TabName         nvarchar(50),
@ShowMobile      bit,
@MobileTabName   nvarchar(50),
@AuthorizedRoles nvarchar(256),
@LeftPaneWidth   nvarchar(5),
@RightPaneWidth  nvarchar(5),
@IsVisible       bit

as

update Tabs
set    TabName = @TabName,
       ShowMobile = @ShowMobile,
       MobileTabName = @MobileTabName,
       AuthorizedRoles = @AuthorizedRoles,
       LeftPaneWidth = @LeftPaneWidth,
       RightPaneWidth = @RightPaneWidth,
       IsVisible = @IsVisible
where  TabID = @TabID


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO



CREATE PROCEDURE UpdateTabOrder
(
    @TabID           int,
    @TabOrder        int
)
AS

UPDATE
    Tabs

SET
    TabOrder = @TabOrder

WHERE
    TabID = @TabID



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure AddFAQ

@ModuleID int,
@UserName nvarchar(100),
@Question text,
@Answer   text

as

insert into FAQs (
  CreatedByUser,
  CreatedDate,
  ModuleID,
  Question,
  Answer
)
values (
  @UserName,
  getdate(),
  @ModuleID,
  @Question,
  @Answer
)


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure AddFile

@PortalId    int,
@FileName    nvarchar(100),
@Extension   nvarchar(100),
@Size        int,
@Width       int,
@Height      int,
@ContentType nvarchar(200)

as

declare @FileId int

select @FileId = null

select @FileId = FileId
from   Files
where  FileName = @FileName
and    PortalId = @PortalId

if @FileId is null
begin
  insert Files ( 
    PortalId,
    FileName,
    Extension,
    Size,
    Width,
    Height,
    ContentType 
  )
  values (
    @PortalId,
    @FileName,
    @Extension,
    @Size,
    @Width,
    @Height,
    @ContentType 
  )
end
else
begin
  update Files
  set    FileName = @FileName,
         Extension = @Extension,
         Size = @Size,
         Width = @Width,
         Height = @Height,
         ContentType = @ContentType
  where  FileId = @FileId
end

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure DeleteFile

@FileName nvarchar(100),
@PortalId int

as

delete 
from   Files
where  FileName = @FileName
and    PortalId = @PortalId

return 1

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure DeleteFiles

@PortalId int

as

if @PortalId is null
begin
  delete 
  from   Files
  where  PortalId is null
end
else
begin
  delete 
  from   Files
  where  PortalId = @PortalId
end

return 1

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure GetBannerTypes

as

select BannerTypeId,
       BannerTypeName
from   BannerTypes

return 1

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure GetCountryCodes
    
as

select *
from   CodeCountry
order by Description


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure GetCurrencies

as

select Code,
       Description
from   CodeCurrency

return 1

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure GetFiles

@PortalId   int

as

if @PortalId is null
begin
  select FileId,
         PortalId,
         FileName,
         Extension,
         Size,
         Width,
         Height,
         ContentType
  from   Files
  where  PortalId is null
end
else
begin
  select FileId,
         PortalId,
         FileName,
         Extension,
         Size,
         Width,
         Height,
         ContentType
  from   Files
  where  PortalId = @PortalId
end

return 1

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure GetModuleDefinitions

@Admin bit = 1

as

if @Admin = 1
begin
  select FriendlyName,
         DesktopSrc,
         MobileSrc,
         ModuleDefID
  from   ModuleDefinitions
  order  by FriendlyName
end
else
begin
  select FriendlyName,
         DesktopSrc,
         MobileSrc,
         ModuleDefID
  from   ModuleDefinitions
  where  AdminOrder is null
  and    DesktopSrc is not null
  order  by FriendlyName
end


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO



create procedure GetPortalByAlias

@PortalAlias nvarchar(200)

as

select 'PortalID' = min(PortalID)
from   Portals
where  PortalAlias like '%' + @PortalAlias + '%'


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure GetPortalSpaceUsed

@PortalId int

as

select 'SpaceUsed' = sum(Size)
from   Files
where  PortalId = @PortalId

return 1

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure GetRegionCodes
    
@Country char(2)

as

select *
from   CodeRegion
where  Country = @Country
order by Description


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure GetSingleFAQ

@ItemID   int,
@ModuleId int

as

select ItemID,
       ModuleID,
       Question,
       Answer,
       'CreatedByUser' = Users.FirstName + ' ' + Users.LastName,
       FAQs.CreatedDate
from   FAQs
left outer join Users on FAQs.CreatedByUser = Users.UserID
where  ItemID = @ItemID
and    ModuleId = @ModuleId


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure GetSingleFile

@FileName  nvarchar(100),
@PortalId  int

as

select FileName,
       Extension,
       Size,
       Width,
       Height,
       ContentType
from   Files
where  FileName = @FileName
and    PortalId = @PortalId

return 1

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure GetSingleModuleDefinition

@ModuleDefID int

as

select FriendlyName,
       DesktopSrc,
       MobileSrc,
       AdminOrder,
       EditSrc,
       Secure
from   ModuleDefinitions
where  ModuleDefID = @ModuleDefID


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure GetSingleModuleDefinitionByName

@FriendlyName nvarchar(128)

as

select ModuleDefId,
       FriendlyName,
       DesktopSrc,
       MobileSrc,
       AdminOrder,
       EditSrc,
       Secure
from   ModuleDefinitions
where  FriendlyName = @FriendlyName


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure GetSinglePortal

@PortalID  int

as

select *
from   Portals
where  PortalID = @PortalID


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure GetSingleUserByEmail

@Email nvarchar(100)

as
 
select UserId,
       Email,
       Password,
       'FullName' = FirstName + ' ' + LastName,
       FirstName,
       LastName,
       Unit,
       Street,
       City,
       Region,
       PostalCode,
       Country
from   Users
where  Email  = @Email


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure UpdatePortalInfo

@PortalID           int,
@PortalName         nvarchar(50),
@PortalAlias        nvarchar(200) = null,
@UploadDirectory    nvarchar(100) = null,
@LogoFile           nvarchar(50) = null,
@FooterText         nvarchar(100) = null,
@ExpiryDate         datetime = null,
@UserRegistration   int = null,
@BannerAdvertising  int = null,
@Currency           char(3) = null,
@AdministratorId    int = null,
@HostFee            nvarchar(10) = null,
@HostSpace          int = null,
@PayPalId           nvarchar(50) = null

as

update Portals
set    PortalName = @PortalName,
       PortalAlias = isnull(@PortalAlias,PortalAlias),
       UploadDirectory = isnull(@UploadDirectory,UploadDirectory),
       LogoFile = @LogoFile,
       FooterText = @FooterText,
       ExpiryDate = @ExpiryDate,
       UserRegistration = @UserRegistration,
       BannerAdvertising = @BannerAdvertising,
       Currency = @Currency,
       AdministratorId = @AdministratorId,
       HostFee = @HostFee,
       HostSpace = @HostSpace,
       PayPalId = @PayPalId
where  PortalID = @PortalID


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure AddRole

@PortalID         int,
@RoleName         nvarchar(50),
@Description      nvarchar(1000) = null,
@ServiceFee       decimal = null,
@BillingFrequency char(1),
@TrialPeriod      int = null,
@TrialFrequency   char(1)

as

insert into Roles(
  PortalID,
  RoleName,
  Description,
  ServiceFee,
  BillingFrequency,
  TrialPeriod,
  TrialFrequency
)
values (
  @PortalID,
  @RoleName,
  @Description,
  @ServiceFee,
  @BillingFrequency,
  @TrialPeriod,
  @TrialFrequency
)


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure AddSiteLog

@PortalId                      int,
@UserId                        int                   = null,
@Referrer                      nvarchar(255)         = null,
@Url                           nvarchar(255)         = null,
@UserAgent                     nvarchar(255)         = null,
@UserHostAddress               nvarchar(255)         = null,
@UserHostName                  nvarchar(255)         = null

as
 
insert SiteLog ( 
  DateTime,
  PortalId,
  UserId,
  Referrer,
  Url,
  UserAgent,
  UserHostAddress,
  UserHostName
)
values (
  getdate(),
  @PortalId,
  @UserId,
  @Referrer,
  @Url,
  @UserAgent,
  @UserHostAddress,
  @UserHostName
)

return 1


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure AddUser

@PortalId       int,
@FirstName	nvarchar(50),
@LastName	nvarchar(50),
@Unit		nvarchar(50),
@Street		nvarchar(20),
@City		nvarchar(20),
@Region		nvarchar(20),
@PostalCode	nvarchar(10),
@Country	nvarchar(20),
@Email		nvarchar(100),
@Password	nvarchar(20),
@Authorized     bit,
@UserID	int	OUTPUT

as

select	@UserID = UserID
from 	Users
where	Email = @Email 
and Password = @Password

if @UserID is null
begin
  insert into Users (
    FirstName,
    LastName,
    Unit, 
    Street, 
    City,
    Region, 
    PostalCode,
    Country,
    Email,
    Password,
    CreatedDate,
    LastLoginDate
  )
  values (
    @FirstName,
    @LastName,
    @Unit,
    @Street,
    @City,
    @Region,
    @PostalCode,
    @Country,
    @Email,
    @Password,
    getdate(),
    null
  )

  select @UserID = @@IDENTITY
end

if @@ERROR = 0
begin
  insert into UserPortals (
    UserId,
    PortalId,
    Authorized
  )
  values (
    @UserId,
    @PortalId,
    @Authorized
  )
end


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure AddVendor

@PortalID 	int,
@VendorName 	nvarchar(50),
@Unit    	nvarchar(50),
@Street 	nvarchar(50),
@City		nvarchar(50),
@Region	        nvarchar(50),
@Country	nvarchar(50),
@PostalCode	nvarchar(50),
@Telephone	nvarchar(50),
@Fax   	        nvarchar(50),
@Email    	nvarchar(50),
@Website	nvarchar(100),
@Contact	nvarchar(50),
@UserName       nvarchar(100),
@LogoFile       nvarchar(100),
@KeyWords       text,
@VendorID	int OUTPUT

as

insert into Vendors (
  VendorName,
  Unit,
  Street,
  City,
  Region,
  Country,
  PostalCode,
  Telephone,
  PortalId,
  Fax,
  Email,
  Website,
  Contact,
  ClickThroughs,
  Views,
  CreatedByUser,
  CreatedDate,
  LogoFile,
  KeyWords
)
values (
  @VendorName,
  @Unit,
  @Street,
  @City,
  @Region,
  @Country,
  @PostalCode,
  @Telephone,
  @PortalID,
  @Fax,
  @Email,
  @Website,
  @Contact,
  0,
  0,
  @UserName,
  getdate(), 
  @LogoFile,
  @KeyWords
)

select @VendorID = @@IDENTITY


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO



create procedure DeleteRole

@RoleID int

as

if @RoleID <> 0 /* Admins Role */
begin
  delete 
  from   Roles
  where  RoleID = @RoleID
end


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure DeleteUser

@PortalId int,
@UserID   int

as

declare @RoleId int

if not exists ( select 1 from Portals where AdministratorId = @UserID )
begin
  delete
  from   UserPortals
  where  PortalId = @PortalId
  and    UserID = @UserID

  select @RoleId = min(RoleId)
  from   Roles
  where  PortalId = @PortalId
  while @RoleId is not null
  begin
    delete
    from   UserRoles
    where  UserId = @UserId
    and    RoleId = @RoleId

    select @RoleId = min(RoleId)
    from   Roles
    where  PortalId = @PortalId
    and    RoleId > @RoleId
  end

  if not exists ( select 1 from UserPortals where UserId = @UserID )
  begin
    delete
    from   Users
    where  UserID = @UserID
  end
end


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure GetBannerLog

@BannerId  int

as

select 'LogDate' = convert(varchar,DateTime,102),
       'Views' = count(*)
from   VendorLog
where  BannerId = @BannerId
group by convert(varchar,DateTime,102)
order by LogDate desc

return 1


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO




create procedure GetPortalRoles

@PortalID     int

as

select Roles.RoleID,
       Roles.RoleName,
       Roles.Description,
       Roles.ServiceFee,
       'BillingFrequency' = case when Roles.ServiceFee is not null then C1.Description else null end,
       Roles.TrialPeriod,
       'TrialFrequency' = case when Roles.TrialPeriod is not null then C2.Description else null end
from   Roles
left outer join CodeFrequency C1 on Roles.BillingFrequency = C1.Code
left outer join CodeFrequency C2 on Roles.TrialFrequency = C2.Code
where  PortalID = @PortalID
or     PortalID is null


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure GetPortals

as

select Portals.*,
       'Users' = ( select count(*) from UserPortals where UserPortals.PortalId = Portals.PortalId )
from   Portals
order by PortalName


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure GetSingleRole

@RoleID   int,
@PortalId int

as

select RoleName,
       Description,
       ServiceFee,
       BillingFrequency,
       TrialPeriod,
       TrialFrequency
from   Roles
where  RoleID = @RoleID
and    PortalId = @PortalId


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure GetSingleUser

@PortalId int,
@UserId int

as

select Users.UserID,
       'FullName' = FirstName + ' ' + LastName,
       FirstName,
       LastName,
       Unit,
       Street,
       City,
       Region,
       PostalCode,
       Country,
       Email,
       Authorized,
       CreatedDate,
       LastLoginDate,
       Password
from   Users
inner join UserPortals on Users.UserId = UserPortals.UserId
where  Users.UserId = @UserId
and    UserPortals.PortalId = @PortalId


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure GetSingleVendor

@VendorID int

as

select Vendors.VendorName, 
       Vendors.Unit, 
       Vendors.Street, 
       Vendors.City, 
       Vendors.Region, 
       Vendors.Country, 
       Vendors.PostalCode, 
       Vendors.Telephone,
       Vendors.Fax,
       Vendors.Email,
       Vendors.Website,
       Vendors.Contact,
       Vendors.ClickThroughs,
       Vendors.Views,
       'CreatedByUser' = Users.FirstName + ' ' + Users.LastName,
       Vendors.CreatedDate,
       Vendors.LogoFile,
       Vendors.KeyWords
from   Vendors
left outer join Users on Vendors.CreatedByUser = Users.UserID
where  VendorID = @VendorID


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO




create procedure GetSiteLog

@PortalId   int,
@StartDate  datetime,
@EndDate    datetime

as

select 'Pages' = count(*),
       'Visitors' = count(distinct SiteLog.UserHostAddress),
       'Users' = count(distinct SiteLog.UserId)
from SiteLog
left outer join Users on SiteLog.UserId = Users.UserId 
where SiteLog.PortalId = @PortalId
and   SiteLog.DateTime between @StartDate and @EndDate

return 1


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure GetSiteLogDetail

@PortalId   int,
@StartDate  datetime,
@EndDate    datetime

as

declare @PortalAlias nvarchar(50)

select @PortalAlias = PortalAlias
from   Portals
where  PortalID = @PortalID

select SiteLog.DateTime,
       'FullName' = 
	  case
            when SiteLog.UserId is null then null
            else Users.FirstName + ' ' + Users.LastName
          end,
       'Referrer' = 
         case 
           when SiteLog.Referrer like '%' + @PortalAlias + '%' then null 
           else SiteLog.Referrer
         end,
       'URL' = substring(SiteLog.URL,len(@PortalAlias) + 8,500),
       'UserAgent' = 
         case 
           when SiteLog.UserAgent like '%MSIE 1%' then 'Internet Explorer 1'
           when SiteLog.UserAgent like '%MSIE 2%' then 'Internet Explorer 2'
           when SiteLog.UserAgent like '%MSIE 3%' then 'Internet Explorer 3'
           when SiteLog.UserAgent like '%MSIE 4%' then 'Internet Explorer 4'
           when SiteLog.UserAgent like '%MSIE 5%' then 'Internet Explorer 5'
           when SiteLog.UserAgent like '%MSIE 6%' then 'Internet Explorer 6'
           when SiteLog.UserAgent like '%MSIE%' then 'Internet Explorer'
           when SiteLog.UserAgent like '%Mozilla/1%' then 'Netscape Navigator 1'
           when SiteLog.UserAgent like '%Mozilla/2%' then 'Netscape Navigator 2'
           when SiteLog.UserAgent like '%Mozilla/3%' then 'Netscape Navigator 3'
           when SiteLog.UserAgent like '%Mozilla/4%' then 'Netscape Navigator 4'
           else 'Unknown UserAgent'
         end,
         SiteLog.UserHostAddress
from SiteLog
left outer join Users on SiteLog.UserId = Users.UserId 
where SiteLog.PortalId = @PortalId
and   SiteLog.DateTime between @StartDate and @EndDate
order by SiteLog.DateTime desc


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO



create procedure GetUsers

@PortalId int = null

as

if @PortalId is null
begin
  select UserID,
         Email,
         'FullName' = FirstName + ' ' + LastName,
         FirstName,
         LastName,
         Unit,
         Street,
         City,
         Region,
         Country,
         PostalCode
  from   Users
  order  by 'FullName'
end
else
begin
  select Users.UserID,
         Users.Email,
         'FullName' = Users.FirstName + ' ' + Users.LastName,
         Users.FirstName,
         Users.LastName,
         Users.Unit,
         Users.Street,
         Users.City,
         Users.Region,
         Users.Country,
         Users.PostalCode,
         'Authorized' = case when UserPortals.Authorized = 1 then 'Y' else 'N' end
  from   Users
  inner join UserPortals on Users.UserId = UserPortals.UserId
  where  UserPortals.PortalId = @PortalId
  order  by 'FullName'
end



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure GetVendorClickThrough

@VendorId int

as

update Vendors
set    ClickThroughs = ClickThroughs + 1
where  VendorId = @VendorId

select VendorId,
       VendorName,
       Street,
       City,
       Region,
       Country,
       PostalCode,
       Telephone,
       PortalId,
       Fax,
       Email,
       Website,
       Contact
from   Vendors
where  VendorId = @VendorId

return 1


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure GetVendorLog

@VendorId  int

as

select Search,
       'Requests' = count(*),
       'LastRequest' = max(DateTime)
from   VendorLog
where  VendorId = @VendorId
and    BannerId is null
group by Search
order by Requests desc

return 1


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure dbo.UpdateUser

@PortalId       int,
@UserID         int,
@FirstName	nvarchar(50),
@LastName	nvarchar(50),
@Unit		nvarchar(50),
@Street		nvarchar(20),
@City	        nvarchar(20),
@Region	        nvarchar(20),
@PostalCode	nvarchar(10),
@Country	nvarchar(20),
@Email		nvarchar(100),
@Password	nvarchar(20) = null,
@Authorized     bit = null


as

update Users
set    FirstName = @FirstName,
       LastName	 = @LastName,
       Unit	 = @Unit,
       Street	 = @Street,
       City	 = @City,
       Region	 = @Region,
       PostalCode = @PostalCode,
       Country	 = @Country,
       Email	 = @Email,
       Password	 = isnull(@Password,Password)
where  UserId = @UserID

if @Authorized is not null
begin
  update UserPortals
  set    Authorized = @Authorized
  where  PortalId = @PortalId
  and    userId = @UserId
end


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO



create procedure UpdateVendor

@VendorID	int,
@VendorName 	nvarchar(50),
@Unit	 	nvarchar(50),
@Street 	nvarchar(50),
@City		nvarchar(50),
@Region	        nvarchar(50),
@Country	nvarchar(50),
@PostalCode	nvarchar(50),
@Telephone	nvarchar(50),
@Fax		nvarchar(50),
@Email		nvarchar(50),
@Website	nvarchar(100),
@Contact	nvarchar(50),
@UserName       nvarchar(100),
@LogoFile       nvarchar(100),
@KeyWords       text

as

update Vendors
set    VendorName    = @VendorName,
       Unit          = @Unit,
       Street        = @Street,
       City          = @City,
       Region        = @Region,
       Country       = @Country,
       PostalCode    = @PostalCode,
       Telephone     = @Telephone,
       Fax           = @Fax,
       Email         = @Email,
       Website       = @Website,
       Contact       = @Contact,
       CreatedByUser = @UserName,
       CreatedDate   = getdate(),
       LogoFile      = @LogoFile,
       KeyWords      = @KeyWords
where  VendorId = @VendorId


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure UserLogin

@Email    nvarchar(100),
@Password nvarchar(20),
@PortalID int,
@SuperUserId int

as

declare @UserId int

select @UserId = null

/* validate the user */
select @UserId = UserId
from   Users
where  Email = @Email
and    Password = @Password

if @UserId is not null
begin
  if @UserId <> @SuperUserId
  begin
    select @UserId = null

    /* validate the user belongs to the portal */
    select @UserId = Users.UserId
    from   UserPortals
    inner join Users on UserPortals.UserId = Users.UserId
    where  PortalID = @PortalID
    and    Email = @Email
    and    Password = @Password
    and    Authorized = 1
  end
end

if not @UserId is null
begin
  update Users
  set    LastLoginDate = getdate()
  where  UserId = @UserId

  select 'UserId' = @UserId
end


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure AddBanner
(
    @BannerName    nvarchar(100),
    @VendorId      int,
    @ImageFile     nvarchar(50),
    @URL           nvarchar(100) = null,
    @Impressions   int,
    @CPM           float,
    @StartDate     datetime = null,
    @EndDate       datetime = null,
    @UserName      nvarchar(100),
    @BannerTypeId  int = null
)

as

insert into Banners
(
    VendorId,
    ImageFile,
    BannerName,
    URL,
    Impressions,
    CPM,
    Views,
    ClickThroughs,
    StartDate,
    EndDate,
    CreatedByUser,
    CreatedDate,
    BannerTypeId
)
values
(
    @VendorId,
    @ImageFile,
    @BannerName,
    @URL,
    @Impressions,
    @CPM,
    0,
    0,
    @StartDate,
    @EndDate,
    @UserName,
    getdate(),
    @BannerTypeId
)



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure AddModule
    
@TabID          int,
@ModuleOrder    int,
@ModuleTitle    nvarchar(256),
@PaneName       nvarchar(50),
@ModuleDefID    int,
@CacheTime      int,
@EditRoles      nvarchar(256),
@ShowMobile     bit

as

insert into Modules (
  TabID,
  ModuleOrder,
  ModuleTitle,
  PaneName,
  ModuleDefID,
  CacheTime,
  AuthorizedEditRoles,
  ShowMobile
) 
values (
  @TabID,
  @ModuleOrder,
  @ModuleTitle,
  @PaneName,
  @ModuleDefID,
  @CacheTime,
  @EditRoles,
  @ShowMobile
)


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure AddModuleDefinition
    
@FriendlyName nvarchar(128),
@DesktopSrc   nvarchar(256),
@MobileSrc    nvarchar(256),
@AdminOrder   int,
@EditSrc      nvarchar(256),
@Secure       bit

as

declare @ModuleDefId int
declare @TabId int
declare @ModuleOrder int
declare @AdministratorRoleId int

insert into ModuleDefinitions (
  FriendlyName,
  DesktopSrc,
  MobileSrc,
  AdminOrder,
  EditSrc,
  Secure
)
values (
  @FriendlyName,
  @DesktopSrc,
  @MobileSrc,
  @AdminOrder,
  @EditSrc,
  @Secure
)

select @ModuleDefID = @@IDENTITY

/* add to all Admin tabs */
if @AdminOrder is not null and @AdminOrder > 0
begin
  select @TabId = min(TabId)
  from Tabs
  where TabName = 'Admin'
  while @TabId is not null
  begin
    select @ModuleOrder = (max(ModuleOrder) + 2)
    from   Modules
    where  TabId = @TabId

    select @AdministratorRoleId = AdministratorRoleId
    from   Portals
    inner join Tabs on Portals.PortalId = Tabs.PortalId
    where TabId = @TabId

    if not exists ( select 1 from Modules where TabID = @TabId and ModuleDefID = @ModuleDefId )
    begin
      insert into Modules (
        TabID,
        ModuleDefID,
        ModuleOrder,
        PaneName,
        ModuleTitle,
        AuthorizedEditRoles,
        CacheTime,
        ShowMobile,
        AuthorizedViewRoles
      )
      values (
        @TabId,
        @ModuleDefId,
        @ModuleOrder,
        'ContentPane',
        'Sales Summary',
        convert(varchar,@AdministratorRoleId) + ';',
        0,
        0,
        ''
      )
    end

    select @TabId = min(TabId)
    from Tabs
    where TabName = 'Admin'
    and TabId > @TabId
  end
end


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure AddPortalInfo

@PortalName         nvarchar(50),
@PortalAlias        nvarchar(200),
@UploadDirectory    nvarchar(100),
@LogoFile           nvarchar(50) = null,
@FooterText         nvarchar(100) = null,
@UserRegistration   int = null,
@BannerAdvertising  int = null,
@Currency           char(3) = null,
@AdministratorId    int = null,
@FirstName          nvarchar(100),
@LastName           nvarchar(100),
@Email              nvarchar(200),
@Password           nvarchar(40),
@ExpiryDate         datetime = null,
@HostFee            nvarchar(10) = null,
@HostSpace          int = null,
@PayPalId           nvarchar(50) = null,
@PortalID           int OUTPUT

as

declare @AdminOrder int
declare @ModuleDefId int
declare @FriendlyName nvarchar(128)
declare @PaneName nvarchar(50)
declare @TabId int
declare @ModuleOrder int
declare @RoleId int
declare @UserId int
declare @AdministratorRoleId int
declare @RegisteredRoleId    int

begin transaction

insert into Portals (
  PortalName,
  PortalAlias,
  UploadDirectory,
  LogoFile,
  FooterText,
  ExpiryDate,
  UserRegistration,
  BannerAdvertising,
  Currency,
  AdministratorId,
  HostFee,
  HostSpace,
  PayPalId,
  AdministratorRoleId,
  RegisteredRoleId
)
values (
  @PortalName,
  @PortalAlias,
  @UploadDirectory,
  @LogoFile,
  @FooterText,
  @ExpiryDate,
  @UserRegistration,
  @BannerAdvertising,
  @Currency,
  null,
  @HostFee,
  @HostSpace,
  @PayPalId,
  null,
  null
)

select @PortalID = @@IDENTITY

insert into Roles (
  PortalID,
  RoleName,
  Description,
  ServiceFee,
  BillingFrequency,
  TrialPeriod,
  TrialFrequency
)
values (
  @PortalID,
  'Administrators',
  'Portal Administration',
  null,
  4,
  null,
  null
)

select @AdministratorRoleId = @@IDENTITY

insert into Roles (
  PortalID,
  RoleName,
  Description,
  ServiceFee,
  BillingFrequency,
  TrialPeriod,
  TrialFrequency
)
values (
  @PortalID,
  'Registered Users',
  'Registered Users',
  null,
  0,
  null,
  null
)

select @RegisteredRoleId = @@IDENTITY

insert into Tabs (
    PortalID,
    TabOrder,
    TabName,
    AuthorizedRoles,
    MobileTabName,
    ShowMobile,
    LeftPaneWidth,
    RightPaneWidth
) 
values (
    @PortalID,
    1,
    'Home',
    '-1;',
    'Home',
    1,
    '200',
    '200'   
)

select @TabId = @@IDENTITY

select @ModuleDefId = ModuleDefId
from   ModuleDefinitions
where  FriendlyName = 'HTML'

insert Modules ( 
  TabID,
  ModuleDefID,
  ModuleOrder,
  PaneName,
  ModuleTitle,
  AuthorizedEditRoles,
  CacheTime,
  ShowMobile
)
values (
  @TabId,
  @ModuleDefId,
  1,
  'ContentPane',
  @PortalName,
  convert(varchar,@AdministratorRoleId) + ';',
  0,
  0
)

insert into Tabs (
    PortalID,
    TabOrder,
    TabName,
    AuthorizedRoles,
    MobileTabName,
    ShowMobile,
    LeftPaneWidth,
    RightPaneWidth
) 
values (
    @PortalID,
    5,
    'Admin',
    convert(varchar,@AdministratorRoleId) + ';',
    'Admin',
    0,
    '200',
    '200'   
)

select @TabId = @@IDENTITY

select @ModuleOrder = 0

select @AdminOrder = min(AdminOrder)
from   ModuleDefinitions
where  AdminOrder is not null
and    AdminOrder > 0
while @AdminOrder is not null
begin
  select @ModuleDefId = ModuleDefId,
         @FriendlyName = FriendlyName
  from   ModuleDefinitions
  where  AdminOrder = @AdminOrder

  select @ModuleOrder = @ModuleOrder + 1

  select @PaneName = 'ContentPane'

  insert Modules ( 
    TabID,
    ModuleDefID,
    ModuleOrder,
    PaneName,
    ModuleTitle,
    AuthorizedEditRoles,
    CacheTime,
    ShowMobile
  )
  values (
    @TabId,
    @ModuleDefId,
    @ModuleOrder,
    @PaneName,
    @FriendlyName,
    convert(varchar,@AdministratorRoleId) + ';',
    0,
    0
  )

  select @AdminOrder = min(AdminOrder)
  from   ModuleDefinitions
  where  AdminOrder is not null
  and    AdminOrder > @AdminOrder
end 

select @UserId = null

if @AdministratorId is null
  select @UserId = UserId
  from   Users
  where  Email = @Email
else
  select @UserId = @AdministratorId

if @UserId is null
begin
  insert into Users (
    FirstName,
    LastName, 
    Email,
    Password,
    CreatedDate 
  )
  values (
    @FirstName,
    @LastName,
    @Email,
    @Password,
    getdate()
  )

  select @UserId = @@IDENTITY
end

insert into UserPortals (
  UserId,
  PortalId,
  Authorized
)
values (
  @UserId,
  @PortalID,
  1
)

if not exists ( select 1 from UserRoles where UserId = @UserId and RoleID = @AdministratorRoleId )
begin
  insert into UserRoles (
    UserId,
    RoleId,
    ExpiryDate
  )
  values (
    @UserId,
    @AdministratorRoleId, /* Administrators */
    null
  )
end

if not exists ( select 1 from UserRoles where UserId = @UserId and RoleID = @RegisteredRoleId )
begin
  insert into UserRoles (
    UserId,
    RoleId,
    ExpiryDate
  )
  values (
    @UserId,
    @RegisteredRoleId, /* Registered */
    null
  )
end

update Portals
set    UploadDirectory = @UploadDirectory + '/' + convert(varchar,@PortalID) + '/',
       AdministratorId = @UserId,
       AdministratorRoleId = @AdministratorRoleId,
       RegisteredRoleId = @RegisteredRoleId
where  PortalID = @PortalID

if @@error <> 0
  rollback transaction
else
  commit transaction


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure AddUserRole

@PortalID   int,
@UserID     int,
@RoleID     int,
@ExpiryDate datetime = null

as

declare @UserRoleID int

select @UserRoleID = null
select @UserRoleID = UserRoleID
from   UserRoles
inner join UserPortals on UserPortals.UserId = @UserID
where  UserRoles.UserID = @UserID
and    UserRoles.RoleID = @RoleID
and    PortalID = @PortalID
 
if @UserRoleID is not null
begin
  update UserRoles
  set    ExpiryDate = @ExpiryDate
  where  UserRoleId = @UserRoleID
end
else
begin
  insert UserRoles (
    UserID,
    RoleID,
    ExpiryDate
  )
  values (
    @UserID,
    @RoleID,
    @ExpiryDate
  )
end


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure AddVendorClassification

@VendorId           int,
@ClassificationId   int

as

insert VendorClassification ( 
  VendorId,
  ClassificationId
)
values (
  @VendorId,
  @ClassificationId
)

return 1

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure DeleteUserRole

@UserRoleID int

as

declare @UserID int
declare @RoleID int
declare @AdministratorRoleId int

select @UserID = UserID,
       @RoleID = RoleID
from   UserRoles
where  UserRoleID = @UserRoleID

select @AdministratorRoleId = AdministratorRoleId
from   Roles
inner join Portals on Roles.PortalID = Portals.PortalID
where  RoleID = @RoleID

/* do not remove Administrators role from Portal Administrator */
if not exists ( select 1 from Portals where AdministratorId = @UserID and @RoleID = @AdministratorRoleId ) 
begin
  delete
  from   UserRoles
  where  UserRoleID = @UserRoleID
end


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure DeleteVendorClassifications

@VendorId  int

as

delete
from   VendorClassification
where  VendorId = @VendorId

return 1

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure DeleteVendorFeedback

@VendorId int,
@UserId   int

as

delete
from   VendorFeedback
where  VendorId = @VendorId
and    UserId = @UserId


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure FindBanners

@BannerTypeId int,
@DisplayPortalId int,
@SelectPortalId int = null,
@Banners  int = 1

as

declare @RecordCounter int
declare @RandomRecord int
declare @BannerId int
declare @StartDate smalldatetime
declare @EndDate smalldatetime
declare @Views int
declare @Impressions int
declare @VendorId int

/* find number of banners */
select @RecordCounter = count(*)
from   Banners
inner join Vendors on Banners.VendorId = Vendors.VendorId
where  Banners.BannerTypeId = @BannerTypeId
and    ((Vendors.PortalId = @SelectPortalId) or (@SelectPortalId is null and Vendors.PortalId is null))
and    (Banners.Impressions > Banners.Views Or Banners.Impressions = 0)
and    (Banners.StartDate is null Or getdate() >= Banners.StartDate )
and    (Banners.EndDate is null Or getdate() <= Banners.EndDate )

if @Banners > @RecordCounter
begin
  select @Banners = @RecordCounter
end

/* generate random number */
select @RandomRecord = Round(RAND() * (@RecordCounter - @Banners + 1),0)
if @RandomRecord = 0
begin
  select @RandomRecord = 1
end

/* move record pointer to random record */
select @RecordCounter = 1

select @BannerId = min(Banners.BannerId)
from   Banners
inner join Vendors on Banners.VendorId = Vendors.VendorId
where  Banners.BannerTypeId = @BannerTypeId
and    ((Vendors.PortalId = @SelectPortalId) or (@SelectPortalId is null and Vendors.PortalId is null))
and    (Banners.Impressions > Banners.Views Or Banners.Impressions = 0)
and    (Banners.StartDate is null Or getdate() >= Banners.StartDate )
and    (Banners.EndDate is null Or getdate() <= Banners.EndDate )

while @BannerId is not null and @RecordCounter <> @RandomRecord
begin
  select @BannerId = min(Banners.BannerId)
  from   Banners
  inner join Vendors on Banners.VendorId = Vendors.VendorId
  where  Banners.BannerTypeId = @BannerTypeId
  and    ((Vendors.PortalId = @SelectPortalId) or (@SelectPortalId is null and Vendors.PortalId is null))
  and    (Banners.Impressions > Banners.Views Or Banners.Impressions = 0)
  and    (Banners.StartDate is null Or getdate() >= Banners.StartDate )
  and    (Banners.EndDate is null Or getdate() <= Banners.EndDate )
  and    Banners.BannerId > @BannerId

  select @RecordCounter = @RecordCounter + 1
end

/* return matching banners */
set rowcount @Banners

if @SelectPortalId is null
begin
  select BannerId,
         BannerName,
         ImageFile
  from   Banners
  inner join Vendors on Banners.VendorId = Vendors.VendorId
  where  Banners.BannerTypeId = @BannerTypeId
  and    ((Vendors.PortalId = @SelectPortalId) or (@SelectPortalId is null and Vendors.PortalId is null))
  and    (Banners.Impressions > Banners.Views Or Banners.Impressions = 0)
  and    (Banners.StartDate is null Or getdate() >= Banners.StartDate )
  and    (Banners.EndDate is null Or getdate() <= Banners.EndDate )
  and    BannerId >= @BannerId
end
else
begin
  select BannerId,
         BannerName,
         ImageFile
  from   Banners
  inner join Vendors on Banners.VendorId = Vendors.VendorId
  where  Banners.BannerTypeId = @BannerTypeId
  and    ((Vendors.PortalId = @SelectPortalId) or (@SelectPortalId is null and Vendors.PortalId is null))
  and    (Banners.Impressions > Banners.Views Or Banners.Impressions = 0)
  and    (Banners.StartDate is null Or getdate() >= Banners.StartDate )
  and    (Banners.EndDate is null Or getdate() <= Banners.EndDate )
  and    BannerId >= @BannerId
end

set rowcount 0

/* update banners */
select @RecordCounter = 0

while @RecordCounter < @Banners
begin
  update Banners
  set    Views = Views + 1
  where  BannerId = @BannerId

  select @vendorId = VendorId
  from   Banners
  where  BannerId = @BannerId

  insert VendorLog (
    DateTime,
    PortalId,
    VendorId,
    BannerId,
    Search
  )
  values (
    getdate(),    @DisplayPortalId,
    @VendorId,
    @BannerId,
    null
  ) 

  select @StartDate = StartDate,
         @EndDate = EndDate,
         @Views = Views,
         @Impressions = Impressions
  from   Banners
  where  BannerId = @BannerId

  if @StartDate is null
    select @StartDate = getdate()
  if @Views = @Impressions
    select @EndDate = getdate()

  update Banners
  set    StartDate = @StartDate,
         EndDate = @EndDate
  where  BannerId = @BannerId

  select @BannerId = min(Banners.BannerId)
  from   Banners
  inner join Vendors on Banners.VendorId = Vendors.VendorId
  where  Banners.BannerTypeId = @BannerTypeId
  and    ((Vendors.PortalId = @SelectPortalId) or (@SelectPortalId is null and Vendors.PortalId is null))
  and    (Banners.Impressions > Banners.Views Or Banners.Impressions = 0)
  and    (Banners.StartDate is null Or getdate() >= Banners.StartDate )
  and    (Banners.EndDate is null Or getdate() <= Banners.EndDate )
  and    Banners.BannerId > @BannerId

  select @RecordCounter = @RecordCounter + 1
end

return 1


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure FindVendors

@DisplayPortalId  int,
@SelectPortalId   int = null,
@Search           nvarchar(200) = null

as

if @Search is not null
begin
  insert VendorSearch (
    PortalId,
    DateTime,
    Search
  )
  values (
    @DisplayPortalId,
    getdate(),
    @Search
  )
end

if @SelectPortalId is null
begin
  update Vendors
  set    Views = Views + 1
  where  VendorId in (
    select distinct Vendors.VendorId
    from Vendors
    left outer join VendorClassification on Vendors.VendorId = VendorClassification.VendorId
    left outer join Classification on VendorClassification.ClassificationId = Classification.ClassificationId
    where  PortalId is null
    and    (VendorName like '%' + @Search + '%' or KeyWords like '%' + @Search + '%' or ClassificationName like '%' + @Search + '%')
  )

  insert VendorLog ( VendorId, DateTime, PortalId, BannerId, Search ) 
    select distinct Vendors.VendorId, getdate(), @DisplayPortalId, null, @Search
    from   Vendors
    left outer join VendorClassification on Vendors.VendorId = VendorClassification.VendorId
    left outer join Classification on VendorClassification.ClassificationId = Classification.ClassificationId
    where  PortalId is null
    and    (VendorName like '%' + @Search + '%' or KeyWords like '%' + @Search + '%' or ClassificationName like '%' + @Search + '%')

  select distinct Vendors.VendorId,
         VendorName,
         Unit,
         Street,
         City,
         Region,
         Country,
         PostalCode,
         Telephone,
         PortalId,
         Fax,
         Email,
         Website,
         Contact,
         LogoFile,
         'Feedback' = ( select sum(Value) from VendorFeedback where VendorFeedback.VendorId = Vendors.VendorId )
  from   Vendors
  left outer join VendorClassification on Vendors.VendorId = VendorClassification.VendorId
  left outer join Classification on VendorClassification.ClassificationId = Classification.ClassificationId
  where  PortalId is null
  and    (VendorName like '%' + @Search + '%' or KeyWords like '%' + @Search + '%' or ClassificationName like '%' + @Search + '%')
end
else
begin
  update Vendors
  set    Views = Views + 1
  where  VendorId in (
    select distinct Vendors.VendorId
    from Vendors
    left outer join VendorClassification on Vendors.VendorId = VendorClassification.VendorId
    left outer join Classification on VendorClassification.ClassificationId = Classification.ClassificationId
    where  PortalId = @SelectPortalId
    and    (VendorName like '%' + @Search + '%' or KeyWords like '%' + @Search + '%' or ClassificationName like '%' + @Search + '%')
  )

  insert VendorLog ( VendorId, DateTime, PortalId, BannerId, Search ) 
    select distinct Vendors.VendorId, getdate(), @DisplayPortalId, null, @Search
    from   Vendors
    left outer join VendorClassification on Vendors.VendorId = VendorClassification.VendorId
    left outer join Classification on VendorClassification.ClassificationId = Classification.ClassificationId
    where  PortalId = @SelectPortalId
    and    (VendorName like '%' + @Search + '%' or KeyWords like '%' + @Search + '%' or ClassificationName like '%' + @Search + '%')

  select distinct Vendors.VendorId,
         VendorName,
         Unit,
         Street,
         City,
         Region,
         Country,
         PostalCode,
         Telephone,
         PortalId,
         Fax,
         Email,
         Website,
         Contact,
         LogoFile,
         'Feedback' = ( select sum(Value) from VendorFeedback where VendorFeedback.VendorId = Vendors.VendorId )
  from   Vendors
  left outer join VendorClassification on Vendors.VendorId = VendorClassification.VendorId
  left outer join Classification on VendorClassification.ClassificationId = Classification.ClassificationId
  where  PortalId = @SelectPortalId
  and    (VendorName like '%' + @Search + '%' or KeyWords like '%' + @Search + '%' or ClassificationName like '%' + @Search + '%')
end

return 1


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure GetAuthRoles

@PortalID    int,
@ModuleID    int

as

select Tabs.AuthorizedRoles,
       Modules.AuthorizedEditRoles
from   Modules
inner join Tabs ON Modules.TabID = Tabs.TabID
where  Modules.ModuleID = @ModuleID
and    Tabs.PortalID = @PortalID


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure GetModule

@ModuleID int

as

select *
from   Modules
inner join ModuleDefinitions on Modules.ModuleDefId = ModuleDefinitions.ModuleDefId
where  ModuleID = @ModuleID


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure GetPortalSettings

@PortalAlias nvarchar(200),
@TabID       int

as

declare @PortalID int
declare @VerifyTabID int

/* convert PortalAlias to PortalID */
select @PortalID = min(PortalID)
from   Portals
where  PortalAlias like '%' + @PortalAlias + '%'

select @VerifyTabID = null

/* verify the TabID belongs to the portal */
if @TabID <> 0
begin
  select @VerifyTabID = Tabs.TabID
  from   Tabs
  left outer join Portals on Tabs.PortalID = Portals.PortalID
  where  TabId = @TabId
  and    ( Portals.PortalID = @PortalID or Tabs.PortalId is null )
end
else
begin
  select @VerifyTabID = null
end

/* get the TabID if none provided */
if @VerifyTabID is null
begin
  select @TabID = min(Tabs.TabID)
  from Tabs
  inner join Portals on Tabs.PortalID = Portals.PortalID
  where Portals.PortalID = @PortalID
end

/* First, get Out Params */
select Portals.PortalAlias,
       Portals.PortalID,
       Portals.PortalName,
       Portals.UploadDirectory,
       Portals.LogoFile,
       Portals.FooterText,
       Portals.ExpiryDate,
       Portals.UserRegistration,
       Portals.BannerAdvertising,
       Portals.Currency,
       Portals.AdministratorId,
       Users.Email,
       Portals.HostFee,
       Portals.HostSpace,
       Portals.PayPalId,
       Portals.AdministratorRoleId,
       Portals.RegisteredRoleId,
       Tabs.TabID,
       Tabs.TabOrder,
       Tabs.TabName,
       Tabs.MobileTabName,
       Tabs.AuthorizedRoles,
       Tabs.ShowMobile,
       Tabs.LeftPaneWidth,
       Tabs.RightPaneWidth,
       Tabs.IsVisible
from   Tabs
inner join Portals on Portals.PortalID = @PortalID
inner join Users on Portals.AdministratorId = Users.UserId
where  TabID = @TabID

/* Get Tabs list */
select TabName,
       AuthorizedRoles,
       TabID,
       TabOrder,
       IsVisible
from   Tabs
where  PortalID = @PortalID
order  by TabOrder

/* Get Mobile Tabs list */
select MobileTabName,
       AuthorizedRoles,
       TabID,
       IsVisible,
       ShowMobile
from   Tabs
where  PortalID = @PortalID
and    ShowMobile = 1
order  by TabOrder

/* Then, get the DataTable of module info */
select *
from   Modules
inner join ModuleDefinitions on Modules.ModuleDefID = ModuleDefinitions.ModuleDefID
where  TabID = @TabID
order by ModuleOrder


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO




create procedure GetRoleMembership
    @PortalId int,
    @RoleId   int = null,
    @UserId   int = null

as

if @RoleId is null
begin
  select UserRoles.UserRoleID,
         UserRoles.UserId,
         'FullName' = Users.FirstName + ' ' + Users.LastName,
         UserRoles.RoleId,
         Roles.RoleName,
         UserRoles.ExpiryDate
  from   UserRoles
  inner join Users On Users.UserId = UserRoles.UserId
  inner join Roles On Roles.RoleId = UserRoles.RoleId
  where  Roles.PortalId = @PortalId
  and    UserRoles.UserId = @UserId
end
else
begin
  select UserRoles.UserRoleID,
         UserRoles.UserId,
         'FullName' = Users.FirstName + ' ' + Users.LastName,
         UserRoles.RoleId,
         Roles.RoleName,
         UserRoles.ExpiryDate
  from   UserRoles
  inner join Users On Users.UserId = UserRoles.UserId
  inner join Roles On Roles.RoleId = UserRoles.RoleId
  where  Roles.PortalId = @PortalId
  and    UserRoles.RoleId = @RoleId
end



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO



create procedure dbo.GetRolesByUser
    
@UserId        int,
@PortalId      int

as

select Roles.RoleName,
       Roles.RoleID
from   UserRoles
inner join Users on UserRoles.UserID = Users.UserID
inner join Roles on UserRoles.RoleID = Roles.RoleID
where  Users.UserId = @UserId
and    Roles.PortalId = @PortalId
and    (ExpiryDate >= getdate() or ExpiryDate is null)



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO




create procedure GetServices
    
@PortalId  int,
@UserId    int = null

as

select RoleID,
       Roles.RoleName,
       Roles.Description,
       Roles.ServiceFee,
       'BillingFrequency' = C1.Description,
       Roles.TrialPeriod,
       'TrialFrequency' = C2.Description,
       'ExpiryDate' = ( select ExpiryDate from UserRoles where UserRoles.RoleId = Roles.RoleID and UserRoles.UserID = @UserID )
from   Roles
inner join CodeFrequency C1 on Roles.BillingFrequency = C1.Code
left outer join CodeFrequency C2 on Roles.TrialFrequency = C2.Code
where  Roles.PortalId = @PortalId
and    Roles.ServiceFee is not null




GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO



create procedure GetServicesByUser
    
@UserId        int,
@PortalId      int

as

select RoleID,
       Roles.RoleName,
       Roles.Description,
       Roles.ServiceFee,
       'BillingFrequency' = CodeFrequency.Description,
       'ExpiryDate' = ( select ExpiryDate from UserRoles where UserRoles.RoleId = Roles.RoleID and UserRoles.UserID = @UserID )
from   Roles
inner join CodeFrequency on Roles.BillingFrequency = CodeFrequency.Code
where  Roles.PortalId = @PortalId
and    (Roles.ServiceFee is not null and Roles.ServiceFee > 0)



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO



create procedure GetSingleBanner

@BannerId int,
@VendorId int

as

select BannerId,
       VendorId,
       ImageFile,
       BannerName,
       URL,
       Impressions,
       CPM,
       Views,
       ClickThroughs,
       StartDate,
       EndDate,
       'CreatedByUser' = Users.FirstName + ' ' + Users.LastName,
       Banners.CreatedDate,
       BannerTypeId       
from   Banners
left outer join Users on Banners.CreatedByUser = Users.UserID
where  BannerId = @BannerId
and    vendorId = @VendorId


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO



create procedure dbo.GetSingleUserRole
    
@UserId        int,
@RoleId        int,
@PortalId      int

as

select UserRoles.UserID,
       UserRoles.RoleID
from   UserRoles
inner join Roles on UserRoles.RoleID = Roles.RoleID
where  UserRoles.UserId = @UserId
and    UserRoles.RoleId = @RoleId
and    Roles.PortalId = @PortalId
and    (UserRoles.ExpiryDate >= getdate() or UserRoles.ExpiryDate is null)



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure GetSingleVendorFeedback

@VendorId  int,
@UserId    int

as

select VendorFeedbackId,
       VendorId,
       UserId,
       Date,
       Comment,
       Value
from   VendorFeedback
where  VendorId = @VendorId
and    UserId = @UserId

return 1

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure GetVendorClassifications

@VendorId  int = null

as

if @VendorId is null
begin
  select ClassificationId,
         ClassificationName,
         'IsAssociated' = 0
  from   Classification
end
else
begin
  select ClassificationId,
         ClassificationName,
         'IsAssociated' = case when exists ( select 1 from VendorClassification vc where vc.VendorId = @VendorId and vc.ClassificationId = Classification.ClassificationId ) then 1 else 0 end
  from   Classification
end

return 1

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure GetVendorFeedback

@VendorId  int 

as

select VendorFeedback.VendorFeedbackId,
       VendorFeedback.UserId,
       'FullName' = Users.FirstName + ' ' + Users.LastName,
       Users.Email,
       VendorFeedback.Date,
       VendorFeedback.Comment,
       VendorFeedback.Value
from   VendorFeedback
inner join Users on VendorFeedback.UserId = Users.UserId
where  VendorId = @VendorId
order by Date desc

return 1

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO



create procedure GetVendors

@PortalId int = null

as

if @PortalId is null
begin
  select VendorID,
         VendorName,
         Unit, 
         Street, 
         City, 
         Region, 
         Country, 
         PostalCode, 
         Telephone,
         Fax,
         Email,
         Website,
         Contact,
         ClickThroughs,
         Views,
         'Banners' = ( select count(*) from Banners where Banners.VendorId = Vendors.VendorId )
  from   Vendors
  where  PortalId is null
  order  by VendorName
end
else
begin
  select VendorID,
         VendorName,
         Unit, 
         Street, 
         City, 
         Region, 
         Country, 
         PostalCode, 
         Telephone,
         Fax,
         Email,
         Website,
         Contact,
         ClickThroughs,
         Views,
         'Banners' = ( select count(*) from Banners where Banners.VendorId = Vendors.VendorId )
  from   Vendors
  where  PortalId = @PortalId
  order  by VendorName
end

return 1


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure UpdateBanner

@BannerId     int,
@BannerName   nvarchar(100),
@ImageFile    nvarchar(50),
@URL          nvarchar(100) = null,
@Impressions  int,
@CPM          float,
@StartDate    datetime = null,
@EndDate      datetime = null,
@UserName     nvarchar(100),
@BannerTypeId int

as

update Banners
set    ImageFile     = @ImageFile,
       BannerName    = @BannerName,
       URL           = @URL,
       Impressions   = @Impressions,
       CPM           = @CPM,
       StartDate     = @StartDate,
       EndDate       = @EndDate,
       CreatedByUser = @UserName,
       CreatedDate   = getdate(),
       BannerTypeId  = @BannerTypeId
where  BannerId = @BannerId 


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure UpdateModule

@ModuleID       int,
@ModuleTitle    nvarchar(256),
@Alignment      nvarchar(10),
@Color          nvarchar(20),
@Border         nvarchar(1),
@IconFile       nvarchar(100),
@CacheTime      int,
@ViewRoles      nvarchar(256),
@EditRoles      nvarchar(256),
@ShowMobile     bit,
@TabId          int

as

update Modules
set    ModuleTitle = @ModuleTitle,
       CacheTime   = @CacheTime,
       ShowMobile  = @ShowMobile,
       AuthorizedViewRoles = @ViewRoles,
       AuthorizedEditRoles = @EditRoles,
       Alignment = @Alignment,
       Color = @Color,
       Border = @Border,
       IconFile = @IconFile,
       TabId = @TabId
where  ModuleID = @ModuleID


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure UpdateModuleDefinition

@ModuleDefID   int,
@FriendlyName  nvarchar(128),
@DesktopSrc    nvarchar(256),
@MobileSrc     nvarchar(256),
@AdminOrder    int,
@EditSrc       nvarchar(256),
@Secure        bit

as

declare @TabId int
declare @ModuleOrder int
declare @AdministratorRoleId int

update ModuleDefinitions
set    FriendlyName = @FriendlyName,
       DesktopSrc   = @DesktopSrc,
       MobileSrc    = @MobileSrc,
       AdminOrder   = @AdminOrder,
       EditSrc      = @EditSrc,
       Secure       = @Secure
where  ModuleDefID = @ModuleDefID

/* add to all Admin tabs */
if @AdminOrder is not null and @AdminOrder > 0
begin
  select @TabId = min(TabId)
  from Tabs
  where TabName = 'Admin'
  while @TabId is not null
  begin
    select @ModuleOrder = (max(ModuleOrder) + 2)
    from   Modules
    where  TabId = @TabId

    select @AdministratorRoleId = AdministratorRoleId
    from   Portals
    inner join Tabs on Portals.PortalId = Tabs.PortalId
    where TabId = @TabId

    if not exists ( select 1 from Modules where TabID = @TabId and ModuleDefID = @ModuleDefId )
    begin
      insert into Modules (
        TabID,
        ModuleDefID,
        ModuleOrder,
        PaneName,
        ModuleTitle,
        AuthorizedEditRoles,
        CacheTime,
        ShowMobile,
        AuthorizedViewRoles
      )
      values (
        @TabId,
        @ModuleDefId,
        @ModuleOrder,
        'ContentPane',
        'Sales Summary',
        convert(varchar,@AdministratorRoleId) + ';',
        0,
        0,
        ''
      )
    end

    select @TabId = min(TabId)
    from Tabs
    where TabName = 'Admin'
    and TabId > @TabId
  end
end


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure UpdateVendorFeedback

@VendorId  int,
@UserId    int,
@Comment   nvarchar(4000),
@Value     int

as

if not exists ( select 1 from VendorFeedback where VendorId = @VendorId and UserId = @UserId )
begin
  insert VendorFeedback ( 
    VendorId,
    UserId,
    Date,
    Comment,
    Value
  )
  values (
    @VendorId,
    @UserId,
    getdate(),
    @Comment,
    @Value
  )
end
else
begin
  update VendorFeedback
  set    Date = getdate(),
         Comment = @Comment,
         Value = @Value
  where  VendorId = @VendorId
  and    UserId = @UserId
end

return 1

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure AddAnnouncement

@ModuleID       int,
@UserName       nvarchar(100),
@Title          nvarchar(150),
@URL            nvarchar(150),
@Syndicate      bit,
@ExpireDate     DateTime,
@Description    nvarchar(2000)

as

insert into Announcements(
  ModuleID,
  CreatedByUser,
  CreatedDate,
  Title,
  URL,
  Syndicate,
  ExpireDate,
  Description
)

values (
  @ModuleID,
  @UserName,
  getdate(),
  @Title,
  @URL,
  @Syndicate,
  @ExpireDate,
  @Description
)


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure AddContact

@ModuleID int,
@UserName nvarchar(100),
@Name     nvarchar(50),
@Role     nvarchar(100),
@Email    nvarchar(100),
@Contact1 nvarchar(250),
@Contact2 nvarchar(250)

as

insert into Contacts (
  CreatedByUser,
  CreatedDate,
  ModuleID,
  Name,
  Role,
  Email,
  Contact1,
  Contact2
)
values (
  @UserName,
  getdate(),
  @ModuleID,
  @Name,
  @Role,
  @Email,
  @Contact1,
  @Contact2
)


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure AddDocument

@ModuleID int,
@Title            nvarchar(150),
@URL              nvarchar(250),
@UserName         nvarchar(100),
@Category         nvarchar(50),
@Syndicate        bit

as

insert into Documents
(
  ModuleID,
  Title,
  URL,
  CreatedByUser,
  CreatedDate,
  Category,
  Syndicate
)
values (
  @ModuleID,
  @Title,
  @URL,
  @UserName,
  getdate(),
  @Category,
  @Syndicate
)



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure AddLink

@ModuleID    int,
@UserName    nvarchar(100),
@Title       nvarchar(100),
@Url         nvarchar(250),
@MobileUrl   nvarchar(250),
@ViewOrder   int,
@Description nvarchar(2000),
@NewWindow   bit

as

insert into Links (
  ModuleID,
  CreatedByUser,
  CreatedDate,
  Title,
  Url,
  MobileUrl,
  ViewOrder,
  Description,
  NewWindow
)
values (
  @ModuleID,
  @UserName,
  getdate(),
  @Title,
  @Url,
  @MobileUrl,
  @ViewOrder,
  @Description,
  @NewWindow
)



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure AddMessage

@Title nvarchar(100),
@Body nvarchar(3000),
@ParentID int,
@UserName nvarchar(100),
@ModuleID int

as

declare @ParentDisplayOrder nvarchar(750)

select @ParentDisplayOrder = ''

select @ParentDisplayOrder = DisplayOrder
from   Discussion 
where  ItemID = @ParentID

insert into Discussion (
  Title,
  Body,
  DisplayOrder,
  CreatedDate, 
  CreatedByUser,
  ModuleID
)
values (
  @Title,
  @Body,
  @ParentDisplayOrder + convert(nvarchar(24),getdate(),21),
  getdate(),
  @UserName,
  @ModuleID
)


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO



create procedure AddModuleEvent

@ModuleID    int,
@Description nvarchar(2000),
@DateTime    datetime,
@Title       nvarchar(100),
@ExpireDate  datetime = null,
@UserName    nvarchar(200),
@Every       int,
@Period      char(1),
@IconFile    nvarchar(256)

as

insert ModuleEvents ( 
  ModuleID,
  Description,
  DateTime,
  Title,
  ExpireDate,
  CreatedByUser,
  CreatedDate,
  Every,
  Period,
  IconFile
)
values (
  @ModuleID,
  @Description,
  @DateTime,
  @Title,
  @ExpireDate,
  @UserName,
  getdate(),
  @Every,
  @Period,
  @IconFile
)



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure DeleteMessage

@ItemId int

as

declare @ModuleId int
declare @Start int
declare @Parent nvarchar(23)

select @ModuleId = ModuleId,
       @Start = len(DisplayOrder) - 22,
       @Parent = substring(DisplayOrder,len(DisplayOrder) - 22,23)
from   Discussion
where  ItemId = @ItemId

delete
from   Discussion
where  ModuleId = @ModuleId
and    substring(DisplayOrder, @Start,23) = @Parent


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure GetAnnouncements

@ModuleID int

as

select ItemID,
       CreatedByUser,
       CreatedDate,
       Title,
       URL,
       Syndicate,
       ExpireDate,
       Description
from   Announcements
where  ModuleID = @ModuleID
and    ExpireDate > GetDate()


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure GetContacts

@ModuleID int

as

select ItemID,
       CreatedDate,
       CreatedByUser,
       Name,
       Role,
       Email,
       Contact1,
       Contact2
from   Contacts
where  ModuleID = @ModuleID



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure GetLinks

@ModuleID int

as

select ItemID,
       CreatedByUser,
       CreatedDate,
       Title,
       Url,
       ViewOrder,
       Description,
       NewWindow
from   Links
where  ModuleID = @ModuleID
order by ViewOrder, Title


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure GetModuleEvents

@ModuleID int,
@StartDate datetime = null,
@EndDate datetime = null

as

declare @MaxWidth int

if @StartDate is null
begin
  select @MaxWidth = max(Width)
  from   ModuleEvents
  left outer join Files on ModuleEvents.IconFile = Files.FileName
  where  ModuleID = @ModuleID
  and    (ExpireDate > getdate() or ExpireDate is null)

  select ItemID,
         Description,
         DateTime,
         Title,
         ExpireDate,
         CreatedByUser,
         CreatedDate,
         IconFile,
         'MaxWidth' = @MaxWidth
  from   ModuleEvents
  where  ModuleID = @ModuleID
  and    (ExpireDate > getdate() or ExpireDate is null)
  order by DateTime
end
else
begin
  select ItemID,
         Description,
         DateTime,
         Title,
         ExpireDate,
         CreatedByUser,
         CreatedDate,
         Every,
         Period,
         IconFile
  from   ModuleEvents
  where  ModuleID = @ModuleID
  and    ( (Period is null and (DateTime >= @StartDate and DateTime <= @EndDate)) or Period is not null )
  order by DateTime
end


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure GetSingleAnnouncement

@ItemID   int,
@ModuleId int

as

select Title,
       URL,
       Syndicate,
       ExpireDate,
       Description,
       'CreatedByUser' = Users.FirstName + ' ' + Users.LastName,
       Announcements.CreatedDate
from   Announcements
left outer join Users on Announcements.CreatedByUser = Users.UserID
where  ItemID = @ItemID
and    ModuleId = @ModuleId


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure GetSingleContact

@ItemID   int,
@ModuleId int

as

select Name,
       Role,
       Contacts.Email,
       Contact1,
       Contact2,
       'CreatedByUser' = Users.FirstName + ' ' + Users.LastName,
       Contacts.CreatedDate
from   Contacts
left outer join Users on Contacts.CreatedByUser = Users.UserID
where  ItemID = @ItemID
and    ModuleId = @ModuleId


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure GetSingleDocument

@ItemID   int,
@ModuleId int

as

select Title,
       URL,
       'CreatedByUser' = Users.FirstName + ' ' + Users.LastName,
       Documents.CreatedDate,
       Category,
       Syndicate
from   Documents
left outer join Users on Documents.CreatedByUser = Users.UserID
where  ItemID = @ItemID
and    ModuleId = @ModuleId



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure GetSingleLink

@ItemID   int,
@ModuleId int

as

select Title,
       Url,
       MobileUrl,
       ViewOrder,
       Description,
       NewWindow,
       'CreatedByUser' = Users.FirstName + ' ' + Users.LastName,
       Links.CreatedDate
from   Links
left outer join Users on Links.CreatedByUser = Users.UserID
where  ItemID = @ItemID
and    ModuleId = @ModuleId


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure GetSingleMessage

@ItemID   int,
@ModuleId int

as

select ItemID,
       Title,
       'CreatedByUser' = Users.FirstName + ' ' + Users.LastName,
       Discussion.CreatedDate,
       Body,
       DisplayOrder
from   Discussion
left outer join Users on Discussion.CreatedByUser = Users.UserID
where  ItemID = @ItemID
and    ModuleId = @ModuleId


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure GetSingleModuleEvent

@ItemID   int,
@ModuleId int

as

select ItemID,
       Description,
       DateTime,
       Title,
       ExpireDate,
       'CreatedByUser' = FirstName + ' ' + LastName,
       ModuleEvents.CreatedDate,
       Every,
       Period,
       IconFile
from   ModuleEvents
left outer join Users on ModuleEvents.CreatedByUser = Users.UserId
where  ItemID = @ItemID
and    ModuleId = @ModuleId


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO



create procedure GetThreadMessages

@Parent nvarchar(750)

as

select ItemID,
       DisplayOrder,
       'Indent' = REPLICATE( '&nbsp;', ( ( LEN( DisplayOrder ) / 23 ) - 1 ) * 5 ),
       Title,  
       'CreatedByUser' = Users.FirstName + ' ' + Users.LastName,
       Discussion.CreatedDate,
       Body
from   Discussion
left outer join Users on Discussion.CreatedByUser = Users.UserID
where  LEFT(DisplayOrder, 23) = @Parent
and    (LEN( DisplayOrder ) / 23 ) > 1
order by DisplayOrder



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO



create procedure GetTopLevelMessages

@ModuleID int

as

select ItemID,
       DisplayOrder,
       'Parent' = LEFT(DisplayOrder, 23),    
       'ChildCount' = (SELECT COUNT(*) -1  FROM Discussion Disc2 WHERE LEFT(Disc2.DisplayOrder,LEN(RTRIM(Disc.DisplayOrder))) = Disc.DisplayOrder),
       Title,  
       'CreatedByUser' = Users.FirstName + ' ' + Users.LastName,
       Disc.CreatedDate
from   Discussion Disc
left outer join Users on Disc.CreatedByUser = Users.UserID
where  ModuleID = @ModuleID
and    (LEN( DisplayOrder ) / 23 ) = 1
order by DisplayOrder



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure UpdateAnnouncement

@ItemID         int,
@UserName       nvarchar(100),
@Title          nvarchar(150),
@URL            nvarchar(150),
@Syndicate      bit,
@ExpireDate     datetime,
@Description    nvarchar(2000)

as

update Announcements
set    CreatedByUser   = @UserName,
       CreatedDate     = GetDate(),
       Title           = @Title,
       URL             = @URL,
       Syndicate       = @Syndicate,
       ExpireDate      = @ExpireDate,
       Description     = @Description
where  ItemID = @ItemID


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure UpdateDocument

@ItemID           int,
@Title            nvarchar(150),
@URL              nvarchar(250),
@UserName         nvarchar(100),
@Category         nvarchar(50),
@Syndicate        bit

as

update Documents
set    Title             = @Title,
       URL               = @URL,
       CreatedByUser     = @UserName,
       CreatedDate       = getdate(),
       Category          = @Category,
       Syndicate         = @Syndicate
where  ItemID = @ItemID


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure UpdateLink
  
@ItemID      int,
@UserName    nvarchar(100),
@Title       nvarchar(100),
@Url         nvarchar(250),
@MobileUrl   nvarchar(250),
@ViewOrder   int,
@Description nvarchar(2000),
@NewWindow   bit

as

update Links
set    CreatedByUser = @UserName,
       CreatedDate   = GetDate(),
       Title         = @Title,
       Url           = @Url,
       MobileUrl     = @MobileUrl,
       ViewOrder     = @ViewOrder,
       Description   = @Description,
       NewWindow     = @NewWindow
where  ItemID = @ItemID


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure UpdateMessage

@ItemID     int,
@Title      nvarchar(100),
@Body       nvarchar(3000),
@UserName   nvarchar(100)

as

update Discussion
set    Title             = @Title,
       Body              = @Body,
       CreatedByUser     = @UserName,
       CreatedDate       = getdate()
where  ItemID = @ItemID


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


create procedure UpdateModuleEvent

@ItemId      int,
@Description nvarchar(2000),
@DateTime    datetime,
@Title       nvarchar(100),
@ExpireDate  datetime = null,
@UserName    nvarchar(200),
@Every       int,
@Period      char(1),
@IconFile    nvarchar(256)

as

update ModuleEvents
set    Description = @Description,
       DateTime = @DateTime,
       Title = @Title,
       ExpireDate = @ExpireDate,
       CreatedByUser = @UserName,
       CreatedDate = getdate(),
       Every = @Every,
       Period = @Period,
       IconFile = @IconFile
where  ItemId = @ItemId


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

create procedure GetDocuments

@ModuleID int,
@PortalId int

as

select ItemID,
       Title,
       URL,
       'CreatedByUser' = Users.FirstName + ' ' + Users.LastName,
       Documents.CreatedDate,
       Category,
       Size,
       Syndicate
from   Documents
left outer join Users on Documents.CreatedByUser = Users.UserID
left outer join Files on Documents.URL = Files.FileName and Files.PortalId = @PortalId
where  ModuleID = @ModuleID

GO

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


/************************************************************/
/*****              Initialize Data                     *****/
/************************************************************/


/* Insert scripts for table: [dbo].[BannerTypes] */
PRINT 'Inserting rows into table: [dbo].[BannerTypes]'

SET IDENTITY_INSERT [dbo].[BannerTypes] ON

INSERT INTO [dbo].[BannerTypes] ([BannerTypeId], [BannerTypeName]) VALUES (1, 'Banner')
GO
INSERT INTO [dbo].[BannerTypes] ([BannerTypeId], [BannerTypeName]) VALUES (2, 'Button ( Small )')
GO
INSERT INTO [dbo].[BannerTypes] ([BannerTypeId], [BannerTypeName]) VALUES (3, 'Button ( Medium )')
GO
INSERT INTO [dbo].[BannerTypes] ([BannerTypeId], [BannerTypeName]) VALUES (4, 'Button ( Large )')
GO
INSERT INTO [dbo].[BannerTypes] ([BannerTypeId], [BannerTypeName]) VALUES (5, 'Skyscraper')
GO

SET IDENTITY_INSERT [dbo].[BannerTypes] OFF


/* Insert scripts for table: [dbo].[CodeCountry] */
PRINT 'Inserting rows into table: [dbo].[CodeCountry]'

INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('AD', 'Andorra')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('AE', 'United Arab Emirates')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('AF', 'Afghanistan')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('AG', 'Antigua and Barbuda')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('AI', 'Anguilla')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('AL', 'Albania')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('AM', 'Armenia')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('AN', 'Netherlands Antilles')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('AO', 'Angola')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('AQ', 'Antarctica')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('AR', 'Argentina')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('AS', 'American Samoa')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('AT', 'Austria')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('AU', 'Australia')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('AW', 'Aruba')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('AZ', 'Azerbaijan')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('BA', 'Bosnia and Herzegovina')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('BB', 'Barbados')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('BD', 'Bangladesh')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('BE', 'Belgium')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('BF', 'Burkina Faso')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('BG', 'Bulgaria')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('BH', 'Bahrain')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('BI', 'Burundi')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('BJ', 'Benin')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('BM', 'Bermuda')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('BN', 'Brunei Darussalam')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('BO', 'Bolivia')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('BR', 'Brazil')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('BS', 'Bahamas')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('BT', 'Bhutan')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('BV', 'Bouvet Island')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('BW', 'Botswana')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('BY', 'Belarus')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('BZ', 'Belize')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('CA', 'Canada')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('CC', 'Cocos')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('CF', 'Central African Republic')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('CG', 'Congo')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('CH', 'Switzerland')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('CI', 'Ivory Coast')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('CK', 'Cook Islands')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('CL', 'Chile')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('CM', 'Cameroon')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('CN', 'China')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('CO', 'Colombia')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('CR', 'Costa Rica')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('CU', 'Cuba')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('CV', 'Cape Verde')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('CX', 'Christmas Island')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('CY', 'Cyprus')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('CZ', 'Czech Republic')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('DE', 'Germany')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('DJ', 'Djibouti')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('DK', 'Denmark')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('DM', 'Dominica')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('DO', 'Dominican Republic')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('DZ', 'Algeria')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('EC', 'Ecuador')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('EE', 'Estonia')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('EG', 'Egypt')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('EH', 'Western Sahara')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('ER', 'Eritrea')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('ES', 'Spain')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('ET', 'Ethiopia')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('FI', 'Finland')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('FJ', 'Fiji')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('FK', 'Falkland Islands')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('FM', 'Micronesia')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('FO', 'Faroe Islands')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('FR', 'France')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('GA', 'Gabon')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('GD', 'Grenada')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('GE', 'Georgia')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('GF', 'French Guiana')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('GH', 'Ghana')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('GI', 'Gibraltar')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('GL', 'Greenland')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('GM', 'Gambia')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('GN', 'Guinea')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('GP', 'Guadeloupe')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('GQ', 'Equatorial Guinea')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('GR', 'Greece')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('GS', 'S. Georgia and S. Sandwich Islands')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('GT', 'Guatemala')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('GU', 'Guam')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('GW', 'Guinea-Bissau')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('GY', 'Guyana')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('HK', 'Hong Kong')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('HM', 'Heard and McDonald Islands')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('HN', 'Honduras')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('HR', 'Croatia')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('HT', 'Haiti')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('HU', 'Hungary')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('ID', 'Indonesia')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('IE', 'Ireland')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('IL', 'Israel')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('IN', 'India')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('IO', 'British Indian Ocean Territory')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('IQ', 'Iraq')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('IR', 'Iran')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('IS', 'Iceland')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('IT', 'Italy')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('JM', 'Jamaica')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('JO', 'Jordan')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('JP', 'Japan')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('KE', 'Kenya')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('KG', 'Kyrgyzstan')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('KH', 'Cambodia')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('KI', 'Kiribati')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('KM', 'Comoros')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('KN', 'Saint Kitts and Nevis')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('KP', 'North Korea')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('KR', 'South Korea')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('KW', 'Kuwait')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('KY', 'Cayman Islands')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('KZ', 'Kazakhstan')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('LA', 'Laos')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('LB', 'Lebanon')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('LC', 'Saint Lucia')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('LI', 'Liechtenstein')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('LK', 'Sri Lanka')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('LR', 'Liberia')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('LS', 'Lesotho')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('LT', 'Lithuania')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('LU', 'Luxembourg')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('LV', 'Latvia')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('LY', 'Libya')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('MA', 'Morocco')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('MC', 'Monaco')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('MD', 'Moldova')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('MG', 'Madagascar')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('MH', 'Marshall Islands')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('MK', 'Macedonia')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('ML', 'Mali')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('MM', 'Myanmar')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('MN', 'Mongolia')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('MO', 'Macau')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('MP', 'Northern Mariana Islands')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('MQ', 'Martinique')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('MR', 'Mauritania')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('MS', 'Montserrat')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('MT', 'Malta')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('MU', 'Mauritius')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('MV', 'Maldives')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('MW', 'Malawi')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('MX', 'Mexico')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('MY', 'Malaysia')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('MZ', 'Mozambique')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('NA', 'Namibia')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('NC', 'New Caledonia')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('NE', 'Niger')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('NF', 'Norfolk Island')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('NG', 'Nigeria')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('NI', 'Nicaragua')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('NL', 'Netherlands')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('NO', 'Norway')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('NP', 'Nepal')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('NR', 'Nauru')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('NU', 'Niue')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('NZ', 'New Zealand')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('OM', 'Oman')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('PA', 'Panama')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('PE', 'Peru')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('PF', 'French Polynesia')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('PG', 'Papua New Guinea')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('PH', 'Philippines')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('PK', 'Pakistan')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('PL', 'Poland')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('PM', 'St. Pierre and Miquelon')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('PN', 'Pitcairn')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('PR', 'Puerto Rico')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('PT', 'Portugal')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('PW', 'Palau')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('PY', 'Paraguay')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('QA', 'Qatar')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('RE', 'Reunion')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('RO', 'Romania')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('RU', 'Russian Federation')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('RW', 'Rwanda')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('SA', 'Saudi Arabia')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('SB', 'Solomon Islands')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('SC', 'Seychelles')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('SD', 'Sudan')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('SE', 'Sweden')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('SG', 'Singapore')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('SH', 'St. Helena')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('SI', 'Slovenia')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('SJ', 'Svalbard and Jan Mayen Islands')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('SK', 'Slovakia')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('SL', 'Sierra Leone')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('SM', 'San Marino')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('SN', 'Senegal')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('SO', 'Somalia')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('SR', 'Suriname')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('ST', 'Sao Tome and Principe')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('SU', 'Soviet Union')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('SV', 'El Salvador')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('SY', 'Syria')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('SZ', 'Swaziland')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('TC', 'Turks and Caicos Islands')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('TD', 'Chad')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('TF', 'French Southern Territories')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('TG', 'Togo')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('TH', 'Thailand')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('TJ', 'Tajikistan')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('TK', 'Tokelau')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('TM', 'Turkmenistan')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('TN', 'Tunisia')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('TO', 'Tonga')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('TP', 'East Timor')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('TR', 'Turkey')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('TT', 'Trinidad and Tobago')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('TV', 'Tuvalu')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('TW', 'Taiwan')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('TZ', 'Tanzania')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('UA', 'Ukraine')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('UG', 'Uganda')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('UK', 'United Kingdom')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('UM', 'US Minor Outlying Islands')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('US', 'United States')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('UY', 'Uruguay')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('UZ', 'Uzbekistan')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('VC', 'Saint Vincent and The Grenadines')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('VE', 'Venezuela')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('VG', 'British Virgin Islands')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('VI', 'US Virgin Islands')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('VN', 'Viet Nam')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('VU', 'Vanuatu')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('WF', 'Wallis and Futuna Islands')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('WS', 'Samoa')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('YE', 'Yemen')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('YT', 'Mayotte')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('YU', 'Yugoslavia')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('ZA', 'South Africa')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('ZM', 'Zambia')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('ZR', 'Zaire')
GO
INSERT INTO [dbo].[CodeCountry] ([Code], [Description]) VALUES ('ZW', 'Zimbabwe')
GO

/* Insert scripts for table: [dbo].[CodeCurrency] */
PRINT 'Inserting rows into table: [dbo].[CodeCurrency]'

INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('ARS', 'ARS Argentina Pesos')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('ATS', 'ATS Austria Schillings')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('AUD', 'AUD Australia Dollars')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('BBD', 'BBD Barbados Dollars')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('BEF', 'BEF Belgium Francs')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('BGL', 'BGL Bulgaria Leva')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('BMD', 'BMD Bermuda Dollars')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('BRL', 'BRL Brazil Real')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('BSD', 'BSD Bahamas Dollars')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('CAD', 'CAD Canada Dollars')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('CHF', 'CHF Switzerland Francs')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('CLP', 'CLP Chile Pesos')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('CNY', 'CNY China Yuan Renminbi')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('CYP', 'CYP Cyprus Pounds')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('CZK', 'CZK Czech Republic Koruny')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('DEM', 'DEM Germany Deutsche Marks')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('DKK', 'DKK Denmark Kroner')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('DZD', 'DZD Algeria Dinars')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('EGP', 'EGP Egypt Pounds')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('ESP', 'ESP Spain Pesetas')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('EUR', 'EUR Euro')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('FIM', 'FIM Finland Markkaa')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('FJD', 'FJD Fiji Dollars')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('FRF', 'FRF France Francs')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('GBP', 'GBP United Kingdom Pounds')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('GRD', 'GRD Greece Drachmae')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('HKD', 'HKD Hong Kong Dollars')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('HUF', 'HUF Hungary Forint')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('IDR', 'IDR Indonesia Rupiahs')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('IEP', 'IEP Ireland Pounds')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('ILS', 'ILS Israel New Shekels')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('INR', 'INR India Rupees')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('ISK', 'ISK Iceland Kronur')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('ITL', 'ITL Italy Lire')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('JMD', 'JMD Jamaica Dollars')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('JOD', 'JOD Jordan Dinars')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('JPY', 'JPY Japan Yen')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('KRW', 'KRW Korea (South) Won')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('LBP', 'LBP Lebanon Pounds')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('LUF', 'LUF Luxembourg Francs')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('MXN', 'MXN Mexico Pesos')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('MYR', 'MYR Malaysia Ringgits')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('NLG', 'NLG Netherlands Guilders')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('NOK', 'NOK Norway Kroner')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('NZD', 'NZD New Zealand Dollars')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('PHP', 'PHP Philippines Pesos')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('PKR', 'PKR Pakistan Rupees')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('PLN', 'PLN Poland Zlotych')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('PTE', 'PTE Portugal Escudos')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('ROL', 'ROL Romania Lei')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('RUR', 'RUR Russia Rubles')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('SAR', 'SAR Saudi Arabia Riyals')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('SDD', 'SDD Sudan Dinars')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('SEK', 'SEK Sweden Kronor')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('SGD', 'SGD Singapore Dollars')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('SKK', 'SKK Slovakia Koruny')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('THB', 'THB Thailand Baht')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('TRL', 'TRL Turkey Liras')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('TTD', 'TTD Trinidad and Tobago Dollars')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('TWD', 'TWD Taiwan New Dollars')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('USD', 'USD United States Dollars')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('VEB', 'VEB Venezuela Bolivares')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('XAG', 'XAG Silver Ounces')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('XAU', 'XAU Gold Ounces')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('XCD', 'XCD Eastern Caribbean Dollars')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('XDR', 'XDR Special Drawing Rights (IMF)')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('XPD', 'XPD Palladium Ounces')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('XPT', 'XPT Platinum Ounces')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('ZAR', 'ZAR South Africa Rand')
GO
INSERT INTO [dbo].[CodeCurrency] ([Code], [Description]) VALUES ('ZMK', 'ZMK Zambia Kwacha')
GO

/* Insert scripts for table: [dbo].[CodeFrequency] */
PRINT 'Inserting rows into table: [dbo].[CodeFrequency]'

INSERT INTO [dbo].[CodeFrequency] ([Code], [Description]) VALUES ('0', 'None')
GO
INSERT INTO [dbo].[CodeFrequency] ([Code], [Description]) VALUES ('1', 'One-time Fee')
GO
INSERT INTO [dbo].[CodeFrequency] ([Code], [Description]) VALUES ('2', 'Day')
GO
INSERT INTO [dbo].[CodeFrequency] ([Code], [Description]) VALUES ('3', 'Week')
GO
INSERT INTO [dbo].[CodeFrequency] ([Code], [Description]) VALUES ('4', 'Month')
GO
INSERT INTO [dbo].[CodeFrequency] ([Code], [Description]) VALUES ('5', 'Year')
GO

/* Insert scripts for table: [dbo].[CodeRegion] */
PRINT 'Inserting rows into table: [dbo].[CodeRegion]'

INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('AL', 'Alabama', 'US')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('AK', 'Alaska', 'US')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('AZ', 'Arizona', 'US')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('AR', 'Arkansas', 'US')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('CA', 'California', 'US')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('CO', 'Colorado', 'US')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('CT', 'Connecticut', 'US')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('DE', 'Delaware', 'US')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('DC', 'District of Columbia', 'US')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('FL', 'Florida', 'US')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('GA', 'Georgia', 'US')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('HI', 'Hawaii', 'US')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('ID', 'Idaho', 'US')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('IL', 'Illinois', 'US')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('IN', 'Indiana', 'US')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('IA', 'Iowa', 'US')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('KS', 'Kansas', 'US')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('KY', 'Kentucky', 'US')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('LA', 'Louisiana', 'US')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('ME', 'Maine', 'US')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('MD', 'Maryland', 'US')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('MA', 'Massachusetts', 'US')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('MI', 'Michigan', 'US')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('MN', 'Minnesota', 'US')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('MS', 'Mississippi', 'US')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('MO', 'Missouri', 'US')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('MT', 'Montana', 'US')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('NE', 'Nebraska', 'US')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('NV', 'Nevada', 'US')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('NH', 'New Hampshire', 'US')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('NJ', 'New Jersey', 'US')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('NM', 'New Mexico', 'US')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('NY', 'New York', 'US')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('NC', 'North Carolina', 'US')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('ND', 'North Dakota', 'US')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('OH', 'Ohio', 'US')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('OK', 'Oklahoma', 'US')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('OR', 'Oregon', 'US')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('PA', 'Pennsylvania', 'US')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('RI', 'Rhode Island', 'US')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('SC', 'South Carolina', 'US')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('SD', 'South Dakota', 'US')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('TN', 'Tennessee', 'US')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('TX', 'Texas', 'US')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('UT', 'Utah', 'US')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('VT', 'Vermont', 'US')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('VA', 'Virginia', 'US')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('WA', 'Washington', 'US')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('WV', 'West Virginia', 'US')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('WI', 'Wisconsin', 'US')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('WY', 'Wyoming', 'US')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('AB', 'Alberta', 'CA')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('BC', 'British Columbia', 'CA')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('MB', 'Manitoba', 'CA')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('NB', 'New Brunswick', 'CA')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('NF', 'Newfoundland', 'CA')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('NT', 'Northwest Territories', 'CA')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('NS', 'Nova Scotia', 'CA')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('ON', 'Ontario', 'CA')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('PE', 'Prince Edward Island', 'CA')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('QC', 'Quebec', 'CA')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('SK', 'Saskatchewan', 'CA')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('YT', 'Yukon Territory', 'CA')
GO
INSERT INTO [dbo].[CodeRegion] ([Code], [Description], [Country]) VALUES ('NV', 'Nunavut', 'CA')
GO


/* Insert scripts for table: [dbo].[ModuleDefinitions] */
PRINT 'Inserting rows into table: [dbo].[ModuleDefinitions]'

SET IDENTITY_INSERT [dbo].[ModuleDefinitions] ON

INSERT INTO [dbo].[ModuleDefinitions] ([ModuleDefID], [FriendlyName], [DesktopSrc], [MobileSrc], [AdminOrder], [EditSrc], [Secure]) VALUES (1, 'Announcements', 'DesktopModules/Announcements/Announcements.ascx', 'MobileModules/Announcements.ascx', NULL, 'DesktopModules/Announcements/EditAnnouncements.ascx', 1)
GO
INSERT INTO [dbo].[ModuleDefinitions] ([ModuleDefID], [FriendlyName], [DesktopSrc], [MobileSrc], [AdminOrder], [EditSrc], [Secure]) VALUES (2, 'Contacts', 'DesktopModules/Contacts/Contacts.ascx', 'MobileModules/Contacts.ascx', NULL, 'DesktopModules/Contacts/EditContacts.ascx', 1)
GO
INSERT INTO [dbo].[ModuleDefinitions] ([ModuleDefID], [FriendlyName], [DesktopSrc], [MobileSrc], [AdminOrder], [EditSrc], [Secure]) VALUES (3, 'Discussions', 'DesktopModules/Discussions/Discussion.ascx', '', NULL, 'DesktopModules/Discussions/DiscussDetails.ascx', 0)
GO
INSERT INTO [dbo].[ModuleDefinitions] ([ModuleDefID], [FriendlyName], [DesktopSrc], [MobileSrc], [AdminOrder], [EditSrc], [Secure]) VALUES (4, 'Events', 'DesktopModules/Events/Events.ascx', 'MobileModules/Events.ascx', NULL, 'DesktopModules/Events/EditEvents.ascx', 1)
GO
INSERT INTO [dbo].[ModuleDefinitions] ([ModuleDefID], [FriendlyName], [DesktopSrc], [MobileSrc], [AdminOrder], [EditSrc], [Secure]) VALUES (5, 'HTML', 'DesktopModules/HTML/HtmlModule.ascx', 'MobileModules/Text.ascx', NULL, 'DesktopModules/HTML/EditHTML.ascx', 1)
GO
INSERT INTO [dbo].[ModuleDefinitions] ([ModuleDefID], [FriendlyName], [DesktopSrc], [MobileSrc], [AdminOrder], [EditSrc], [Secure]) VALUES (6, 'Image', 'DesktopModules/Images/ImageModule.ascx', '', NULL, 'DesktopModules/Images/EditImage.ascx', 1)
GO
INSERT INTO [dbo].[ModuleDefinitions] ([ModuleDefID], [FriendlyName], [DesktopSrc], [MobileSrc], [AdminOrder], [EditSrc], [Secure]) VALUES (7, 'Links', 'DesktopModules/Links/Links.ascx', 'MobileModules/Links.ascx', NULL, 'DesktopModules/Links/EditLinks.ascx', 1)
GO
INSERT INTO [dbo].[ModuleDefinitions] ([ModuleDefID], [FriendlyName], [DesktopSrc], [MobileSrc], [AdminOrder], [EditSrc], [Secure]) VALUES (9, 'XML/XSL', 'DesktopModules/XML/XmlModule.ascx', '', NULL, 'DesktopModules/XML/EditXml.ascx', 1)
GO
INSERT INTO [dbo].[ModuleDefinitions] ([ModuleDefID], [FriendlyName], [DesktopSrc], [MobileSrc], [AdminOrder], [EditSrc], [Secure]) VALUES (10, 'Documents', 'DesktopModules/Documents/Document.ascx', '', NULL, 'DesktopModules/Documents/EditDocs.ascx', 1)
GO
INSERT INTO [dbo].[ModuleDefinitions] ([ModuleDefID], [FriendlyName], [DesktopSrc], [MobileSrc], [AdminOrder], [EditSrc], [Secure]) VALUES (12, 'Security Roles', 'Admin/Users/Roles.ascx', '', 4, 'Admin/Users/EditRoles.ascx', 1)
GO
INSERT INTO [dbo].[ModuleDefinitions] ([ModuleDefID], [FriendlyName], [DesktopSrc], [MobileSrc], [AdminOrder], [EditSrc], [Secure]) VALUES (13, 'Tabs', 'Admin/Tabs/Tabs.ascx', '', 3, 'Admin/Tabs/ManageTabs.ascx', 1)
GO
INSERT INTO [dbo].[ModuleDefinitions] ([ModuleDefID], [FriendlyName], [DesktopSrc], [MobileSrc], [AdminOrder], [EditSrc], [Secure]) VALUES (14, 'Site Settings', 'Admin/Portal/SiteSettings.ascx', '', 2, '', 1)
GO
INSERT INTO [dbo].[ModuleDefinitions] ([ModuleDefID], [FriendlyName], [DesktopSrc], [MobileSrc], [AdminOrder], [EditSrc], [Secure]) VALUES (15, 'Manage Users', 'Admin/Users/Users.ascx', '', 5, 'Admin/Users/ManageUsers.ascx', 1)
GO
INSERT INTO [dbo].[ModuleDefinitions] ([ModuleDefID], [FriendlyName], [DesktopSrc], [MobileSrc], [AdminOrder], [EditSrc], [Secure]) VALUES (19, 'Vendors', 'Admin/Vendors/Vendors.ascx', '', 7, 'Admin/Vendors/EditVendors.ascx', 1)
GO
INSERT INTO [dbo].[ModuleDefinitions] ([ModuleDefID], [FriendlyName], [DesktopSrc], [MobileSrc], [AdminOrder], [EditSrc], [Secure]) VALUES (20, 'Banners', 'DesktopModules/Banners/Banners.ascx', '', NULL, 'DesktopModules/Banners/EditBanners.ascx', 1)
GO
INSERT INTO [dbo].[ModuleDefinitions] ([ModuleDefID], [FriendlyName], [DesktopSrc], [MobileSrc], [AdminOrder], [EditSrc], [Secure]) VALUES (21, 'File Manager', 'Admin/Files/FileManager.ascx', '', 6, 'Admin/Files/WebUpload.ascx', 1)
GO
INSERT INTO [dbo].[ModuleDefinitions] ([ModuleDefID], [FriendlyName], [DesktopSrc], [MobileSrc], [AdminOrder], [EditSrc], [Secure]) VALUES (22, 'FAQs', 'DesktopModules/FAQs/FAQs.ascx', '', NULL, 'DesktopModules/FAQs/EditFAQs.ascx', 1)
GO
INSERT INTO [dbo].[ModuleDefinitions] ([ModuleDefID], [FriendlyName], [DesktopSrc], [MobileSrc], [AdminOrder], [EditSrc], [Secure]) VALUES (27, 'Site Log', 'Admin/Log/SiteLog.ascx', '', 8, 'Admin/Log/ViewSiteLog.ascx', 1)
GO
INSERT INTO [dbo].[ModuleDefinitions] ([ModuleDefID], [FriendlyName], [DesktopSrc], [MobileSrc], [AdminOrder], [EditSrc], [Secure]) VALUES (28, 'Bulk Email', 'Admin/Users/BulkEmail.ascx', '', 9, NULL, 1)
GO
INSERT INTO [dbo].[ModuleDefinitions] ([ModuleDefID], [FriendlyName], [DesktopSrc], [MobileSrc], [AdminOrder], [EditSrc], [Secure]) VALUES (39, 'Business Directory', 'DesktopModules/Vendors/Directory.ascx', '', NULL, 'DesktopModules/Vendors/EditDirectory.ascx', 1)
GO
INSERT INTO [dbo].[ModuleDefinitions] ([ModuleDefID], [FriendlyName], [DesktopSrc], [MobileSrc], [AdminOrder], [EditSrc], [Secure]) VALUES (44, 'News Feeds (RSS)', 'DesktopModules/News/RssModule.ascx', '', NULL, 'DesktopModules/News/EditRss.ascx', 1)
GO
INSERT INTO [dbo].[ModuleDefinitions] ([ModuleDefID], [FriendlyName], [DesktopSrc], [MobileSrc], [AdminOrder], [EditSrc], [Secure]) VALUES (45, 'Vendor Feedback', NULL, NULL, NULL, 'DesktopModules/Vendors/VendorFeedback.ascx', 0)
GO
INSERT INTO [dbo].[ModuleDefinitions] ([ModuleDefID], [FriendlyName], [DesktopSrc], [MobileSrc], [AdminOrder], [EditSrc], [Secure]) VALUES (48, 'Help', NULL, NULL, NULL, 'Admin/Portal/help.ascx', 0)
GO
INSERT INTO [dbo].[ModuleDefinitions] ([ModuleDefID], [FriendlyName], [DesktopSrc], [MobileSrc], [AdminOrder], [EditSrc], [Secure]) VALUES (49, 'Banner', NULL, NULL, NULL, 'Admin/Vendors/EditBanner.ascx', 1)
GO
INSERT INTO [dbo].[ModuleDefinitions] ([ModuleDefID], [FriendlyName], [DesktopSrc], [MobileSrc], [AdminOrder], [EditSrc], [Secure]) VALUES (50, 'User Roles', NULL, NULL, NULL, 'Admin/Users/SecurityRoles.ascx', 1)
GO
INSERT INTO [dbo].[ModuleDefinitions] ([ModuleDefID], [FriendlyName], [DesktopSrc], [MobileSrc], [AdminOrder], [EditSrc], [Secure]) VALUES (51, 'Module', NULL, NULL, NULL, 'Admin/Tabs/ModuleSettings.ascx', 1)
GO
INSERT INTO [dbo].[ModuleDefinitions] ([ModuleDefID], [FriendlyName], [DesktopSrc], [MobileSrc], [AdminOrder], [EditSrc], [Secure]) VALUES (52, 'Access Denied', NULL, NULL, NULL, 'Admin/Security/AccessDenied.ascx', 0)
GO
INSERT INTO [dbo].[ModuleDefinitions] ([ModuleDefID], [FriendlyName], [DesktopSrc], [MobileSrc], [AdminOrder], [EditSrc], [Secure]) VALUES (53, 'Edit Access Denied', NULL, NULL, NULL, 'Admin/Security/EditAccessDenied.ascx', 0)
GO
INSERT INTO [dbo].[ModuleDefinitions] ([ModuleDefID], [FriendlyName], [DesktopSrc], [MobileSrc], [AdminOrder], [EditSrc], [Secure]) VALUES (54, 'Register', NULL, NULL, NULL, 'Admin/Users/Register.ascx', 0)
GO
INSERT INTO [dbo].[ModuleDefinitions] ([ModuleDefID], [FriendlyName], [DesktopSrc], [MobileSrc], [AdminOrder], [EditSrc], [Secure]) VALUES (55, 'Module Definition', NULL, NULL, NULL, 'Admin/Portal/ModuleDefinitions.ascx', 1)
GO
INSERT INTO [dbo].[ModuleDefinitions] ([ModuleDefID], [FriendlyName], [DesktopSrc], [MobileSrc], [AdminOrder], [EditSrc], [Secure]) VALUES (56, 'Purchase', NULL, NULL, NULL, 'Admin/Sales/Purchase.ascx', 0)
GO
INSERT INTO [dbo].[ModuleDefinitions] ([ModuleDefID], [FriendlyName], [DesktopSrc], [MobileSrc], [AdminOrder], [EditSrc], [Secure]) VALUES (57, 'Privacy', NULL, NULL, NULL, 'Admin/Portal/Privacy.ascx', 0)
GO
INSERT INTO [dbo].[ModuleDefinitions] ([ModuleDefID], [FriendlyName], [DesktopSrc], [MobileSrc], [AdminOrder], [EditSrc], [Secure]) VALUES (58, 'Terms', NULL, NULL, NULL, 'Admin/Portal/Terms.ascx', 0)
GO
INSERT INTO [dbo].[ModuleDefinitions] ([ModuleDefID], [FriendlyName], [DesktopSrc], [MobileSrc], [AdminOrder], [EditSrc], [Secure]) VALUES (61, 'Signup', NULL, NULL, NULL, 'Admin/Portal/Signup.ascx', 0)
GO
INSERT INTO [dbo].[ModuleDefinitions] ([ModuleDefID], [FriendlyName], [DesktopSrc], [MobileSrc], [AdminOrder], [EditSrc], [Secure]) VALUES (63, 'Portals', 'Admin/Portal/Portals.ascx', NULL, -1, 'Admin/Portal/SiteSettings.ascx', 1)
GO
INSERT INTO [dbo].[ModuleDefinitions] ([ModuleDefID], [FriendlyName], [DesktopSrc], [MobileSrc], [AdminOrder], [EditSrc], [Secure]) VALUES (64, 'Module Definitions', 'Admin/Portal/ModuleDefs.ascx', NULL, -1, 'Admin/Portal/ModuleDefinitions.ascx', 1)
GO
INSERT INTO [dbo].[ModuleDefinitions] ([ModuleDefID], [FriendlyName], [DesktopSrc], [MobileSrc], [AdminOrder], [EditSrc], [Secure]) VALUES (65, 'SQL', 'Admin/Portal/SQL.ascx', NULL, -1, '', 1)
GO
INSERT INTO [dbo].[ModuleDefinitions] ([ModuleDefID], [FriendlyName], [DesktopSrc], [MobileSrc], [AdminOrder], [EditSrc], [Secure]) VALUES (66, 'IFrame', 'DesktopModules/IFrame/IFrame.ascx', '', NULL, 'DesktopModules/IFrame/EditIFrame.ascx', 1)
GO

SET IDENTITY_INSERT [dbo].[ModuleDefinitions] OFF


/* Insert scripts for table: [dbo].[Portals] */
PRINT 'Inserting rows into table: [dbo].[Portals]'

SET IDENTITY_INSERT [dbo].[Portals] ON

INSERT INTO [dbo].[Portals] ([PortalID], [PortalAlias], [PortalName], [UploadDirectory], [LogoFile], [FooterText], [ExpiryDate], [UserRegistration], [BannerAdvertising], [AdministratorId], [PayPalId], [Currency], [HostFee], [HostSpace], [AdministratorRoleId], [RegisteredRoleId], [GUID]) VALUES (0, '.default', 'DotNetNuke', '/DotNetNuke/0/', 'logo.gif', 'Copyright 2002-2003 DotNetNuke', NULL, 2, 0, 9, '', 'USD', '', 5, 0, 11, '57ad7180-c5e7-49f5-b282-c6475cdb7ee7')
GO

SET IDENTITY_INSERT [dbo].[Portals] OFF


/* Insert scripts for table: [dbo].[Tabs] */
PRINT 'Inserting rows into table: [dbo].[Tabs]'

SET IDENTITY_INSERT [dbo].[Tabs] ON

INSERT INTO [dbo].[Tabs] ([TabID], [TabOrder], [PortalID], [TabName], [MobileTabName], [AuthorizedRoles], [ShowMobile], [LeftPaneWidth], [RightPaneWidth], [IsVisible]) VALUES (1, 1, 0, 'Home', 'Home', '-1;', 1, '200', '200', 1)
GO
INSERT INTO [dbo].[Tabs] ([TabID], [TabOrder], [PortalID], [TabName], [MobileTabName], [AuthorizedRoles], [ShowMobile], [LeftPaneWidth], [RightPaneWidth], [IsVisible]) VALUES (6, 23, 0, 'Admin', 'Admin', '0;', 0, '200', '200', 1)
GO
INSERT INTO [dbo].[Tabs] ([TabID], [TabOrder], [PortalID], [TabName], [MobileTabName], [AuthorizedRoles], [ShowMobile], [LeftPaneWidth], [RightPaneWidth], [IsVisible]) VALUES (7, 1, NULL, 'Super User', '', '-2;', 0, '200', '200', 1)
GO

SET IDENTITY_INSERT [dbo].[Tabs] OFF


/* Insert scripts for table: [dbo].[Modules] */
PRINT 'Inserting rows into table: [dbo].[Modules]'

SET IDENTITY_INSERT [dbo].[Modules] ON

INSERT INTO [dbo].[Modules] ([ModuleID], [TabID], [ModuleDefID], [ModuleOrder], [PaneName], [ModuleTitle], [AuthorizedEditRoles], [CacheTime], [ShowMobile], [AuthorizedViewRoles], [Alignment], [Color], [Border], [IconFile]) VALUES (2, 1, 5, 1, 'ContentPane', 'Welcome to DotNetNuke...', '0;', 0, 1, '', 'left', '', '', NULL)
GO
INSERT INTO [dbo].[Modules] ([ModuleID], [TabID], [ModuleDefID], [ModuleOrder], [PaneName], [ModuleTitle], [AuthorizedEditRoles], [CacheTime], [ShowMobile], [AuthorizedViewRoles], [Alignment], [Color], [Border], [IconFile]) VALUES (3, 1, 7, 1, 'LeftPane', 'Links', '0;', 0, 1, '', 'left', '', '', NULL)
GO
INSERT INTO [dbo].[Modules] ([ModuleID], [TabID], [ModuleDefID], [ModuleOrder], [PaneName], [ModuleTitle], [AuthorizedEditRoles], [CacheTime], [ShowMobile], [AuthorizedViewRoles], [Alignment], [Color], [Border], [IconFile]) VALUES (4, 1, 5, 1, 'RightPane', 'Sponsors', '0;', 0, 1, '', 'center', '', '', NULL)
GO
INSERT INTO [dbo].[Modules] ([ModuleID], [TabID], [ModuleDefID], [ModuleOrder], [PaneName], [ModuleTitle], [AuthorizedEditRoles], [CacheTime], [ShowMobile], [AuthorizedViewRoles], [Alignment], [Color], [Border], [IconFile]) VALUES (29, 6, 14, 1, 'ContentPane', 'Site Settings', '0;', 0, 0, NULL, NULL, NULL, NULL, NULL)
GO
INSERT INTO [dbo].[Modules] ([ModuleID], [TabID], [ModuleDefID], [ModuleOrder], [PaneName], [ModuleTitle], [AuthorizedEditRoles], [CacheTime], [ShowMobile], [AuthorizedViewRoles], [Alignment], [Color], [Border], [IconFile]) VALUES (30, 6, 13, 3, 'ContentPane', 'Tabs', '0;', 0, 0, NULL, NULL, NULL, NULL, NULL)
GO
INSERT INTO [dbo].[Modules] ([ModuleID], [TabID], [ModuleDefID], [ModuleOrder], [PaneName], [ModuleTitle], [AuthorizedEditRoles], [CacheTime], [ShowMobile], [AuthorizedViewRoles], [Alignment], [Color], [Border], [IconFile]) VALUES (31, 6, 12, 5, 'ContentPane', 'Security Roles', '0;', 0, 0, NULL, NULL, NULL, NULL, NULL)
GO
INSERT INTO [dbo].[Modules] ([ModuleID], [TabID], [ModuleDefID], [ModuleOrder], [PaneName], [ModuleTitle], [AuthorizedEditRoles], [CacheTime], [ShowMobile], [AuthorizedViewRoles], [Alignment], [Color], [Border], [IconFile]) VALUES (32, 6, 15, 7, 'ContentPane', 'Manage Users', '0;', 0, 0, NULL, NULL, NULL, NULL, NULL)
GO
INSERT INTO [dbo].[Modules] ([ModuleID], [TabID], [ModuleDefID], [ModuleOrder], [PaneName], [ModuleTitle], [AuthorizedEditRoles], [CacheTime], [ShowMobile], [AuthorizedViewRoles], [Alignment], [Color], [Border], [IconFile]) VALUES (72, 6, 19, 11, 'ContentPane', 'Vendors', '0;', 0, 0, NULL, NULL, NULL, NULL, NULL)
GO
INSERT INTO [dbo].[Modules] ([ModuleID], [TabID], [ModuleDefID], [ModuleOrder], [PaneName], [ModuleTitle], [AuthorizedEditRoles], [CacheTime], [ShowMobile], [AuthorizedViewRoles], [Alignment], [Color], [Border], [IconFile]) VALUES (111, 6, 27, 13, 'ContentPane', 'Site Log', '0;', 0, 0, NULL, NULL, NULL, NULL, NULL)
GO
INSERT INTO [dbo].[Modules] ([ModuleID], [TabID], [ModuleDefID], [ModuleOrder], [PaneName], [ModuleTitle], [AuthorizedEditRoles], [CacheTime], [ShowMobile], [AuthorizedViewRoles], [Alignment], [Color], [Border], [IconFile]) VALUES (112, 6, 28, 15, 'ContentPane', 'Bulk Email', '0;', 0, 0, NULL, NULL, NULL, NULL, NULL)
GO
INSERT INTO [dbo].[Modules] ([ModuleID], [TabID], [ModuleDefID], [ModuleOrder], [PaneName], [ModuleTitle], [AuthorizedEditRoles], [CacheTime], [ShowMobile], [AuthorizedViewRoles], [Alignment], [Color], [Border], [IconFile]) VALUES (316, 6, 21, 9, 'ContentPane', 'File Manager', '0;', 0, 0, NULL, NULL, NULL, NULL, NULL)
GO
INSERT INTO [dbo].[Modules] ([ModuleID], [TabID], [ModuleDefID], [ModuleOrder], [PaneName], [ModuleTitle], [AuthorizedEditRoles], [CacheTime], [ShowMobile], [AuthorizedViewRoles], [Alignment], [Color], [Border], [IconFile]) VALUES (321, 7, 63, 1, 'ContentPane', 'Portals', '-2;', 0, 0, '', '', '', '', NULL)
GO
INSERT INTO [dbo].[Modules] ([ModuleID], [TabID], [ModuleDefID], [ModuleOrder], [PaneName], [ModuleTitle], [AuthorizedEditRoles], [CacheTime], [ShowMobile], [AuthorizedViewRoles], [Alignment], [Color], [Border], [IconFile]) VALUES (322, 7, 64, 2, 'ContentPane', 'Module Definitions', '-2;', 0, 0, '', '', '', '', NULL)
GO
INSERT INTO [dbo].[Modules] ([ModuleID], [TabID], [ModuleDefID], [ModuleOrder], [PaneName], [ModuleTitle], [AuthorizedEditRoles], [CacheTime], [ShowMobile], [AuthorizedViewRoles], [Alignment], [Color], [Border], [IconFile]) VALUES (323, 7, 21, 3, 'ContentPane', 'File Manager', '-2;', 0, 0, '', '', '', '', NULL)
GO
INSERT INTO [dbo].[Modules] ([ModuleID], [TabID], [ModuleDefID], [ModuleOrder], [PaneName], [ModuleTitle], [AuthorizedEditRoles], [CacheTime], [ShowMobile], [AuthorizedViewRoles], [Alignment], [Color], [Border], [IconFile]) VALUES (324, 7, 19, 4, 'ContentPane', 'Vendors', '-2;', 0, 0, '', '', '', '', NULL)
GO
INSERT INTO [dbo].[Modules] ([ModuleID], [TabID], [ModuleDefID], [ModuleOrder], [PaneName], [ModuleTitle], [AuthorizedEditRoles], [CacheTime], [ShowMobile], [AuthorizedViewRoles], [Alignment], [Color], [Border], [IconFile]) VALUES (325, 7, 65, 5, 'ContentPane', 'SQL', '-2;', 0, 0, '', '', '', '', NULL)
GO

SET IDENTITY_INSERT [dbo].[Modules] OFF


/* Insert scripts for table: [dbo].[Roles] */
PRINT 'Inserting rows into table: [dbo].[Roles]'

SET IDENTITY_INSERT [dbo].[Roles] ON

INSERT INTO [dbo].[Roles] ([RoleID], [PortalID], [RoleName], [Description], [ServiceFee], [BillingFrequency], [TrialPeriod], [TrialFrequency]) VALUES (0, 0, 'Administrators', 'Portal Administration', NULL, '4', NULL, NULL)
GO
INSERT INTO [dbo].[Roles] ([RoleID], [PortalID], [RoleName], [Description], [ServiceFee], [BillingFrequency], [TrialPeriod], [TrialFrequency]) VALUES (11, 0, 'Registered Users', 'Registered Users', NULL, '0', NULL, NULL)
GO

SET IDENTITY_INSERT [dbo].[Roles] OFF


/* Insert scripts for table: [dbo].[Users] */
PRINT 'Inserting rows into table: [dbo].[Users]'

SET IDENTITY_INSERT [dbo].[Users] ON

INSERT INTO [dbo].[Users] ([UserID], [FirstName], [LastName], [Street], [City], [Region], [PostalCode], [Country], [Password], [Email], [CreatedDate], [LastLoginDate], [Unit]) VALUES (2, 'Host', 'Account', NULL, NULL, NULL, NULL, NULL, 'host', 'host', NULL, getdate(), NULL)
GO
INSERT INTO [dbo].[Users] ([UserID], [FirstName], [LastName], [Street], [City], [Region], [PostalCode], [Country], [Password], [Email], [CreatedDate], [LastLoginDate], [Unit]) VALUES (9, 'Administrator', 'Account', NULL, NULL, NULL, NULL, NULL, 'admin', 'admin', NULL, getdate(), NULL)
GO

SET IDENTITY_INSERT [dbo].[Users] OFF


/* Insert scripts for table: [dbo].[UserRoles] */
PRINT 'Inserting rows into table: [dbo].[UserRoles]'

SET IDENTITY_INSERT [dbo].[UserRoles] ON

INSERT INTO [dbo].[UserRoles] ([UserRoleID], [UserID], [RoleID], [ExpiryDate], [IsTrialUsed]) VALUES (1, 9, 0, NULL, NULL)
GO
INSERT INTO [dbo].[UserRoles] ([UserRoleID], [UserID], [RoleID], [ExpiryDate], [IsTrialUsed]) VALUES (3, 9, 11, NULL, NULL)
GO

SET IDENTITY_INSERT [dbo].[UserRoles] OFF


/* Insert scripts for table: [dbo].[UserPortals] */
PRINT 'Inserting rows into table: [dbo].[UserPortals]'

INSERT INTO [dbo].[UserPortals] ([UserId], [PortalId], [Authorized]) VALUES (9, 0, 1)
GO


/* Insert scripts for table: [dbo].[Files] */
PRINT 'Inserting rows into table: [dbo].[Files]'

SET IDENTITY_INSERT [dbo].[Files] ON

INSERT INTO [dbo].[Files] ([FileId], [PortalId], [FileName], [Extension], [Size], [Width], [Height], [ContentType]) VALUES (1, 0, 'logo.gif', 'gif', 1206, 92, 105, 'image/gif')
GO
INSERT INTO [dbo].[Files] ([FileId], [PortalId], [FileName], [Extension], [Size], [Width], [Height], [ContentType]) VALUES (2, 0, 'portal.css', 'css', 5786, NULL, NULL, 'application/octet-stream')
GO
INSERT INTO [dbo].[Files] ([FileId], [PortalId], [FileName], [Extension], [Size], [Width], [Height], [ContentType]) VALUES (3, NULL, 'portal.template', 'template', 1163, NULL, NULL, 'application/octet-stream')
GO
INSERT INTO [dbo].[Files] ([FileId], [PortalId], [FileName], [Extension], [Size], [Width], [Height], [ContentType]) VALUES (4, 0, 'PerpetualMotion.gif', 'gif', 3738, 130, 90, 'image/gif')
GO
INSERT INTO [dbo].[Files] ([FileId], [PortalId], [FileName], [Extension], [Size], [Width], [Height], [ContentType]) VALUES (5, 0, 'aspnet.gif', 'gif', 2832, 160, 50, 'image/gif')
GO

SET IDENTITY_INSERT [dbo].[Files] OFF


/* Insert scripts for table: [dbo].[HtmlText] */
PRINT 'Inserting rows into table: [dbo].[HtmlText]'

INSERT INTO [dbo].[HtmlText] ([ModuleID], [DesktopHtml], [MobileSummary], [MobileDetails]) VALUES (2, '<br><b>Administrator Login:</b><br><br>Username: admin<br>Password: admin<br><br>* Select the Admin tab to manage the portal settings as the Administrator. Make sure you change the default password and specify a valid Email address for this account.<br><br><b>Host Login:</b><br><br>Username: host<br>Password: host<br><br>* Select the Host tab to manage multiple portals as the Host. Make sure you change the default password and specify a valid Email address for this account.<br><br>&lt;b&gt;Open Source License:&lt;/b&gt;<br><br>DotNetNuke -  <a href="http://www.dotnetnuke.com">http://www.dotnetnuke.com</a><br>Copyright (c) 2002-2003<br>by Shaun Walker ( <a href="mailto:sales@perpetualmotion.ca">sales@perpetualmotion.ca</a> )<br>of Perpetual Motion Interactive Systems Inc. ( <a href="http://www.perpetualmotion.ca">http://www.perpetualmotion.ca</a> )<br><br>Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:<br><br>The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.<br><br>THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.', '', '')
GO
INSERT INTO [dbo].[HtmlText] ([ModuleID], [DesktopHtml], [MobileSummary], [MobileDetails]) VALUES (4, '<center><br><a href="http://www.perpetualmotion.ca"><img src="PerpetualMotion.gif" border="0" alt="Perpetual Motion Interactive Systems Inc."></a><br><br><br><a href="http://www.asp.net"><img src="aspnet.gif" border="0" alt="The Official Microsoft ASP.NET Site"></a><br></center>', '', '')
GO

/* Insert scripts for table: [dbo].[Links] */
PRINT 'Inserting rows into table: [dbo].[Links]'

SET IDENTITY_INSERT [dbo].[Links] ON

INSERT INTO [dbo].[Links] ([ItemId], [ModuleID], [CreatedByUser], [CreatedDate], [Title], [Url], [MobileUrl], [ViewOrder], [Description], [NewWindow] ) VALUES (1, 3, 9, getdate(), 'DotNetNuke Site', 'http://www.dotnetnuke.com', null, 1, 'The Official DotNetNuke Website', 1 )
GO
INSERT INTO [dbo].[Links] ([ItemId], [ModuleID], [CreatedByUser], [CreatedDate], [Title], [Url], [MobileUrl], [ViewOrder], [Description], [NewWindow] ) VALUES (2, 3, 9, getdate(), 'Discussion Forum', 'http://www.asp.net/forums/showforum.aspx?forumid=90', null, 2, 'The Official Discussion Forum on ASP.NET', 1 )
GO
INSERT INTO [dbo].[Links] ([ItemId], [ModuleID], [CreatedByUser], [CreatedDate], [Title], [Url], [MobileUrl], [ViewOrder], [Description], [NewWindow] ) VALUES (3, 3, 9, getdate(), 'Report Defects', 'https://sourceforge.net/tracker/?group_id=77052&atid=549034', null, 3, 'The Official Defect Tracking System on SourceForge.Net', 1 )
GO
INSERT INTO [dbo].[Links] ([ItemId], [ModuleID], [CreatedByUser], [CreatedDate], [Title], [Url], [MobileUrl], [ViewOrder], [Description], [NewWindow] ) VALUES (4, 3, 9, getdate(), 'Request Feature', 'https://sourceforge.net/tracker/?group_id=77052&atid=549037', null, 4, 'The Official Feature Request System on SourceForge.Net', 1 )
GO

SET IDENTITY_INSERT [dbo].[Links] OFF

insert into Version (
  Major,
  Minor,
  Build,
  Comment,
  CreatedDate
)
values (
  1,
  0,
  0,
  'database creation',
  getdate()
)
GO




