/************************************************************/
/*****              Upgrade Script 1.0.3                *****/
/************************************************************/

if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Version]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
begin
  CREATE TABLE [dbo].[Version] (
  	  [VersionId] [int] IDENTITY (1, 1) NOT NULL ,
	  [Major] [int] NOT NULL ,
	  [Minor] [int] NOT NULL ,
	  [Build] [int] NOT NULL ,
	  [Comment] [varchar] (100) NOT NULL ,
	  [CreatedDate] [datetime] NOT NULL 
  ) ON [PRIMARY]

  ALTER TABLE [dbo].[Version] WITH NOCHECK ADD 
	CONSTRAINT [PK_Version] PRIMARY KEY  CLUSTERED 
	(
		[VersionId]
	)  ON [PRIMARY] 
end
GO

drop procedure GetFiles
GO

create procedure GetFiles

@PortalId   int

as

if @PortalId is null
begin
  select FileId,
         PortalId,
         FileName,
         Extension,
         Size,
         Width,
         Height,
         ContentType
  from   Files
  where  PortalId is null
  order by FileName
end
else
begin
  select FileId,
         PortalId,
         FileName,
         Extension,
         Size,
         Width,
         Height,
         ContentType
  from   Files
  where  PortalId = @PortalId
  order by FileName
end

return 1

GO

/************************************************************/
/*****              Upgrade Script 1.0.3                *****/
/************************************************************/

insert into Version (
  Major,
  Minor,
  Build,
  Comment,
  CreatedDate
)
values (
  1,
  0,
  3,
  'Version table, order files by name',
  getdate()
)
GO




