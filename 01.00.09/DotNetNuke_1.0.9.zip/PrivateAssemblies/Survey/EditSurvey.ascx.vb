'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2003
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.IO
Imports System.Runtime.Serialization.Formatters

Namespace DotNetNuke

    Public Class EditSurvey

        Inherits DotNetNuke.PortalModuleControl

        ' module options
        Protected WithEvents txtClosingDate As System.Web.UI.WebControls.TextBox
        Protected WithEvents optResults As System.Web.UI.WebControls.RadioButtonList
        Protected WithEvents txtGraphWidth As System.Web.UI.WebControls.TextBox
        Protected WithEvents cmdUpdateOptions As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancelOptions As System.Web.UI.WebControls.LinkButton

        Protected WithEvents txtQuestion As System.Web.UI.WebControls.TextBox
        Protected WithEvents cboOptionType As System.Web.UI.WebControls.DropDownList
        Protected WithEvents txtViewOrder As System.Web.UI.WebControls.TextBox
        Protected WithEvents rowOptions As System.Web.UI.HtmlControls.HtmlTableRow
        Protected WithEvents cmdAddOption As System.Web.UI.WebControls.LinkButton
        Protected WithEvents grdOptions As System.Web.UI.WebControls.DataGrid

        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdDelete As System.Web.UI.WebControls.LinkButton

        Protected WithEvents pnlAudit As System.Web.UI.WebControls.Panel
        Protected WithEvents lblCreatedBy As System.Web.UI.WebControls.Label
        Protected WithEvents lblCreatedDate As System.Web.UI.WebControls.Label

        Dim SurveyId As Integer = -1

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        '*******************************************************
        '
        ' The Page_Load server event handler on this user control is used
        ' to populate the current site settings from the config system
        '
        '*******************************************************

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            ' Determine ItemId of Link to Update
            If Not (Request.Params("SurveyId") Is Nothing) Then
                SurveyId = Int32.Parse(Request.Params("SurveyId"))
            End If

            If Page.IsPostBack = False Then

                cmdDelete.Attributes.Add("onClick", "javascript:return confirm('Are You Sure You Wish To Delete This Item ?');")

                txtClosingDate.Text = CType(Settings("surveyclosingdate"), String)
                txtGraphWidth.Text = CType(Settings("surveygraphwidth"), String)

                If SurveyId <> -1 Then

                    ' Obtain a single row of link information
                    Dim objSurvey As New SurveyDB()

                    Dim dr As SqlDataReader = objSurvey.GetSingleSurvey(SurveyId, ModuleId)
                    If dr.Read() Then

                        txtQuestion.Text = dr("Question").ToString
                        txtViewOrder.Text = dr("ViewOrder").ToString
                        cboOptionType.Items.FindByValue(dr("OptionType")).Selected = True

                        BindData()

                        lblCreatedBy.Text = dr("CreatedByUser").ToString
                        lblCreatedDate.Text = CType(dr("CreatedDate"), DateTime).ToShortDateString()

                        ' Close datareader
                        dr.Close()

                    Else ' security violation attempt to access item not related to this Module

                        Response.Redirect("~/desktopdefault.aspx?tabid=" & TabId)

                    End If

                Else ' new item

                    rowOptions.Visible = False
                    cmdDelete.Visible = False
                    pnlAudit.Visible = False

                End If

                ' Store URL Referrer to return to portal
                If Not Request.UrlReferrer Is Nothing Then
                    ViewState("UrlReferrer") = Request.UrlReferrer.ToString()
                Else
                    ViewState("UrlReferrer") = ""
                End If

            End If

        End Sub

        Private Sub cmdAddOption_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdAddOption.Click
            grdOptions.EditItemIndex = 0
            BindData(True)
        End Sub

        Private Sub BindData(Optional ByVal blnInsertField As Boolean = False)

            Dim objSurvey As New SurveyDB()

            Dim dr As SqlDataReader = objSurvey.GetSurveyOptions(SurveyId)

            Dim ds As DataSet

            ds = ConvertDataReaderToDataSet(dr)

            ' inserting a new field
            If blnInsertField Then
                Dim row As DataRow
                row = ds.Tables(0).NewRow()
                row("SurveyOptionId") = "-1"
                row("OptionName") = ""
                row("ViewOrder") = "0"
                ds.Tables(0).Rows.InsertAt(row, 0)
                'grdOptions.EditItemIndex = 0
            End If

            grdOptions.DataSource = ds
            grdOptions.DataBind()

        End Sub

        Private Sub Update_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click

            ' update Portal info in the database
            Dim objSurvey As New SurveyDB()

            If SurveyId = -1 Then
                objSurvey.AddSurvey(ModuleId, txtQuestion.Text, txtViewOrder.Text, cboOptionType.SelectedItem.Value, Context.User.Identity.Name)
            Else
                objSurvey.UpdateSurvey(SurveyId, txtQuestion.Text, txtViewOrder.Text, cboOptionType.SelectedItem.Value, Context.User.Identity.Name)
            End If

            ' Redirect back to the portal home page
            Response.Redirect(CStr(ViewState("UrlReferrer")))

        End Sub

        Private Sub Delete_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdDelete.Click

            Dim objSurvey As New SurveyDB()

            If SurveyId <> -1 Then
                objSurvey.DeleteSurvey(SurveyId)
            End If

            ' Redirect back to the portal home page
            Response.Redirect(CStr(ViewState("UrlReferrer")))

        End Sub

        Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCancel.Click

            Response.Redirect(CType(Viewstate("UrlReferrer"), String))

        End Sub

        Private Sub grdOptions_ItemCreated(ByVal sender As System.Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs)

            Dim cmdDeleteOption As Control = e.Item.FindControl("cmdDeleteOption")

            If Not cmdDeleteOption Is Nothing Then
                CType(cmdDeleteOption, ImageButton).Attributes.Add("onClick", "javascript:return confirm('Are You Sure You Wish To Delete This Item ?');")
            End If

        End Sub

        Public Sub grdOptions_Edit(ByVal sender As Object, ByVal e As DataGridCommandEventArgs)
            grdOptions.EditItemIndex = e.Item.ItemIndex
            grdOptions.SelectedIndex = -1

            BindData()
        End Sub

        Public Sub grdOptions_Delete(ByVal sender As Object, ByVal e As DataGridCommandEventArgs)

            Dim objSurvey As New SurveyDB()

            objSurvey.DeleteSurveyOption(Integer.Parse(grdOptions.DataKeys(e.Item.ItemIndex).ToString()))

            grdOptions.EditItemIndex = -1

            BindData()
        End Sub

        Public Sub grdOptions_Update(ByVal sender As Object, ByVal e As DataGridCommandEventArgs)

            Dim txtOptionName As TextBox = e.Item.Cells(1).Controls(1)
            Dim txtViewOrder As TextBox = e.Item.Cells(2).Controls(1)

            Dim objSurvey As New SurveyDB()

            If Integer.Parse(grdOptions.DataKeys(e.Item.ItemIndex).ToString()) = -1 Then
                objSurvey.AddSurveyOption(SurveyId, txtOptionName.Text, txtViewOrder.Text)
            Else
                objSurvey.UpdateSurveyOption(Integer.Parse(grdOptions.DataKeys(e.Item.ItemIndex).ToString()), txtOptionName.Text, txtViewOrder.Text)
            End If

            grdOptions.EditItemIndex = -1

            BindData()
        End Sub

        Public Sub grdOptions_CancelEdit(ByVal sender As Object, ByVal e As DataGridCommandEventArgs)
            grdOptions.EditItemIndex = -1
            BindData()
        End Sub

        Private Sub cmdUpdateOptions_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdUpdateOptions.Click

            Dim objAdmin As New AdminDB()

            objAdmin.UpdateModuleSetting(ModuleId, "surveyclosingdate", txtClosingDate.Text)
            objAdmin.UpdateModuleSetting(ModuleId, "surveygraphwidth", txtGraphWidth.Text)

            ' Redirect back to the portal home page
            Response.Redirect(CStr(ViewState("UrlReferrer")))

        End Sub

        Private Sub cmdCancelOptions_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCancelOptions.Click

            ' Redirect back to the portal home page
            Response.Redirect(CStr(ViewState("UrlReferrer")))

        End Sub

    End Class

End Namespace

