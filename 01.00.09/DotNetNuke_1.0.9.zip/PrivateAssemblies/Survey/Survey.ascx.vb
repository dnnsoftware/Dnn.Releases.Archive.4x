'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2003
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.Data.SqlClient
Imports System.Web
Imports System
Imports System.Web.UI.WebControls
Imports System.Web.UI

Namespace DotNetNuke

    Public MustInherit Class Survey

        Inherits PortalModuleControl

        Protected WithEvents pnlSurvey As System.Web.UI.WebControls.Panel
        Protected WithEvents lstSurvey As System.Web.UI.WebControls.DataList
        Protected WithEvents cmdSubmit As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdResults As System.Web.UI.WebControls.LinkButton
        Protected WithEvents lblMessage As System.Web.UI.WebControls.Label

        Protected WithEvents pnlResults As System.Web.UI.WebControls.Panel
        Protected WithEvents lstResults As System.Web.UI.WebControls.DataList
        Protected WithEvents cmdSurvey As System.Web.UI.WebControls.LinkButton

        Private strCookie As String
        Private strClosingDate As String

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            strCookie = "_Module" & ModuleId.ToString & "_Survey"

            strClosingDate = CType(Settings("surveyclosingdate"), String)
            If strClosingDate = "" Then
                strClosingDate = Now.ToString
            End If

            If Not Page.IsPostBack Then

                If Request.Cookies(strCookie) Is Nothing And DateDiff(DateInterval.Day, Now, Date.Parse(strClosingDate)) >= 0 Then
                    DisplaySurvey()
                Else
                    DisplayResults()
                End If
            End If

        End Sub

        Private Sub DisplaySurvey()

            Dim objSurvey As New SurveyDB()

            lstSurvey.DataSource = objSurvey.GetSurveys(ModuleId)
            lstSurvey.DataBind()

            pnlSurvey.Visible = True
            pnlResults.Visible = False

            If lstSurvey.Items.Count = 0 Then
                cmdSubmit.Visible = False
                cmdResults.Visible = False
            End If

        End Sub

        Private Sub DisplayResults()

            If Request.Cookies(strCookie) Is Nothing And DateDiff(DateInterval.Day, Now, Date.Parse(strClosingDate)) >= 0 Then
                cmdSurvey.Visible = True
            Else
                cmdSurvey.Visible = False
            End If

            Dim objSurvey As New SurveyDB()

            lstResults.DataSource = objSurvey.GetSurveys(ModuleId)
            lstResults.DataBind()

            pnlSurvey.Visible = False
            pnlResults.Visible = True

        End Sub

        Public Function FormatQuestion(ByVal strQuestion As String, ByVal ItemNumber As Integer) As String

            Return ItemNumber.ToString & ". " & strQuestion

        End Function

        Private Sub lstSurvey_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataListItemEventArgs) Handles lstSurvey.ItemDataBound

            Dim objSurvey As New SurveyDB()
            Dim dr As SqlDataReader = objSurvey.GetSingleSurvey(Int32.Parse(lstSurvey.DataKeys(e.Item.ItemIndex).ToString), ModuleId)
            If dr.Read Then
                Select Case dr("OptionType")
                    Case "R"
                        Dim optOptions As RadioButtonList = CType(e.Item.FindControl("optOptions"), RadioButtonList)
                        optOptions.DataSource = objSurvey.GetSurveyOptions(dr("SurveyID"))
                        optOptions.DataBind()
                        optOptions.Visible = True
                    Case "C"
                        Dim chkOptions As CheckBoxList = CType(e.Item.FindControl("chkOptions"), CheckBoxList)
                        chkOptions.DataSource = objSurvey.GetSurveyOptions(dr("SurveyID"))
                        chkOptions.DataBind()
                        chkOptions.Visible = True
                End Select
            End If
            dr.Close()

        End Sub

        Private Sub cmdSubmit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSubmit.Click

            Dim objSurvey As New SurveyDB()
            Dim drQuestions As SqlDataReader
            Dim drOptions As SqlDataReader
            Dim intQuestion As Integer
            Dim intOption As Integer
            Dim blnValid As Boolean = True

            intQuestion = -1
            drQuestions = objSurvey.GetSurveys(ModuleId)
            While drQuestions.Read
                intQuestion += 1
                Select Case drQuestions("OptionType")
                    Case "R"
                        If Request.Form(lstSurvey.UniqueID & ":_ctl" & intQuestion.ToString & ":optOptions") = "" Then
                            blnValid = False
                        End If
                    Case "C"
                        blnValid = False
                        intOption = -1
                        drOptions = objSurvey.GetSurveyOptions(drQuestions("SurveyID"))
                        While drOptions.Read
                            intOption += 1
                            If Request.Form(lstSurvey.UniqueID & ":_ctl" & intQuestion.ToString & ":chkOptions:" & intOption.ToString) <> "" Then
                                blnValid = True
                            End If
                        End While
                        drOptions.Close()
                End Select
            End While
            drQuestions.Close()

            If blnValid Then
                intQuestion = -1
                drQuestions = objSurvey.GetSurveys(ModuleId)
                While drQuestions.Read
                    intQuestion += 1
                    Select Case drQuestions("OptionType")
                        Case "R"
                            If Request.Form(lstSurvey.UniqueID & ":_ctl" & intQuestion.ToString & ":optOptions") <> "" Then
                                objSurvey.AddSurveyResult(Int32.Parse(Request.Form(lstSurvey.UniqueID & ":_ctl" & intQuestion.ToString & ":optOptions")))
                            End If
                        Case "C"
                            intOption = -1
                            drOptions = objSurvey.GetSurveyOptions(drQuestions("SurveyID"))
                            While drOptions.Read
                                intOption += 1
                                If Request.Form(lstSurvey.UniqueID & ":_ctl" & intQuestion.ToString & ":chkOptions:" & intOption.ToString) <> "" Then
                                    objSurvey.AddSurveyResult(drOptions("SurveyOptionID"))
                                End If
                            End While
                            drOptions.Close()
                    End Select
                End While
                drQuestions.Close()

                ' Store a cookie to show the chart after the submit
                Dim objCookie As HttpCookie = New HttpCookie("_Module" & ModuleId.ToString & "_Survey")
                objCookie.Value = "True"
                objCookie.Expires = DateTime.MaxValue ' never expires
                Response.AppendCookie(objCookie)

                DisplayResults()
            Else
                lblMessage.Text = "Survey Incomplete"
            End If

        End Sub

        Private Sub cmdResults_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdResults.Click

            DisplayResults()

        End Sub

        Private Sub lstResults_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataListItemEventArgs) Handles lstResults.ItemDataBound

            Dim strHTML As String
            Dim intGraphWidth As Integer = 400

            If CType(Settings("surveygraphwidth"), String) <> "" Then
                intGraphWidth = Int32.Parse(CType(Settings("surveygraphwidth"), String))
            End If

            strHTML += "<BR><TABLE BORDER=""0"" CELLPADDING=""2"" CELLSPACING=""0"" WIDTH=""100%"">"

            Dim objSurvey As New SurveyDB()
            Dim drSurvey As SqlDataReader = objSurvey.GetSingleSurvey(Int32.Parse(lstResults.DataKeys(e.Item.ItemIndex).ToString), ModuleId)
            If drSurvey.Read Then
                Dim drResults As SqlDataReader = objSurvey.GetSurveyOptions(drSurvey("SurveyID"))
                While drResults.Read
                    Dim dblPercent As Double = 0
                    If drSurvey("Votes") <> 0 Then
                        dblPercent = drResults("Votes") / drSurvey("Votes")
                    End If
                    strHTML += "<TR>"
                    strHTML += "<TD VALIGN=""top"" CLASS=""Normal"">" & drResults("OptionName").ToString & "&nbsp;(" & drResults("Votes").ToString & ")</TD>"
                    strHTML += "<TD ALIGN=""left"" VALIGN=""top"" CLASS=""Normal"" NOWRAP><IMG SRC=""images/red.gif"" WIDTH=""" & (intGraphWidth * dblPercent) & """ BORDER=""0"" HEIGHT=""15"">&nbsp;" & CInt(dblPercent * 100).ToString & "%</TD>"
                    strHTML += "</TR>"
                End While
                drResults.Close()
            End If
            drSurvey.Close()

            strHTML += "</TABLE>"

            Dim lblResults As Label = CType(e.Item.FindControl("lblResults"), Label)
            lblResults.Text = strHTML
        End Sub

        Private Sub cmdSurvey_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSurvey.Click

            DisplaySurvey()

        End Sub

    End Class

End Namespace