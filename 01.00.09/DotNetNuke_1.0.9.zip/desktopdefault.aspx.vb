'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2003
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Namespace DotNetNuke

    Public Class DesktopDefault

        Inherits DotNetNuke.BasePage

        Protected WithEvents Body As System.Web.UI.HtmlControls.HtmlContainerControl
        Protected WithEvents ScrollTop As System.Web.UI.HtmlControls.HtmlInputHidden

        Protected WithEvents rowAdmin As System.Web.UI.HtmlControls.HtmlTableRow
        Protected WithEvents colAdmin As System.Web.UI.HtmlControls.HtmlTableCell
        Protected WithEvents cmdEditTabText As System.Web.UI.WebControls.HyperLink
        Protected WithEvents cmdEditTabImage As System.Web.UI.WebControls.HyperLink
        Protected WithEvents cboModuleDefs As System.Web.UI.WebControls.DropDownList
        Protected WithEvents cmdAdd As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdHelpShow As System.Web.UI.WebControls.ImageButton
        Protected WithEvents cmdHelpHide As System.Web.UI.WebControls.ImageButton
        Protected WithEvents chkPreview As System.Web.UI.WebControls.CheckBox
        Protected WithEvents lblDescription As System.Web.UI.WebControls.Label
        Protected WithEvents cmdAddTabText As System.Web.UI.WebControls.HyperLink
        Protected WithEvents cmdAddTabImage As System.Web.UI.WebControls.HyperLink

        Protected LeftPane As System.Web.UI.HtmlControls.HtmlTableCell
        Protected LeftPaneSpacer As System.Web.UI.WebControls.Image
        Protected ContentPane As System.Web.UI.HtmlControls.HtmlTableCell
        Protected ContentPaneSpacer As System.Web.UI.WebControls.Image
        Protected RightPane As System.Web.UI.HtmlControls.HtmlTableCell
        Protected RightPaneSpacer As System.Web.UI.WebControls.Image

        Protected WithEvents hypCopyright As System.Web.UI.WebControls.HyperLink

        Public Description As String = ""
        Public KeyWords As String = ""
        Public Copyright As String = ""
        Public Generator As String = ""

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

#End Region

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            '
            ' CODEGEN: This call is required by the ASP.NET Web Form Designer.
            '
            InitializeComponent()

            Dim objAdmin As New AdminDB()

            ' redirect to a specific tab based on name
            If Request.Params("tabname") <> "" Then
                Dim strURL As String = ""

                Dim admin As New AdminDB()
                Dim result As SqlDataReader = admin.GetTabByName(Request.Params("TabName"), CType(HttpContext.Current.Items("PortalSettings"), PortalSettings).PortalId)
                If result.Read() Then
                    strURL = "~/DesktopDefault.aspx?tabid=" & result("TabId")
                End If
                result.Close()

                If strURL <> "" Then
                    Dim intParam As Integer
                    For intParam = 0 To Request.QueryString.Count - 1
                        Select Case Request.QueryString.Keys(intParam).ToLower()
                            Case "tabid", "tabname"
                            Case Else
                                strURL += "&" + Request.QueryString.Keys(intParam) + "=" + Request.QueryString(intParam)
                        End Select
                    Next

                    Response.Redirect(strURL)
                End If
            End If

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            Description = _portalSettings.Description
            KeyWords = _portalSettings.KeyWords & IIf(_portalSettings.KeyWords <> "", ",", "") & "DotNetNuke"
            Copyright = "Copyright (c) 2002-" & Year(Now).ToString & " by DotNetNuke ( " & System.Diagnostics.FileVersionInfo.GetVersionInfo(System.Reflection.Assembly.GetExecutingAssembly.Location).ProductName.ToString & " )"
            Generator = "DotNetNuke " & _portalSettings.Version

            ' if first time loading this page then reload to avoid caching
            If Request.Params("tabId") Is Nothing Then
                Response.Expires = -1
            End If

            ' get module container
            Dim settings As Hashtable = PortalSettings.GetModuleSettings(objAdmin.GetSiteModule("Site Settings", _portalSettings.PortalId))
            Dim strContainer As String = settings("container")

            ' set width of left and right panes
            If _portalSettings.ActiveTab.LeftPaneWidth <> "" Then
                LeftPaneSpacer.Width = System.Web.UI.WebControls.Unit.Parse(_portalSettings.ActiveTab.LeftPaneWidth & "px")
            End If
            If _portalSettings.ActiveTab.RightPaneWidth <> "" Then
                RightPaneSpacer.Width = System.Web.UI.WebControls.Unit.Parse(_portalSettings.ActiveTab.RightPaneWidth & "px")
            End If

            Dim blnShowLogin As Boolean = False

            ' ensure that the user has access to the current page
            If PortalSecurity.IsInRoles(_portalSettings.ActiveTab.AuthorizedRoles) = False Then
                Dim objModule As PortalModuleControl = CType(Me.LoadModule("~/Admin/Security/AccessDenied.ascx"), PortalModuleControl)
                AddModule(ContentPane, objModule, strContainer, _portalSettings.UploadDirectory)
                blnShowLogin = True
            End If

            ' show login module if the client is not yet authenticated and they requested to login
            If Request.IsAuthenticated = False And Request.QueryString("showlogin") = "1" Then
                blnShowLogin = True
            End If

            ' show login module
            If blnShowLogin Then
                Dim objModule As PortalModuleControl = CType(Me.LoadModule("~/Admin/Security/SignIn.ascx"), PortalModuleControl)
                AddModule(LeftPane, objModule, strContainer, _portalSettings.UploadDirectory)
            End If

            ' check portal expiry date
            Dim blnExpired As Boolean = False
            If _portalSettings.ExpiryDate <> "" Then
                If CDate(_portalSettings.ExpiryDate) < Now() Then
                    blnExpired = True
                End If
            End If

            ' Dynamically inject an expiry message into the Content pane if the portal license has expired
            If blnExpired = True And _portalSettings.ActiveTab.ParentId <> _portalSettings.AdminTabId And _portalSettings.ActiveTab.TabId <> _portalSettings.SuperTabId Then
                Dim objModule As PortalModuleControl = CType(Me.LoadModule("~/Admin/Security/Expired.ascx"), PortalModuleControl)
                AddModule(ContentPane, objModule, strContainer, _portalSettings.UploadDirectory, "center")
            Else
                If (PortalSecurity.IsInRoles(_portalSettings.AdministratorRoleId.ToString) = True Or PortalSecurity.IsInRoles(_portalSettings.ActiveTab.AdministratorRoles.ToString) = True) And IsAdminTab(_portalSettings.ActiveTab.TabId, _portalSettings.ActiveTab.ParentId) = False Then
                    cmdEditTabText.NavigateUrl = "~/EditModule.aspx?tabid=" & _portalSettings.ActiveTab.TabId & "&def=Tabs&action=edit"
                    cmdEditTabImage.NavigateUrl = "~/EditModule.aspx?tabid=" & _portalSettings.ActiveTab.TabId & "&def=Tabs&action=edit"
                    cboModuleDefs.DataSource = objAdmin.GetModuleDefinitions(_portalSettings.PortalId, False)
                    cboModuleDefs.DataBind()

                    cmdAddTabText.NavigateUrl = "~/EditModule.aspx?tabid=" & _portalSettings.ActiveTab.TabId & "&def=Tabs"
                    cmdAddTabImage.NavigateUrl = "~/EditModule.aspx?tabid=" & _portalSettings.ActiveTab.TabId & "&def=Tabs"

                    cmdHelpShow.ImageUrl = "~/images/help.gif"
                    cmdHelpShow.ToolTip = "Show Module Info"
                    cmdHelpShow.Visible = True

                    cmdHelpHide.ImageUrl = "~/images/cancel.gif"
                    cmdHelpHide.ToolTip = "Hide Module Info"
                    cmdHelpHide.Visible = False

                    If Not Request.Cookies("_Tab_Admin_Preview") Is Nothing Then
                        chkPreview.Checked = Boolean.Parse(Request.Cookies("_Tab_Admin_Preview").Value)
                    End If

                    ContentPane.Visible = True
                    rowAdmin.Visible = True
                End If

                ' Dynamically Populate the Left, Center and Right pane sections of the portal page
                If _portalSettings.ActiveTab.Modules.Count > 0 Then

                    ' Loop through each entry in the configuration system for this tab
                    Dim _moduleSettings As ModuleSettings
                    For Each _moduleSettings In _portalSettings.ActiveTab.Modules

                        If PortalSecurity.IsInRoles(IIf(_moduleSettings.AuthorizedViewRoles <> "", _moduleSettings.AuthorizedViewRoles, _portalSettings.ActiveTab.AuthorizedRoles)) Then

                            ' modules which are displayed on all tabs should not be displayed on the Admin or Super tabs
                            If _moduleSettings.AllTabs = False Or IsAdminTab(_portalSettings.ActiveTab.TabId, _portalSettings.ActiveTab.ParentId) = False Then

                                Dim parent As Control = Page.FindControl(_moduleSettings.PaneName)

                                ' If no caching is specified, create the user control instance and dynamically
                                ' inject it into the page.  Otherwise, create a cached module instance that
                                ' may or may not optionally inject the module into the tree
                                Try
                                    If _moduleSettings.CacheTime = 0 Then
                                        Dim objModule As PortalModuleControl = CType(Me.LoadModule(_moduleSettings.DesktopSrc), PortalModuleControl)
                                        objModule.ModuleConfiguration = _moduleSettings
                                        AddModule(parent, objModule, IIf(_moduleSettings.Container <> "", _moduleSettings.Container, strContainer), _portalSettings.UploadDirectory, _moduleSettings.Alignment, _moduleSettings.Color, _moduleSettings.Border)
                                    Else
                                        Dim objModule As New CachedPortalModuleControl()
                                        objModule.ModuleConfiguration = _moduleSettings
                                        AddModule(parent, objModule, IIf(_moduleSettings.Container <> "", _moduleSettings.Container, strContainer), _portalSettings.UploadDirectory, _moduleSettings.Alignment, _moduleSettings.Color, _moduleSettings.Border)
                                    End If

                                Catch objException As Exception
                                    ' error loading user control - the file may have been deleted or moved
                                    If InStr(1, Request.Url.ToString.ToLower, "localhost") Then
                                        Throw objException
                                    Else
                                        If PortalSecurity.IsInRoles(_portalSettings.AdministratorRoleId.ToString) = True Or PortalSecurity.IsInRoles(_portalSettings.ActiveTab.AdministratorRoles.ToString) = True Then
                                            parent.Controls.Add(New LiteralControl("<span class=""NormalRed"">Error Loading " & _moduleSettings.DesktopSrc & "</span>"))
                                        End If
                                    End If
                                End Try

                            End If

                        End If

                    Next _moduleSettings
                End If

                ' set the Admin row properties
                If rowAdmin.Visible Then
                    Dim intColSpan As Integer = 0
                    If LeftPane.Visible Then
                        intColSpan += 1
                        LeftPane.Controls.RemoveAt(0)
                    End If
                    If ContentPane.Visible Then
                        intColSpan += 1
                        ContentPane.Controls.RemoveAt(0)
                    End If
                    If RightPane.Visible Then
                        intColSpan += 1
                        RightPane.Controls.RemoveAt(0)
                    End If
                    If intColSpan > 1 Then
                        colAdmin.ColSpan = intColSpan
                    End If
                End If
            End If

            hypCopyright.Text = Replace(System.Diagnostics.FileVersionInfo.GetVersionInfo(System.Reflection.Assembly.GetExecutingAssembly.Location).LegalCopyright.ToString, "YYYY", Year(Now).ToString)
            hypCopyright.NavigateUrl = System.Diagnostics.FileVersionInfo.GetVersionInfo(System.Reflection.Assembly.GetExecutingAssembly.Location).ProductName.ToString
        End Sub

        Private Sub AddModule(ByVal objPane As HtmlTableCell, ByVal objModule As Control, ByVal strContainer As String, ByVal strUploadDirectory As String, Optional ByVal strAlignment As String = "", Optional ByVal strColor As String = "", Optional ByVal strBorder As String = "")

            Dim arrContainer As Array

            strContainer = Replace(strContainer, "[ALIGN]", IIf(strAlignment <> "", " align=""" & strAlignment & """", ""))
            strContainer = Replace(strContainer, "[COLOR]", IIf(strColor <> "", " bgcolor=""" & strColor & """", ""))
            strContainer = Replace(strContainer, "[BORDER]", IIf(strBorder <> "", " border=""" & strBorder & """", ""))
            strContainer = ManageUploadDirectory(strContainer, strUploadDirectory)

            arrContainer = Split(strContainer, "[MODULE]")

            objPane.Controls.Add(New LiteralControl(arrContainer(0)))
            objPane.Controls.Add(objModule)
            objPane.Controls.Add(New LiteralControl(arrContainer(1)))
            objPane.Visible = True

        End Sub

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            If ScrollTop.Value <> "" Then
                Body.Attributes.Add("onload", "javascript:Body.scrollTop=" & ScrollTop.Value & ";")
            End If
        End Sub

        Private Sub cmdAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdAdd.Click

            ' Obtain portalId from Current Context
            Dim _portalSettings As PortalSettings = CType(Context.Items("PortalSettings"), PortalSettings)

            Dim strEditRoles As String = _portalSettings.ActiveTab.AdministratorRoles
            If InStr(1, strEditRoles, _portalSettings.AdministratorRoleId.ToString & ";") = 0 Then
                strEditRoles += _portalSettings.AdministratorRoleId.ToString & ";"
            End If

            ' save to database
            Dim objAdmin As New AdminDB()
            objAdmin.AddModule(_portalSettings.ActiveTab.TabId, -1, "ContentPane", cboModuleDefs.SelectedItem.Text, Int32.Parse(cboModuleDefs.SelectedItem.Value), 0, strEditRoles, False)

            ' Redirect to the same page to pick up changes
            Response.Redirect(Request.RawUrl)
        End Sub

        Private Sub cmdHelpHide_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles cmdHelpHide.Click

            lblDescription.Text = ""

            cmdHelpShow.Visible = True
            cmdHelpHide.Visible = False
        End Sub

        Private Sub cmdHelpShow_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles cmdHelpShow.Click
            Dim objAdmin As New AdminDB()

            Dim dr As SqlDataReader = objAdmin.GetSingleModuleDefinition(Int32.Parse(cboModuleDefs.SelectedItem.Value))
            If dr.Read() Then
                lblDescription.Text = "<br>" & dr("Description").ToString & "<br>"
            End If
            dr.Close()

            cmdHelpShow.Visible = False
            cmdHelpHide.Visible = True
        End Sub

        Private Sub chkPreview_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkPreview.CheckedChanged

            Dim objPreview As HttpCookie

            If Request.Cookies("_Tab_Admin_Preview") Is Nothing Then
                objPreview = New HttpCookie("_Tab_Admin_Preview")
                objPreview.Expires = DateTime.MaxValue ' never expires
                Response.AppendCookie(objPreview)
            End If

            objPreview = Request.Cookies("_Tab_Admin_Preview")
            objPreview.Value = chkPreview.Checked.ToString
            Response.SetCookie(objPreview)

            Response.Redirect(Request.RawUrl)

        End Sub

    End Class

End Namespace