'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.Security
Imports System.Security.Principal
Imports System.Web
Imports System.Web.Security
Imports System.IO

Imports AspNetSecurity = System.Web.Security

Imports DotNetNuke.Common
Imports DotNetNuke.Common.Utilities
Imports DotNetNuke.Entities.Portals
Imports DotNetNuke.Entities.Users
Imports DotNetNuke.Services.Personalization
Imports DotNetNuke.Security
Imports DotNetNuke.Security.Roles

Namespace DotNetNuke.HttpModules

    Public Class DNNMembershipModule

        Implements IHttpModule

        Public ReadOnly Property ModuleName() As String
            Get
                Return "DNNMembershipModule"
            End Get
        End Property

        Public Sub Init(ByVal application As HttpApplication) Implements IHttpModule.Init

            AddHandler application.AuthenticateRequest, AddressOf Me.OnAuthenticateRequest
            AddHandler application.EndRequest, AddressOf Me.OnEndRequest


        End Sub

        Public Sub OnAuthenticateRequest(ByVal s As Object, ByVal e As EventArgs)

            Dim Context As HttpContext = CType(s, HttpApplication).Context
            Dim Request As HttpRequest = Context.Request
            Dim Response As HttpResponse = Context.Response

            'First check if we are upgrading/installing
            If Request.Url.LocalPath.EndsWith("Install.aspx") Then
                Exit Sub
            End If

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = PortalController.GetCurrentPortalSettings
            Dim OriginalApplicationName As String = Globals.GetApplicationName

            If Request.IsAuthenticated = True And Not _portalSettings Is Nothing Then
                Dim objMembershipUser As AspNetSecurity.MembershipUser = AspNetSecurity.Membership.GetUser(True)
                If objMembershipUser Is Nothing Then
                    'could be a SuperUser, try super user application name
                    Globals.SetApplicationName(Globals.glbSuperUserAppName)
                    objMembershipUser = AspNetSecurity.Membership.GetUser
                    'Reset the Application Name
                    Globals.SetApplicationName(OriginalApplicationName)
                End If
                If Not Request.Cookies("portalaliasid") Is Nothing Then
                    Dim PortalCookie As FormsAuthenticationTicket = FormsAuthentication.Decrypt(Context.Request.Cookies("portalaliasid").Value)

                    ' check if user has switched portals
                    If _portalSettings.PortalAlias.PortalAliasID <> Int32.Parse(PortalCookie.UserData) Then

                        ' expire cookies if portal has changed
                        Response.Cookies("portalaliasid").Value = Nothing
                        Response.Cookies("portalaliasid").Path = "/"
                        Response.Cookies("portalaliasid").Expires = DateTime.Now.AddYears(-30)

                        Response.Cookies("portalroles").Value = Nothing
                        Response.Cookies("portalroles").Path = "/"
                        Response.Cookies("portalroles").Expires = DateTime.Now.AddYears(-30)

                        ' check if user is valid for new portal
                        Dim objUsers As New UserController
                        Dim objUser As UserInfo = objUsers.GetUserByUsername(_portalSettings.PortalId, Context.User.Identity.Name)
                        If objUser Is Nothing Then
                            ' log user out
                            Dim objPortalSecurity As New PortalSecurity
                            objPortalSecurity.SignOut()
                            ' Redirect browser back to home page
                            Response.Redirect(Request.RawUrl, True)
                            Exit Sub
                        End If
                    End If
                End If


                Dim arrPortalRoles() As String
                Dim objRoleController As New RoleController
                Dim objUserController As New UserController
                Dim Username As String
                Dim intUserId As Integer = -1

                Dim UserInfoCacheKey As String = objUserController.GetCacheKey(_portalSettings.PortalId, Context.User.Identity.Name)
                Dim objUserInfo As UserInfo = CType(DataCache.GetCache(UserInfoCacheKey), UserInfo)
                If objUserInfo Is Nothing Then
                    objUserInfo = objUserController.GetUserByUsername(_portalSettings.PortalId, Context.User.Identity.Name)
                    DataCache.SetCache(UserInfoCacheKey, objUserInfo, TimeSpan.FromMinutes(Globals.PerformanceSetting))
                End If

                If Not objUserInfo Is Nothing Then
                    intUserId = objUserInfo.UserID
                    Username = objUserInfo.Username
                Else
                    'The user is authenticated because they have
                    'an auth cookie, but it is possible that
                    'their cookie contains the userid instead
                    'of the username.
                    Dim objPortalSecurity As New PortalSecurity
                    objPortalSecurity.SignOut()
                    Exit Sub
                End If


                ' authenticate user and set last login ( this is necessary for users who have a permanent Auth cookie set ) 
                If objMembershipUser Is Nothing Or objMembershipUser.IsLockedOut = True Or objMembershipUser.IsApproved = False Then

                    Dim objPortalSecurity As New PortalSecurity
                    objPortalSecurity.SignOut()

                Else    ' valid Auth cookie

                    ' create cookies if they do not exist yet for this session.
                    If Request.Cookies("portalroles") Is Nothing Then

                        ' keep cookies in sync
                        Dim CurrentDateTime As Date = DateTime.Now

                        ' create a cookie authentication ticket ( version, user name, issue time, expires every hour, don't persist cookie, roles )
                        Dim PortalTicket As New FormsAuthenticationTicket(1, Username, CurrentDateTime, CurrentDateTime.AddHours(1), False, _portalSettings.PortalAlias.PortalAliasID.ToString)
                        ' encrypt the ticket
                        Dim strPortalAliasID As String = FormsAuthentication.Encrypt(PortalTicket)
                        ' send portal cookie to client
                        Response.Cookies("portalaliasid").Value = strPortalAliasID
                        Response.Cookies("portalaliasid").Path = "/"
                        Response.Cookies("portalaliasid").Expires = CurrentDateTime.AddMinutes(1)

                        ' get roles from UserRoles table
                        arrPortalRoles = objRoleController.GetPortalRolesByUser(intUserId, _portalSettings.PortalId)

                        ' create a string to persist the roles
                        Dim strPortalRoles As String = Join(arrPortalRoles, New Char() {";"c})

                        ' create a cookie authentication ticket ( version, user name, issue time, expires every hour, don't persist cookie, roles )
                        Dim RolesTicket As New FormsAuthenticationTicket(1, objUserInfo.Username, CurrentDateTime, CurrentDateTime.AddHours(1), False, strPortalRoles)
                        ' encrypt the ticket
                        Dim strRoles As String = FormsAuthentication.Encrypt(RolesTicket)
                        ' send roles cookie to client
                        Response.Cookies("portalroles").Value = strRoles
                        Response.Cookies("portalroles").Path = "/"
                        Response.Cookies("portalroles").Expires = CurrentDateTime.AddMinutes(1)

                    End If

                    If Not Request.Cookies("portalroles") Is Nothing Then
                        ' get roles from roles cookie
                        If Request.Cookies("portalroles").Value <> "" Then
                            Dim RoleTicket As FormsAuthenticationTicket = FormsAuthentication.Decrypt(Context.Request.Cookies("portalroles").Value)

                            ' convert the string representation of the role data into a string array
                            Context.Items.Add("UserRoles", ";" + RoleTicket.UserData + ";")
                        Else
                            Context.Items.Add("UserRoles", "")
                        End If
                        Context.Items.Add("UserInfo", objUserInfo)
                    End If
                End If
            End If


            If CType(HttpContext.Current.Items("UserInfo"), UserInfo) Is Nothing Then
                Context.Items.Add("UserInfo", New UserInfo)
            End If


        End Sub

        Public Sub OnEndRequest(ByVal s As Object, ByVal e As EventArgs)
            Dim Context As HttpContext = CType(s, HttpApplication).Context
            Dim Response As HttpResponse = Context.Response
            'avoid adding to .net 2 as httpOnlyCookies default to true in 2.0
            If System.Environment.Version.Major < 2 Then
                Const HTTPONLYSTRING As String = ";HttpOnly"
                For Each cookie As String In Response.Cookies
                    Dim path As String = Response.Cookies(cookie).Path
                    If path.EndsWith(HTTPONLYSTRING) = False Then
                        'append HttpOnly to cookie 
                        Response.Cookies(cookie).Path += HTTPONLYSTRING
                    End If
                Next
            End If
        End Sub

        Public Sub Dispose() Implements IHttpModule.Dispose
        End Sub

    End Class

End Namespace
