'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.Collections
Imports System.Configuration
Imports System.Data
Imports System.IO
Imports System.Security.Cryptography
Imports System.Text
Imports System.Text.RegularExpressions
Imports System.Web
Imports System.Web.Security

Imports AspNetSecurity = System.Web.Security

Imports DotNetNuke.Entities.Modules

Namespace DotNetNuke.Security

    '''-----------------------------------------------------------------------------
    ''' <summary>
    ''' The SecurityAccessLevel enum is used to determine which level of access rights
    ''' to assign to a specific module or module action. 
    ''' </summary>
    '''-----------------------------------------------------------------------------
    Public Enum SecurityAccessLevel As Integer
        ControlPanel = -3
        SkinObject = -2
        Anonymous = -1
        View = 0
        Edit = 1
        Admin = 2
        Host = 3
    End Enum

    Public Class PortalSecurity

        '''-----------------------------------------------------------------------------
        ''' <summary>
        ''' The FilterFlag enum determines which filters are applied by the InputFilter
        ''' function.  The Flags attribute allows the user to include multiple 
        ''' enumerated values in a single variable by OR'ing the individual values
        ''' together.
        ''' </summary>
        ''' <history>
        ''' 	[Joe Brinkman] 	8/15/2003	Created  Bug #000120, #000121
        ''' </history>
        '''-----------------------------------------------------------------------------
        <FlagsAttribute()> _
        Enum FilterFlag
            MultiLine = 1
            NoMarkup = 2
            NoScripting = 4
            NoSQL = 8
        End Enum

        Public Function UserLogin(ByVal Username As String, ByVal Password As String, ByVal PortalID As Integer, ByVal PortalName As String, ByVal IP As String, ByVal CreatePersistentCookie As Boolean) As Integer

            Dim objUsers As New UserController
            Dim objEventLog As New Services.Log.EventLog.EventLogController

            Dim UserId As Integer = -1

            Try
                ' get the user based on username from the local data store
                Dim objUser As UserInfo = objUsers.GetUserByUsername(PortalID, Username)

                ' check if the account is locked out
                If Not objUser Is Nothing Then
                    ' if the lockout period has expired then unlock the account
                    If objUser.Membership.LockedOut Then
                        Dim intTimeout As Integer
                        intTimeout = Convert.ToInt32(IIf(Not HostSettings("AutoAccountUnlockDuration") Is Nothing, HostSettings("AutoAccountUnlockDuration"), -1))
                        If intTimeout <> 0 Then
                            If intTimeout = -1 Then
                                intTimeout = 10
                            End If
                            If objUser.Membership.LastLockoutDate < Date.Now.AddMinutes(-1 * intTimeout) Then
                                objUsers.UnlockUserAccount(objUser)
                                objUser.Membership.LockedOut = False
                            End If
                        End If
                    End If
                End If

                ' if the user is a super user we must set the ApplicationName
                If Not objUser Is Nothing AndAlso objUser.IsSuperUser Then
                    Common.Globals.SetApplicationName(Common.Globals.glbSuperUserAppName)
                End If

                ' initialize log record
                Dim objEventLogInfo As New Services.Log.EventLog.LogInfo
                Dim objSecurity As New PortalSecurity
                objEventLogInfo.AddProperty("IP", IP)
                objEventLogInfo.LogPortalID = PortalID
                objEventLogInfo.LogPortalName = PortalName
                objEventLogInfo.LogUserName = objSecurity.InputFilter(Username, PortalSecurity.FilterFlag.NoScripting Or PortalSecurity.FilterFlag.NoMarkup)
                objEventLogInfo.LogTypeKey = "LOGIN_FAILURE"

                ' validate user credentials against the global Membership data store
                If AspNetSecurity.Membership.ValidateUser(Username, Password) Then
                    ' the user exists in the global Membership store
                    If objUser Is Nothing Then
                        ' the user does not exist in the local store - this is because the user was 
                        ' created by a third party application which is leveraging the common global Membership
                        ' data store. Use lazy synchronization to create the user in the local data store.
                        objUser = New UserInfo
                        objUser.Username = Username
                        objUser.PortalID = PortalID
                        objUser.FirstName = ""
                        objUser.LastName = ""
                        objUser.AffiliateID = Null.NullInteger
                        objUser.IsSuperUser = False
                        objUser.UserID = objUsers.AddUser(objUser, False)
                    End If

                    ' check if user account is approved and not locked out ( these values are dynamically loaded from the global Membership data store )
                    If objUser.Membership.Approved = True And objUser.Membership.LockedOut = False Then
                        UserId = objUser.UserID
                    End If

                    ' set log type
                    If UserId <> -1 Then
                        If objUser.IsSuperUser Then
                            objEventLogInfo.LogTypeKey = "LOGIN_SUPERUSER"
                        Else
                            objEventLogInfo.LogTypeKey = "LOGIN_SUCCESS"
                        End If
                    End If
                End If

                ' create log record
                objEventLogInfo.LogUserID = UserId
                objEventLog.AddLog(objEventLogInfo)

                ' if the user is valid
                If UserId <> -1 Then
                    ' set the forms authentication cookie ( log the user in )
                    FormsAuthentication.SetAuthCookie(Username, CreatePersistentCookie)
                End If

            Finally
                ' reset the ApplicationName ( this should only be relevant for super users )
                Common.Globals.SetApplicationName(PortalID)
            End Try

            ' return the UserID
            Return UserId

        End Function

        Public Sub SignOut()
            ' Log User Off from Cookie Authentication System
            System.Web.Security.FormsAuthentication.SignOut()

            ' expire cookies
            HttpContext.Current.Response.Cookies("portalaliasid").Value = Nothing
            HttpContext.Current.Response.Cookies("portalaliasid").Path = "/"
            HttpContext.Current.Response.Cookies("portalaliasid").Expires = DateTime.Now.AddYears(-30)

            HttpContext.Current.Response.Cookies("portalroles").Value = Nothing
            HttpContext.Current.Response.Cookies("portalroles").Path = "/"
            HttpContext.Current.Response.Cookies("portalroles").Expires = DateTime.Now.AddYears(-30)
        End Sub

        Public Shared Function IsInRole(ByVal role As String) As Boolean

            Dim objUserInfo As UserInfo = UserController.GetCurrentUserInfo
            Dim context As HttpContext = HttpContext.Current

            If objUserInfo.IsSuperUser Or (role <> "" AndAlso Not role Is Nothing AndAlso _
               ((context.Request.IsAuthenticated = False And role = glbRoleUnauthUserName) Or _
               role = glbRoleAllUsersName _
               )) Then
                Return True
            Else
                'Check with the Roles Provider
                'to see if the user has the role
                If AspNetSecurity.Roles.IsUserInRole(role) Then
                    'Now check with the DNN roles to see
                    'if the user has the role because
                    'the ExpiryDate may have passed
                    'for the user's role
                    Dim strRoles As String
                    strRoles = Convert.ToString(HttpContext.Current.Items("UserRoles"))
                    If strRoles.IndexOf(";" + role + ";") >= 0 Then
                        Return True
                    End If
                End If
            End If
            Return False
        End Function

        Public Shared Function IsInRoles(ByVal roles As String) As Boolean
    
            If Not roles Is Nothing Then
               
                Dim context As HttpContext = HttpContext.Current

                Dim objUserInfo As UserInfo = UserController.GetCurrentUserInfo

                Dim role As String
                For Each role In roles.Split(New Char() {";"c})

                    If objUserInfo.IsSuperUser Or (role <> "" AndAlso Not role Is Nothing AndAlso _
                     ((context.Request.IsAuthenticated = False And role = glbRoleUnauthUserName) Or _
                     role = glbRoleAllUsersName Or _
                     IsInRole(role) = True _
                     )) Then
                        'context.User.IsInRole(role) = True Or _
                        Return True
                    End If

                Next role
            End If

            Return False

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Verifies edit permissions on a module
        ''' </summary>
        ''' <param name="objModulePermissions"></param>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[VMasanas]	07/12/2004	Changed to remove the check: if not visible not editable. 
        '''             Was causing trouble when inheritviewpermissions from tab was checked.
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function HasEditPermissions(ByVal objModulePermissions As Security.Permissions.ModulePermissionCollection) As Boolean

            Return Security.Permissions.ModulePermissionController.HasModulePermission(objModulePermissions, "EDIT")

        End Function

        Public Shared Function HasEditPermissions(ByVal ModuleId As Integer) As Boolean

            Dim objModulePermissionController As New Security.Permissions.ModulePermissionController
            Dim objModulePermissions As Security.Permissions.ModulePermissionCollection = objModulePermissionController.GetModulePermissionsCollectionByModuleID(ModuleId)
            Return HasEditPermissions(objModulePermissions)

        End Function

        Public Function Encrypt(ByVal strKey As String, ByVal strData As String) As String

            Dim strValue As String = ""

            If strKey <> "" Then
                ' convert key to 16 characters for simplicity
                Select Case Len(strKey)
                    Case Is < 16
                        strKey = strKey & Left("XXXXXXXXXXXXXXXX", 16 - Len(strKey))
                    Case Is > 16
                        strKey = Left(strKey, 16)
                End Select

                ' create encryption keys
                Dim byteKey() As Byte = Encoding.UTF8.GetBytes(Left(strKey, 8))
                Dim byteVector() As Byte = Encoding.UTF8.GetBytes(Right(strKey, 8))

                ' convert data to byte array
                Dim byteData() As Byte = Encoding.UTF8.GetBytes(strData)

                ' encrypt 
                Dim objDES As New DESCryptoServiceProvider
                Dim objMemoryStream As New MemoryStream
                Dim objCryptoStream As New CryptoStream(objMemoryStream, objDES.CreateEncryptor(byteKey, byteVector), CryptoStreamMode.Write)
                objCryptoStream.Write(byteData, 0, byteData.Length)
                objCryptoStream.FlushFinalBlock()

                ' convert to string and Base64 encode
                strValue = Convert.ToBase64String(objMemoryStream.ToArray())
            Else
                strValue = strData
            End If

            Return strValue

        End Function

        Public Function Decrypt(ByVal strKey As String, ByVal strData As String) As String

            Dim strValue As String = ""

            If strKey <> "" Then
                ' convert key to 16 characters for simplicity
                Select Case Len(strKey)
                    Case Is < 16
                        strKey = strKey & Left("XXXXXXXXXXXXXXXX", 16 - Len(strKey))
                    Case Is > 16
                        strKey = Left(strKey, 16)
                End Select

                ' create encryption keys
                Dim byteKey() As Byte = Encoding.UTF8.GetBytes(Left(strKey, 8))
                Dim byteVector() As Byte = Encoding.UTF8.GetBytes(Right(strKey, 8))

                ' convert data to byte array and Base64 decode
                Dim byteData(strData.Length) As Byte
                Try
                    byteData = Convert.FromBase64String(strData)
                Catch    ' invalid length
                    strValue = strData
                End Try

                If strValue = "" Then
                    Try
                        ' decrypt
                        Dim objDES As New DESCryptoServiceProvider
                        Dim objMemoryStream As New MemoryStream
                        Dim objCryptoStream As New CryptoStream(objMemoryStream, objDES.CreateDecryptor(byteKey, byteVector), CryptoStreamMode.Write)
                        objCryptoStream.Write(byteData, 0, byteData.Length)
                        objCryptoStream.FlushFinalBlock()

                        ' convert to string
                        Dim objEncoding As System.Text.Encoding = System.Text.Encoding.UTF8
                        strValue = objEncoding.GetString(objMemoryStream.ToArray())
                    Catch       ' decryption error
                        strValue = ""
                    End Try
                End If
            Else
                strValue = strData
            End If

            Return strValue

        End Function

        '''-----------------------------------------------------------------------------
        ''' <summary>
        ''' This function applies security filtering to the UserInput string.
        ''' </summary>
        ''' <param name="UserInput">This is the string to be filtered</param>
        ''' <param name="FilterType">Flags which designate the filters to be applied</param>
        ''' <returns>Filtered UserInput</returns>
        ''' <history>
        ''' 	[Joe Brinkman] 	8/15/2003	Created Bug #000120, #000121
        ''' </history>
        '''-----------------------------------------------------------------------------
        Public Function InputFilter(ByVal UserInput As String, ByVal FilterType As FilterFlag) As String
            If UserInput Is Nothing Then Return ""

            Dim TempInput As String = UserInput

            If (FilterType And FilterFlag.NoSQL) = FilterFlag.NoSQL Then
                TempInput = FormatRemoveSQL(TempInput)
            Else
                If (FilterType And FilterFlag.NoMarkup) = FilterFlag.NoMarkup Then
                    If IncludesMarkup(TempInput) Then
                        TempInput = HttpUtility.HtmlEncode(TempInput)
                    End If
                ElseIf (FilterType And FilterFlag.NoScripting) = FilterFlag.NoScripting Then
                    TempInput = FormatDisableScripting(TempInput)
                End If

                If (FilterType And FilterFlag.MultiLine) = FilterFlag.MultiLine Then
                    TempInput = FormatMultiLine(TempInput)
                End If
            End If

            Return TempInput
        End Function

        '''-----------------------------------------------------------------------------
        ''' <summary>
        ''' This filter removes CrLf characters and inserts br
        ''' </summary>
        ''' <param name="strInput">This is the string to be filtered</param>
        ''' <returns>Filtered UserInput</returns>
        ''' <remarks>
        ''' This is a private function that is used internally by the InputFilter function
        ''' </remarks>
        ''' <history>
        ''' 	[Joe Brinkman] 	8/15/2003	Created Bug #000120
        ''' </history>
        '''-----------------------------------------------------------------------------
        Private Function FormatMultiLine(ByVal strInput As String) As String
            Dim TempInput As String = strInput.Replace(ControlChars.Cr + ControlChars.Lf, "<br>")
            Return TempInput.Replace(ControlChars.Cr, "<br>")
        End Function    'FormatMultiLine

        '''-----------------------------------------------------------------------------
        ''' <summary>
        ''' This function uses Regex search strings to remove HTML tags which are 
        ''' targeted in Cross-site scripting (XSS) attacks.  This function will evolve
        ''' to provide more robust checking as additional holes are found.
        ''' </summary>
        ''' <param name="strInput">This is the string to be filtered</param>
        ''' <returns>Filtered UserInput</returns>
        ''' <remarks>
        ''' This is a private function that is used internally by the InputFilter function
        ''' </remarks>
        ''' <history>
        ''' 	[Joe Brinkman] 	8/15/2003	Created Bug #000120
        ''' </history>
        '''-----------------------------------------------------------------------------
        Private Function FormatDisableScripting(ByVal strInput As String) As String
            Dim TempInput As String = strInput

            Dim options As RegexOptions = RegexOptions.IgnoreCase Or RegexOptions.Singleline
            Dim strReplacement As String = " "
          
            TempInput = Regex.Replace(TempInput, "<script[^>]*>.*?</script[^><]*>", strReplacement, options)
            TempInput = Regex.Replace(TempInput, "<input[^>]*>.*?</input[^><]*>", strReplacement, options)
            TempInput = Regex.Replace(TempInput, "<object[^>]*>.*?</object[^><]*>", strReplacement, options)
            TempInput = Regex.Replace(TempInput, "<embed[^>]*>.*?</embed[^><]*>", strReplacement, options)
            TempInput = Regex.Replace(TempInput, "<applet[^>]*>.*?</applet[^><]*>", strReplacement, options)
            TempInput = Regex.Replace(TempInput, "<form[^>]*>.*?</form[^><]*>", strReplacement, options)
            TempInput = Regex.Replace(TempInput, "<option[^>]*>.*?</option[^><]*>", strReplacement, options)
            TempInput = Regex.Replace(TempInput, "<select[^>]*>.*?</select[^><]*>", strReplacement, options)
            TempInput = Regex.Replace(TempInput, "<iframe[^>]*>.*?</iframe[^><]*>", strReplacement, options)
            TempInput = Regex.Replace(TempInput, "<ilayer[^>]*>.*?</ilayer[^><]*>", strReplacement, options)
            TempInput = Regex.Replace(TempInput, "<form[^>]*>", strReplacement, options)
            TempInput = Regex.Replace(TempInput, "</form[^><]*>", strReplacement, options)
            TempInput = Regex.Replace(TempInput, "javascript:", strReplacement, options)
            TempInput = Regex.Replace(TempInput, "vbscript:", strReplacement, options)

            Return TempInput

        End Function    'FormatDisableScripting

        '''-----------------------------------------------------------------------------
        ''' <summary>
        ''' This function verifies raw SQL statements to prevent SQL injection attacks 
        ''' and replaces a similar function (PreventSQLInjection) from the Common.Globals.vb module
        ''' </summary>
        ''' <param name="strSQL">This is the string to be filtered</param>
        ''' <returns>Filtered UserInput</returns>
        ''' <remarks>
        ''' This is a private function that is used internally by the InputFilter function
        ''' </remarks>
        ''' <history>
        ''' 	[Joe Brinkman] 	8/15/2003	Created Bug #000121
        '''     [Tom Lucas]     3/8/2004    Fixed   Bug #000114 (Aardvark)
        ''' </history>
        '''-----------------------------------------------------------------------------
        Private Function FormatRemoveSQL(ByVal strSQL As String) As String

            Dim strCleanSQL As String = strSQL

            If strSQL <> Nothing Then

                Dim BadCommands As Array = Split(";,--,create,drop,select,insert,delete,update,union,sp_,xp_", ",")

                ' strip any dangerous SQL commands
                Dim intCommand As Integer
                For intCommand = 0 To BadCommands.Length - 1
                    strCleanSQL = Regex.Replace(strCleanSQL, Convert.ToString(BadCommands.GetValue(intCommand)), " ", RegexOptions.IgnoreCase)
                Next

                ' convert any single quotes
                strCleanSQL = Replace(strCleanSQL, "'", "''")
            End If

            Return strCleanSQL

        End Function

        '''-----------------------------------------------------------------------------
        ''' <summary>
        ''' This function determines if the Input string contains any markup.
        ''' </summary>
        ''' <param name="strInput">This is the string to be checked</param>
        ''' <returns>True if string contains Markup tag(s)</returns>
        ''' <remarks>
        ''' This is a private function that is used internally by the InputFilter function
        ''' </remarks>
        ''' <history>
        ''' 	[Joe Brinkman] 	8/15/2003	Created Bug #000120
        ''' </history>
        '''-----------------------------------------------------------------------------
        Private Function IncludesMarkup(ByVal strInput As String) As Boolean
            Dim options As RegexOptions = RegexOptions.IgnoreCase Or RegexOptions.Singleline
            Dim strPattern As String = "<[^<>]*>"
            Return Regex.IsMatch(strInput, strPattern, options)
        End Function

        '''-----------------------------------------------------------------------------
        ''' <summary>
        ''' Determines is user has the necessary permissions to access the an item with the
        ''' designated AccessLevel.
        ''' </summary>
        ''' <param name="AccessLevel">The SecurityAccessLevel required to access a portal module or module action.</param>
        ''' <param name="PortalSettings">The PortalSettings for the current portal.</param>
        ''' <param name="ModuleConfiguration">The ModuleInfo object for the associated module.</param>
        ''' <param name="UserName">The Context.User.Identity.Name of the currently logged in user.</param>
        ''' <returns>A boolean value indicating if the user has the necessary permissions</returns>
        ''' <remarks>Every module control and module action has an associated permission level.  This
        ''' function determines whether the user represented by UserName has sufficient permissions, as
        ''' determined by the PortalSettings and ModuleSettings, to access a resource with the 
        ''' designated AccessLevel.</remarks>
        ''' <history>
        ''' 	[jbrinkman] 	12/21/2003	Created
        ''' </history>
        '''-----------------------------------------------------------------------------
        Public Shared Function HasNecessaryPermission(ByVal AccessLevel As SecurityAccessLevel, ByVal PortalSettings As PortalSettings, ByVal ModuleConfiguration As ModuleInfo, ByVal UserName As String) As Boolean
            Dim blnAuthorized As Boolean = True
            Select Case AccessLevel
                Case SecurityAccessLevel.Anonymous
                    blnAuthorized = True
                Case SecurityAccessLevel.View     ' view
                    If PortalSecurity.IsInRole(PortalSettings.AdministratorRoleName.ToString) = False _
                     And PortalSecurity.IsInRoles(PortalSettings.ActiveTab.AdministratorRoles.ToString) = False Then
                        If Not PortalSecurity.IsInRoles(ModuleConfiguration.AuthorizedViewRoles) Then
                            blnAuthorized = False
                        End If
                    End If
                Case SecurityAccessLevel.Edit     ' edit
                    If PortalSecurity.IsInRole(PortalSettings.AdministratorRoleName.ToString) = False _
                     And PortalSecurity.IsInRoles(PortalSettings.ActiveTab.AdministratorRoles.ToString) = False Then
                        If Not PortalSecurity.IsInRoles(ModuleConfiguration.AuthorizedViewRoles) Then
                            blnAuthorized = False
                        Else
                            If Not PortalSecurity.HasEditPermissions(ModuleConfiguration.ModulePermissions) Then
                                blnAuthorized = False
                            End If
                        End If
                    End If
                Case SecurityAccessLevel.Admin     ' admin
                    If PortalSecurity.IsInRole(PortalSettings.AdministratorRoleName.ToString) = False _
                     And PortalSecurity.IsInRoles(PortalSettings.ActiveTab.AdministratorRoles.ToString) = False Then
                        blnAuthorized = False
                    End If
                Case SecurityAccessLevel.Host     ' host
                    If UserName.Length > 0 Then
                        Dim objUserInfo As UserInfo = UserController.GetCurrentUserInfo
                        If Not objUserInfo.IsSuperUser Then
                            blnAuthorized = False
                        End If
                    Else       ' no longer logged in
                        blnAuthorized = False
                    End If
            End Select
            Return blnAuthorized
        End Function

        '''-----------------------------------------------------------------------------
        ''' <summary>
        ''' This function creates a random key
        ''' </summary>
        ''' <param name="numBytes">This is the number of bytes for the key</param>
        ''' <returns>A random string</returns>
        ''' <remarks>
        ''' This is a public function used for generating SHA1 keys 
        ''' </remarks>
        ''' <history>
        ''' </history>
        '''-----------------------------------------------------------------------------
        Public Function CreateKey(ByVal numBytes As Integer) As String
            Dim rng As New RNGCryptoServiceProvider
            Dim buff(numBytes - 1) As Byte

            rng.GetBytes(buff)

            Return BytesToHexString(buff)
        End Function

        '''-----------------------------------------------------------------------------
        ''' <summary>
        ''' This function converts a byte array to a hex string
        ''' </summary>
        ''' <param name="bytes">An array of bytes</param>
        ''' <returns>A string representing the hex converted value</returns>
        ''' <remarks>
        ''' This is a private function that is used internally by the CreateKey function
        ''' </remarks>
        ''' <history>
        ''' </history>
        '''-----------------------------------------------------------------------------
        Private Function BytesToHexString(ByVal bytes() As Byte) As String
            Dim hexString As New StringBuilder(64)

            Dim counter As Integer
            For counter = 0 To bytes.Length - 1
                hexString.Append([String].Format("{0:X2}", bytes(counter)))
            Next counter

            Return hexString.ToString()
        End Function

    End Class

End Namespace