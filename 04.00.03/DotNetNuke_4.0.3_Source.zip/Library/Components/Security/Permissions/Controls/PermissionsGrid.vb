'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.Drawing
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.IO
Imports System.Collections
Imports System.Data


Namespace DotNetNuke.Security.Permissions.Controls

    Public MustInherit Class PermissionsGrid
        Inherits DataGrid

        Private _roles As String()
        Private _Permissions As ArrayList

        Public Sub New()

			'AddHandler ItemDataBound, AddressOf DataGridItemBind
            AutoGenerateColumns = False
            CellSpacing = 0
            Font.Size = FontUnit.XSmall
            Font.Name = "Verdana"
            BorderStyle = WebControls.BorderStyle.None
            BorderWidth = New Unit(1)
            GridLines = WebControls.GridLines.None
			FooterStyle.BackColor = Color.White
            HeaderStyle.ForeColor = Color.Black
			HeaderStyle.BackColor = Color.White
            HeaderStyle.Font.Bold = True


        End Sub

        Public MustOverride Sub GenerateDataGrid()

        Public Property DynamicColumnAdded() As Boolean
            Get
                If ViewState("ColumnAdded") Is Nothing Then
                    Return False
                Else
                    Return True
                End If
            End Get
            Set(ByVal Value As Boolean)
                ViewState("ColumnAdded") = Value
            End Set
        End Property

        Protected Overrides Sub LoadViewState(ByVal savedState As Object)
            MyBase.LoadViewState(savedState)
            If Me.DynamicColumnAdded Then
                Me.GenerateDataGrid()
            End If
        End Sub

        'Uncomment this section if you want to 
        'highlight the system roles with
        'a different color.
        'Also uncomment above: AddHandler ItemDataBound, AddressOf DataGridItemBind

        '  Protected Sub DataGridItemBind(ByVal sender As Object, ByVal e As DataGridItemEventArgs)
        '      Dim itemType As ListItemType = e.Item.ItemType
        '      If itemType = ListItemType.Item Or itemType = ListItemType.SelectedItem Or itemType = ListItemType.AlternatingItem Then
        '          Select Case e.Item.Cells(0).Text.ToLower
        '              Case Common.Globals.glbRoleAllUsersName.ToLower, Common.Globals.glbRoleUnauthUserName.ToLower, "administrators", "registered users"
        '                  'these are built-in system roles
        'e.Item.BackColor = Color.WhiteSmoke
        '              Case Else
        '                  e.Item.BackColor = Color.White
        '          End Select
        '      End If
        '  End Sub

    End Class


End Namespace