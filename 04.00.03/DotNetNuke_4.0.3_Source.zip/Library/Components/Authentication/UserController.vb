'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Namespace DotNetNuke.Security.Authentication

    Public Class UserController

        Private mProviderTypeName As String = ""

        Sub New()
            Dim _config As Authentication.Configuration = Authentication.Configuration.GetConfig()
            mProviderTypeName = _config.ProviderTypeName
        End Sub

        ''' -------------------------------------------------------------------
        ''' <summary>
        '''     User object with info obtained from Active Directory
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        '''     [tamttt]	08/01/2004	Created
        ''' </history>
        ''' -------------------------------------------------------------------
        Public Function GetUser(ByVal LoggedOnUserName As String) As Authentication.UserInfo
            Return AuthenticationProvider.Instance(mProviderTypeName).GetUser(LoggedOnUserName)
        End Function

        ''' -------------------------------------------------------------------
        ''' <summary>
        '''     User object with info obtained from Active Directory
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        '''     [tamttt]	08/01/2004	Created
        ''' </history>
        ''' -------------------------------------------------------------------
        Public Function GetUser(ByVal LoggedOnUserName As String, ByVal LoggedOnPassword As String) As Authentication.UserInfo
            Return AuthenticationProvider.Instance(mProviderTypeName).GetUser(LoggedOnUserName, LoggedOnPassword)
        End Function

        ''' -------------------------------------------------------------------
        ''' <summary>
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        '''     [tamttt]	08/01/2004	Created 
        ''' </history>
        ''' -------------------------------------------------------------------
        Public Function AddDNNUser(ByVal AuthenticationUser As Authentication.UserInfo) As Integer
            Dim _portalSettings As PortalSettings = PortalController.GetCurrentPortalSettings
            Dim objSecurity As New PortalSecurity

            Dim objDNNUsers As New DotNetNuke.Entities.Users.UserController
            Dim objAuthUsers As New Authentication.UserController

            Dim objDNNUser As DotNetNuke.Entities.Users.UserInfo = CType(AuthenticationUser, DotNetNuke.Entities.Users.UserInfo)
            Dim AffiliateId As Integer = -1

            If Not HttpContext.Current.Request.Cookies("AffiliateId") Is Nothing Then
                AffiliateId = Integer.Parse(HttpContext.Current.Request.Cookies("AffiliateId").Value)
            End If

            Dim UserID As Integer = -1
            UserID = objDNNUsers.AddUser(objDNNUser)

            If AuthenticationUser.AuthenticationExists AndAlso UserID > -1 Then
                AuthenticationUser.UserID = UserID
                UserController.AddUserRoles(_portalSettings.PortalId, AuthenticationUser)
            End If

            Return UserID
        End Function

        ''' -------------------------------------------------------------------
        ''' <summary>
        ''' </summary>
        ''' <remarks>
        ''' This routine is more accurated, 
        ''' Prevent user assign to admin role in case user logon as LOCAL\Administrator
        ''' </remarks>
        ''' <history>
        '''     [tamttt]	08/01/2004	Created
        ''' </history>
        ''' -------------------------------------------------------------------
        Public Overloads Shared Sub AddUserRoles(ByVal PortalID As Integer, ByVal AuthenticationUser As Authentication.UserInfo)
            Dim objGroupController As New GroupController
            Dim colGroup As ArrayList = objGroupController.GetGroups()
            Dim objRoles As New DotNetNuke.Security.Roles.RoleController
            Dim authenticationGroup As Authentication.GroupInfo
            Try
                For Each authenticationGroup In colGroup
                    If objGroupController.IsAuthenticationMember(authenticationGroup, AuthenticationUser) Then
                        objRoles.AddUserRole(PortalID, AuthenticationUser.UserID, authenticationGroup.RoleID, Null.NullDate)
                    End If
                Next

            Catch exc As Exception
                LogException(exc)
            End Try
        End Sub

    End Class

End Namespace
