'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports DotNetNuke.Entities.Modules
Imports DotNetNuke.Framework.Providers

Namespace DotNetNuke.Security.Authentication

#Region "Enum"
    ''' -------------------------------------------------------------------
    ''' <summary>
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    '''     [tamttt]	08/01/2004	Created
    ''' </history>
    ''' -------------------------------------------------------------------
    Public Enum ObjectClass As Integer
        domainDNS '= 203
        person '= 210
        user '= 211
        group '= 212
        contact '= 213
        computer '= 214
        printer '= 215
        crossRef '= 216
    End Enum

    ''' -------------------------------------------------------------------
    ''' <summary>
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    '''     [tamttt]	08/01/2004	Created
    ''' </history>
    ''' -------------------------------------------------------------------
    Public Enum AuthenticationMode As Integer
        FormAuthentication
        WindowsAuthentication
        MixedAuthentication
        FormAndAuthentication
    End Enum

    ''' -------------------------------------------------------------------
    ''' <summary>
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    '''     [tamttt]	08/01/2004	Created
    ''' </history>
    ''' -------------------------------------------------------------------
    Public Enum AuthenticationStatus As Integer
        Undefined
        WinProcess
        WinLogon
        WinLogoff
    End Enum

#End Region ' Enum

    Public Class Configuration

        Public Const AUTHENTICATION_LOGON_PAGE As String = "WindowsSignin.aspx"
        Public Const AUTHENTICATION_LOGOFF_PAGE As String = "Logoff.aspx"
        Public Const AUTHENTICATION_KEY As String = "authentication"
        Public Const AUTHENTICATION_STATUS_KEY As String = "authentication.status"
        Public Const LOGON_USER_VARIABLE As String = "LOGON_USER"
        '
        Private Const AUTHENTICATION_CONFIG_CACHE_PREFIX As String = "Authentication.Configuration"

        Private mPortalId As Integer
        Private mWindowsAuthentication As Boolean = False
        Private mRootDomain As String = ""
        Private mUserName As String = ""
        Private mPassword As String = ""
        Private mSynchronizeRole As Boolean = False
        Private mSynchronizePassword As Boolean = False ' reserve for future feature
        Private mProviderTypeName As String = DefaultProviderTypeName
        Private mAuthenticationType As String = DefaultAuthenticationType
        Private mEmailDomain As String = DefaultEmailDomain

        ''' -------------------------------------------------------------------
        ''' <summary>
        ''' - Obtain Authentication settings from database
        ''' </summary>
        ''' <remarks>
        ''' - Setting records are stored in ModuleSettings table, separately for each portal,
        ''' this method allows each portal could have different accessing method to Windows Active Directory
        ''' </remarks>
        ''' <history>
        '''     [tamttt]	08/01/2004	Created
        ''' </history>
        ''' -------------------------------------------------------------------        
        Sub New()
            Dim _portalSettings As PortalSettings = PortalController.GetCurrentPortalSettings
            Dim _providerConfiguration As ProviderConfiguration = ProviderConfiguration.GetProviderConfiguration(AUTHENTICATION_KEY)

            mPortalId = _portalSettings.PortalId

            Dim objSecurity As New PortalSecurity
            Try
                If _providerConfiguration.DefaultProvider Is Nothing Then
                    ' No provider specified, so disable authentication feature
                    Return
                Else
                    Dim objModules As New ModuleController
                    Dim objModuleInfo As ModuleInfo = objModules.GetModuleByDefinition(mPortalId, "Site Settings")
                    Dim settings As Hashtable = PortalSettings.GetModuleSettings(objModuleInfo.ModuleID)

                    mWindowsAuthentication = CType(Null.GetNull(settings("WindowsAuthentication"), mWindowsAuthentication), Boolean)
                    mSynchronizeRole = CType(Null.GetNull(settings("SynchronizeRole"), mSynchronizeRole), Boolean)
                    mSynchronizePassword = CType(Null.GetNull(settings("SynchronizePassword"), mSynchronizePassword), Boolean)
                    mRootDomain = CType(Null.GetNull(settings("RootDomain"), mRootDomain), String)
                    mEmailDomain = CType(Null.GetNull(settings("EmailDomain"), mEmailDomain), String)
                    mUserName = CType(Null.GetNull(settings("UserName"), mUserName), String)
                    mProviderTypeName = CType(Null.GetNull(settings("ProviderTypeName"), mProviderTypeName), String)
                    mAuthenticationType = CType(Null.GetNull(settings("AuthenticationType"), mAuthenticationType), String)
                    ' Since DNN 3.0, HostSettings("EncryptionKey") is empty string, so we handle by AUTHENTICATION_KEY 
                    mPassword = objSecurity.Decrypt(AUTHENTICATION_KEY, CType(Null.GetNull(settings("AuthenticationPassword"), mPassword.ToString), String))
                    'mPassword = objSecurity.Decrypt(CStr(_portalSettings.HostSettings("EncryptionKey")), CType(GetValue(settings("AuthenticationPassword"), mPassword.ToString), String))

                End If
            Catch ex As Exception
            End Try

        End Sub

        ''' -------------------------------------------------------------------
        ''' <summary>
        ''' Obtain Authentication Configuration
        ''' </summary>
        ''' <remarks>
        ''' Accessing Active Directory also costs resource, 
        ''' so we only do it once then save into cache for later use
        ''' </remarks>
        ''' <history>
        '''     [tamttt]	08/01/2004	Created
        ''' </history>
        ''' -------------------------------------------------------------------
        Public Shared Function GetConfig() As Authentication.Configuration
            Dim _portalSettings As PortalSettings = PortalController.GetCurrentPortalSettings

            Dim strKey As String = AUTHENTICATION_CONFIG_CACHE_PREFIX & "." & CStr(_portalSettings.PortalId)
            Dim config As Authentication.Configuration = CType(DataCache.GetCache(strKey), Authentication.Configuration)

            If config Is Nothing Then
                config = New Authentication.Configuration
                DataCache.SetCache(strKey, config)
            End If

            Return config

        End Function

        ''' -------------------------------------------------------------------
        ''' <summary>
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        '''     [tamttt]	08/01/2004	Created
        ''' </history>
        ''' -------------------------------------------------------------------
        Public Shared Sub ResetConfig()
            Dim _portalSettings As PortalSettings = PortalController.GetCurrentPortalSettings

            Dim strKey As String = AUTHENTICATION_CONFIG_CACHE_PREFIX & "." & CStr(_portalSettings.PortalId)
            DataCache.RemoveCache(strKey)
        End Sub

        ''' -------------------------------------------------------------------
        ''' <summary>
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        '''     [tamttt]	08/01/2004	Created
        ''' </history>
        ''' -------------------------------------------------------------------
        Public Shared Sub UpdateConfig(ByVal PortalID As Integer, _
        ByVal WindowsAuthentication As Boolean, _
        ByVal RootDomain As String, _
        ByVal EmailDomain As String, _
        ByVal AuthenticationUserName As String, _
        ByVal AuthenticationPassword As String, _
        ByVal SynchronizeRole As Boolean, _
        ByVal SynchronizePassword As Boolean, _
        ByVal ProviderTypeName As String, _
        ByVal AuthenticationType As String)

            Dim _portalSettings As PortalSettings = PortalController.GetCurrentPortalSettings
            Dim objModules As New ModuleController
            Dim objSecurity As New PortalSecurity
            Dim objModuleInfo As ModuleInfo = objModules.GetModuleByDefinition(PortalID, "Site Settings")
            Dim intModuleId As Integer = objModuleInfo.ModuleID

            objModules.UpdateModuleSetting(intModuleId, "WindowsAuthentication", WindowsAuthentication.ToString)
            objModules.UpdateModuleSetting(intModuleId, "SynchronizeRole", SynchronizeRole.ToString)
            objModules.UpdateModuleSetting(intModuleId, "SynchronizePassword", SynchronizePassword.ToString)
            objModules.UpdateModuleSetting(intModuleId, "RootDomain", RootDomain)
            objModules.UpdateModuleSetting(intModuleId, "EmailDomain", EmailDomain)
            objModules.UpdateModuleSetting(intModuleId, "UserName", AuthenticationUserName)
            objModules.UpdateModuleSetting(intModuleId, "ProviderTypeName", ProviderTypeName)
            objModules.UpdateModuleSetting(intModuleId, "AuthenticationType", AuthenticationType)

            'Only update password if it has been changed
            If AuthenticationPassword.Length > 0 Then
                objModules.UpdateModuleSetting(intModuleId, "AuthenticationPassword", Convert.ToString(objSecurity.Encrypt(AUTHENTICATION_KEY, AuthenticationPassword)))
            End If

        End Sub

        ''' -------------------------------------------------------------------
        ''' <summary>
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        '''     [tamttt]	08/01/2004	Created
        ''' </history>
        ''' -------------------------------------------------------------------
        Public Shared ReadOnly Property DefaultProviderTypeName() As String
            Get
                Return "DotNetNuke.Security.Authentication.ADSIProvider, DotNetNuke.Authentication.ADSIProvider"
            End Get
        End Property

        ''' -------------------------------------------------------------------
        ''' <summary>
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        '''     [tamttt]	08/01/2004	Created
        ''' </history>
        ''' -------------------------------------------------------------------
        Public Shared ReadOnly Property DefaultAuthenticationType() As String
            Get
                Return "Delegation"
            End Get
        End Property

        ''' -------------------------------------------------------------------
        ''' <summary>
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        '''     [tamttt]	08/01/2004	Created
        ''' </history>
        ''' -------------------------------------------------------------------
        Public Shared ReadOnly Property DefaultEmailDomain() As String
            Get
                Dim _portalSettings As PortalSettings = PortalController.GetCurrentPortalSettings
                Dim _portalEmail As String = _portalSettings.Email
                Return _portalEmail.Substring(_portalEmail.IndexOf("@"))
            End Get
        End Property

        ''' -------------------------------------------------------------------
        ''' <summary>
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        '''     [tamttt]	08/01/2004	Created
        ''' </history>
        ''' -------------------------------------------------------------------
        Public ReadOnly Property WindowsAuthentication() As Boolean
            Get
                Return mWindowsAuthentication
            End Get
        End Property

        ''' -------------------------------------------------------------------
        ''' <summary>
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        '''     [tamttt]	08/01/2004	Created
        ''' </history>
        ''' -------------------------------------------------------------------
        Public ReadOnly Property RootDomain() As String
            Get
                Return mRootDomain
            End Get
        End Property

        ''' -------------------------------------------------------------------
        ''' <summary>
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        '''     [tamttt]	08/01/2004	Created
        ''' </history>
        ''' -------------------------------------------------------------------
        Public ReadOnly Property UserName() As String
            Get
                Return mUserName
            End Get
        End Property

        ''' -------------------------------------------------------------------
        ''' <summary>
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        '''     [tamttt]	08/01/2004	Created
        ''' </history>
        ''' -------------------------------------------------------------------
        Public ReadOnly Property Password() As String
            Get
                Return mPassword
            End Get
        End Property

        ''' -------------------------------------------------------------------
        ''' <summary>
        ''' Role membership to be synchronized (Authentication/DNN) when user logon
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        '''     [tamttt]	08/01/2004	Created
        ''' </history>
        ''' -------------------------------------------------------------------
        Public ReadOnly Property SynchronizeRole() As Boolean
            Get
                Return mSynchronizeRole
            End Get
        End Property

        ''' -------------------------------------------------------------------
        ''' <summary>
        '''     Process checking DNN password against Windows password
        '''     update DNN password if not match
        '''     requires modified signin page for functionality
        ''' </summary>
        ''' <remarks>
        '''     This process quite expensive in terms of performance
        '''     Reserve for future implementation
        ''' </remarks>
        ''' <history>
        '''     [tamttt]	08/01/2005	Created
        ''' </history>
        ''' -------------------------------------------------------------------
        Public ReadOnly Property SynchronizePassword() As Boolean
            Get
                Return mSynchronizePassword
            End Get
        End Property

        ''' -------------------------------------------------------------------
        ''' <summary>
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        '''     [tamttt]	08/01/2004	Created
        ''' </history>
        ''' -------------------------------------------------------------------
        Public ReadOnly Property PortalId() As Integer
            Get
                Return mPortalId
            End Get
        End Property

        ''' -------------------------------------------------------------------
        ''' <summary>
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        '''     [tamttt]	08/01/2004	Created
        ''' </history>
        ''' -------------------------------------------------------------------
        Public ReadOnly Property ProviderTypeName() As String
            Get
                Return mProviderTypeName
            End Get
        End Property

        ''' -------------------------------------------------------------------
        ''' <summary>
        ''' </summary>
        ''' <remarks>
        '''     It was configured in web.config, move to site settings is more flexible
        '''     When configure first time, only default provider (ADs) available to provide list of type to select 
        ''' </remarks>
        ''' <history>
        '''     [tamttt]	08/01/2005	Created
        ''' </history>
        ''' -------------------------------------------------------------------
        Public ReadOnly Property AuthenticationType() As String
            Get
                Return mAuthenticationType
            End Get
        End Property

        ''' -------------------------------------------------------------------
        ''' <summary>
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        '''     [tamttt]	08/01/2004	Created
        ''' </history>
        ''' -------------------------------------------------------------------
        Public ReadOnly Property EmailDomain() As String
            Get
                Return mEmailDomain
            End Get
        End Property

        ''' -------------------------------------------------------------------
        ''' <summary>
        ''' Used to determine if a valid input is provided, if not, return default value
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        '''     [tamttt]	08/01/2004	Created
        '''     [tamttt]    08/20/2005  Replace by core Null.GetNull function
        ''' </history>
        ''' -------------------------------------------------------------------
        Private Function GetValue(ByVal Input As Object, ByVal DefaultValue As String) As String
            If Input Is Nothing Then
                Return DefaultValue
            Else
                Return CStr(Input)
            End If
        End Function

    End Class


End Namespace
