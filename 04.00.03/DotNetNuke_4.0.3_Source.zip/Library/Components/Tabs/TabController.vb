'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.Configuration
Imports System.Data
Imports System.Globalization

Imports DotNetNuke.Entities.Modules
Imports DotNetNuke.Entities.Portals

Namespace DotNetNuke.Entities.Tabs

    Public Class TabController
#Region "Helper structure for sorting tabs"
        Private Structure TabOrderHelper
            Public TabOrder As Integer
            Public Level As Integer
            Public ParentId As Integer

            Public Sub New(ByVal inttaborder As Integer, ByVal intlevel As Integer, ByVal intparentid As Integer)
                TabOrder = inttaborder
                Level = intlevel
                ParentId = intparentid
            End Sub
        End Structure
#End Region

        Public Sub UpdatePortalTabOrder(ByVal PortalId As Integer, ByVal TabId As Integer, ByVal NewParentId As Integer, ByVal Level As Integer, ByVal Order As Integer, ByVal IsVisible As Boolean, Optional ByVal NewTab As Boolean = False)

            Dim objTab As TabInfo

            Dim intCounter As Integer = 0
            Dim intFromIndex As Integer = -1
            Dim intOldParentId As Integer = -2
            Dim intToIndex As Integer = -1
            Dim intNewParentIndex As Integer = 0
            Dim intLevel As Integer
            Dim intAddTabLevel As Integer

            Dim objPortals As New PortalController
            Dim objPortal As PortalInfo = objPortals.GetPortal(PortalId)

            'hashtable to prevent db calls when no change
            Dim htabs As New Hashtable

            ' create temporary tab collection
            Dim objTabs As New ArrayList

            ' populate temporary tab collection
            Dim arrTabs As ArrayList = GetTabs(PortalId)
            For Each objTab In arrTabs
                If NewTab = False Or objTab.TabID <> TabId Then
                    ' save old data
                    htabs.Add(objTab.TabID, New TabOrderHelper(objTab.TabOrder, objTab.Level, objTab.ParentId))

                    If objTab.TabOrder = 0 Then
                        objTab.TabOrder = 999
                    End If
                    objTabs.Add(objTab)
                    If objTab.TabID = TabId Then
                        intOldParentId = objTab.ParentId
                        intFromIndex = intCounter
                    End If
                    If objTab.TabID = NewParentId Then
                        intNewParentIndex = intCounter
                        intAddTabLevel = objTab.Level + 1
                    End If
                    intCounter += 1
                End If
            Next

            If NewParentId <> -2 Then    ' not deleted
                ' adding new tab
                If intFromIndex = -1 Then
                    objTab = New TabInfo
                    objTab.TabID = TabId
                    objTab.ParentId = NewParentId
                    objTab.IsVisible = IsVisible
                    objTab.Level = intAddTabLevel
                    objTabs.Add(objTab)
                    intFromIndex = objTabs.Count - 1
                End If

                If Level = 0 And Order = 0 Then
                    CType(objTabs(intFromIndex), TabInfo).IsVisible = IsVisible
                End If
            End If

            If NewParentId <> -2 Then    ' not deleted
                ' if the parent changed or we added a new non root level tab
                If intOldParentId <> NewParentId And Not (intOldParentId = -2 And NewParentId = -1) Then
                    ' locate position of last child for new parent
                    If NewParentId <> -1 Then
                        intLevel = CType(objTabs(intNewParentIndex), TabInfo).Level
                    Else
                        intLevel = -1
                    End If

                    intCounter = intNewParentIndex + 1
                    While intCounter <= objTabs.Count - 1
                        If CType(objTabs(intCounter), TabInfo).Level > intLevel Then
                            intToIndex = intCounter
                        Else
                            Exit While
                        End If
                        intCounter += 1
                    End While
                    ' adding to parent with no children
                    If intToIndex = -1 Then
                        intToIndex = intNewParentIndex
                    End If
                    ' move tab
                    CType(objTabs(intFromIndex), TabInfo).ParentId = NewParentId
                    MoveTab(objTabs, intFromIndex, intToIndex, intLevel + 1)
                Else
                    ' if level has changed
                    If Level <> 0 Then
                        intLevel = CType(objTabs(intFromIndex), TabInfo).Level

                        Dim blnValid As Boolean = True
                        Select Case Level
                            Case -1
                                If intLevel = 0 Then
                                    blnValid = False
                                End If
                            Case 1
                                If intFromIndex > 0 Then
                                    If intLevel > CType(objTabs(intFromIndex - 1), TabInfo).Level Then
                                        blnValid = False
                                    End If
                                Else
                                    blnValid = False
                                End If
                        End Select

                        If blnValid Then
                            Dim intNewLevel As Integer
                            If Level = -1 Then
                                intNewLevel = intLevel + Level
                            Else
                                intNewLevel = intLevel
                            End If

                            ' get new parent
                            NewParentId = -2
                            intCounter = intFromIndex - 1
                            While intCounter >= 0 And NewParentId = -2
                                If CType(objTabs(intCounter), TabInfo).Level = intNewLevel Then
                                    If Level = -1 Then
                                        NewParentId = CType(objTabs(intCounter), TabInfo).ParentId
                                    Else
                                        NewParentId = CType(objTabs(intCounter), TabInfo).TabID
                                    End If
                                    intNewParentIndex = intCounter
                                End If
                                intCounter -= 1
                            End While
                            CType(objTabs(intFromIndex), TabInfo).ParentId = NewParentId

                            If Level = -1 Then
                                ' locate position of next child for parent
                                intToIndex = -1
                                intCounter = intNewParentIndex + 1
                                While intCounter <= objTabs.Count - 1
                                    If CType(objTabs(intCounter), TabInfo).Level > intNewLevel Then
                                        intToIndex = intCounter
                                    Else
                                        Exit While
                                    End If
                                    intCounter += 1
                                End While
                                ' adding to parent with no children
                                If intToIndex = -1 Then
                                    intToIndex = intNewParentIndex
                                End If
                            Else
                                intToIndex = intFromIndex - 1
                                intNewLevel = intLevel + Level
                            End If

                            ' move tab
                            If intFromIndex = intToIndex Then
                                CType(objTabs(intFromIndex), TabInfo).Level = intNewLevel
                            Else
                                MoveTab(objTabs, intFromIndex, intToIndex, intNewLevel)
                            End If
                        End If
                    Else
                        ' if order has changed
                        If Order <> 0 Then
                            intLevel = CType(objTabs(intFromIndex), TabInfo).Level

                            ' find previous/next item for parent
                            intToIndex = -1
                            intCounter = intFromIndex + Order
                            While intCounter >= 0 And intCounter <= objTabs.Count - 1 And intToIndex = -1
                                If CType(objTabs(intCounter), TabInfo).ParentId = NewParentId Then
                                    intToIndex = intCounter
                                End If
                                intCounter += Order
                            End While
                            If intToIndex <> -1 Then
                                If Order = 1 Then
                                    ' locate position of next child for parent
                                    intNewParentIndex = intToIndex
                                    intToIndex = -1
                                    intCounter = intNewParentIndex + 1
                                    While intCounter <= objTabs.Count - 1
                                        If CType(objTabs(intCounter), TabInfo).Level > intLevel Then
                                            intToIndex = intCounter
                                        Else
                                            Exit While
                                        End If
                                        intCounter += 1
                                    End While
                                    ' adding to parent with no children
                                    If intToIndex = -1 Then
                                        intToIndex = intNewParentIndex
                                    End If
                                    intToIndex += 1
                                End If
                                MoveTab(objTabs, intFromIndex, intToIndex, intLevel, False)
                            End If
                        End If
                    End If
                End If
            End If

            ' update the tabs
            Dim intTabOrder As Integer
            Dim intDesktopTabOrder As Integer = -1
            Dim intAdminTabOrder As Integer = 9999    ' this seeds the taborder for the admin tab so that they are always at the end of the tab list ( max = 5000 desktop tabs per portal )
            For Each objTab In objTabs
                If ((objTab.TabID = objPortal.AdminTabId) Or (objTab.ParentId = objPortal.AdminTabId) Or (objTab.TabID = objPortal.SuperTabId) Or (objTab.ParentId = objPortal.SuperTabId)) And _
                 (objPortal.AdminTabId <> -1) Then    ' special case when creating new portals
                    intAdminTabOrder += 2
                    intTabOrder = intAdminTabOrder
                Else    ' desktop tab
                    intDesktopTabOrder += 2
                    intTabOrder = intDesktopTabOrder
                End If
                ' update only if changed
                If htabs.Contains(objTab.TabID) Then
                    Dim ttab As TabOrderHelper = CType(htabs(objTab.TabID), TabOrderHelper)
                    If intTabOrder <> ttab.TabOrder Or objTab.Level <> ttab.Level Or objTab.ParentId <> ttab.ParentId Then
                        UpdateTabOrder(objTab.PortalID, objTab.TabID, intTabOrder, objTab.Level, objTab.ParentId)
                    End If
                Else
                    UpdateTabOrder(objTab.PortalID, objTab.TabID, intTabOrder, objTab.Level, objTab.ParentId)
                End If
            Next

            ' clear portal cache
            DataCache.ClearPortalCache(PortalId, True)

        End Sub

        Private Sub MoveTab(ByVal objDesktopTabs As ArrayList, ByVal intFromIndex As Integer, ByVal intToIndex As Integer, ByVal intNewLevel As Integer, Optional ByVal blnAddChild As Boolean = True)
            Dim intCounter As Integer
            Dim objTab As TabInfo
            Dim blnInsert As Boolean
            Dim intIncrement As Integer

            Dim intOldLevel As Integer = CType(objDesktopTabs(intFromIndex), TabInfo).Level
            If intToIndex <> objDesktopTabs.Count - 1 Then
                blnInsert = True
            End If

            ' clone tab and children from old parent
            Dim objClone As New ArrayList
            intCounter = intFromIndex
            While intCounter <= objDesktopTabs.Count - 1
                If CType(objDesktopTabs(intCounter), TabInfo).TabID = CType(objDesktopTabs(intFromIndex), TabInfo).TabID Or CType(objDesktopTabs(intCounter), TabInfo).Level > intOldLevel Then
                    objClone.Add(objDesktopTabs(intCounter))
                    intCounter += 1
                Else
                    Exit While
                End If
            End While

            ' remove tab and children from old parent
            objDesktopTabs.RemoveRange(intFromIndex, objClone.Count)
            If intToIndex > intFromIndex Then
                intToIndex -= objClone.Count
            End If

            ' add clone to new parent
            If blnInsert Then
                objClone.Reverse()
            End If

            For Each objTab In objClone
                objTab.TabPath = GenerateTabPath(objTab.ParentId, objTab.TabName)
                If blnInsert Then
                    objTab.Level += (intNewLevel - intOldLevel)
                    If blnAddChild Then
                        intIncrement = 1
                    Else
                        intIncrement = 0
                    End If
                    objDesktopTabs.Insert(intToIndex + intIncrement, objTab)
                Else
                    objTab.Level += (intNewLevel - intOldLevel)
                    objDesktopTabs.Add(objTab)
                End If
            Next
        End Sub

        Public Function AddTab(ByVal objTab As TabInfo) As Integer

            Return AddTab(objTab, True)

        End Function

        Public Function AddTab(ByVal objTab As TabInfo, ByVal AddAllTabsModules As Boolean) As Integer

            Dim intTabId As Integer

            objTab.TabPath = GenerateTabPath(objTab.ParentId, objTab.TabName)
            intTabId = DataProvider.Instance().AddTab(objTab.PortalID, objTab.TabName, objTab.IsVisible, objTab.DisableLink, objTab.ParentId, objTab.IconFile, objTab.Title, objTab.Description, objTab.KeyWords, objTab.Url, objTab.SkinSrc, objTab.ContainerSrc, objTab.TabPath, objTab.StartDate, objTab.EndDate, objTab.RefreshInterval, objTab.PageHeadText)

            Dim objTabController As New TabController
            Dim objTabPermissionController As New Security.Permissions.TabPermissionController

            If Not objTab.TabPermissions Is Nothing Then
                Dim objTabPermissions As Security.Permissions.TabPermissionCollection
                objTabPermissions = objTab.TabPermissions

                Dim objTabPermission As New Security.Permissions.TabPermissionInfo
                For Each objTabPermission In objTabPermissions
                    objTabPermission.TabID = intTabId
                    If objTabPermission.AllowAccess Then
                        objTabPermissionController.AddTabPermission(objTabPermission)
                    End If
                Next
            End If
            If Not Null.IsNull(objTab.PortalID) Then
                UpdatePortalTabOrder(objTab.PortalID, intTabId, objTab.ParentId, 0, 0, objTab.IsVisible, True)
            Else    ' host tab
                Dim arrTabs As ArrayList = GetTabsByParentId(objTab.ParentId)
                UpdateTabOrder(objTab.PortalID, intTabId, (arrTabs.Count * 2) - 1, 1, objTab.ParentId)
            End If

            If AddAllTabsModules Then
                Dim objmodules As New ModuleController
                Dim arrMods As ArrayList = objmodules.GetAllTabsModules(objTab.PortalID, True)

                For Each objModule As ModuleInfo In arrMods
                    objmodules.CopyModule(objModule.ModuleID, objModule.TabID, intTabId, "", True)
                Next
            End If

            Return intTabId

        End Function

        Public Sub UpdateTab(ByVal objTab As TabInfo)
            Dim updateChildren As Boolean = False
            Dim objTmpTab As TabInfo = GetTab(objTab.TabID)
            If objTmpTab.TabName <> objTab.TabName Or objTmpTab.ParentId <> objTab.ParentId Then
                updateChildren = True
            End If

            UpdatePortalTabOrder(objTab.PortalID, objTab.TabID, objTab.ParentId, 0, 0, objTab.IsVisible)

            DataProvider.Instance().UpdateTab(objTab.TabID, objTab.TabName, objTab.IsVisible, objTab.DisableLink, objTab.ParentId, objTab.IconFile, objTab.Title, objTab.Description, objTab.KeyWords, objTab.IsDeleted, objTab.Url, objTab.SkinSrc, objTab.ContainerSrc, objTab.TabPath, objTab.StartDate, objTab.EndDate, objTab.RefreshInterval, objTab.PageHeadText)

            Dim objTabController As New TabController
            Dim objTabPermissionController As New Security.Permissions.TabPermissionController

            Dim objTabPermissions As Security.Permissions.TabPermissionCollection
            objTabPermissions = objTab.TabPermissions

            Dim objCurrentTabPermissions As Security.Permissions.TabPermissionCollection
            objCurrentTabPermissions = objTabPermissionController.GetTabPermissionsCollectionByTabID(objTab.TabID)

            If Not objCurrentTabPermissions.CompareTo(objTab.TabPermissions) Then
                objTabPermissionController.DeleteTabPermissionsByTabID(objTab.TabID)

                Dim objTabPermission As New Security.Permissions.TabPermissionInfo
                For Each objTabPermission In objTabPermissions
                    If objTabPermission.AllowAccess Then
                        objTabPermissionController.AddTabPermission(objTabPermission)
                    End If
                Next
            End If
            If updateChildren Then
                UpdateChildTabPath(objTab.TabID)
            End If
        End Sub

        Public Sub CopyTab(ByVal PortalId As Integer, ByVal FromTabId As Integer, ByVal ToTabId As Integer, ByVal IncludeContent As Boolean)

            Dim arrModules As ArrayList
            Dim objModules As New ModuleController
            Dim objModule As ModuleInfo
            Dim intIndex As Integer

            arrModules = objModules.GetPortalTabModules(PortalId, FromTabId)
            For intIndex = 0 To arrModules.Count - 1
                objModule = CType(arrModules(intIndex), ModuleInfo)

                ' if the module shows on all pages does not need to be copied since it will
                ' be already added to this page
                If Not objModule.AllTabs Then

                    If IncludeContent = False Then
                        objModule.ModuleID = Null.NullInteger
                    End If

                    objModule.TabID = ToTabId
                    objModules.AddModule(objModule)

                End If
            Next

        End Sub

        Public Sub UpdateTabOrder(ByVal PortalID As Integer, ByVal TabId As Integer, ByVal TabOrder As Integer, ByVal Level As Integer, ByVal ParentId As Integer)

            DataProvider.Instance().UpdateTabOrder(TabId, TabOrder, Level, ParentId)

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Deletes a tab premanently from the database
        ''' </summary>
        ''' <param name="TabId">TabId of the tab to be deleted</param>
        ''' <param name="PortalId">PortalId of the portal</param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[Vicen�]	19/09/2004	Added skin deassignment before deleting the tab.
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub DeleteTab(ByVal TabId As Integer, ByVal PortalId As Integer)

            ' parent tabs can not be deleted
            Dim arrTabs As ArrayList = GetTabsByParentId(TabId)

            If arrTabs.Count = 0 Then
                DataProvider.Instance().DeleteTab(TabId)
                UpdatePortalTabOrder(PortalId, TabId, -2, 0, 0, True)
            End If

        End Sub

        Public Function GetTabs(ByVal PortalId As Integer) As ArrayList

            Return FillTabInfoCollection(DataProvider.Instance().GetTabs(PortalId))

        End Function

        Public Function GetAllTabs() As ArrayList

            Return FillTabInfoCollection(DataProvider.Instance().GetAllTabs())

        End Function

        Public Function GetTab(ByVal TabId As Integer) As TabInfo
            Dim dr As IDataReader = DataProvider.Instance().GetTab(TabId)
            Try
                Return FillTabInfo(dr)
            Finally
                If Not dr Is Nothing Then
                    dr.Close()
                End If
            End Try
        End Function

        Public Function GetTabByName(ByVal TabName As String, ByVal PortalId As Integer) As TabInfo
            Return GetTabByName(TabName, PortalId, Integer.MinValue)
        End Function

        Public Function GetTabByName(ByVal TabName As String, ByVal PortalId As Integer, ByVal ParentId As Integer) As TabInfo

            Dim arrTabs As ArrayList = FillTabInfoCollection(DataProvider.Instance().GetTabByName(TabName, PortalId))

            Dim intTab As Integer = -1

            If Not arrTabs Is Nothing Then
                Select Case arrTabs.Count
                    Case 0    ' no results
                    Case 1    ' exact match
                        intTab = 0
                    Case Else    ' multiple matches
                        Dim intIndex As Integer
                        Dim objTab As TabInfo
                        For intIndex = 0 To arrTabs.Count - 1
                            objTab = CType(arrTabs(intIndex), TabInfo)
                            ' check if the parentids match
                            If objTab.ParentId = ParentId Then
                                intTab = intIndex
                            End If
                        Next intIndex
                        If intTab = -1 Then
                            ' no match - return the first item
                            intTab = 0
                        End If
                End Select
            End If

            If intTab <> -1 Then
                Return CType(arrTabs(intTab), TabInfo)
            Else
                Return Nothing
            End If

        End Function

        Public Function GetTabsByParentId(ByVal ParentId As Integer) As ArrayList

            Return FillTabInfoCollection(DataProvider.Instance().GetTabsByParentId(ParentId))

        End Function

        Private Function FillTabInfoCollection(ByVal dr As IDataReader) As ArrayList

            Dim arr As New ArrayList
            Try
                Dim obj As TabInfo
                While dr.Read
                    ' fill business object
                    obj = FillTabInfo(dr, False)
                    ' add to collection
                    arr.Add(obj)
                End While
            Catch exc As Exception
                LogException(exc)
            Finally
                ' close datareader
                If Not dr Is Nothing Then
                    dr.Close()
                End If
            End Try

            Return arr
        End Function

        Private Function FillTabInfo(ByVal dr As IDataReader) As TabInfo

            Return FillTabInfo(dr, True)

        End Function

        Private Function FillTabInfo(ByVal dr As IDataReader, ByVal CheckForOpenDataReader As Boolean) As TabInfo

            Dim objTabInfo As New TabInfo
            Dim objTabPermissionController As New Security.Permissions.TabPermissionController
            ' read datareader
            Dim [Continue] As Boolean = True

            If CheckForOpenDataReader Then
                [Continue] = False
                If dr.Read Then
                    [Continue] = True
                End If
            End If
            If [Continue] Then
                Try
                    objTabInfo.TabID = Convert.ToInt32(Null.SetNull(dr("TabID"), objTabInfo.TabID))
                Catch
                End Try
                Try
                    objTabInfo.TabOrder = Convert.ToInt32(Null.SetNull(dr("TabOrder"), objTabInfo.TabOrder))
                Catch
                End Try
                Try
                    objTabInfo.PortalID = Convert.ToInt32(Null.SetNull(dr("PortalID"), objTabInfo.PortalID))
                Catch
                End Try
                Try
                    objTabInfo.TabName = Convert.ToString(Null.SetNull(dr("TabName"), objTabInfo.TabName))
                Catch
                End Try
                Try
                    objTabInfo.IsVisible = Convert.ToBoolean(Null.SetNull(dr("IsVisible"), objTabInfo.IsVisible))
                Catch
                End Try
                Try
                    objTabInfo.ParentId = Convert.ToInt32(Null.SetNull(dr("ParentId"), objTabInfo.ParentId))
                Catch
                End Try
                Try
                    objTabInfo.Level = Convert.ToInt32(Null.SetNull(dr("Level"), objTabInfo.Level))
                Catch
                End Try
                Try
                    objTabInfo.IconFile = Convert.ToString(Null.SetNull(dr("IconFile"), objTabInfo.IconFile))
                Catch
                End Try
                Try
                    objTabInfo.DisableLink = Convert.ToBoolean(Null.SetNull(dr("DisableLink"), objTabInfo.DisableLink))
                Catch
                End Try
                Try
                    objTabInfo.Title = Convert.ToString(Null.SetNull(dr("Title"), objTabInfo.Title))
                Catch
                End Try
                Try
                    objTabInfo.Description = Convert.ToString(Null.SetNull(dr("Description"), objTabInfo.Description))
                Catch
                End Try
                Try
                    objTabInfo.KeyWords = Convert.ToString(Null.SetNull(dr("KeyWords"), objTabInfo.KeyWords))
                Catch
                End Try
                Try
                    objTabInfo.IsDeleted = Convert.ToBoolean(Null.SetNull(dr("IsDeleted"), objTabInfo.IsDeleted))
                Catch
                End Try
                Try
                    objTabInfo.Url = Convert.ToString(Null.SetNull(dr("Url"), objTabInfo.Url))
                Catch
                End Try
                Try
                    objTabInfo.SkinSrc = Convert.ToString(Null.SetNull(dr("SkinSrc"), objTabInfo.SkinSrc))
                Catch
                End Try
                Try
                    objTabInfo.ContainerSrc = Convert.ToString(Null.SetNull(dr("ContainerSrc"), objTabInfo.ContainerSrc))
                Catch
                End Try
                Try
                    objTabInfo.TabPath = Convert.ToString(Null.SetNull(dr("TabPath"), objTabInfo.TabPath))
                Catch
                End Try
                Try
                    objTabInfo.StartDate = Convert.ToDateTime(Null.SetNull(dr("StartDate"), objTabInfo.StartDate))
                Catch
                End Try
                Try
                    objTabInfo.EndDate = Convert.ToDateTime(Null.SetNull(dr("EndDate"), objTabInfo.EndDate))
                Catch
                End Try
                Try
                    objTabInfo.HasChildren = Convert.ToBoolean(Null.SetNull(dr("HasChildren"), objTabInfo.HasChildren))
                Catch
                End Try
                Try
                    objTabInfo.RefreshInterval = Convert.ToInt32(Null.SetNull(dr("RefreshInterval"), objTabInfo.RefreshInterval))
                Catch
                End Try
                Try
                    objTabInfo.PageHeadText = Convert.ToString(Null.SetNull(dr("PageHeadText"), objTabInfo.PageHeadText))
                Catch
                End Try

                If Not objTabInfo Is Nothing Then
                    Dim arrTabPermissions As ArrayList = objTabPermissionController.GetTabPermissionsByPortal(objTabInfo.PortalID)
                    Try
                        objTabInfo.AdministratorRoles = objTabPermissionController.GetTabPermissionsByTabID(arrTabPermissions, objTabInfo.TabID, "EDIT")
                        If objTabInfo.AdministratorRoles = ";" Then
                            ' this code is here for legacy support - the AdministratorRoles were stored as a concatenated list of roleids prior to DNN 3.0
                            Try
                                objTabInfo.AdministratorRoles = Convert.ToString(Null.SetNull(dr("AdministratorRoles"), objTabInfo.AdministratorRoles))
                            Catch
                                ' the AdministratorRoles field was removed from the Tabs table in 3.0
                            End Try
                        End If
                    Catch
                    End Try
                    Try
                        objTabInfo.AuthorizedRoles = objTabPermissionController.GetTabPermissionsByTabID(arrTabPermissions, objTabInfo.TabID, "VIEW")
                        If objTabInfo.AuthorizedRoles = ";" Then
                            ' this code is here for legacy support - the AuthorizedRoles were stored as a concatenated list of roleids prior to DNN 3.0
                            Try
                                objTabInfo.AuthorizedRoles = Convert.ToString(Null.SetNull(dr("AuthorizedRoles"), objTabInfo.AuthorizedRoles))
                            Catch
                                ' the AuthorizedRoles field was removed from the Tabs table in 3.0
                            End Try
                        End If
                    Catch
                    End Try
                    Try
                        objTabInfo.TabPermissions = objTabPermissionController.GetTabPermissionsCollectionByTabID(arrTabPermissions, objTabInfo.TabID)
                    Catch
                    End Try

                    objTabInfo.BreadCrumbs = Nothing
                    objTabInfo.Panes = Nothing
                    objTabInfo.Modules = Nothing
                End If

            Else
                objTabInfo = Nothing
            End If

            Return objTabInfo

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Updates child tabs TabPath field
        ''' </summary>
        ''' <param name="intTabid">ID of the parent tab</param>
        ''' <remarks>
        ''' When a ParentTab is updated this method should be called to 
        ''' ensure that the TabPath of the Child Tabs is consistent with the Parent
        ''' </remarks>
        ''' <history>
        ''' 	[JWhite]	16/11/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub UpdateChildTabPath(ByVal intTabid As Integer)
            Dim objtabs As New TabController
            Dim objtab As TabInfo
            Dim arrTabs As ArrayList = objtabs.GetTabsByParentId(intTabid)

            For Each objtab In arrTabs
                Dim oldTabPath As String = objtab.TabPath
                objtab.TabPath = GenerateTabPath(objtab.ParentId, objtab.TabName)
                If oldTabPath <> objtab.TabPath Then
                    DataProvider.Instance().UpdateTab(objtab.TabID, objtab.TabName, objtab.IsVisible, objtab.DisableLink, objtab.ParentId, objtab.IconFile, objtab.Title, objtab.Description, objtab.KeyWords, objtab.IsDeleted, objtab.Url, objtab.SkinSrc, objtab.ContainerSrc, objtab.TabPath, objtab.StartDate, objtab.EndDate, objtab.RefreshInterval, objtab.PageHeadText)
                    UpdateChildTabPath(objtab.TabID)
                End If
            Next

        End Sub
    End Class


End Namespace

