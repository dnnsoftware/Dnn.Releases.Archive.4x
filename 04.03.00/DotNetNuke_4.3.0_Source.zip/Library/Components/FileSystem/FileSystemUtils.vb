'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2006
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.IO
Imports DotNetNuke.Services.FileSystem
Imports DotNetNuke.Services.Localization
Imports DotNetNuke.Security.Permissions
Imports ICSharpCode.SharpZipLib.Checksums
Imports ICSharpCode.SharpZipLib.Zip

Namespace DotNetNuke.Common.Utilities

    Public Class FileSystemUtils

#Region "Private Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Adds a File
        ''' </summary>
        ''' <param name="strFile">The File Name</param>
        ''' <param name="PortalId">The Id of the Portal</param>
        ''' <param name="HomeDirectory">The home directory for the Portal</param>
        ''' <param name="ClearCache">A flag that indicates whether the file cache should be cleared</param>
        ''' <remarks>This method is called by the SynchonizeFolder method, when the file exists in the file system
        ''' but not in the Database
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	12/2/2004	Created
        '''     [cnurse]    04/26/2006  Updated to account for secure storage
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Shared Function AddFile(ByVal strFile As String, ByVal PortalId As Integer, ByVal HomeDirectory As String, ByVal ClearCache As Boolean) As String
            Dim retValue As String = ""
            Try
                Dim objFileController As New DotNetNuke.Services.FileSystem.FileController
                Dim fInfo As System.IO.FileInfo = New System.IO.FileInfo(strFile)
                Dim sourceFolderName As String = GetSubFolderPath(strFile)
                Dim sourceFileName As String = GetFileName(strFile)
                Dim file As DotNetNuke.Services.FileSystem.FileInfo = objFileController.GetFile(sourceFileName, PortalId, sourceFolderName)

                If file Is Nothing Then
                    'Add the new File
                    AddFile(PortalId, fInfo.OpenRead(), strFile, "", fInfo.Length, sourceFolderName, True, ClearCache)
                End If
            Catch ex As Exception
                retValue = ex.Message
            End Try
            Return retValue
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Adds a File
        ''' </summary>
        ''' <param name="PortalId">The Id of the Portal</param>
        ''' <param name="inStream">The stream to add</param>
        ''' <param name="contentType">The type of the content</param>
        ''' <param name="length">The length of the content</param>
        ''' <param name="folderName">The name of the folder</param>
        ''' <param name="closeInputStream">A flag that dermines if the Input Stream should be closed.</param>
        ''' <param name="ClearCache">A flag that indicates whether the file cache should be cleared</param>
        ''' <remarks>This method adds a new file
        ''' </remarks>
        ''' <history>
        '''     [cnurse]    04/26/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Shared Function AddFile(ByVal PortalId As Integer, ByVal inStream As Stream, ByVal fileName As String, ByVal contentType As String, ByVal length As Long, ByVal folderName As String, ByVal closeInputStream As Boolean, ByVal clearCache As Boolean) As String

            Dim objFolderController As New DotNetNuke.Services.FileSystem.FolderController
            Dim objFileController As New DotNetNuke.Services.FileSystem.FileController
            Dim sourceFolderName As String = GetSubFolderPath(fileName)
            Dim folder As FolderInfo = objFolderController.GetFolder(PortalId, sourceFolderName)
            Dim sourceFileName As String = GetFileName(fileName)
            Dim imgImage As System.Drawing.Image
            Dim imageWidth As Integer
            Dim imageHeight As Integer
            Dim intFileID As Integer
            Dim retValue As String = ""

            retValue += CheckValidFileName(fileName)
            If retValue.Length > 0 Then
                Return retValue
            End If

            Dim extension As String = Path.GetExtension(fileName).Replace(".", "")
            If contentType = "" Then
                contentType = GetContentType(extension)
            End If

            'If an image lets try and find out the image size and the file size.  In this scenario the file will exist
            'on the file system so lets load the file
            If Convert.ToBoolean(InStr(1, glbImageFileTypes & ",", extension.ToLower & ",")) Then
                Try
                    imgImage = Drawing.Image.FromStream(inStream)
                    imageHeight = imgImage.Height
                    imageWidth = imgImage.Width
                    imgImage.Dispose()
                    inStream.Position = 0
                Catch
                    ' error loading image file
                    contentType = "application/octet-stream"
                End Try
            End If

            'Add file to Database
            intFileID = objFileController.AddFile(PortalId, sourceFileName, extension, length, imageWidth, imageHeight, contentType, folderName, clearCache)

            'Save file to File Storage
            WriteStream(intFileID, inStream, fileName, folder.StorageLocation, closeInputStream)

            If folder.StorageLocation <> FolderController.StorageLocationTypes.InsecureFileSystem Then
                'try and delete the Insecure file
                AttemptFileDeletion(fileName)
            End If

            If folder.StorageLocation <> FolderController.StorageLocationTypes.SecureFileSystem Then
                'try and delete the Secure file
                AttemptFileDeletion(fileName + glbProtectedExtension)
            End If

            Return retValue

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Adds a Folder
        ''' </summary>
        ''' <param name="PortalId">The Id of the Portal</param>
        ''' <param name="AdministratorRoleId">The Id of the Administrator role</param>
        ''' <param name="relativePath">The relative path of the folder</param>
        ''' <param name="StorageLocation">The type of storage location</param>
        ''' <history>
        '''     [cnurse]    04/26/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Shared Function AddFolder(ByVal PortalId As Integer, ByVal AdministratorRoleId As Integer, ByVal relativePath As String, ByVal StorageLocation As Integer) As Integer

            Dim objFolderController As New DotNetNuke.Services.FileSystem.FolderController

            Dim isProtected As Boolean
            isProtected = FileSystemUtils.DefaultProtectedFolders(relativePath)

            Dim FolderID As Integer = objFolderController.AddFolder(PortalId, relativePath, StorageLocation, isProtected, False)

            If PortalId <> Null.NullInteger Then
                SetFolderPermissions(PortalId, FolderID, AdministratorRoleId, relativePath)
            End If

            Return FolderID

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Trys to delete a file from the file system
        ''' </summary>
        ''' <param name="strFileName">The name of the file</param>
        ''' <history>
        '''     [cnurse]    04/26/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Shared Sub AttemptFileDeletion(ByVal strFileName As String)
            If File.Exists(strFileName) Then
                File.SetAttributes(strFileName, FileAttributes.Normal)
                File.Delete(strFileName)
            End If
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Checks that the file name is valid
        ''' </summary>
        ''' <param name="strFileName">The name of the file</param>
        ''' <history>
        '''     [cnurse]    04/26/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Shared Function CheckValidFileName(ByVal strFileName As String) As String

            Dim retValue As String = Null.NullString
            If strFileName.IndexOf("'") > -1 Then
                ' check if context is valid since this method is called from the scheduller too
                If Not HttpContext.Current Is Nothing Then
                    retValue = Localization.GetString("InvalidFileName")
                Else
                    retValue = "InvalidFileName"
                End If
            End If

            'Return
            Return retValue

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets the filename for a file path
        ''' </summary>
        ''' <param name="filePath">The full name of the file</param>
        ''' <history>
        '''     [cnurse]    04/26/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Shared Function GetFileName(ByVal filePath As String) As String

            Return System.IO.Path.GetFileName(filePath).Replace(glbProtectedExtension, "")

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Updates a File
        ''' </summary>
        ''' <param name="strSourceFile">The original File Name</param>
        ''' <param name="strDestFile">The new File Name</param>
        ''' <param name="isCopy">Flag determines whether file is to be be moved or copied</param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	12/2/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Shared Function UpdateFile(ByVal strSourceFile As String, ByVal strDestFile As String, ByVal PortalId As Integer, ByVal HomeDirectory As String, ByVal isCopy As Boolean, ByVal isNew As Boolean, ByVal ClearCache As Boolean) As String

            Dim retValue As String = ""
            retValue += CheckValidFileName(strSourceFile) & " "
            retValue += CheckValidFileName(strDestFile)
            If retValue.Length > 1 Then
                Return retValue
            End If
            retValue = ""

            Try
                Dim objFolderController As New DotNetNuke.Services.FileSystem.FolderController
                Dim objFileController As New DotNetNuke.Services.FileSystem.FileController
                Dim sourceFolderName As String = GetSubFolderPath(strSourceFile)
                Dim sourceFileName As String = GetFileName(strSourceFile)
                Dim sourceFolder As FolderInfo = objFolderController.GetFolder(PortalId, sourceFolderName)

                Dim destFileName As String = GetFileName(strDestFile)
                Dim destFolderName As String = GetSubFolderPath(strDestFile)

                Dim file As DotNetNuke.Services.FileSystem.FileInfo = objFileController.GetFile(sourceFileName, PortalId, sourceFolderName)

                'Get the source Content from wherever it is
                Dim sourceStream As MemoryStream = CType(GetFileStream(file, PortalId, HomeDirectory), MemoryStream)

                If isCopy Then
                    'Add the new File
                    AddFile(PortalId, sourceStream, strDestFile, "", file.Size, destFolderName, True, ClearCache)
                Else
                    'Move/Update existing file
                    If Not file Is Nothing Then
                        objFileController.UpdateFile(PortalId, sourceFileName, destFileName, file.Extension, file.Size, _
                            file.Width, file.Height, file.ContentType, sourceFolderName, destFolderName, ClearCache)

                        Dim destinationFolder As FolderInfo = objFolderController.GetFolder(PortalId, destFolderName)

                        'Now move the file
                        If (Not sourceFolder Is Nothing) AndAlso (Not destinationFolder Is Nothing) Then
                            'Write the content to the Destination
                            WriteStream(file.FileId, sourceStream, strDestFile, destinationFolder.StorageLocation, True)

                            'Now we need to clean up the original files
                            If sourceFolder.StorageLocation = FolderController.StorageLocationTypes.InsecureFileSystem Then
                                'try and delete the Insecure file
                                AttemptFileDeletion(strSourceFile)
                            End If
                            If sourceFolder.StorageLocation = FolderController.StorageLocationTypes.SecureFileSystem Then
                                'try and delete the Secure file
                                AttemptFileDeletion(strSourceFile + glbProtectedExtension)
                            End If

                        End If

                    End If
                End If

            Catch ex As Exception
                retValue = ex.Message
            End Try

            Return retValue

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Writes a Stream to the appropriate File Storage
        ''' </summary>
        ''' <param name="fileId">The Id of the File</param>
        ''' <param name="inStream">The Input Stream</param>
        ''' <param name="fileName">The name of the file</param>
        ''' <param name="StorageLocation">The type of storage location</param>
        ''' <param name="closeInputStream">A flag that dermines if the Input Stream should be closed.</param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	04/27/2006	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Shared Sub WriteStream(ByVal fileId As Integer, ByVal inStream As Stream, ByVal fileName As String, ByVal storageLocation As Integer, ByVal closeInputStream As Boolean)

            Dim objFileController As New DotNetNuke.Services.FileSystem.FileController

            'Clear any existing content from the db
            objFileController.ClearFileContent(fileId)

            ' Buffer to read 10K bytes in chunk:
            Dim arrData(2048) As Byte
            Dim outStream As Stream = Nothing
            Select Case storageLocation
                Case FolderController.StorageLocationTypes.DatabaseSecure
                    outStream = New MemoryStream
                Case FolderController.StorageLocationTypes.SecureFileSystem
                    outStream = New FileStream(fileName & glbProtectedExtension, FileMode.Create)
                Case FolderController.StorageLocationTypes.InsecureFileSystem
                    outStream = New FileStream(fileName, FileMode.Create)
            End Select

            Try
                ' Total bytes to read:
                Dim intLength As Integer
                ' Read the data in buffer
                intLength = inStream.Read(arrData, 0, arrData.Length)
                While intLength > 0
                    ' Write the data to the current output stream.
                    outStream.Write(arrData, 0, intLength)

                    'Read the next chunk
                    intLength = inStream.Read(arrData, 0, arrData.Length)
                End While

                If storageLocation = FolderController.StorageLocationTypes.DatabaseSecure Then
                    outStream.Seek(0, SeekOrigin.Begin)
                    objFileController.UpdateFileContent(fileId, outStream)
                End If
            Catch ex As Exception
            Finally
                If IsNothing(inStream) = False And closeInputStream Then
                    ' Close the file.
                    inStream.Close()
                End If
                If IsNothing(outStream) = False Then
                    ' Close the file.
                    outStream.Close()
                End If
            End Try

        End Sub

#End Region

#Region "Path Manipulation Methods"

        Public Shared Function AddTrailingSlash(ByVal strSource As String) As String
            If Not strSource.EndsWith("\") Then strSource = strSource & "\"
            Return strSource
        End Function

        Public Shared Function RemoveTrailingSlash(ByVal strSource As String) As String
            If strSource = "" Then Return ""
            If Mid(strSource, Len(strSource), 1) = "\" Or Mid(strSource, Len(strSource), 1) = "/" Then
                Return strSource.Substring(0, Len(strSource) - 1)
            Else
                Return strSource
            End If
        End Function

        Public Shared Function StripFolderPath(ByVal strOrigPath As String) As String
            If strOrigPath.IndexOf("\") <> -1 Then
                Return Replace(strOrigPath, "0\", "", 1, 1)
            Else
                Return Replace(strOrigPath, "0", "", 1, 1)
            End If
        End Function

        Public Shared Function FormatFolderPath(ByVal strFolderPath As String) As String
            If strFolderPath = "" Then
                Return ""
            Else
                If strFolderPath.EndsWith("/") Then
                    Return strFolderPath
                Else
                    Return strFolderPath & "/"
                End If
            End If
        End Function

#End Region

#Region "Public Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Adds a Folder
        ''' </summary>
        ''' <param name="_PortalSettings">Portal Settings for the Portal</param>
        ''' <param name="parentFolder">The Parent Folder Name</param>
        ''' <param name="newFolder">The new Folder Name</param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	12/4/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Sub AddFolder(ByVal _PortalSettings As PortalSettings, ByVal parentFolder As String, ByVal newFolder As String)
            AddFolder(_PortalSettings, parentFolder, newFolder, FolderController.StorageLocationTypes.InsecureFileSystem)
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Adds a Folder
        ''' </summary>
        ''' <param name="_PortalSettings">Portal Settings for the Portal</param>
        ''' <param name="parentFolder">The Parent Folder Name</param>
        ''' <param name="newFolder">The new Folder Name</param>
        ''' <param name="StorageLocation">The Storage Location</param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	12/4/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Sub AddFolder(ByVal _PortalSettings As PortalSettings, ByVal parentFolder As String, ByVal newFolder As String, ByVal StorageLocation As Integer)

            Dim PortalId As Integer
            Dim ParentFolderName As String
            Dim dinfo As New System.IO.DirectoryInfo(parentFolder)
            Dim dinfoNew As System.IO.DirectoryInfo

            If _PortalSettings.ActiveTab.ParentId = _PortalSettings.SuperTabId Then
                PortalId = Null.NullInteger
                ParentFolderName = Common.Globals.HostMapPath
            Else
                PortalId = _PortalSettings.PortalId
                ParentFolderName = _PortalSettings.HomeDirectoryMapPath
            End If

            dinfoNew = New System.IO.DirectoryInfo(parentFolder & newFolder)
            If dinfoNew.Exists Then
                Throw New ArgumentException(Localization.GetString("EXCEPTION_DirectoryExists"))
            End If
            Dim strResult As String = dinfo.CreateSubdirectory(newFolder).FullName

            Dim FolderPath As String = ""
            FolderPath = strResult.Substring(ParentFolderName.Length).Replace("\", "/")

            'Persist in Database
            AddFolder(PortalId, _PortalSettings.AdministratorRoleId, FolderPath, StorageLocation)

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Adds a File to a Zip File
        ''' </summary>
        ''' <history>
        ''' 	[cnurse]	12/4/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Sub AddToZip(ByRef ZipFile As ZipOutputStream, ByVal filePath As String, ByVal fileName As String, ByVal folder As String)
            Dim crc As Crc32 = New Crc32

            'Open File Stream
            Dim fs As FileStream = File.OpenRead(filePath)

            'Read file into byte array buffer
            Dim buffer As Byte()
            ReDim buffer(Convert.ToInt32(fs.Length) - 1)
            fs.Read(buffer, 0, buffer.Length)

            'Create Zip Entry
            Dim entry As ZipEntry = New ZipEntry(folder & fileName)
            entry.DateTime = DateTime.Now
            entry.Size = fs.Length
            fs.Close()
            crc.Reset()
            crc.Update(buffer)
            entry.Crc = crc.Value

            'Compress file and add to Zip file
            ZipFile.PutNextEntry(entry)
            ZipFile.Write(buffer, 0, buffer.Length)

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Copies a File
        ''' </summary>
        ''' <param name="strSourceFile">The original File Name</param>
        ''' <param name="strDestFile">The new File Name</param>
        ''' <param name="settings">The Portal Settings for the Portal/Host Account</param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	12/2/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function CopyFile(ByVal strSourceFile As String, ByVal strDestFile As String, ByVal settings As PortalSettings) As String
            Dim FolderPortalId As Integer = Null.NullInteger
            Dim HomeDirectory As String = Globals.HostMapPath
            Dim isHost As Boolean = CType(IIf(settings.ActiveTab.ParentId = settings.SuperTabId, True, False), Boolean)
            If Not isHost Then
                FolderPortalId = settings.PortalId
                HomeDirectory = settings.HomeDirectoryMapPath
            End If
            Return UpdateFile(strSourceFile, strDestFile, FolderPortalId, HomeDirectory, True, False, True)
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' This checks to see if the folder is a protected type of folder 
        ''' </summary>
        ''' <param name="folderPath">String</param>
        ''' <returns>Boolean</returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cpaterra]	4/7/2006	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function DefaultProtectedFolders(ByVal folderPath As String) As Boolean
            If folderPath = "" Or folderPath.ToLower = "skins" Or folderPath.ToLower = "containers" Or folderPath.ToLower.StartsWith("skins/") = True Or folderPath.ToLower.StartsWith("containers/") = True Then
                Return True
            Else
                Return False
            End If
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Deletes a file
        ''' </summary>
        ''' <param name="strSourceFile">The File to delete</param>
        ''' <param name="settings">The Portal Settings for the Portal/Host Account</param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[Jon Henning]	11/1/2004	Created
        '''     [cnurse]        12/6/2004   delete file from db
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function DeleteFile(ByVal strSourceFile As String, ByVal settings As PortalSettings) As String
            Return DeleteFile(strSourceFile, settings, True)
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Deletes a file
        ''' </summary>
        ''' <param name="strSourceFile">The File to delete</param>
        ''' <param name="settings">The Portal Settings for the Portal/Host Account</param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[Jon Henning]	11/1/2004	Created
        '''     [cnurse]        12/6/2004   delete file from db
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function DeleteFile(ByVal strSourceFile As String, ByVal settings As PortalSettings, ByVal ClearCache As Boolean) As String

            Dim retValue As String = ""
            Try
                Dim folderName As String = GetSubFolderPath(strSourceFile)
                Dim fileName As String = GetFileName(strSourceFile)

                Dim PortalId As Integer
                If settings.ActiveTab.ParentId = settings.SuperTabId Then
                    PortalId = Null.NullInteger
                Else
                    PortalId = settings.PortalId
                End If

                'Remove file from DataBase
                Dim objFileController As New DotNetNuke.Services.FileSystem.FileController
                objFileController.DeleteFile(PortalId, fileName, folderName, ClearCache)

                'try and delete the Insecure file
                AttemptFileDeletion(strSourceFile)

                'try and delete the Secure file
                AttemptFileDeletion(strSourceFile + glbProtectedExtension)

            Catch ex As Exception
                retValue = ex.Message
            End Try

            Return retValue
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Deletes a folder
        ''' </summary>
        ''' <param name="PortalId">The Id of the Portal</param>
        ''' <param name="folder">The Directory Info object to delete</param>
        ''' <param name="folderName">The Name of the folder relative to the Root of the Portal</param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	12/4/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Sub DeleteFolder(ByVal PortalId As Integer, ByVal folder As System.IO.DirectoryInfo, ByVal folderName As String)

            'Delete Folder
            folder.Delete(False)

            'Remove Folder from DataBase
            Dim objFolderController As New DotNetNuke.Services.FileSystem.FolderController
            objFolderController.DeleteFolder(PortalId, folderName.Replace("\", "/"))

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Moved directly from FileManager code, probably should make extension lookup more generic
        ''' </summary>
        ''' <param name="FileLoc">File Location</param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[Jon Henning]	11/1/2004	Created
        ''' 	[Jon Henning]	1/4/2005	Fixed extension comparison, added content length header - DNN-386
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Sub DownloadFile(ByVal FileLoc As String)
            Dim objFile As New System.IO.FileInfo(FileLoc)
            Dim objResponse As System.Web.HttpResponse = System.Web.HttpContext.Current.Response
            If objFile.Exists Then
                objResponse.ClearContent()
                objResponse.ClearHeaders()
                objResponse.AppendHeader("content-disposition", "attachment; filename=" + objFile.Name.ToString)
                objResponse.AppendHeader("Content-Length", objFile.Length.ToString())

                objResponse.ContentType = GetContentType(objFile.Extension.Replace(".", ""))

                WriteFile(objFile.FullName)

                objResponse.Flush()
                objResponse.Close()
            End If
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Streams a file to the output stream if the user has the proper permissions
        ''' </summary>
        ''' <param name="FileId">FileId identifying file in database</param>
        ''' <param name="ClientCache">Cache file in client browser - true/false</param>
        ''' <param name="ForceDownload">Force Download File dialog box - true/false</param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function DownloadFile(ByVal settings As PortalSettings, ByVal FileId As Integer, ByVal ClientCache As Boolean, ByVal ForceDownload As Boolean) As Boolean
            Dim blnDownload As Boolean = False

            Dim FolderPortalId As Integer = Null.NullInteger
            Dim HomeDirectory As String = Globals.HostMapPath
            Dim isHost As Boolean = CType(IIf(settings.ActiveTab.ParentId = settings.SuperTabId, True, False), Boolean)
            If Not isHost Then
                FolderPortalId = settings.PortalId
                HomeDirectory = settings.HomeDirectoryMapPath
            End If

            ' get file
            Dim objFiles As New FileController
            Dim objFile As DotNetNuke.Services.FileSystem.FileInfo = objFiles.GetFileById(FileId, FolderPortalId)

            If Not objFile Is Nothing Then

                ' check folder view permissions
                If PortalSecurity.IsInRoles(FileSystemUtils.GetRoles(objFile.Folder, FolderPortalId, "READ")) Then
                    ' serve file
                    Dim objContent As Byte() = Nothing
                    Dim strCacheKey As String = "GetFileContent" & FileId.ToString

                    ' check cache
                    If objFile.IsCached Then
                        objContent = CType(DataCache.GetCache(strCacheKey), Byte())
                    End If

                    If IsNothing(objContent) Then
                        ' get file from storage location
                        objContent = FileSystemUtils.GetFileContent(objFile, FolderPortalId, HomeDirectory)

                        If objFile.IsCached Then
                            ' insert into cache
                            Dim intCacheTimeout As Integer = 20 * Convert.ToInt32(Common.Globals.PerformanceSetting)
                            DataCache.SetCache(strCacheKey, objContent, TimeSpan.FromMinutes(intCacheTimeout))
                        End If

                    End If

                    Dim objResponse As System.Web.HttpResponse = System.Web.HttpContext.Current.Response

                    ' client side caching
                    If ClientCache Then
                        objResponse.Cache.SetExpires(DateTime.Now.AddDays(1))
                        objResponse.Cache.SetCacheability(HttpCacheability.Public)
                        objResponse.Cache.SetValidUntilExpires(False)
                        objResponse.Cache.VaryByParams("fileid") = True
                    Else
                        objResponse.Cache.SetExpires(DateTime.Now.AddDays(-1))
                        objResponse.Cache.SetCacheability(HttpCacheability.NoCache)
                    End If

                    ' force download dialog 
                    If ForceDownload Then
                        objResponse.AppendHeader("content-disposition", "attachment; filename=" + objFile.FileName)
                    Else
                        'use proper file name when browser forces download because of file type (save as name should match file name)
                        objResponse.AppendHeader("content-disposition", "inline; filename=" + objFile.FileName)
                    End If

                    ' stream to response
                    objResponse.ContentType = objFile.ContentType
                    objResponse.OutputStream.Write(objContent, 0, objContent.Length)
                    objResponse.Flush()
                    objResponse.End()

                    blnDownload = True
                End If
                End If

            Return blnDownload

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' gets the content type based on the extension
        ''' </summary>
        ''' <param name="extension">The extension</param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	04/26/2006	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function GetContentType(ByVal extension As String) As String

            Dim contentType As String

            Select Case extension.ToLower
                Case "txt" : contentType = "text/plain"
                Case "htm", "html" : contentType = "text/html"
                Case "rtf" : contentType = "text/richtext"
                Case "jpg", "jpeg" : contentType = "image/jpeg"
                Case "gif" : contentType = "image/gif"
                Case "bmp" : contentType = "image/bmp"
                Case "mpg", "mpeg" : contentType = "video/mpeg"
                Case "avi" : contentType = "video/avi"
                Case "pdf" : contentType = "application/pdf"
                Case "doc", "dot" : contentType = "application/msword"
                Case "csv", "xls", "xlt" : contentType = "application/x-msexcel"
                Case Else : contentType = "application/octet-stream"
            End Select

            Return contentType

        End Function

        Public Shared Function GetFileContent(ByVal objFile As DotNetNuke.Services.FileSystem.FileInfo, ByVal PortalId As Integer, ByVal HomeDirectory As String) As Byte()

            Dim objStream As Stream = FileSystemUtils.GetFileStream(objFile, PortalId, HomeDirectory)
            Dim objBinaryReader As BinaryReader = New BinaryReader(objStream)
            Dim objContent As Byte() =  objBinaryReader.ReadBytes(CType(objStream.Length, Integer))
            objBinaryReader.Close()

            Return objContent

        End Function

        Public Shared Function GetFileStream(ByVal objFile As DotNetNuke.Services.FileSystem.FileInfo, ByVal PortalId As Integer, ByVal HomeDirectory As String) As Stream

            Dim objFileController As New DotNetNuke.Services.FileSystem.FileController
            Dim strFileName As String
            Dim fileStream As Stream = Nothing

            Select Case objFile.StorageLocation
                Case FolderController.StorageLocationTypes.InsecureFileSystem
                    ' read from file system 
                    strFileName = HomeDirectory & objFile.Folder & objFile.FileName
                    fileStream = New FileStream(strFileName, FileMode.Open, FileAccess.Read)
                Case FolderController.StorageLocationTypes.SecureFileSystem
                    ' read from file system 
                    strFileName = HomeDirectory & objFile.Folder & objFile.FileName & glbProtectedExtension
                    fileStream = New FileStream(strFileName, FileMode.Open, FileAccess.Read)
                Case FolderController.StorageLocationTypes.DatabaseSecure
                    ' read from database 
                    fileStream = New MemoryStream(objFileController.GetFileContent(objFile.FileId, PortalId))
            End Select

            Return fileStream

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets all the folders for a Portal
        ''' </summary>
        ''' <param name="PortalId">The Id of the Portal</param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	04/22/2006	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function GetFolders(ByVal PortalID As Integer) As ArrayList
            Dim arrFolders As ArrayList = CType(DataCache.GetCache("Folders:" + PortalID.ToString), ArrayList)
            If arrFolders Is Nothing Then
                Dim objFolderController As New FolderController
                arrFolders = objFolderController.GetFoldersByPortal(PortalID)
                DataCache.SetCache("Folders:" + PortalID.ToString, arrFolders)
            End If
            Return arrFolders
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets all the subFolders for a Parent
        ''' </summary>
        ''' <param name="PortalId">The Id of the Portal</param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	04/22/2006	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function GetFoldersByParentFolder(ByVal PortalId As Integer, ByVal ParentFolder As String) As ArrayList

            Dim folders As ArrayList = GetFolders(PortalId)
            Dim subFolders As New ArrayList
            For Each folder As FolderInfo In folders
                Dim strfolderPath As String = folder.FolderPath
                If folder.FolderPath.IndexOf(ParentFolder) > -1 AndAlso _
                        folder.FolderPath <> Null.NullString AndAlso _
                        folder.FolderPath <> ParentFolder Then
                    If ParentFolder = Null.NullString Then
                        If strfolderPath.IndexOf("/") = strfolderPath.LastIndexOf("/") Then
                            subFolders.Add(folder)
                        End If
                    ElseIf strfolderPath.StartsWith(ParentFolder) Then
                        strfolderPath = strfolderPath.Substring(ParentFolder.Length + 1)
                        If strfolderPath.IndexOf("/") = strfolderPath.LastIndexOf("/") Then
                            subFolders.Add(folder)
                        End If
                    End If
                End If
            Next

            Return subFolders

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets the Roles that have a particualr Permission for a Folder
        ''' </summary>
        ''' <param name="Folder">The Folder</param>
        ''' <param name="PortalId">The Id of the Portal</param>
        ''' <param name="Permission">The Permissions to find</param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function GetRoles(ByVal Folder As String, ByVal PortalId As Integer, ByVal Permission As String) As String

            Dim Roles As New System.Text.StringBuilder
            Dim objFolderPermissionController As New DotNetNuke.Security.Permissions.FolderPermissionController

            Dim objCurrentFolderPermissions As DotNetNuke.Security.Permissions.FolderPermissionCollection
            objCurrentFolderPermissions = objFolderPermissionController.GetFolderPermissionsCollectionByFolderPath(PortalId, Folder)
            Dim objFolderPermission As DotNetNuke.Security.Permissions.FolderPermissionInfo
            For Each objFolderPermission In objCurrentFolderPermissions
                If objFolderPermission.AllowAccess And objFolderPermission.PermissionKey = Permission Then
                    Roles.Append(objFolderPermission.RoleName)
                    Roles.Append(";")
                End If
            Next
            Return Roles.ToString
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Moves (Renames) a File
        ''' </summary>
        ''' <param name="strSourceFile">The original File Name</param>
        ''' <param name="strDestFile">The new File Name</param>
        ''' <param name="settings">The Portal Settings for the Portal/Host Account</param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	12/2/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function MoveFile(ByVal strSourceFile As String, ByVal strDestFile As String, ByVal settings As PortalSettings) As String
            Dim FolderPortalId As Integer = Null.NullInteger
            Dim HomeDirectory As String = Globals.HostMapPath
            Dim isHost As Boolean = CType(IIf(settings.ActiveTab.ParentId = settings.SuperTabId, True, False), Boolean)
            If Not isHost Then
                FolderPortalId = settings.PortalId
                HomeDirectory = settings.HomeDirectoryMapPath
            End If
            Return UpdateFile(strSourceFile, strDestFile, FolderPortalId, HomeDirectory, False, False, True)
        End Function

        Public Shared Sub SaveFile(ByVal FullFileName As String, ByVal Buffer As Byte())
            If System.IO.File.Exists(FullFileName) Then
                System.IO.File.SetAttributes(FullFileName, FileAttributes.Normal)
            End If
            Dim fs As New FileStream(FullFileName, FileMode.Create, FileAccess.Write)
            fs.Write(Buffer, 0, Buffer.Length)
            fs.Close()
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Assigns 1 or more attributes to a file
        ''' </summary>
        ''' <param name="FileLoc">File Location</param>
        ''' <param name="FileAttributesOn">Pass in Attributes you wish to switch on (i.e. FileAttributes.Hidden + FileAttributes.ReadOnly)</param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[Jon Henning]	11/1/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Sub SetFileAttributes(ByVal FileLoc As String, ByVal FileAttributesOn As Integer)
            System.IO.File.SetAttributes(FileLoc, CType(FileAttributesOn, FileAttributes))
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Sets a Folders Permissions
        ''' </summary>
        ''' <param name="PortalId">The Id of the Portal</param>
        ''' <param name="FolderId">The Id of the Folder</param>
        ''' <param name="AdministratorRoleId">The Id of the Administrator Role</param>
        ''' <param name="relativePath">The folder's Relative Path</param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	12/4/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Sub SetFolderPermissions(ByVal PortalId As Integer, ByVal FolderId As Integer, ByVal AdministratorRoleId As Integer, ByVal relativePath As String)

            'Set Permissions
            Dim objPermissionController As New PermissionController
            Dim Permissions As ArrayList = objPermissionController.GetPermissionsByFolder(PortalId, "")
            Dim objPermssionsInfo As PermissionInfo
            Dim objFolderPermissionController As New DotNetNuke.Security.Permissions.FolderPermissionController
            For Each objPermssionsInfo In Permissions
                SetFolderPermission(PortalId, FolderId, objPermssionsInfo.PermissionID, AdministratorRoleId, relativePath)
            Next

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Sets a Folder Permission
        ''' </summary>
        ''' <param name="PortalId">The Id of the Portal</param>
        ''' <param name="FolderId">The Id of the Folder</param>
        ''' <param name="PermissionId">The Id of the Permission</param>
        ''' <param name="RoleId">The Id of the Role</param>
        ''' <param name="relativePath">The folder's Relative Path</param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	01/12/2005	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Sub SetFolderPermission(ByVal PortalId As Integer, ByVal FolderId As Integer, ByVal PermissionId As Integer, ByVal RoleId As Integer, ByVal relativePath As String)

            Dim objFolderPermissionController As New FolderPermissionController
            Dim objCurrentFolderPermissions As FolderPermissionCollection
            Dim objFolderPermissionInfo As New FolderPermissionInfo
            objCurrentFolderPermissions = objFolderPermissionController.GetFolderPermissionsCollectionByFolderPath(PortalId, relativePath)

            'Iterate current permissions to see if permisison has already been added
            For Each objFolderPermissionInfo In objCurrentFolderPermissions
                If objFolderPermissionInfo.FolderID = FolderId And _
                    objFolderPermissionInfo.PermissionID = PermissionId And _
                    objFolderPermissionInfo.RoleID = RoleId And _
                    objFolderPermissionInfo.AllowAccess = True Then

                    Exit Sub
                End If
            Next

            'Permission not found so Add
            objFolderPermissionInfo = CType(CBO.InitializeObject(objFolderPermissionInfo, GetType(FolderPermissionInfo)), FolderPermissionInfo)
            objFolderPermissionInfo.FolderID = FolderId
            objFolderPermissionInfo.PermissionID = PermissionId
            objFolderPermissionInfo.RoleID = RoleId
            objFolderPermissionInfo.AllowAccess = True
            objFolderPermissionController.AddFolderPermission(objFolderPermissionInfo)
        End Sub

        Public Shared Sub Synchronize(ByVal PortalId As Integer, ByVal AdministratorRoleId As Integer, ByVal HomeDirectory As String)

            Dim PhysicalRoot As String = HomeDirectory
            Dim VirtualRoot As String = ""

            'Call Synchronize Folder that recursively parses the subfolders
            SynchronizeFolder(PortalId, AdministratorRoleId, HomeDirectory, PhysicalRoot, VirtualRoot, True)

            Dim f As New FileController
            f.GetAllFilesRemoveCache()

        End Sub

        Public Shared Sub SynchronizeFolder(ByVal PortalId As Integer, ByVal AdministratorRoleId As Integer, ByVal HomeDirectory As String, ByVal physicalPath As String, ByVal relativePath As String, ByVal isRecursive As Boolean)

            Dim folder As String
            Dim fileName As String
            Dim FolderId As Integer

            If Directory.Exists(physicalPath) Then
                'Add the folder
                Dim dr As IDataReader = DataProvider.Instance().GetFolder(PortalId, relativePath)
                Dim storageLocation As Integer
                Dim IsProtected As Boolean = False

                ' check to see if the folder exists in the db, if it does then use the current file system storage method
                If dr.Read Then
                    storageLocation = Convert.ToInt16(dr("StorageLocation"))
                Else
                    ' folder is not in db, use default type of storage
                    storageLocation = FolderController.StorageLocationTypes.InsecureFileSystem
                End If
                dr.Close()

                FolderId = AddFolder(PortalId, AdministratorRoleId, relativePath, storageLocation)

                'Get Sub Folders (and synchronize recursively)
                If isRecursive Then
                    Dim folders As String() = Directory.GetDirectories(physicalPath)
                    For Each folder In folders
                        Dim dir As New DirectoryInfo(folder)
                        Dim relPath As String
                        If relativePath = "" Then
                            relPath = dir.Name
                        Else
                            relPath = relativePath & "/" & dir.Name
                        End If
                        SynchronizeFolder(PortalId, AdministratorRoleId, HomeDirectory, folder, relPath, True)
                    Next
                End If

                'Get Files in this Folder
                Dim files As String() = Directory.GetFiles(physicalPath)
                For Each fileName In files
                    'Add the File if it doesn't exist
                    AddFile(fileName, PortalId, HomeDirectory, False)
                Next
            End If

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Unzips a File
        ''' </summary>
        ''' <param name="fileName">The zip File Name</param>
        ''' <param name="DestFolder">The folder where the file is extracted to</param>
        ''' <param name="settings">The Portal Settings for the Portal/Host Account</param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function UnzipFile(ByVal fileName As String, ByVal DestFolder As String, ByVal settings As PortalSettings) As String

            Dim FolderPortalId As Integer = Null.NullInteger
            Dim HomeDirectory As String = Globals.HostMapPath
            Dim isHost As Boolean = CType(IIf(settings.ActiveTab.ParentId = settings.SuperTabId, True, False), Boolean)
            If Not isHost Then
                FolderPortalId = settings.PortalId
                HomeDirectory = settings.HomeDirectoryMapPath
            End If

            Dim objPortalController As New PortalController
            Dim objFolderController As New DotNetNuke.Services.FileSystem.FolderController
            Dim objFileController As New DotNetNuke.Services.FileSystem.FileController
            Dim sourceFolderName As String = GetSubFolderPath(fileName)
            Dim sourceFileName As String = GetFileName(fileName)
            Dim folder As FolderInfo = objFolderController.GetFolder(FolderPortalId, sourceFolderName)
            Dim file As DotNetNuke.Services.FileSystem.FileInfo = objFileController.GetFile(sourceFileName, FolderPortalId, sourceFolderName)
            Dim storageLocation As Integer = folder.StorageLocation
            Dim objZipInputStream As ZipInputStream
            Dim objZipEntry As ZipEntry
            Dim strMessage As String = ""
            Dim strFileName As String = ""
            Dim strExtension As String

            'Get the source Content from wherever it is

            'Create a Zip Input Stream
            Try
                objZipInputStream = New ZipInputStream(GetFileStream(file, FolderPortalId, HomeDirectory))
            Catch ex As Exception
                Return ex.Message
            End Try

            objZipEntry = objZipInputStream.GetNextEntry
            While Not objZipEntry Is Nothing
                If objZipEntry.IsDirectory Then
                    Try
                        AddFolder(settings, DestFolder, objZipEntry.Name, storageLocation)
                    Catch ex As Exception
                        objZipInputStream.Close()
                        Return ex.Message
                    End Try
                End If
                objZipEntry = objZipInputStream.GetNextEntry
            End While

            'Recreate the Zip Input Stream and parse it for the files
            objZipInputStream = New ZipInputStream(GetFileStream(file, FolderPortalId, HomeDirectory))
            objZipEntry = objZipInputStream.GetNextEntry
            While Not objZipEntry Is Nothing
                If Not objZipEntry.IsDirectory Then
                    If objPortalController.HasSpaceAvailable(FolderPortalId, objZipEntry.Size) Or isHost Then
                        strFileName = Path.GetFileName(objZipEntry.Name)
                        If strFileName <> "" Then
                            strExtension = Path.GetExtension(strFileName).Replace(".", "")
                            If InStr(1, "," & settings.HostSettings("FileExtensions").ToString.ToLower, "," & strExtension.ToLower) <> 0 Or isHost Then
                                Try
                                    Dim folderPath As String = System.IO.Path.GetDirectoryName(DestFolder & Replace(objZipEntry.Name, "/", "\"))
                                    Dim Dinfo As New DirectoryInfo(folderPath)
                                    If Not Dinfo.Exists Then
                                        AddFolder(settings, DestFolder, objZipEntry.Name.Substring(0, Replace(objZipEntry.Name, "/", "\").LastIndexOf("\")))
                                    End If

                                    Dim zipEntryFileName As String = DestFolder & Replace(objZipEntry.Name, "/", "\")
                                    strMessage += AddFile(FolderPortalId, objZipInputStream, zipEntryFileName, "", objZipEntry.Size, GetSubFolderPath(zipEntryFileName), False, False)
                                Catch ex As Exception
                                    If Not objZipInputStream Is Nothing Then
                                        objZipInputStream.Close()
                                    End If
                                    Return ex.Message
                                End Try
                            Else
                                ' restricted file type
                                strMessage += "<br>" & String.Format(Localization.GetString("RestrictedFileType"), strFileName, Replace(settings.HostSettings("FileExtensions").ToString, ",", ", *."))
                            End If
                        End If
                    Else    ' file too large
                        strMessage += "<br>" & String.Format(Localization.GetString("DiskSpaceExceeded"), strFileName)
                    End If

                End If

                objZipEntry = objZipInputStream.GetNextEntry
            End While

            objZipInputStream.Close()

            Dim f As New FileController
            f.GetAllFilesRemoveCache()

            Return strMessage

        End Function

        Public Shared Sub UnzipResources(ByVal zipStream As ZipInputStream, ByVal destPath As String)
            Dim objZipEntry As ZipEntry
            Dim LocalFileName, RelativeDir, FileNamePath As String

            objZipEntry = zipStream.GetNextEntry
            While Not objZipEntry Is Nothing
                ' This gets the Zipped FileName (including the path)
                LocalFileName = objZipEntry.Name

                ' This creates the necessary directories if they don't 
                ' already exist.
                RelativeDir = Path.GetDirectoryName(objZipEntry.Name)
                If (RelativeDir <> String.Empty) AndAlso (Not Directory.Exists(Path.Combine(destPath, RelativeDir))) Then
                    Directory.CreateDirectory(Path.Combine(destPath, RelativeDir))
                End If

                ' This block creates the file using buffered reads from the zipfile
                If (Not objZipEntry.IsDirectory) AndAlso (LocalFileName <> "") Then
                    FileNamePath = Path.Combine(destPath, LocalFileName).Replace("/", "\")

                    Try
                        ' delete the file if it already exists
                        If File.Exists(FileNamePath) Then
                            File.SetAttributes(FileNamePath, FileAttributes.Normal)
                            File.Delete(FileNamePath)
                        End If

                        ' create the file
                        Dim objFileStream As FileStream = File.Create(FileNamePath)

                        Dim intSize As Integer = 2048
                        Dim arrData(2048) As Byte

                        intSize = zipStream.Read(arrData, 0, arrData.Length)
                        While intSize > 0
                            objFileStream.Write(arrData, 0, intSize)
                            intSize = zipStream.Read(arrData, 0, arrData.Length)
                        End While

                        objFileStream.Close()
                    Catch
                        ' an error occurred saving a file in the resource file
                    End Try

                End If

                objZipEntry = zipStream.GetNextEntry
            End While
            If Not zipStream Is Nothing Then
                zipStream.Close()
            End If


        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' UploadFile pocesses a single file 
        ''' </summary>
        ''' <param name="RootPath">The folder wherr the file will be put</param>
        ''' <param name="objHtmlInputFile">The file to upload</param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        '''     [cnurse]        16/9/2004   Updated for localization, Help and 508
        '''     [Philip Beadle] 10/06/2004  Moved to Globals from WebUpload.ascx.vb so can be accessed by URLControl.ascx
        '''     [cnurse]        04/26/2006  Updated for Secure Storage    
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function UploadFile(ByVal RootPath As String, ByVal objHtmlInputFile As HttpPostedFile, Optional ByVal Unzip As Boolean = False) As String

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = PortalController.GetCurrentPortalSettings
            Dim PortalId As Integer

            If _portalSettings.ActiveTab.ParentId = _portalSettings.SuperTabId Then
                PortalId = Null.NullInteger
            Else
                PortalId = _portalSettings.PortalId
            End If

            Dim objPortalController As New PortalController
            Dim strMessage As String = ""
            Dim strFileName As String = RootPath & Path.GetFileName(objHtmlInputFile.FileName)
            Dim strExtension As String = Replace(Path.GetExtension(strFileName), ".", "")
            Dim strFolderpath As String = GetSubFolderPath(strFileName)

            If ((((objPortalController.GetPortalSpaceUsedBytes(_portalSettings.PortalId) + objHtmlInputFile.ContentLength) / 1024 ^ 2) <= _portalSettings.HostSpace) Or _portalSettings.HostSpace = 0) Or (_portalSettings.ActiveTab.ParentId = _portalSettings.SuperTabId) Then
                If InStr(1, "," & _portalSettings.HostSettings("FileExtensions").ToString.ToUpper, "," & strExtension.ToUpper) <> 0 Or _portalSettings.ActiveTab.ParentId = _portalSettings.SuperTabId Then
                    'Save Uploaded file to server
                    Try
                        strMessage += AddFile(PortalId, objHtmlInputFile.InputStream, strFileName, objHtmlInputFile.ContentType, objHtmlInputFile.ContentLength, strFolderpath, True, True)

                        'Optionally Unzip File?
                        If Path.GetExtension(strFileName).ToLower = ".zip" And Unzip = True Then
                            strMessage += UnzipFile(strFileName, RootPath, _portalSettings)
                        End If
                    Catch Exc As Exception
                        ' save error - can happen if the security settings are incorrect
                        strMessage += "<br>" & String.Format(Localization.GetString("SaveFileError"), strFileName)
                    End Try
                Else
                    ' restricted file type
                    strMessage += "<br>" & String.Format(Localization.GetString("RestrictedFileType"), strFileName, Replace(_portalSettings.HostSettings("FileExtensions").ToString, ",", ", *."))
                End If
            Else    ' file too large
                strMessage += "<br>" & String.Format(Localization.GetString("DiskSpaceExceeded"), strFileName)
            End If

            Return strMessage
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Writes file to response stream.  Workaround offered by MS for large files
        ''' http://support.microsoft.com/default.aspx?scid=kb;EN-US;812406
        ''' </summary>
        ''' <param name="strFileName">FileName</param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[Jon Henning]	1/4/2005	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Sub WriteFile(ByVal strFileName As String)
            Dim objResponse As System.Web.HttpResponse = System.Web.HttpContext.Current.Response
            Dim objStream As System.IO.Stream = Nothing

            ' Buffer to read 10K bytes in chunk:
            Dim bytBuffer(10000) As Byte

            ' Length of the file:
            Dim intLength As Integer

            ' Total bytes to read:
            Dim lngDataToRead As Long

            Try
                ' Open the file.
                objStream = New System.IO.FileStream(strFileName, System.IO.FileMode.Open, IO.FileAccess.Read, IO.FileShare.Read)

                ' Total bytes to read:
                lngDataToRead = objStream.Length

                objResponse.ContentType = "application/octet-stream"

                ' Read the bytes.
                While lngDataToRead > 0
                    ' Verify that the client is connected.
                    If objResponse.IsClientConnected Then
                        ' Read the data in buffer
                        intLength = objStream.Read(bytBuffer, 0, 10000)

                        ' Write the data to the current output stream.
                        objResponse.OutputStream.Write(bytBuffer, 0, intLength)

                        ' Flush the data to the HTML output.
                        objResponse.Flush()

                        ReDim bytBuffer(10000)       ' Clear the buffer
                        lngDataToRead = lngDataToRead - intLength
                    Else
                        'prevent infinite loop if user disconnects
                        lngDataToRead = -1
                    End If
                End While

            Catch ex As Exception
                ' Trap the error, if any.
                objResponse.Write("Error : " & ex.Message)
            Finally
                If IsNothing(objStream) = False Then
                    ' Close the file.
                    objStream.Close()
                End If
            End Try
        End Sub


#End Region

    End Class

End Namespace
