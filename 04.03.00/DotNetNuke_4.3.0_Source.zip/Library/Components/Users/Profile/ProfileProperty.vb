'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2006
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Namespace DotNetNuke.Entities.Profile

    ''' -----------------------------------------------------------------------------
    ''' Project:    DotNetNuke
    ''' Namespace:  DotNetNuke.Entities.Profile
    ''' Class:      ProfileProperty
    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' The ProfileProperty class provides the Entity Layer's definition of a property
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    '''     [cnurse]	02/02/2006	created
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Public Class ProfileProperty

#Region "Private Members"

        Private _IsDirty As Boolean = False
        Private _IsPublic As Boolean = True
        Private _PropertyValue As Object

#End Region

#Region "Constructors"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Constructs a property
        ''' </summary>
        ''' <remarks>This overload constructs a property with true visibility</remarks>
        ''' <param name="value">The value of the property</param>
        ''' <history>
        '''     [cnurse]	01/31/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub New(ByVal value As Object)
            Me.New(value, True, False)
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Constructs a property
        ''' </summary>
        ''' <remarks>This overload constructs a property with optional visibility</remarks>
        ''' <param name="value">The value of the property</param>
        ''' <param name="isPublic">A flag that determines the visibility of the property</param>
        ''' <history>
        '''     [cnurse]	01/31/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub New(ByVal value As Object, ByVal isPublic As Boolean)
            Me.New(value, isPublic, False)
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Constructs a property
        ''' </summary>
        ''' <remarks>This overload constructs a property with optional visibility</remarks>
        ''' <param name="value">The value of the property</param>
        ''' <param name="isPublic">A flag that determines the visibility of the property</param>
        ''' <param name="isDirty">A flag that determines whether the property has been changed</param>
        ''' <history>
        '''     [cnurse]	01/31/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub New(ByVal value As Object, ByVal isPublic As Boolean, ByVal isDirty As Boolean)
            _PropertyValue = value
            _IsPublic = isPublic
            _IsDirty = isDirty
        End Sub

#End Region

#Region "Public Properties"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets whether the property has been changed
        ''' </summary>
        ''' <history>
        '''     [cnurse]	01/31/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public ReadOnly Property IsDirty() As Boolean
            Get
                Return _IsDirty
            End Get
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets and sets the public visibility of this property
        ''' </summary>
        ''' <history>
        '''     [cnurse]	01/31/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Property IsPublic() As Boolean
            Get
                Return _IsPublic
            End Get
            Set(ByVal Value As Boolean)
                If _IsPublic <> Value Then
                    _IsDirty = True
                End If
                _IsPublic = Value

            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets and sets the value of the property
        ''' </summary>
        ''' <history>
        '''     [cnurse]	01/31/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Property PropertyValue() As Object
            Get
                Return _PropertyValue
            End Get
            Set(ByVal Value As Object)
                If Not (_PropertyValue Is Value) Then
                    _IsDirty = True
                End If
                _PropertyValue = Value
            End Set
        End Property

#End Region

#Region "Public Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets the string value of the property
        ''' </summary>
        ''' <history>
        '''     [cnurse]	02/14/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overrides Function ToString() As String

            Dim retValue As String = ""

            If Not PropertyValue Is Nothing Then
                retValue = PropertyValue.ToString()
            End If

            Return retValue

        End Function

#End Region

    End Class

End Namespace

