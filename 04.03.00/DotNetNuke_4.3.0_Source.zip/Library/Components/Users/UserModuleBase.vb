'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2006
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.Configuration
Imports System.Data
Imports System.IO

Imports DotNetNuke.Entities.Modules.Actions
Imports DotNetNuke.UI.Skins

Namespace DotNetNuke.Entities.Modules

#Region "Enums"

    Public Enum DisplayMode
        All = 0
        FirstLetter = 1
        None = 2
    End Enum

    Public Enum UsersControl
        Combo = 0
        TextBox = 1
    End Enum

#End Region


    ''' -----------------------------------------------------------------------------
    ''' Project	 :  DotNetNuke
    ''' Namespace:  DotNetNuke.Entities.Modules
    ''' Class	 :  UserModuleBase
    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' The UserModuleBase class defines a custom base class inherited by all
    ''' desktop portal modules within the Portal that manage Users.
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    '''		[cnurse]	03/20/2006
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Public Class UserModuleBase
        Inherits PortalModuleBase

#Region "Public Shared Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets the Default Settings for the Module
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	03/02/2006
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function GetDefaultSettings() As Hashtable

            Return GetSettings(New Hashtable)

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets the Settings for the Module
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	03/02/2006
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function GetSettings(ByVal settings As Hashtable) As Hashtable

            Dim _portalSettings As PortalSettings = PortalController.GetCurrentPortalSettings()

            If settings("Column_FirstName") Is Nothing Then
                settings("Column_FirstName") = False
            End If
            If settings("Column_LastName") Is Nothing Then
                settings("Column_LastName") = False
            End If
            If settings("Column_DisplayName") Is Nothing Then
                settings("Column_DisplayName") = True
            End If
            If settings("Column_Address") Is Nothing Then
                settings("Column_Address") = True
            End If
            If settings("Column_Telephone") Is Nothing Then
                settings("Column_Telephone") = True
            End If
            If settings("Column_Email") Is Nothing Then
                settings("Column_Email") = False
            End If
            If settings("Column_CreatedDate") Is Nothing Then
                settings("Column_CreatedDate") = True
            End If
            If settings("Column_LastLogin") Is Nothing Then
                settings("Column_LastLogin") = False
            End If
            If settings("Column_Authorized") Is Nothing Then
                settings("Column_Authorized") = True
            End If
            If settings("Display_Mode") Is Nothing Then
                settings("Display_Mode") = DisplayMode.None
            Else
                settings("Display_Mode") = CType(settings("Display_Mode"), DisplayMode)
            End If
            If settings("Records_PerPage") Is Nothing Then
                settings("Records_PerPage") = 10
            End If
            If settings("Redirect_AfterLogin") Is Nothing Then
                settings("Redirect_AfterLogin") = -1
            End If
            If settings("Redirect_AfterRegistration") Is Nothing Then
                settings("Redirect_AfterRegistration") = -1
            End If
            If settings("Redirect_AfterLogout") Is Nothing Then
                settings("Redirect_AfterLogout") = -1
            End If
            If settings("Security_CaptchaLogin") Is Nothing Then
                settings("Security_CaptchaLogin") = False
            End If
            If settings("Security_CaptchaRegister") Is Nothing Then
                settings("Security_CaptchaRegister") = False
            End If
            If settings("Security_RequireValidProfile") Is Nothing Then
                settings("Security_RequireValidProfile") = False
            End If
            If settings("Security_UsersControl") Is Nothing Then
                If UserController.GetUserCountByPortal(_portalSettings.PortalId) > 1000 Then
                    settings("Security_UsersControl") = UsersControl.TextBox
                Else
                    settings("Security_UsersControl") = UsersControl.Combo
                End If
            Else
                settings("Security_UsersControl") = CType(settings("Security_UsersControl"), UsersControl)
            End If

            Return settings

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets a Setting for the Module
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	05/01/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function GetSetting(ByVal portalId As Integer, ByVal settingKey As String) As Object

            Dim settings As Hashtable = UserController.GetUserSettings(portalId)
            Dim setting As Object = settings(settingKey)
            If setting Is Nothing Then
                'Get Default Setting
                setting = GetDefaultSettings(settingKey)
            End If

            Return setting

        End Function

#End Region

#Region "Private Members"

        Private _User As UserInfo

#End Region

#Region "Protected Properties"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets whether we are in Add User mode
        ''' </summary>
        ''' <history>
        ''' 	[cnurse]	03/06/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Protected ReadOnly Property AddUser() As Boolean
            Get
                Return (UserId = Null.NullInteger)
            End Get
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets whether the current user is an Administrator (or SuperUser)
        ''' </summary>
        ''' <history>
        ''' 	[cnurse]	03/03/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Protected ReadOnly Property IsAdmin() As Boolean
            Get
                Return (UserInfo.IsInRole(Me.PortalSettings.AdministratorRoleName) Or UserInfo.IsSuperUser)
            End Get
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets whether the current user is modifying their profile
        ''' </summary>
        ''' <history>
        ''' 	[cnurse]	03/21/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Protected ReadOnly Property IsProfile() As Boolean
            Get
                Dim _IsProfile As Boolean = False
                If IsUser Then
                    If Not (Request.QueryString("ctl") Is Nothing) Then
                        Dim ctl As String = Request.QueryString("ctl")
                        If ctl = "Profile" Then
                            _IsProfile = True
                        End If
                    End If
                End If
                Return _IsProfile
            End Get
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets whether an anonymous user is trying to register
        ''' </summary>
        ''' <history>
        ''' 	[cnurse]	03/21/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Protected ReadOnly Property IsRegister() As Boolean
            Get
                Dim _IsRegister As Boolean = False
                If Not IsAdmin And Not IsUser Then
                    If Not (Request.QueryString("ctl") Is Nothing) Then
                        Dim ctl As String = Request.QueryString("ctl")
                        If ctl = "Register" Then
                            _IsRegister = True
                        End If
                    End If
                End If
                Return _IsRegister
            End Get
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets whether the User is editing their own information
        ''' </summary>
        ''' <history>
        ''' 	[cnurse]	03/03/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Protected ReadOnly Property IsUser() As Boolean
            Get
                Dim _IsUser As Boolean = False
                If Request.IsAuthenticated Then
                    _IsUser = (User.UserID = UserInfo.UserID)
                End If
                Return _IsUser
            End Get
        End Property

#End Region

#Region "Public Properties"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets and sets the User associated with this control
        ''' </summary>
        ''' <history>
        ''' 	[cnurse]	03/02/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Property User() As UserInfo
            Get
                If _User Is Nothing Then
                    If AddUser Then
                        _User = InitialiseUser()
                    Else
                        _User = UserController.GetUser(PortalId, UserId, False)
                    End If
                End If
                Return _User
            End Get
            Set(ByVal Value As UserInfo)
                _User = Value
                If Not _User Is Nothing Then
                    UserId = _User.UserID
                End If
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets and sets the UserId associated with this control
        ''' </summary>
        ''' <history>
        ''' 	[cnurse]	03/01/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shadows Property UserId() As Integer
            Get
                Return CType(ViewState("UserId"), Integer)
            End Get
            Set(ByVal Value As Integer)
                ViewState("UserId") = Value
            End Set
        End Property

#End Region

#Region "Private Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' InitialiseUser initialises a "new" user
        ''' </summary>
        ''' <history>
        ''' 	[cnurse]	03/13/2006
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function InitialiseUser() As UserInfo

            Dim newUser As New UserInfo

            If IsHostMenu Then
                newUser.IsSuperUser = True
            Else
                newUser.PortalID = PortalId
            End If

            ''Initialise the ProfileProperties Collection
            newUser.Profile.InitialiseProfile(PortalId)
            newUser.Profile.PreferredLocale = Me.PortalSettings.DefaultLanguage
            newUser.Profile.TimeZone = Me.PortalSettings.TimeZoneOffset

            ''Set AffiliateId
            Dim AffiliateId As Integer = Null.NullInteger
            If Not Request.Cookies("AffiliateId") Is Nothing Then
                AffiliateId = Integer.Parse(Request.Cookies("AffiliateId").Value)
            End If
            newUser.AffiliateID = AffiliateId

            Return newUser

        End Function

#End Region

    End Class

End Namespace
