FreeTextBox Readme

FreeTextBox is an ASP.NET Control written in C#.NET that utilizes 
Microsoft's MSHTML to created a WYSIWYG HTML editor.  It is fully customizable
and includes some helper scripts for image and color editing.

The source can be found at http://sourceforge.net/projects/freetextbox/
Discussion forums are http://revjon.com/forums/

And