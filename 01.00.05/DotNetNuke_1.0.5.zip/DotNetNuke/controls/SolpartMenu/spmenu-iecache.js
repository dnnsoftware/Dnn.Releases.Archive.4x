//script generated taken from solpartmenu
//using prefix spm

var spm_m_sOuterTables = '';
var spm_m_objDOM;
var spm_m_objMenu;

function GenerateMenuHTML(oXML, oMenu) 
{
    //'Generates the main menu bar
    var sHTML = '';
	if (oXML.readyState != 'complete')
		return;
	spm_m_objMenu = oMenu;
	spm_m_objDOM = oXML;
	
	//stop.it;
    if (spm_m_objMenu.Display == "Vertical")
    {
        sHTML = "<TABLE ID='tblMenuBar' CELLPADDING=\"0\" CELLSPACING=\"0\" BORDER='0' BGCOLOR='" + spm_m_objMenu.BackColor + "' CLASS='spmbctr' HEIGHT='100%'>";
        sHTML += "	<TR ID='trMenuBar' >";
        sHTML += MyIIf(Number(spm_m_objMenu.Moveable), "       <TD height=\"3px\" style=\"cursor: move; " + spm_m_objMenu.MenuBorderStyle + "\" onmousedown=\"menuhook_MouseDown(this)\" onmouseup=\"menuhook_MouseUp(this)\" onmousemove=\"menuhook_MouseMove(event)\">" + GetSpacer() + "</TD>", "");
        sHTML += "   </TR>";
        sHTML +=         GetMenuItems(spm_m_objDOM.documentElement);
        sHTML += "       <TR><TD HEIGHT='100%'>" + GetSpacer() + "</TD>" ;
        sHTML += "   </TR>";
        sHTML += "</TABLE>";
    }
    else
    {
        sHTML = "<TABLE ID='tblMenuBar' CELLPADDING=\"0\" CELLSPACING=\"0\" BORDER='0' BGCOLOR='" + spm_m_objMenu.BackColor + "' CLASS='spmbctr' WIDTH='100%' onkeydown='menuhook_KeyDown();' onkeypress='menuhook_KeyPress();' tabindex='0'>";
        sHTML += "	<TR ID='trMenuBar' >";
        sHTML += MyIIf(Number(spm_m_objMenu.Moveable), "       <TD width=\"3px\" style=\"cursor: move; " + spm_m_objMenu.MenuBorderStyle + "\" onmousedown=\"menuhook_MouseDown(this)\" onmouseup=\"menuhook_MouseUp(this)\" onmousemove=\"menuhook_MouseMove(event)\">" + GetSpacer() + "</TD>", "");
        sHTML += GetMenuSpacingImage("left");
        sHTML +=         GetMenuItems(spm_m_objDOM.documentElement);
        sHTML += GetMenuSpacingImage("right");
        sHTML += "   </TR>";
        sHTML += "</TABLE>";
    }

    sHTML = sHTML + spm_m_sOuterTables;
    spm_m_objMenu.innerHTML = sHTML;
}

function GetMenuItems(objParent)
{
    var objNode;
    var sHTML = '';
    var sID;
    var sParentID;
    var sClickAction;
	for (var i = 0; i < objParent.childNodes.length; i++)
	{
		objNode = objParent.childNodes(i);
		
		//'determine if root level item and set parent id accordingly
		if (objNode.parentNode.nodeName != "menuitem")
			sParentID = "-1";
		else
			sParentID = objNode.parentNode.getAttribute("id");

		if (objNode.nodeName == "menuitem")
			sID = objNode.getAttribute("id");
		else
			sID = "";

		if (sParentID == "-1")	//'if top level menu item
		{
			if (GetMenuClickAction(objNode).length == 0)
			{
				//'if no URL associated then display sub menu
				sClickAction = "mb_c(this)";
			}
			else
			{
				//'top level menu item has URL so navigate to it when clicked
				sClickAction = GetMenuClickAction(objNode);
			}
			if (spm_m_objMenu.Display == "Vertical")
				sHTML += "<TR>"; //'if vertical display then add rows for each top menuitem
				
			sHTML += "   <TD id=\"td" + sID + "\" class=\"spmbar\" onclick=\"" + sClickAction + "\" onmousedown=\"mb_md(this)\" onmouseup=\"mb_mu(this)\" onmouseover=\"mb_mo(this)\" onmouseout=\"mb_mout(this)\" NOWRAP><table width=\"100%\"><tr class=\"spmbar\"><td class=\"spmitm\" NOWRAP style=\"" + GetMenuItemStyle("item", objNode) + "\">&nbsp;" + objNode.getAttribute("title") + MyIIf(spm_m_objMenu.RootArrow == 'True', '</td><td class="spmarw" align="right" NOWRAP>' + GetArrow() + '', "&nbsp;") + "</td></tr></table></TD>";

			if (spm_m_objMenu.Display == "Vertical")
				sHTML += "</TR>";
		}
		else                        //'submenu - not top level menu item
		{
			switch(objNode.nodeName)
			{
				case "menuitem":
				{
					sHTML +=		"   <TR ID=\"tr" + sID + "\" parentID=\"" + sParentID + "\" onclick=\"mbi_c(this);" + GetMenuClickAction(objNode) + "\" onmouseover=\"mbi_mo(this)\" onmouseout=\"mbi_mout(this)\" class=\"spmitmr\" style=\"" + GetMenuItemStyle("item", objNode) + "\">";
					sHTML +=		"       <TD id=\"icon" + sID + "\" class=\"spmicn\" style=\"" + GetMenuItemStyle("image", objNode) + "\">" + GetImage(objNode.getAttribute("image")) + "</TD>";
					sHTML +=		"       <TD id=\"td" + sID + "\" class=\"spmitm\" NOWRAP >" + objNode.getAttribute("title") + "</TD>";
					sHTML +=		"       <TD id=\"arrow" + sID + "\" width=\"15px\" CLASS=\"spmarw\">" + MyIIf(objNode.childNodes.length > 0, GetArrow(), GetSpacer()) + "</TD>";
					sHTML +=		"   </TR>";
					break;
				}
				case "menubreak":
				{
					if (spm_m_objMenu.IconBackgroundColor == spm_m_objMenu.BackColor)
						sHTML += "   <TR><TD NOWRAP height=\"0px\" colspan=\"3\" class=\"spbrk\">" + GetImage2("spacer.gif") + "</TD></TR>";
					else
						sHTML += "   <TR><TD class=\"spmicn\">" + GetImage2("spacer.gif") + "</TD><TD NOWRAP height=\"0px\" colspan=\"2\" class=\"spbrk\">" + GetImage("spacer.gif") + "</TD></TR>";
					break;
				}
			}
		}

		//'Generate sub menu - note: we are recursively calling ourself
		//'netscape renders tables with display: block as having cellpadding!!! therefore using div outside table - LAME!
		if (objNode.childNodes.length > 0)
			spm_m_sOuterTables = "<DIV ID=\"tbl" + sID + "\" CLASS=\"spsub\" STYLE=\"display:none;\"><TABLE BGCOLOR=\"" + spm_m_objMenu.BackColor + "\" CELLPADDING=\"0\" CELLSPACING=\"0\" CLASS=\"spmenu\">" + GetMenuItems(objNode) + "</TABLE></DIV>" + spm_m_sOuterTables;
	}

	return sHTML;
}
function GetMenuItemStyle(sType, objNode)
{
  var sStyle = '';
  if (objNode.getAttribute(sType + "style") != null)
    sStyle += objNode.getAttribute(sType + "style");
  
  return sStyle;
}

function GetMenuClickAction(objNode)
{
  //'function to determine if menu item has action associated (URL)

  if (objNode.getAttribute("runat") != null)
    return "__doPostBack(SPM_UNIQUEID, '" + objNode.getAttribute('id') + "');";
  if (objNode.getAttribute("server") != null)
    return "__doPostBack(SPM_UNIQUEID, '" + objNode.getAttribute('id') + "');";
  
  if (objNode.getAttribute("url") == null)
		return "";
	
	if (objNode.getAttribute("url").length)
	{
		if (objNode.getAttribute("url").toLowerCase().substr(0, "javascript:".length) == "javascript:")
			return objNode.getAttribute("url").substr("javascript:".length) + ";";
		else
			return "document.location.href='" + objNode.getAttribute("url") + "';"
	}
	return '';
	
}

function GetMenuSpacingImage(sPos)
{
    if ((sPos == 'left' && spm_m_objMenu.MenuAlignment == 'Right') || (sPos == 'right' && spm_m_objMenu.MenuAlignment == 'Left'))
		return "       <TD width=\"100%\">" + GetSpacer() + "</TD>";

    if ((sPos == 'right' && spm_m_objMenu.MenuAlignment == 'Left') || (sPos == 'left' && spm_m_objMenu.MenuAlignment == 'Right'))
		return "       <TD width=\"3px\">" + GetSpacer() + "</TD>";

	if (spm_m_objMenu.MenuAlignment == 'Center')
		return "       <TD width=\"33%\">" + GetSpacer() + "</TD>";
	
	return '';   
}

function GetSpacer() 
{
    return '&nbsp;'; //"<IMG SRC=\"" + spm_m_objMenu.SystemImagesPath + "spacer.gif\">";
}


function GetImage(objAttr)
{
    //'retrieves an image for a passed in XMLAttribute
    if (objAttr == null)
        return '&nbsp;'; //GetImage2("spacer.gif");
    else
        return GetImage2(objAttr);
}

function GetImage2(sImage)
{
    //'generates html for image using the SystemImagesPath property
    if (sImage.length)
        return "<IMG SRC=\"" + spm_m_objMenu.SystemImagesPath + sImage + "\">";
}


function MyIIf(bFlag, sTrue, sFalse) 
{
    if (bFlag)
		return sTrue;
	else
		return sFalse;
}

function GetArrow() 
{
    if (spm_m_objMenu.ArrowImage.length)
        return GetImage2(spm_m_objMenu.ArrowImage);
    else
        return "4"; //'defaults to using wingdings font (4 = arrow)
    
}
