'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2003
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Namespace DotNetNuke

    Public Class ModuleDefinitions
        Inherits DotNetNuke.PortalModuleControl

        Protected WithEvents txtFriendlyName As System.Web.UI.WebControls.TextBox
        Protected WithEvents valFriendlyName As System.Web.UI.WebControls.RequiredFieldValidator
        Protected WithEvents txtDescription As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtDesktopSrc As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtEditSrc As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtMobileSrc As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtHostFee As System.Web.UI.WebControls.TextBox
        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdDelete As System.Web.UI.WebControls.LinkButton

        Private defId As Integer = -1

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        '*******************************************************
        '
        ' The Page_Load server event handler on this page is used
        ' to populate the role information for the page
        '
        '*******************************************************

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            ' Verify that the current user has access to this page
            If Context.User.Identity.Name <> _portalSettings.SuperUserId Then
                Response.Redirect("~/EditModule.aspx?tabid=" & TabId & "&def=Edit Access Denied")
            End If

            If Not (Request.Params("defid") Is Nothing) Then
                defId = Int32.Parse(Request.Params("defid"))
            End If

            ' If this is the first visit to the page, bind the definition data 
            If Page.IsPostBack = False Then

                cmdDelete.Attributes.Add("onClick", "javascript:return confirm('Are You Sure You Wish To Delete This Item ?');")

                If defId = -1 Then

                    ' new module definition
                    txtFriendlyName.Text = "New Definition"
                    txtDescription.Text = ""
                    txtDesktopSrc.Text = "DesktopModules/Directory/Module.ascx"
                    txtEditSrc.Text = "DesktopModules/Directory/EditModule.ascx"
                    txtMobileSrc.Text = "MobileModules/Module.ascx"
                    txtHostFee.Text = "0"

                Else

                    ' Obtain the module definition to edit from the database
                    Dim admin As New AdminDB()

                    Dim dr As SqlDataReader = admin.GetSingleModuleDefinition(defId)

                    If dr.Read() Then
                        txtFriendlyName.Text = dr("FriendlyName").ToString
                        txtDescription.Text = dr("Description").ToString
                        txtDesktopSrc.Text = dr("DesktopSrc").ToString
                        txtEditSrc.Text = dr("EditSrc").ToString
                        txtMobileSrc.Text = dr("MobileSrc").ToString
                        txtHostFee.Text = dr("HostFee").ToString
                    End If

                    dr.Close()

                End If

                ' Store URL Referrer to return to portal
                If Not Request.UrlReferrer Is Nothing Then
                    ViewState("UrlReferrer") = Request.UrlReferrer.ToString()
                Else
                    ViewState("UrlReferrer") = ""
                End If

            End If

        End Sub


        '****************************************************************
        '
        ' The cmdUpdate_Click event handler on this Page is used to either
        ' create or update a link.  It  uses the DotNetNuke.LinkDB()
        ' data component to encapsulate all data functionality.
        '
        '****************************************************************

        Private Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click

            If Page.IsValid = True Then

                Dim dblHostFee As Double = 0
                If txtHostFee.Text <> "" Then
                    dblHostFee = Double.Parse(txtHostFee.Text)
                End If

                Dim admin As New AdminDB()

                If defId = -1 Then
                    admin.AddModuleDefinition(txtFriendlyName.Text, txtDesktopSrc.Text, txtMobileSrc.Text, "", txtEditSrc.Text, True, txtDescription.Text, dblHostFee)
                Else
                    admin.UpdateModuleDefinition(defId, txtFriendlyName.Text, txtDesktopSrc.Text, txtMobileSrc.Text, "", txtEditSrc.Text, True, txtDescription.Text, dblHostFee)
                End If

                Response.Redirect(CType(Viewstate("UrlReferrer"), String))

            End If

        End Sub


        '****************************************************************
        '
        ' The cmdDelete_Click event handler on this Page is used to delete an
        ' a link.  It  uses the DotNetNuke.LinksDB()
        ' data component to encapsulate all data functionality.
        '
        '****************************************************************

        Private Sub cmdDelete_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdDelete.Click

            ' delete definition
            Dim admin As New AdminDB()
            admin.DeleteModuleDefinition(defId)

            Response.Redirect(CType(Viewstate("UrlReferrer"), String))

        End Sub


        '****************************************************************
        '
        ' The cmdCancel_Click event handler on this Page is used to cancel
        ' out of the page -- and return the user back to the portal home
        ' page.
        '
        '****************************************************************'

        Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click

            Response.Redirect(CType(Viewstate("UrlReferrer"), String))

        End Sub

    End Class

End Namespace
