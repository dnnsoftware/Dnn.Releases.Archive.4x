'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2003
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Namespace DotNetNuke

    Public Class WebUpload
        Inherits DotNetNuke.PortalModuleControl

        Protected WithEvents htmlUploadFile As System.Web.UI.HtmlControls.HtmlInputFile
        Protected WithEvents cmdUpload As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        '*******************************************************
        '
        ' The Page_Load server event handler on this page is used
        ' to populate the role information for the page
        '
        '*******************************************************

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            If Page.IsPostBack = False Then
                ' Store URL Referrer to return to portal
                If Not Request.UrlReferrer Is Nothing Then
                    ViewState("UrlReferrer") = Request.UrlReferrer.ToString()
                Else
                    ViewState("UrlReferrer") = ""
                End If
            End If

        End Sub

        Private Sub cmdUpload_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdUpload.Click
            Dim strFileName As String
            Dim strFileNamePath As String
            Dim strExtension As String = ""
            Dim imgImage As System.Drawing.Image
            Dim strWidth As String = ""
            Dim strHeight As String = ""

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            Dim objAdmin As New AdminDB()

            If ((((objAdmin.GetPortalSpaceUsed(PortalId) + htmlUploadFile.PostedFile.ContentLength) / 1000000) <= _portalSettings.HostSpace) Or _portalSettings.HostSpace = 0) Or (_portalSettings.ActiveTab.ParentId = _portalSettings.SuperTabId) Then

                'Gets the file name
                strFileName = System.IO.Path.GetFileName(htmlUploadFile.PostedFile.FileName)

                If _portalSettings.ActiveTab.ParentId = _portalSettings.SuperTabId Then
                    strFileNamePath = Request.MapPath("~/Site/") & strFileName
                Else
                    strFileNamePath = Request.MapPath(_portalSettings.UploadDirectory) & strFileName
                End If

                'Save Uploaded file to server
                htmlUploadFile.PostedFile.SaveAs(strFileNamePath)

                If InStr(1, strFileName, ".") Then
                    strExtension = Mid(strFileName, InStrRev(strFileName, ".") + 1)
                End If

                If InStr(1, "gif,jpg,jpeg", strExtension) Then
                    imgImage = imgImage.FromFile(strFileNamePath)
                    strHeight = imgImage.Height
                    strWidth = imgImage.Width
                    imgImage.Dispose()
                End If

                If _portalSettings.ActiveTab.ParentId = _portalSettings.SuperTabId Then
                    objAdmin.AddFile(-1, strFileName, strExtension, FileLen(strFileNamePath), strWidth, strHeight, htmlUploadFile.PostedFile.ContentType)
                Else
                    objAdmin.AddFile(PortalId, strFileName, strExtension, FileLen(strFileNamePath), strWidth, strHeight, htmlUploadFile.PostedFile.ContentType)
                End If

                Response.Redirect(CType(Viewstate("UrlReferrer"), String))
            End If

        End Sub

        Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
            Response.Redirect(CType(Viewstate("UrlReferrer"), String))
        End Sub

    End Class

End Namespace