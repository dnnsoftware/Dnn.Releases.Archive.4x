'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2003
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Namespace DotNetNuke

    Public MustInherit Class FileManager
        Inherits DotNetNuke.PortalModuleControl

        Protected WithEvents cboFiles As System.Web.UI.WebControls.DropDownList
        Protected WithEvents cmdDelete As System.Web.UI.WebControls.ImageButton
        Protected WithEvents cmdDownload As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdSynchronize As System.Web.UI.WebControls.LinkButton
        Protected WithEvents lblDiskSpace As System.Web.UI.WebControls.Label

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        '*******************************************************
        '
        ' The Page_Load server event handler on this user control is used
        ' to populate the current roles settings from the configuration system
        '
        '*******************************************************

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            ' If this is the first visit to the page, bind the role data to the datalist
            If Page.IsPostBack = False Then

                cmdDelete.Attributes.Add("onClick", "javascript:return confirm('Are You Sure You Wish To Delete This File ?');")
                BindData()

            End If

        End Sub

        '*******************************************************
        '
        ' The BindData helper method is used to bind the list of
        ' users for this portal to an asp:DropDownList server control
        '
        '*******************************************************

        Sub BindData()

            Dim FileName As String
            Dim FileList As New ArrayList()
            Dim SpaceUsed As Double

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            Dim objAdmin As New AdminDB()

            If _portalSettings.ActiveTab.ParentId = _portalSettings.SuperTabId Then
                FileList = GetFileList(, , False)
            Else
                FileList = GetFileList(PortalId, , False)
            End If
            cboFiles.DataSource = FileList
            cboFiles.DataBind()

            If _portalSettings.ActiveTab.ParentId <> _portalSettings.SuperTabId Then
                SpaceUsed = objAdmin.GetPortalSpaceUsed(PortalId) / 1000000
                If _portalSettings.HostSpace = 0 Then
                    lblDiskSpace.Text = "Disk Space ( Used: <b>" & Format(SpaceUsed, "#,##0.00") & " MB</b> )"
                Else
                    lblDiskSpace.Text = "Disk Space ( Capacity: <b>" & Format(_portalSettings.HostSpace, "#,##0.00") & " MB</b>  Used: <b>" & Format(SpaceUsed, "#,##0.00") & " MB</b>  Free: <b>" & Format(_portalSettings.HostSpace - SpaceUsed, "#,##0.00") & " MB</b> )"
                End If
            Else
                SpaceUsed = objAdmin.GetPortalSpaceUsed() / 1000000
                lblDiskSpace.Text = "Disk Space ( Used: <b>" & Format(SpaceUsed, "#,##0.00") & " MB</b> )"
            End If

        End Sub

        '*******************************************************
        '
        ' The cmdDelete_Click server event handler is used to 
        ' delete a file from the portal
        '
        '*******************************************************

        Private Sub cmdDelete_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles cmdDelete.Click

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            Dim objAdmin As New AdminDB()

            Try
                If _portalSettings.ActiveTab.ParentId = _portalSettings.SuperTabId Then
                    objAdmin.DeleteFile(cboFiles.SelectedItem.Text)
                    System.IO.File.Delete(Request.MapPath("~/Site/") & cboFiles.SelectedItem.Text)
                Else
                    objAdmin.DeleteFile(cboFiles.SelectedItem.Text, PortalId)
                    System.IO.File.Delete(Request.MapPath(_portalSettings.UploadDirectory) & cboFiles.SelectedItem.Text)
                End If
            Catch
                ' delete error - can happen if the file is read-only
            End Try

            BindData()

        End Sub


        Private Sub cmdDownload_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDownload.Click
            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            Dim objAdmin As New AdminDB()
            Dim dr As SqlDataReader

            If _portalSettings.ActiveTab.ParentId = _portalSettings.SuperTabId Then
                dr = objAdmin.GetSingleFile(cboFiles.SelectedItem.Text)
            Else
                dr = objAdmin.GetSingleFile(cboFiles.SelectedItem.Text, PortalId)
            End If

            If dr.Read Then
                Response.AppendHeader("content-disposition", "attachment; filename=" + dr("FileName").ToString)
                Response.ContentType = dr("ContentType").ToString
                If _portalSettings.ActiveTab.ParentId = _portalSettings.SuperTabId Then
                    Response.WriteFile("~/Site/" & dr("FileName").ToString)
                Else
                    Response.WriteFile(_portalSettings.UploadDirectory & dr("FileName").ToString)
                End If
                Response.End()
            End If
            dr.Close()

        End Sub

        Private Sub cmdSynchronize_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSynchronize.Click

            Dim strFolder As String
            Dim strFileName As String
            Dim strExtension As String
            Dim strContentType As String
            Dim imgImage As System.Drawing.Image
            Dim strWidth As String
            Dim strHeight As String

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            Dim objAdmin As New AdminDB()

            If _portalSettings.ActiveTab.ParentId = _portalSettings.SuperTabId Then
                objAdmin.DeleteFiles()
            Else
                objAdmin.DeleteFiles(PortalId)
            End If

            If _portalSettings.ActiveTab.ParentId = _portalSettings.SuperTabId Then
                strFolder = Request.MapPath("~/Site/")
            Else
                strFolder = Request.MapPath(_portalSettings.UploadDirectory)
            End If

            If System.IO.Directory.Exists(strFolder) Then
                Dim fileEntries As String() = System.IO.Directory.GetFiles(strFolder)
                For Each strFileName In fileEntries
                    If InStr(1, strFileName, ".") Then
                        strExtension = Mid(strFileName, InStrRev(strFileName, ".") + 1)
                    End If

                    Select Case strExtension
                        Case "txt" : strContentType = "text/plain"
                        Case "htm", "html" : strContentType = "text/html"
                        Case "rtf" : strContentType = "text/richtext"
                        Case "jpg", "jpeg" : strContentType = "image/jpeg"
                        Case "gif" : strContentType = "image/gif"
                        Case "bmp" : strContentType = "image/bmp"
                        Case "mpg", "mpeg" : strContentType = "video/mpeg"
                        Case "avi" : strContentType = "video/avi"
                        Case "pdf" : strContentType = "application/pdf"
                        Case "doc", "dot" : strContentType = "application/msword"
                        Case "csv", "xls", "xlt" : strContentType = "application/x-msexcel"
                        Case Else : strContentType = "application/octet-stream"
                    End Select

                    If InStr(1, "gif,jpg,jpeg", strExtension) Then
                        imgImage = imgImage.FromFile(strFileName)
                        strHeight = imgImage.Height
                        strWidth = imgImage.Width
                        imgImage.Dispose()
                    Else
                        strHeight = ""
                        strWidth = ""
                    End If

                    If _portalSettings.ActiveTab.ParentId = _portalSettings.SuperTabId Then
                        objAdmin.AddFile(-1, Mid(strFileName, InStrRev(strFileName, "\") + 1), strExtension, FileLen(strFileName), strWidth, strHeight, strContentType)
                    Else
                        objAdmin.AddFile(PortalId, Mid(strFileName, InStrRev(strFileName, "\") + 1), strExtension, FileLen(strFileName), strWidth, strHeight, strContentType)
                    End If
                Next strFileName
            End If

            BindData()

        End Sub

    End Class

End Namespace
