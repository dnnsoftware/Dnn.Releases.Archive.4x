'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2003
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Namespace DotNetNuke

    Public Class ManageTabs
        Inherits DotNetNuke.PortalModuleControl

        Protected WithEvents tabName As System.Web.UI.WebControls.TextBox
        Protected WithEvents valtabName As System.Web.UI.WebControls.RequiredFieldValidator
        Protected WithEvents cboIcon As System.Web.UI.WebControls.DropDownList
        Protected WithEvents cmdUpload As System.Web.UI.WebControls.HyperLink
        Protected WithEvents cboTab As System.Web.UI.WebControls.DropDownList
        Protected WithEvents IsVisible As System.Web.UI.WebControls.CheckBox
        Protected WithEvents txtLeftPaneWidth As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtRightPaneWidth As System.Web.UI.WebControls.TextBox
        Protected WithEvents authRoles As System.Web.UI.WebControls.CheckBoxList
        Protected WithEvents showMobile As System.Web.UI.WebControls.CheckBox
        Protected WithEvents mobileTabName As System.Web.UI.WebControls.TextBox

        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdDelete As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCopy As System.Web.UI.WebControls.LinkButton

        Private strAction As String = ""

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        '*******************************************************
        '
        ' The Page_Load server event handler on this page is used
        ' to populate a tab's layout settings on the page
        '
        '*******************************************************

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            ' Verify that the current user has access to edit this module
            If Not PortalSecurity.IsInRoles(_portalSettings.AdministratorRoleId.ToString) Then
                Response.Redirect("~/EditModule.aspx?tabid=" & TabId & "&def=Edit Access Denied")
            End If

            If Not (Request.Params("action") Is Nothing) Then
                strAction = Request.Params("action")
            End If

            If Page.IsPostBack = False Then

                cmdDelete.Attributes.Add("onClick", "javascript:return confirm('Are You Sure You Wish To Delete This Item ?');")

                ' load the list of files found in the upload directory
                If PortalSecurity.IsInRole(_portalSettings.AdministratorRoleId.ToString) Then
                    cmdUpload.NavigateUrl = "~/EditModule.aspx?tabid=" & TabId & "&def=File Manager"
                Else
                    cmdUpload.Visible = False
                End If
                Dim LogoFileList As ArrayList = GetFileList(PortalId, "jpg,jpeg,gif")
                cboIcon.DataSource = LogoFileList
                cboIcon.DataBind()

                cboTab.DataSource = GetPortalTabs(_portalSettings.DesktopTabs, True)
                cboTab.DataBind()

                If strAction = "" Then
                    InitializeTab()
                    cmdDelete.Visible = False
                    cmdCopy.Visible = False
                Else
                    BindData()
                End If

                If Not Request.UrlReferrer Is Nothing Then
                    ViewState("UrlReferrer") = Request.UrlReferrer.ToString()
                Else
                    ViewState("UrlReferrer") = ""
                End If
            End If

        End Sub


        '*******************************************************
        '
        ' The cmdCancel_Click() handler cancels operation and redirects
        ' user to admin tab of their portal.
        '
        '*******************************************************

        Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCancel.Click

            Response.Redirect(ViewState("UrlReferrer"))

        End Sub


        Sub InitializeTab()

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            ' Populate Tab Names, etc.
            tabName.Text = ""

            If _portalSettings.ActiveTab.ParentId <> _portalSettings.AdminTabId Then
                If Not cboTab.Items.FindByValue(TabId.ToString) Is Nothing Then
                    cboTab.Items.FindByValue(TabId).Selected = True
                End If
            End If

            IsVisible.Checked = True
            mobileTabName.Text = ""
            showMobile.Checked = False
            txtLeftPaneWidth.Text = 200
            txtRightPaneWidth.Text = 200

            ' Populate checkbox list with all security roles for this portal
            ' and "check" the ones already configured for this tab
            Dim objUser As New UsersDB()
            Dim roles As SqlDataReader = objUser.GetPortalRoles(PortalId)

            ' Clear existing items in checkboxlist
            authRoles.Items.Clear()

            Dim allItem As New ListItem()
            allItem.Text = "All Users"
            allItem.Value = glbRoleAllUsers
            authRoles.Items.Add(allItem)

            While roles.Read()
                Dim item As New ListItem()
                item.Text = CType(roles("RoleName"), String)
                item.Value = roles("RoleID").ToString()
                If item.Value = _portalSettings.AdministratorRoleId.ToString Then
                    item.Selected = True
                End If
                authRoles.Items.Add(item)
            End While

        End Sub

        Private Sub cmdUpdate_Click(ByVal Sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click

            SaveTabData(strAction)

            Response.Redirect(ViewState("UrlReferrer"))

        End Sub

        Private Sub cmdDelete_Click(ByVal Sender As Object, ByVal e As EventArgs) Handles cmdDelete.Click

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(Context.Items("PortalSettings"), PortalSettings)

            Dim objAdmin As New AdminDB()

            objAdmin.DeleteTab(TabId)
            Dim dr As SqlDataReader = objAdmin.GetTabById(TabId)
            If Not dr.Read Then
                objAdmin.UpdatePortalTabOrder(_portalSettings.DesktopTabs, TabId, -2)
            End If
            dr.Close()

            Response.Redirect(GetPortalDomainName(PortalAlias))
        End Sub

        '*******************************************************
        '
        ' The SaveTabData helper method is used to persist the
        ' current tab settings to the database.
        '
        '*******************************************************

        Sub SaveTabData(ByVal strAction As String)

            Dim intTabId As Integer

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(Context.Items("PortalSettings"), PortalSettings)

            ' Construct AuthorizedUserRoles String
            Dim sAuthorizedRoles As String = ""

            Dim item As ListItem
            For Each item In authRoles.Items

                ' admins always have access to all tabs
                If item.Selected = True Or item.Value = _portalSettings.AdministratorRoleId.ToString Then
                    sAuthorizedRoles = sAuthorizedRoles & item.Value & ";"
                End If

            Next item

            Dim strIcon As String = ""
            If Not cboIcon.SelectedItem Is Nothing Then
                strIcon = cboIcon.SelectedItem.Value
            End If

            Dim admin As New AdminDB()

            If strAction = "edit" Then

                ' trap circular tab reference
                If TabId <> Int32.Parse(cboTab.SelectedItem.Value) Then
                    admin.UpdateTab(TabId, tabName.Text, showMobile.Checked, mobileTabName.Text, sAuthorizedRoles, txtLeftPaneWidth.Text, txtRightPaneWidth.Text, IsVisible.Checked, Int32.Parse(cboTab.SelectedItem.Value), strIcon)
                    admin.UpdatePortalTabOrder(_portalSettings.DesktopTabs, TabId, Int32.Parse(cboTab.SelectedItem.Value))
                End If

            Else ' add or copy

                ' child tabs must be visible
                If Int32.Parse(cboTab.SelectedItem.Value) <> -1 Then
                    IsVisible.Checked = True
                End If

                intTabId = admin.AddTab(PortalId, tabName.Text, showMobile.Checked, mobileTabName.Text, sAuthorizedRoles, txtLeftPaneWidth.Text, txtRightPaneWidth.Text, IsVisible.Checked, Int32.Parse(cboTab.SelectedItem.Value), strIcon, intTabId)
                admin.UpdatePortalTabOrder(_portalSettings.DesktopTabs, intTabId, Int32.Parse(cboTab.SelectedItem.Value), , , IsVisible.Checked)

                If strAction = "copy" Then
                    ' copy all modules to new tab
                    admin.CopyTab(TabId, intTabId)
                End If
            End If

        End Sub

        '*******************************************************
        '
        ' The BindData helper method is used to update the tab's
        ' layout panes with the current configuration information
        '
        '*******************************************************
        Sub BindData()

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(Context.Items("PortalSettings"), PortalSettings)

            Dim tab As TabSettings = _portalSettings.ActiveTab

            ' Populate Tab Names, etc.
            tabName.Text = tab.TabName
            If cboIcon.Items.Contains(New ListItem(tab.IconFile)) Then
                cboIcon.Items.FindByText(tab.IconFile).Selected = True
            End If
            cboTab.Items.FindByValue(tab.ParentId).Selected = True
            IsVisible.Checked = tab.IsVisible
            mobileTabName.Text = tab.MobileTabName
            showMobile.Checked = tab.ShowMobile
            txtLeftPaneWidth.Text = tab.LeftPaneWidth
            txtRightPaneWidth.Text = tab.RightPaneWidth

            ' Populate checkbox list with all security roles for this portal
            ' and "check" the ones already configured for this tab
            Dim objUser As New UsersDB()
            Dim roles As SqlDataReader = objUser.GetPortalRoles(PortalId)

            ' Clear existing items in checkboxlist
            authRoles.Items.Clear()

            Dim allItem As New ListItem()
            allItem.Text = "All Users"
            allItem.Value = "-1"

            If tab.AuthorizedRoles.LastIndexOf(allItem.Value & ";") > -1 Then
                allItem.Selected = True
            End If

            authRoles.Items.Add(allItem)

            While roles.Read()

                Dim item As New ListItem()
                item.Text = CType(roles("RoleName"), String)
                item.Value = roles("RoleID").ToString()

                If tab.AuthorizedRoles.LastIndexOf(item.Value & ";") > -1 Then
                    item.Selected = True
                End If

                authRoles.Items.Add(item)

            End While

        End Sub

        Private Sub cmdCopy_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCopy.Click

            SaveTabData("copy")

            Response.Redirect(ViewState("UrlReferrer"))

        End Sub

    End Class

End Namespace
