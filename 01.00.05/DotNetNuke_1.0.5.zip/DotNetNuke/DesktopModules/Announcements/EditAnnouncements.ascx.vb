'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2003
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.IO

Namespace DotNetNuke

    Public Class EditAnnouncements
        Inherits DotNetNuke.PortalModuleControl

        Protected WithEvents txtTitle As System.Web.UI.WebControls.TextBox
        Protected WithEvents valTitle As System.Web.UI.WebControls.RequiredFieldValidator
        Protected WithEvents txtDescription As System.Web.UI.WebControls.TextBox
        Protected WithEvents valDescription As System.Web.UI.WebControls.RequiredFieldValidator
        Protected WithEvents optInternal As System.Web.UI.WebControls.RadioButton
        Protected WithEvents cboInternal As System.Web.UI.WebControls.DropDownList
        Protected WithEvents cmdUpload As System.Web.UI.WebControls.HyperLink
        Protected WithEvents optExternal As System.Web.UI.WebControls.RadioButton
        Protected WithEvents txtExternal As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtExpires As System.Web.UI.WebControls.TextBox
        Protected WithEvents valExpires As System.Web.UI.WebControls.CompareValidator
        Protected WithEvents chkSyndicate As System.Web.UI.WebControls.CheckBox

        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdDelete As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdSyndicate As System.Web.UI.WebControls.LinkButton

        Protected WithEvents pnlAudit As System.Web.UI.WebControls.Panel
        Protected WithEvents lblCreatedBy As System.Web.UI.WebControls.Label
        Protected WithEvents lblCreatedDate As System.Web.UI.WebControls.Label
        Protected WithEvents lblSyndicate As System.Web.UI.WebControls.Label

        Private itemId As Integer = -1

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        '****************************************************************
        '
        ' The Page_Load event on this Page is used to obtain the ModuleId
        ' and ItemId of the announcement to edit.
        '
        ' It then uses the DotNetNuke.AnnouncementsDB() data component
        ' to populate the page's edit controls with the annoucement details.
        '
        '****************************************************************

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            ' Determine ItemId of Announcement to Update
            If Not (Request.Params("ItemId") Is Nothing) Then
                itemId = Int32.Parse(Request.Params("ItemId"))
            End If

            If optExternal.Checked = False And optInternal.Checked = False Then
                optInternal.Checked = True
            End If

            EnableControls()

            If Page.IsPostBack = False Then

                cmdDelete.Attributes.Add("onClick", "javascript:return confirm('Are You Sure You Wish To Delete This Item ?');")

                ' load the list of files found in the upload directory
                If PortalSecurity.IsInRole(_portalSettings.AdministratorRoleId.ToString) Then
                    cmdUpload.NavigateUrl = "~/EditModule.aspx?tabid=" & TabId & "&def=File Manager"
                Else
                    cmdUpload.Visible = False
                End If
                Dim FileList As ArrayList = GetFileList(PortalId)
                cboInternal.DataSource = FileList
                cboInternal.DataBind()

                Dim admin As New AdminDB()
                Dim drAdmin As SqlDataReader = admin.GetModule(ModuleId)
                drAdmin.Read()
                lblSyndicate.Text = "* Syndicated RSS Channel: " & GetPortalDomainName(_portalSettings.PortalAlias) & _portalSettings.UploadDirectory & drAdmin("ModuleTitle").ToString & ".rss"
                drAdmin.Close()

                If itemId <> -1 Then

                    ' Obtain a single row of announcement information
                    Dim objAnnouncements As New AnnouncementsDB()
                    Dim dr As SqlDataReader = objAnnouncements.GetSingleAnnouncement(itemId, ModuleId)

                    ' Load first row into DataReader
                    If dr.Read() Then
                        If InStr(1, dr("URL").ToString, "://") = 0 Then
                            optInternal.Checked = True
                            optExternal.Checked = False
                            EnableControls()
                            If cboInternal.Items.Contains(New ListItem(dr("URL").ToString)) Then
                                cboInternal.Items.FindByText(dr("URL").ToString).Selected = True
                            End If
                        Else
                            optInternal.Checked = False
                            optExternal.Checked = True
                            EnableControls()
                            txtExternal.Text = dr("URL").ToString
                        End If

                        txtTitle.Text = dr("Title").ToString
                        txtDescription.Text = dr("Description").ToString
                        txtExpires.Text = GetRegionalDate(dr("ExpireDate").ToString)
                        chkSyndicate.Checked = dr("Syndicate")

                        lblCreatedBy.Text = dr("CreatedByUser").ToString
                        lblCreatedDate.Text = CType(dr("CreatedDate"), DateTime).ToShortDateString()

                        ' Close the datareader
                        dr.Close()

                    Else ' security violation attempt to access item not related to this Module
                        Response.Redirect("~/desktopdefault.aspx?tabid=" & TabId)
                    End If
                Else
                    cmdDelete.Visible = False
                    pnlAudit.Visible = False
                End If

                ' Store URL Referrer to return to portal
                ViewState("UrlReferrer") = "~/DesktopDefault.aspx?tabid=" & TabId

            End If

        End Sub


        '****************************************************************
        '
        ' The cmdUpdate_Click event handler on this Page is used to either
        ' create or update an announcement.  It  uses the DotNetNuke.AnnouncementsDB()
        ' data component to encapsulate all data functionality.
        '
        '****************************************************************

        Private Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click

            Dim strLink As String

            ' Only Update if the Entered Data is Valid
            If Page.IsValid = True Then

                ' Create an instance of the Announcement DB component
                Dim objAnnouncements As New AnnouncementsDB()

                If txtExternal.Text <> "" Then
                    strLink = AddHTTP(txtExternal.Text)
                Else
                    strLink = cboInternal.SelectedItem.Value
                End If

                If itemId = -1 Then
                    objAnnouncements.AddAnnouncement(ModuleId, Context.User.Identity.Name, txtTitle.Text, GetRegionalDate(txtExpires.Text), txtDescription.Text, strLink, chkSyndicate.Checked)
                Else
                    objAnnouncements.UpdateAnnouncement(itemId, Context.User.Identity.Name, txtTitle.Text, GetRegionalDate(txtExpires.Text), txtDescription.Text, strLink, chkSyndicate.Checked)
                End If

                CreateRSS()

                ' Redirect back to the portal home page
                Response.Redirect(CType(ViewState("UrlReferrer"), String))

            End If

        End Sub


        '****************************************************************
        '
        ' The cmdDelete_Click event handler on this Page is used to delete an
        ' an announcement.  It  uses the DotNetNuke.AnnouncementsDB()
        ' data component to encapsulate all data functionality.
        '
        '****************************************************************

        Private Sub cmdDelete_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdDelete.Click

            If itemId <> -1 Then
                Dim objAnnouncements As New AnnouncementsDB()
                objAnnouncements.DeleteAnnouncement(itemId)
            End If

            ' Redirect back to the portal home page
            Response.Redirect(CType(ViewState("UrlReferrer"), String))

        End Sub


        '****************************************************************
        '
        ' The cmdCancel_Click event handler on this Page is used to cancel
        ' out of the page, and return the user back to the portal home
        ' page.
        '
        '****************************************************************

        Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click

            ' Redirect back to the portal home page
            Response.Redirect(CType(ViewState("UrlReferrer"), String))

        End Sub

        Private Sub EnableControls()
            If optExternal.Checked Then
                cboInternal.ClearSelection()
                cboInternal.Enabled = False
                txtExternal.Enabled = True
            Else
                cboInternal.Enabled = True
                txtExternal.Text = ""
                txtExternal.Enabled = False
            End If
        End Sub

        Private Sub CreateRSS()

            Dim objAnnouncements As New AnnouncementsDB()

            Dim dr As SqlDataReader = objAnnouncements.GetAnnouncements(ModuleId)
            If dr.Read Then
                ' Obtain PortalSettings from Current Context
                Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

                ' create RSS file
                Dim strRSS As String = ""
                Dim blnSave As Boolean = False

                strRSS += "<?xml version=""1.0"" encoding=""iso-8859-1""?>" & ControlChars.CrLf
                strRSS += "<rss version=""0.91"">" & ControlChars.CrLf
                strRSS += "  <channel>" & ControlChars.CrLf
                strRSS += "     <title>" & _portalSettings.PortalName & "</title>" & ControlChars.CrLf
                strRSS += "     <link>" & GetPortalDomainName(_portalSettings.PortalAlias) & "</link>" & ControlChars.CrLf
                strRSS += "     <description>" & _portalSettings.PortalName & "</description>" & ControlChars.CrLf
                strRSS += "     <language>en-us</language>" & ControlChars.CrLf
                strRSS += "     <copyright>" & _portalSettings.FooterText & "</copyright>" & ControlChars.CrLf
                strRSS += "     <webMaster>" & _portalSettings.Email & "</webMaster>" & ControlChars.CrLf

                While dr.Read()
                    If dr("Syndicate") Then
                        strRSS += "      <item>" & ControlChars.CrLf
                        strRSS += "         <title>" & dr("Title").ToString & "</title>" & ControlChars.CrLf
                        If InStr(1, dr("URL").ToString, "://") = 0 Then
                            strRSS += "         <link>" & GetPortalDomainName(_portalSettings.PortalAlias) & _portalSettings.UploadDirectory & dr("URL").ToString & "</link>" & ControlChars.CrLf
                        Else
                            strRSS += "         <link>" & dr("URL").ToString & "</link>" & ControlChars.CrLf
                        End If
                        strRSS += "         <description>" & _portalSettings.PortalName & " " & Format(CDate(dr("CreatedDate")), "MMM dd yyyy hh:mm tt") & "</description>" & ControlChars.CrLf
                        strRSS += "     </item>" & ControlChars.CrLf
                        blnSave = True
                    End If
                End While
                dr.Close()

                strRSS += "   </channel>" & ControlChars.CrLf
                strRSS += "</rss>"

                If blnSave Then
                    Dim objStream As StreamWriter
                    objStream = File.CreateText(Request.MapPath(_portalSettings.UploadDirectory) & ModuleConfiguration.ModuleTitle & ".rss")
                    objStream.WriteLine(strRSS)
                    objStream.Close()
                Else
                    If File.Exists(Request.MapPath(_portalSettings.UploadDirectory) & ModuleConfiguration.ModuleTitle & ".rss") Then
                        File.Delete(Request.MapPath(_portalSettings.UploadDirectory) & ModuleConfiguration.ModuleTitle & ".rss")
                    End If
                End If
            End If

        End Sub

        Private Sub cmdSyndicate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSyndicate.Click
            CreateRSS()

            ' Redirect back to the portal home page
            Response.Redirect(CType(ViewState("UrlReferrer"), String))
        End Sub

    End Class

End Namespace