'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2003
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.Net
Imports System.IO

Namespace DotNetNuke

    Public MustInherit Class MapQuest
        Inherits DotNetNuke.PortalModuleControl

        Protected WithEvents lblLocation As System.Web.UI.WebControls.Label
        Protected WithEvents lblAddress As System.Web.UI.WebControls.Label
        Protected WithEvents cboSize As System.Web.UI.WebControls.DropDownList
        Protected WithEvents colSize As System.Web.UI.HtmlControls.HtmlTableCell
        Protected WithEvents hypDirections As System.Web.UI.WebControls.HyperLink
        Protected WithEvents cboZoom As System.Web.UI.WebControls.DropDownList
        Protected WithEvents colZoom As System.Web.UI.HtmlControls.HtmlTableCell
        Protected WithEvents hypMap As System.Web.UI.WebControls.HyperLink

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            If Not Page.IsPostBack Then

                If CType(Settings("location"), String) <> "" Then
                    lblLocation.Text = CType(Settings("location"), String)

                    lblAddress.Text = FormatAddress(CType(Settings("unit"), String), CType(Settings("street"), String), CType(Settings("city"), String), CType(Settings("region"), String), CType(Settings("country"), String), CType(Settings("postalcode"), String))

                    cboSize.Items.FindByValue("small").Selected = True
                    cboZoom.Items.FindByValue("8").Selected = True

                    BuildMapImage()

                    hypDirections.Text = "Get Directions"
                    hypDirections.NavigateUrl = BuildDirectionsURL()
                End If

            End If

        End Sub

        Private Function EncodeValue(ByVal strValue As String) As String
            EncodeValue = Replace(strValue, ControlChars.CrLf, "")
            EncodeValue = Replace(strValue, "%", "%%25")
            EncodeValue = Replace(strValue, "&", "%%26")
            EncodeValue = Replace(strValue, "+", "%%30")
            EncodeValue = Replace(strValue, " ", "+")
        End Function

        Private Function BuildMapURL() As String

            Dim strURL As String

            strURL += "http://www.mapquest.com/maps/map.adp"
            strURL += "?address=" & EncodeValue(CType(Settings("street"), String))
            strURL += "&city=" & EncodeValue(CType(Settings("city"), String))
            strURL += "&state=" & EncodeValue(CType(Settings("region"), String))
            strURL += "&country=" & EncodeValue(CType(Settings("country"), String))
            strURL += "&zip=" & EncodeValue(CType(Settings("postalcode"), String))
            strURL += "&size=" & EncodeValue(cboSize.SelectedItem.Value)
            strURL += "&zoom=" & EncodeValue(cboZoom.SelectedItem.Value)

            BuildMapURL = strURL

        End Function

        Private Function GetMapImageURL(ByVal strURL As String) As String

            Try
                Dim objRequest As HttpWebRequest = WebRequest.Create(strURL)

                Dim objResponse As HttpWebResponse = objRequest.GetResponse()
                Dim sr As StreamReader
                sr = New StreamReader(objResponse.GetResponseStream())
                Dim strResponse As String = sr.ReadToEnd()
                sr.Close()

                Dim intPos1 As Integer
                Dim intPos2 As Integer

                intPos1 = InStr(1, strResponse, "mqmapgend")
                intPos1 = InStrRev(strResponse, "http://", intPos1)
                intPos2 = InStr(intPos1, strResponse, """")

                GetMapImageURL = Mid(strResponse, intPos1, intPos2 - intPos1)
            Catch
                ' error accessing MapQuest website
            End Try

        End Function

        Private Function BuildDirectionsURL() As String

            Dim strURL As String

            strURL = "http://www.mapquest.com/directions/main.adp?go=1"
            strURL += "&2a=" & EncodeValue(CType(Settings("street"), String))
            strURL += "&2c=" & EncodeValue(CType(Settings("city"), String))
            strURL += "&2s=" & EncodeValue(CType(Settings("region"), String))
            strURL += "&2y=" & EncodeValue(CType(Settings("country"), String))
            strURL += "&2z=" & EncodeValue(CType(Settings("postalcode"), String))

            If Request.IsAuthenticated Then
                ' Obtain PortalSettings from Current Context
                Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

                Dim objUser As New UsersDB()

                Dim drUser As SqlDataReader = objUser.GetSingleUser(PortalId, Int32.Parse(context.User.Identity.Name))
                If drUser.Read Then
                    strURL += "&1a=" & EncodeValue(drUser("Street").ToString)
                    strURL += "&1c=" & EncodeValue(drUser("City").ToString)
                    strURL += "&1s=" & EncodeValue(drUser("Region").ToString)
                    strURL += "&1y=" & EncodeValue(drUser("Country").ToString)
                    strURL += "&1z=" & EncodeValue(drUser("PostalCode").ToString)
                End If
                drUser.Close()
            End If

            BuildDirectionsURL = strURL

        End Function

        Private Sub BuildMapImage()

            Dim blnDisplayMap As Boolean = False

            hypMap.Text = "Show Map"
            hypMap.NavigateUrl = BuildMapURL()

            If CType(Settings("displaymap"), String) <> "" Then
                blnDisplayMap = CType(Settings("displaymap"), Boolean)
            End If
            If blnDisplayMap Then
                hypMap.ImageUrl = GetMapImageURL(hypMap.NavigateUrl)
            End If

            If hypMap.ImageUrl = "" Then
                colSize.Visible = False
                colZoom.Visible = False
                hypMap.BorderWidth = Unit.Pixel(0)
            Else
                colSize.Visible = True
                colZoom.Visible = True
                hypMap.BorderWidth = Unit.Pixel(1)
            End If

        End Sub

        Private Sub cboSize_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboSize.SelectedIndexChanged
            BuildMapImage()
        End Sub

        Private Sub cboZoom_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboZoom.SelectedIndexChanged
            BuildMapImage()
        End Sub

    End Class

End Namespace
