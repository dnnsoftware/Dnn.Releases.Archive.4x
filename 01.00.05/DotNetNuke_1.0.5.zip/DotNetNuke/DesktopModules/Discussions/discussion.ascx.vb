'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2003
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Namespace DotNetNuke

    Public MustInherit Class Discussion
        Inherits DotNetNuke.PortalModuleControl

        Protected WithEvents lstDiscussions As System.Web.UI.WebControls.DataList

        Private itemIndex As Integer = -1

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        '*******************************************************
        '
        ' The Page_Load server event handler on this User Control is used
        ' on the first visit of the page to obtain and databind a list of
        ' discussion messages.
        '
        '*******************************************************

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load


            If Not (Request.Params("ItemIndex") Is Nothing) Then
                itemIndex = Int32.Parse(Request.Params("ItemIndex"))
            End If

            If Page.IsPostBack = False Then
                BindList()

                If itemIndex <> -1 Then
                    lstDiscussions.SelectedIndex = itemIndex
                    BindList()
                End If
            End If

        End Sub


        '*******************************************************
        '
        ' The BindList method obtains the list of top-level messages
        ' from the Discussion table and then databinds them against
        ' the "lstDiscussions" asp:datalist server control.  It uses
        ' the DotNetNuke.DiscussionDB() data component to encapsulate
        ' all data access functionality.
        '
        '*******************************************************

        Sub BindList()

            ' Obtain a list of discussion messages for the module
            ' and bind to datalist
            Dim discuss As New DiscussionDB()

            lstDiscussions.DataSource = discuss.GetTopLevelMessages(ModuleId)
            lstDiscussions.DataBind()

        End Sub


        '*******************************************************
        '
        ' The GetThreadMessages method is used to obtain the list
        ' of messages contained within a sub-topic of the
        ' a top-level discussion message thread.  This method is
        ' used to populate the "DetailList" asp:datalist server control
        ' in the SelectedItemTemplate of "lstDiscussions".
        '
        '*******************************************************

        Function GetThreadMessages() As SqlDataReader

            ' Obtain a list of discussion messages for the module
            Dim discuss As New DiscussionDB()
            Dim dr As SqlDataReader = discuss.GetThreadMessages(lstDiscussions.DataKeys(lstDiscussions.SelectedIndex).ToString())

            ' Return the filtered DataView
            Return dr

        End Function


        '*******************************************************
        '
        ' The lstDiscussions_Select server event handler is used to
        ' expand/collapse a selected discussion topic within the
        ' hierarchical <asp:DataList> server control.
        '
        '*******************************************************

        Private Sub lstDiscussions_Select(ByVal Sender As Object, ByVal e As DataListCommandEventArgs) Handles lstDiscussions.ItemCommand

            ' Determine the command of the button (either "select" or "collapse")
            Dim command As String = CType(e.CommandSource, ImageButton).CommandName

            ' Update asp:datalist selection index depending upon the type of command
            ' and then rebind the asp:datalist with content
            If command = "collapse" Then
                lstDiscussions.SelectedIndex = -1
            Else
                lstDiscussions.SelectedIndex = e.Item.ItemIndex
            End If

            BindList()

        End Sub


        '*******************************************************
        '
        ' The FormatUrl method is a helper messages called by a
        ' databinding statement within the <asp:DataList> server
        ' control template.  It is defined as a helper method here
        ' (as opposed to inline within the template) to to improve
        ' code organization and avoid embedding logic within the
        ' content template.
        '
        '*******************************************************

        Public Function EditURL(ByVal strKeyName As String, ByVal strKeyValue As String) As String
            EditURL = "~/EditModule.aspx?tabid=" & TabId & "&mid=" & ModuleId & "&itemindex=" & lstDiscussions.Items.Count & "&" & strKeyName & "=" & strKeyValue
        End Function


        '*******************************************************
        '
        ' The NodeImage method is a helper method called by a
        ' databinding statement within the <asp:datalist> server
        ' control template.  It controls whether or not an item
        ' in the list should be rendered as an expandable topic
        ' or just as a single node within the list.
        '
        '*******************************************************

        Function NodeImage(ByVal count As Integer) As String

            If count > 0 Then
                Return "~/images/plus.gif"
            Else
                Return "~/images/node.gif"
            End If

        End Function

        Public Function HtmlDecode(ByVal strValue As String) As String
            HtmlDecode = Server.HtmlDecode(strValue)
        End Function

    End Class

End Namespace