'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2003
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Namespace DotNetNuke

    Public Class EditModule

        Inherits System.Web.UI.Page

        Protected WithEvents Body As System.Web.UI.HtmlControls.HtmlContainerControl
        Protected WithEvents ScrollTop As System.Web.UI.HtmlControls.HtmlInputHidden

        Protected EditPane As System.Web.UI.HtmlControls.HtmlTableCell

        Protected WithEvents hypCopyright As System.Web.UI.WebControls.HyperLink

        Private moduleId As Integer = -1

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

#End Region

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            '
            ' CODEGEN: This call is required by the ASP.NET Web Form Designer.
            '
            InitializeComponent()

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            ' Determine ModuleId of Portal Module
            If Not (Request.Params("mid") Is Nothing) Then
                moduleId = Int32.Parse(Request.Params("mid"))
            End If

            Dim objAdmin As New AdminDB()

            Dim moduleSettings As New moduleSettings()

            ' load module settings based on moduleid ( instance of desktopmodule )
            If moduleId <> -1 Then
                moduleSettings = PortalSettings.GetEditModuleSettings(moduleId)
            End If

            ' load module definition by name
            If Not (Request.Params("def") Is Nothing) Then
                Dim dr As SqlDataReader = objAdmin.GetSingleModuleDefinitionByName(Request.Params("def"))
                If dr.Read Then
                    moduleSettings.ModuleId = moduleId
                    moduleSettings.ModuleDefId = Int32.Parse(dr("ModuleDefID").ToString)
                    moduleSettings.TabId = _portalSettings.ActiveTab.TabId
                    moduleSettings.PaneName = "Edit"
                    moduleSettings.ModuleTitle = dr("FriendlyName").ToString
                    moduleSettings.AuthorizedEditRoles = ""
                    moduleSettings.EditSrc = dr("EditSrc").ToString
                    moduleSettings.Secure = dr("Secure")
                    moduleSettings.ShowTitle = True
                    moduleSettings.Personalize = 2
                End If
                dr.Close()
            End If

            ' Verify that the current user has access to edit this module
            If moduleSettings.Secure Then
                If PortalSecurity.IsInRole(_portalSettings.AdministratorRoleId.ToString) = False And (moduleId = -1 Or PortalSecurity.HasEditPermissions(moduleId) = False) Then
                    Response.Redirect("~/EditModule.aspx?tabid=" & _portalSettings.ActiveTab.TabId & "&def=Edit Access Denied")
                End If
            End If

            ' load user control
            If moduleSettings.EditSrc <> "" Then
                Dim portalModule As PortalModuleControl = CType(Page.LoadControl(moduleSettings.EditSrc), PortalModuleControl)
                portalModule.ModuleConfiguration = moduleSettings
                EditPane.Controls.Add(portalModule)
            End If

            hypCopyright.Text = "Portal engine source code is copyright &copy; 2002-" & Year(Now) & " by " & glbCopyrightName & ". All Rights Reserved."
            hypCopyright.NavigateUrl = AddHTTP(glbCopyrightURL)

        End Sub

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            If ScrollTop.Value <> "" Then
                Body.Attributes.Add("onload", "javascript:Body.scrollTop=" & ScrollTop.Value & ";")
            End If
        End Sub

    End Class

End Namespace