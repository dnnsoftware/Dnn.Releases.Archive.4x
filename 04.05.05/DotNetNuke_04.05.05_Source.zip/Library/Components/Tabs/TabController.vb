'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2007
' by DotNetNuke Corporation
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.Collections.Generic
Imports System.Configuration
Imports System.Data
Imports System.Globalization

Imports DotNetNuke.Entities.Modules
Imports DotNetNuke.Entities.Portals

Namespace DotNetNuke.Entities.Tabs

    Public Class TabController

#Region "Helper structure for sorting tabs"

        Private Structure TabOrderHelper
            Public TabOrder As Integer
            Public Level As Integer
            Public ParentId As Integer

            Public Sub New(ByVal inttaborder As Integer, ByVal intlevel As Integer, ByVal intparentid As Integer)
                TabOrder = inttaborder
                Level = intlevel
                ParentId = intparentid
            End Sub

        End Structure

#End Region

#Region "Private Methods"

        Private Sub ClearCache(ByVal portalId As Integer)
            DataCache.ClearTabsCache(portalId)

            'Clear the Portal cache so the Pages count is correct
            DataCache.ClearPortalCache(portalId, False)
        End Sub

        Private Function FillTabInfo(ByVal dr As IDataReader) As TabInfo
            Return FillTabInfo(dr, True)
        End Function

        Private Function FillTabInfo(ByVal dr As IDataReader, ByVal CheckForOpenDataReader As Boolean) As TabInfo
            Dim objTabInfo As New TabInfo
            Dim objTabPermissionController As New Security.Permissions.TabPermissionController

            ' read datareader
            Dim canContinue As Boolean = True
            If CheckForOpenDataReader Then
                canContinue = False
                If dr.Read Then
                    canContinue = True
                End If
            End If
            If canContinue Then
                objTabInfo.TabID = Convert.ToInt32(Null.SetNull(dr("TabID"), objTabInfo.TabID))
                objTabInfo.TabOrder = Convert.ToInt32(Null.SetNull(dr("TabOrder"), objTabInfo.TabOrder))
                objTabInfo.PortalID = Convert.ToInt32(Null.SetNull(dr("PortalID"), objTabInfo.PortalID))
                objTabInfo.TabName = Convert.ToString(Null.SetNull(dr("TabName"), objTabInfo.TabName))
                objTabInfo.IsVisible = Convert.ToBoolean(Null.SetNull(dr("IsVisible"), objTabInfo.IsVisible))
                objTabInfo.ParentId = Convert.ToInt32(Null.SetNull(dr("ParentId"), objTabInfo.ParentId))
                objTabInfo.Level = Convert.ToInt32(Null.SetNull(dr("Level"), objTabInfo.Level))
                objTabInfo.IconFile = Convert.ToString(Null.SetNull(dr("IconFile"), objTabInfo.IconFile))
                objTabInfo.DisableLink = Convert.ToBoolean(Null.SetNull(dr("DisableLink"), objTabInfo.DisableLink))
                objTabInfo.Title = Convert.ToString(Null.SetNull(dr("Title"), objTabInfo.Title))
                objTabInfo.Description = Convert.ToString(Null.SetNull(dr("Description"), objTabInfo.Description))
                objTabInfo.KeyWords = Convert.ToString(Null.SetNull(dr("KeyWords"), objTabInfo.KeyWords))
                objTabInfo.IsDeleted = Convert.ToBoolean(Null.SetNull(dr("IsDeleted"), objTabInfo.IsDeleted))
                objTabInfo.Url = Convert.ToString(Null.SetNull(dr("Url"), objTabInfo.Url))
                objTabInfo.SkinSrc = Convert.ToString(Null.SetNull(dr("SkinSrc"), objTabInfo.SkinSrc))
                objTabInfo.ContainerSrc = Convert.ToString(Null.SetNull(dr("ContainerSrc"), objTabInfo.ContainerSrc))
                objTabInfo.TabPath = Convert.ToString(Null.SetNull(dr("TabPath"), objTabInfo.TabPath))
                objTabInfo.StartDate = Convert.ToDateTime(Null.SetNull(dr("StartDate"), objTabInfo.StartDate))
                objTabInfo.EndDate = Convert.ToDateTime(Null.SetNull(dr("EndDate"), objTabInfo.EndDate))
                objTabInfo.HasChildren = Convert.ToBoolean(Null.SetNull(dr("HasChildren"), objTabInfo.HasChildren))
                objTabInfo.RefreshInterval = Convert.ToInt32(Null.SetNull(dr("RefreshInterval"), objTabInfo.RefreshInterval))
                objTabInfo.PageHeadText = Convert.ToString(Null.SetNull(dr("PageHeadText"), objTabInfo.PageHeadText))
                objTabInfo.IsSecure = Convert.ToBoolean(Null.SetNull(dr("IsSecure"), objTabInfo.IsSecure))

                If Not objTabInfo Is Nothing Then
                    objTabInfo.TabPermissions = objTabPermissionController.GetTabPermissionsCollectionByTabID(objTabInfo.TabID, objTabInfo.PortalID)
                    objTabInfo.AdministratorRoles = objTabPermissionController.GetTabPermissions(objTabInfo.TabPermissions, "EDIT")
                    If objTabInfo.AdministratorRoles = ";" Then
                        ' this code is here for legacy support - the AdministratorRoles were stored as a concatenated list of roleids prior to DNN 3.0
                        Try
                            objTabInfo.AdministratorRoles = Convert.ToString(Null.SetNull(dr("AdministratorRoles"), objTabInfo.AdministratorRoles))
                        Catch
                            ' the AdministratorRoles field was removed from the Tabs table in 3.0
                        End Try
                    End If
                    objTabInfo.AuthorizedRoles = objTabPermissionController.GetTabPermissions(objTabInfo.TabPermissions, "VIEW")
                    If objTabInfo.AuthorizedRoles = ";" Then
                        ' this code is here for legacy support - the AuthorizedRoles were stored as a concatenated list of roleids prior to DNN 3.0
                        Try
                            objTabInfo.AuthorizedRoles = Convert.ToString(Null.SetNull(dr("AuthorizedRoles"), objTabInfo.AuthorizedRoles))
                        Catch
                            ' the AuthorizedRoles field was removed from the Tabs table in 3.0
                        End Try
                    End If
                End If

                objTabInfo.BreadCrumbs = Nothing
                objTabInfo.Panes = Nothing
                objTabInfo.Modules = Nothing

                ' add the PortalId and TabId to the Portal Dictionary
                PortalController.AddPortalDictionary(objTabInfo.PortalID, objTabInfo.TabID)
                ' add the TabPath and TabId to the TabPath Dictionary
                AddTabPathDictionary(objTabInfo.PortalID, objTabInfo.TabPath, objTabInfo.TabID)
            Else
                objTabInfo = Nothing
            End If

            Return objTabInfo
        End Function

        Private Function FillTabInfoCollection(ByVal dr As IDataReader) As ArrayList

            Dim arr As New ArrayList
            Try
                Dim obj As TabInfo
                While dr.Read
                    ' fill business object
                    obj = FillTabInfo(dr, False)
                    ' add to collection
                    arr.Add(obj)
                End While
            Catch exc As Exception
                LogException(exc)
            Finally
                ' close datareader
                If Not dr Is Nothing Then
                    dr.Close()
                End If
            End Try

            Return arr
        End Function

        Private Function FillTabInfoDictionary(ByVal dr As IDataReader) As Dictionary(Of Integer, TabInfo)
            Dim dic As New Dictionary(Of Integer, TabInfo)
            Try
                Dim obj As TabInfo
                While dr.Read
                    ' fill business object
                    obj = FillTabInfo(dr, False)
                    ' add to dictionary
                    dic.Add(obj.TabID, obj)
                End While
            Catch exc As Exception
                LogException(exc)
            Finally
                ' close datareader
                If Not dr Is Nothing Then
                    dr.Close()
                End If
            End Try

            Return dic
        End Function

        Private Function GetTabByNameAndParent(ByVal TabName As String, ByVal PortalId As Integer, ByVal ParentId As Integer) As TabInfo
            Dim arrTabs As ArrayList = GetTabsByNameAndPortal(TabName, PortalId)
            Dim intTab As Integer = -1

            If Not arrTabs Is Nothing Then
                Select Case arrTabs.Count
                    Case 0    ' no results
                    Case 1    ' exact match
                        intTab = 0
                    Case Else    ' multiple matches
                        Dim intIndex As Integer
                        Dim objTab As TabInfo
                        For intIndex = 0 To arrTabs.Count - 1
                            objTab = CType(arrTabs(intIndex), TabInfo)
                            ' check if the parentids match
                            If objTab.ParentId = ParentId Then
                                intTab = intIndex
                            End If
                        Next intIndex
                        If intTab = -1 Then
                            ' no match - return the first item
                            intTab = 0
                        End If
                End Select
            End If

            If intTab <> -1 Then
                Return CType(arrTabs(intTab), TabInfo)
            Else
                Return Nothing
            End If
        End Function

        Private Function GetTabsByNameAndPortal(ByVal TabName As String, ByVal PortalId As Integer) As ArrayList
            Dim returnTabs As New ArrayList()
            For Each kvp As KeyValuePair(Of Integer, TabInfo) In GetTabsByPortal(PortalId)
                Dim objTab As TabInfo = kvp.Value

                If objTab.TabName = TabName Then
                    returnTabs.Add(objTab)
                End If
            Next
            Return returnTabs
        End Function

        Private Function GetTabsByParent(ByVal ParentId As Integer, ByVal PortalId As Integer) As ArrayList
            Dim childTabs As New ArrayList()
            For Each kvp As KeyValuePair(Of Integer, TabInfo) In GetTabsByPortal(PortalId)
                Dim objTab As TabInfo = kvp.Value

                If objTab.ParentId = ParentId Then
                    childTabs.Add(objTab)
                End If
            Next
            Return childTabs
        End Function

        Private Sub MoveTab(ByVal objDesktopTabs As ArrayList, ByVal intFromIndex As Integer, ByVal intToIndex As Integer, ByVal intNewLevel As Integer, Optional ByVal blnAddChild As Boolean = True)
            Dim intCounter As Integer
            Dim objTab As TabInfo
            Dim blnInsert As Boolean
            Dim intIncrement As Integer

            Dim intOldLevel As Integer = CType(objDesktopTabs(intFromIndex), TabInfo).Level
            If intToIndex <> objDesktopTabs.Count - 1 Then
                blnInsert = True
            End If

            ' clone tab and children from old parent
            Dim objClone As New ArrayList
            intCounter = intFromIndex
            While intCounter <= objDesktopTabs.Count - 1
                If CType(objDesktopTabs(intCounter), TabInfo).TabID = CType(objDesktopTabs(intFromIndex), TabInfo).TabID Or CType(objDesktopTabs(intCounter), TabInfo).Level > intOldLevel Then
                    objClone.Add(objDesktopTabs(intCounter))
                    intCounter += 1
                Else
                    Exit While
                End If
            End While

            ' remove tab and children from old parent
            objDesktopTabs.RemoveRange(intFromIndex, objClone.Count)
            If intToIndex > intFromIndex Then
                intToIndex -= objClone.Count
            End If

            ' add clone to new parent
            If blnInsert Then
                objClone.Reverse()
            End If

            For Each objTab In objClone
                If blnInsert Then
                    objTab.Level += (intNewLevel - intOldLevel)
                    If blnAddChild Then
                        intIncrement = 1
                    Else
                        intIncrement = 0
                    End If
                    objDesktopTabs.Insert(intToIndex + intIncrement, objTab)
                Else
                    objTab.Level += (intNewLevel - intOldLevel)
                    objDesktopTabs.Add(objTab)
                End If
            Next
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Updates child tabs TabPath field
        ''' </summary>
        ''' <param name="intTabid">ID of the parent tab</param>
        ''' <remarks>
        ''' When a ParentTab is updated this method should be called to 
        ''' ensure that the TabPath of the Child Tabs is consistent with the Parent
        ''' </remarks>
        ''' <history>
        ''' 	[JWhite]	16/11/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub UpdateChildTabPath(ByVal intTabid As Integer, ByVal portalId As Integer)
            Dim objtab As TabInfo
            Dim arrTabs As ArrayList = GetTabsByParentId(intTabid, portalId)

            For Each objtab In arrTabs
                Dim oldTabPath As String = objtab.TabPath
                objtab.TabPath = GenerateTabPath(objtab.ParentId, objtab.TabName)
                If oldTabPath <> objtab.TabPath Then
                    DataProvider.Instance().UpdateTab(objtab.TabID, objtab.TabName, objtab.IsVisible, objtab.DisableLink, objtab.ParentId, objtab.IconFile, objtab.Title, objtab.Description, objtab.KeyWords, objtab.IsDeleted, objtab.Url, objtab.SkinSrc, objtab.ContainerSrc, objtab.TabPath, objtab.StartDate, objtab.EndDate, objtab.RefreshInterval, objtab.PageHeadText, objtab.IsSecure)
                    UpdateChildTabPath(objtab.TabID, objtab.PortalID)
                End If
            Next

            ClearCache(portalId)
        End Sub

#End Region

#Region "Public Methods"

        Public Function AddTab(ByVal objTab As TabInfo) As Integer
            Return AddTab(objTab, True)
        End Function

        Public Function AddTab(ByVal objTab As TabInfo, ByVal AddAllTabsModules As Boolean) As Integer
            Dim intTabId As Integer

            objTab.TabPath = GenerateTabPath(objTab.ParentId, objTab.TabName)
            intTabId = DataProvider.Instance().AddTab(objTab.PortalID, objTab.TabName, objTab.IsVisible, objTab.DisableLink, objTab.ParentId, objTab.IconFile, objTab.Title, objTab.Description, objTab.KeyWords, objTab.Url, objTab.SkinSrc, objTab.ContainerSrc, objTab.TabPath, objTab.StartDate, objTab.EndDate, objTab.RefreshInterval, objTab.PageHeadText, objTab.IsSecure)

            Dim objTabPermissionController As New Security.Permissions.TabPermissionController

            If Not objTab.TabPermissions Is Nothing Then
                Dim objTabPermissions As Security.Permissions.TabPermissionCollection
                objTabPermissions = objTab.TabPermissions

                Dim objTabPermission As New Security.Permissions.TabPermissionInfo
                For Each objTabPermission In objTabPermissions
                    objTabPermission.TabID = intTabId
                    If objTabPermission.AllowAccess Then
                        objTabPermissionController.AddTabPermission(objTabPermission)
                    End If
                Next
            End If
            If Not Null.IsNull(objTab.PortalID) Then
                UpdatePortalTabOrder(objTab.PortalID, intTabId, objTab.ParentId, 0, 0, objTab.IsVisible, True)
            Else    ' host tab
                Dim arrTabs As ArrayList = GetTabsByParentId(objTab.ParentId, objTab.PortalID)
                objTab.TabID = intTabId
                objTab.TabOrder = (arrTabs.Count * 2) - 1
                objTab.Level = 1
                UpdateTabOrder(objTab)
            End If

            If AddAllTabsModules Then
                Dim objmodules As New ModuleController
                Dim arrMods As ArrayList = objmodules.GetAllTabsModules(objTab.PortalID, True)

                For Each objModule As ModuleInfo In arrMods
                    objmodules.CopyModule(objModule.ModuleID, objModule.TabID, intTabId, "", True)
                Next
            End If

            ClearCache(objTab.PortalID)

            Return intTabId
        End Function

        Public Sub CopyTab(ByVal PortalId As Integer, ByVal FromTabId As Integer, ByVal ToTabId As Integer, ByVal IncludeContent As Boolean)
            Dim objModules As New ModuleController
            Dim objModule As ModuleInfo

            For Each kvp As KeyValuePair(Of Integer, ModuleInfo) In objModules.GetTabModules(FromTabId)
                objModule = kvp.Value

                ' if the module shows on all pages does not need to be copied since it will
                ' be already added to this page
                If Not objModule.AllTabs Then
                    If IncludeContent = False Then
                        objModule.ModuleID = Null.NullInteger
                    End If

                    objModule.TabID = ToTabId
                    objModules.AddModule(objModule)
                End If
            Next
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Deletes a tab premanently from the database
        ''' </summary>
        ''' <param name="TabId">TabId of the tab to be deleted</param>
        ''' <param name="PortalId">PortalId of the portal</param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[Vicen�]	19/09/2004	Added skin deassignment before deleting the tab.
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub DeleteTab(ByVal TabId As Integer, ByVal PortalId As Integer)
            ' parent tabs can not be deleted
            Dim arrTabs As ArrayList = GetTabsByParentId(TabId, PortalId)

            If arrTabs.Count = 0 Then
                DataProvider.Instance().DeleteTab(TabId)
                UpdatePortalTabOrder(PortalId, TabId, -2, 0, 0, True)
            End If

            ClearCache(PortalId)
        End Sub

        Public Function GetAllTabs() As ArrayList
            Return FillTabInfoCollection(DataProvider.Instance().GetAllTabs())
        End Function

        Public Function GetTab(ByVal TabId As Integer, ByVal PortalId As Integer, ByVal ignoreCache As Boolean) As TabInfo
            Dim tab As TabInfo = Nothing
            Dim bFound As Boolean = False

            ' if we are using the cache
            If Not ignoreCache Then
                ' if we do not know the PortalId then try to find it in the Portals Dictionary using the TabId
                If Null.IsNull(PortalId) Then
                    Dim portalDic As Dictionary(Of Integer, Integer) = PortalController.GetPortalDictionary()
                    If portalDic.ContainsKey(TabId) Then
                        PortalId = portalDic(TabId)
                    End If
                End If
                ' if we have the PortalId then try to get the TabInfo object from the Tabs Dictionary
                If Not Null.IsNull(PortalId) Then
                    Dim dicTabs As Dictionary(Of Integer, TabInfo)
                    dicTabs = GetTabsByPortal(PortalId)
                    bFound = dicTabs.TryGetValue(TabId, tab)
                End If
            End If

            ' if we are not using the cache or did not find the TabInfo object in the cache
            If ignoreCache Or Not bFound Then
                ' get the TabInfo object from the database
                Dim dr As IDataReader = DataProvider.Instance().GetTab(TabId)
                Try
                    tab = FillTabInfo(dr)
                Finally
                    If Not dr Is Nothing Then
                        dr.Close()
                    End If
                End Try
            End If

            Return tab
        End Function

        Public Function GetTabByName(ByVal TabName As String, ByVal PortalId As Integer) As TabInfo
            Return GetTabByNameAndParent(TabName, PortalId, Integer.MinValue)
        End Function

        Public Function GetTabByName(ByVal TabName As String, ByVal PortalId As Integer, ByVal ParentId As Integer) As TabInfo
            Return GetTabByNameAndParent(TabName, PortalId, ParentId)
        End Function

        Public Function GetTabCount(ByVal portalId As Integer) As Integer
            Return DataProvider.Instance().GetTabCount(portalId)
        End Function

        Public Function GetTabs(ByVal PortalId As Integer) As ArrayList
            Dim arrTabs As New ArrayList
            For Each tabPair As KeyValuePair(Of Integer, TabInfo) In GetTabsByPortal(PortalId)
                arrTabs.Add(tabPair.Value)
            Next
            Return arrTabs
        End Function

        Public Function GetTabsByParentId(ByVal ParentId As Integer, ByVal PortalId As Integer) As ArrayList
            Return GetTabsByParent(ParentId, PortalId)
        End Function

        Public Function GetTabsByPortal(ByVal PortalId As Integer) As Dictionary(Of Integer, TabInfo)
            Dim key As String = String.Format(DataCache.TabCacheKey, PortalId)

            'First Check the Tab Cache
            Dim tabs As Dictionary(Of Integer, TabInfo) = TryCast(DataCache.GetPersistentCacheItem(key, GetType(Dictionary(Of Integer, TabInfo))), Dictionary(Of Integer, TabInfo))

            If tabs Is Nothing Then
                'tab caching settings
                Dim timeOut As Int32 = DataCache.TabCacheTimeOut * Convert.ToInt32(Common.Globals.PerformanceSetting)

                'Get tabs form Database
                tabs = FillTabInfoDictionary(DataProvider.Instance().GetTabs(PortalId))

                'Cache tabs
                If timeOut > 0 Then
                    DataCache.SetCache(key, tabs, TimeSpan.FromMinutes(timeOut), True)
                End If
            End If

            Return tabs
        End Function

        Public Sub UpdatePortalTabOrder(ByVal PortalId As Integer, ByVal TabId As Integer, ByVal NewParentId As Integer, ByVal Level As Integer, ByVal Order As Integer, ByVal IsVisible As Boolean, Optional ByVal NewTab As Boolean = False)
            Dim objTab As TabInfo
            Dim intCounter As Integer = 0
            Dim intFromIndex As Integer = -1
            Dim intOldParentId As Integer = -2
            Dim intToIndex As Integer = -1
            Dim intNewParentIndex As Integer = 0
            Dim intLevel As Integer
            Dim intAddTabLevel As Integer

            Dim objPortals As New PortalController
            Dim objPortal As PortalInfo = objPortals.GetPortal(PortalId)

            'hashtable to prevent db calls when no change
            Dim htabs As New Hashtable

            ' create temporary tab collection
            Dim objTabs As New ArrayList

            ' populate temporary tab collection
            For Each tabPair As KeyValuePair(Of Integer, TabInfo) In GetTabsByPortal(PortalId)
                objTab = tabPair.Value

                If NewTab = False Or objTab.TabID <> TabId Then
                    ' save old data
                    htabs.Add(objTab.TabID, New TabOrderHelper(objTab.TabOrder, objTab.Level, objTab.ParentId))

                    If objTab.TabOrder = 0 Then
                        objTab.TabOrder = 999
                    End If
                    objTabs.Add(objTab)
                    If objTab.TabID = TabId Then
                        intOldParentId = objTab.ParentId
                        intFromIndex = intCounter
                    End If
                    If objTab.TabID = NewParentId Then
                        intNewParentIndex = intCounter
                        intAddTabLevel = objTab.Level + 1
                    End If
                    intCounter += 1
                End If
            Next

            If NewParentId <> -2 Then    ' not deleted
                ' adding new tab
                If intFromIndex = -1 Then
                    'Tab exists - just not in Cache yet so fetch from db , to ensure we have all the properties set
                    objTab = GetTab(TabId, PortalId, True)
                    objTab.TabID = TabId
                    objTab.ParentId = NewParentId
                    objTab.IsVisible = IsVisible
                    objTab.Level = intAddTabLevel
                    objTabs.Add(objTab)
                    intFromIndex = objTabs.Count - 1
                End If

                If Level = 0 And Order = 0 Then
                    CType(objTabs(intFromIndex), TabInfo).IsVisible = IsVisible
                End If
            End If

            If NewParentId <> -2 Then    ' not deleted
                ' if the parent changed or we added a new non root level tab
                If intOldParentId <> NewParentId And Not (intOldParentId = -2 And NewParentId = -1) Then
                    ' locate position of last child for new parent
                    If NewParentId <> -1 Then
                        intLevel = CType(objTabs(intNewParentIndex), TabInfo).Level
                    Else
                        intLevel = -1
                    End If

                    intCounter = intNewParentIndex + 1
                    While intCounter <= objTabs.Count - 1
                        If CType(objTabs(intCounter), TabInfo).Level > intLevel Then
                            intToIndex = intCounter
                        Else
                            Exit While
                        End If
                        intCounter += 1
                    End While
                    ' adding to parent with no children
                    If intToIndex = -1 Then
                        intToIndex = intNewParentIndex
                    End If
                    ' move tab
                    CType(objTabs(intFromIndex), TabInfo).ParentId = NewParentId
                    MoveTab(objTabs, intFromIndex, intToIndex, intLevel + 1)
                Else
                    ' if level has changed
                    If Level <> 0 Then
                        intLevel = CType(objTabs(intFromIndex), TabInfo).Level

                        Dim blnValid As Boolean = True
                        Select Case Level
                            Case -1
                                If intLevel = 0 Then
                                    blnValid = False
                                End If
                            Case 1
                                If intFromIndex > 0 Then
                                    If intLevel > CType(objTabs(intFromIndex - 1), TabInfo).Level Then
                                        blnValid = False
                                    End If
                                Else
                                    blnValid = False
                                End If
                        End Select

                        If blnValid Then
                            Dim intNewLevel As Integer
                            If Level = -1 Then
                                intNewLevel = intLevel + Level
                            Else
                                intNewLevel = intLevel
                            End If

                            ' get new parent
                            NewParentId = -2
                            intCounter = intFromIndex - 1
                            While intCounter >= 0 And NewParentId = -2
                                objTab = CType(objTabs(intCounter), TabInfo)
                                If objTab.Level = intNewLevel And Not objTab.IsDeleted Then
                                    If Level = -1 Then
                                        NewParentId = objTab.ParentId
                                    Else
                                        NewParentId = objTab.TabID
                                    End If
                                    intNewParentIndex = intCounter
                                End If
                                intCounter -= 1
                            End While
                            CType(objTabs(intFromIndex), TabInfo).ParentId = NewParentId

                            If Level = -1 Then
                                ' locate position of next child for parent
                                intToIndex = -1
                                intCounter = intNewParentIndex + 1
                                While intCounter <= objTabs.Count - 1
                                    If CType(objTabs(intCounter), TabInfo).Level > intNewLevel Then
                                        intToIndex = intCounter
                                    Else
                                        Exit While
                                    End If
                                    intCounter += 1
                                End While
                                ' adding to parent with no children
                                If intToIndex = -1 Then
                                    intToIndex = intNewParentIndex
                                End If
                            Else
                                intToIndex = intFromIndex - 1
                                intNewLevel = intLevel + Level
                            End If

                            ' move tab
                            If intFromIndex = intToIndex Then
                                CType(objTabs(intFromIndex), TabInfo).Level = intNewLevel
                            Else
                                MoveTab(objTabs, intFromIndex, intToIndex, intNewLevel)
                            End If
                        End If
                    Else
                        ' if order has changed
                        If Order <> 0 Then
                            intLevel = CType(objTabs(intFromIndex), TabInfo).Level

                            ' find previous/next item for parent
                            intToIndex = -1
                            intCounter = intFromIndex + Order
                            While intCounter >= 0 And intCounter <= objTabs.Count - 1 And intToIndex = -1
                                objTab = CType(objTabs(intCounter), TabInfo)
                                If objTab.ParentId = NewParentId And Not objTab.IsDeleted Then
                                    intToIndex = intCounter
                                End If
                                intCounter += Order
                            End While
                            If intToIndex <> -1 Then
                                If Order = 1 Then
                                    ' locate position of next child for parent
                                    intNewParentIndex = intToIndex
                                    intToIndex = -1
                                    intCounter = intNewParentIndex + 1
                                    While intCounter <= objTabs.Count - 1
                                        If CType(objTabs(intCounter), TabInfo).Level > intLevel Then
                                            intToIndex = intCounter
                                        Else
                                            Exit While
                                        End If
                                        intCounter += 1
                                    End While
                                    ' adding to parent with no children
                                    If intToIndex = -1 Then
                                        intToIndex = intNewParentIndex
                                    End If
                                    intToIndex += 1
                                End If
                                MoveTab(objTabs, intFromIndex, intToIndex, intLevel, False)
                            End If
                        End If
                    End If
                End If
            End If

            ' update the tabs
            Dim intDesktopTabOrder As Integer = -1
            Dim intAdminTabOrder As Integer = 9999    ' this seeds the taborder for the admin tab so that they are always at the end of the tab list ( max = 5000 desktop tabs per portal )
            For Each objTab In objTabs
                If ((objTab.TabID = objPortal.AdminTabId) Or (objTab.ParentId = objPortal.AdminTabId) Or (objTab.TabID = objPortal.SuperTabId) Or (objTab.ParentId = objPortal.SuperTabId)) And _
                 (objPortal.AdminTabId <> -1) Then    ' special case when creating new portals
                    intAdminTabOrder += 2
                    objTab.TabOrder = intAdminTabOrder
                Else    ' desktop tab
                    intDesktopTabOrder += 2
                    objTab.TabOrder = intDesktopTabOrder
                End If
                ' update only if changed
                If htabs.Contains(objTab.TabID) Then
                    Dim ttab As TabOrderHelper = CType(htabs(objTab.TabID), TabOrderHelper)
                    If objTab.TabOrder <> ttab.TabOrder Or objTab.Level <> ttab.Level Or objTab.ParentId <> ttab.ParentId Then
                        UpdateTabOrder(objTab)
                    End If
                Else
                    UpdateTabOrder(objTab)
                End If
            Next

            'clear Tabs cache
            ClearCache(PortalId)
        End Sub

        Public Sub UpdateTab(ByVal objTab As TabInfo)
            Dim updateChildren As Boolean = False
            Dim objTmpTab As TabInfo = GetTab(objTab.TabID, objTab.PortalID, False)
            If objTmpTab.TabName <> objTab.TabName Or objTmpTab.ParentId <> objTab.ParentId Then
                updateChildren = True
            End If

            UpdatePortalTabOrder(objTab.PortalID, objTab.TabID, objTab.ParentId, 0, 0, objTab.IsVisible)

            DataProvider.Instance().UpdateTab(objTab.TabID, objTab.TabName, objTab.IsVisible, objTab.DisableLink, objTab.ParentId, objTab.IconFile, objTab.Title, objTab.Description, objTab.KeyWords, objTab.IsDeleted, objTab.Url, objTab.SkinSrc, objTab.ContainerSrc, objTab.TabPath, objTab.StartDate, objTab.EndDate, objTab.RefreshInterval, objTab.PageHeadText, objTab.IsSecure)

            Dim objTabPermissionController As New Security.Permissions.TabPermissionController

            Dim objTabPermissions As Security.Permissions.TabPermissionCollection
            objTabPermissions = objTab.TabPermissions

            Dim objCurrentTabPermissions As Security.Permissions.TabPermissionCollection
            objCurrentTabPermissions = objTabPermissionController.GetTabPermissionsCollectionByTabID(objTab.TabID, objTab.PortalID)

            If Not objCurrentTabPermissions.CompareTo(objTab.TabPermissions) Then
                objTabPermissionController.DeleteTabPermissionsByTabID(objTab.TabID)

                Dim objTabPermission As New Security.Permissions.TabPermissionInfo
                For Each objTabPermission In objTabPermissions
                    If objTabPermission.AllowAccess Then
                        objTabPermissionController.AddTabPermission(objTabPermission)
                    End If
                Next
            End If
            If updateChildren Then
                UpdateChildTabPath(objTab.TabID, objTab.PortalID)
            End If

            ClearCache(objTab.PortalID)
        End Sub

        Public Sub UpdateTabOrder(ByVal objTab As TabInfo)
            objTab.TabPath = GenerateTabPath(objTab.ParentId, objTab.TabName)
            DataProvider.Instance().UpdateTabOrder(objTab.TabID, objTab.TabOrder, objTab.Level, objTab.ParentId, objTab.TabPath)
        End Sub

        Public Sub CopyDesignToChildren(ByVal tabs As ArrayList, ByVal skinSrc As String, ByVal containerSrc As String)

            For Each objTab As TabInfo In tabs
                DataProvider.Instance().UpdateTab(objTab.TabID, objTab.TabName, objTab.IsVisible, objTab.DisableLink, objTab.ParentId, objTab.IconFile, objTab.Title, objTab.Description, objTab.KeyWords, objTab.IsDeleted, objTab.Url, skinSrc, containerSrc, objTab.TabPath, objTab.StartDate, objTab.EndDate, objTab.RefreshInterval, objTab.PageHeadText, objTab.IsSecure)
            Next

            If tabs.Count > 0 Then
                DotNetNuke.Common.Utilities.DataCache.ClearTabsCache(CType(tabs(0), TabInfo).PortalID)
            End If

        End Sub

        Public Sub CopyPermissionsToChildren(ByVal tabs As ArrayList, ByVal newPermissions As Permissions.TabPermissionCollection)

            Dim objTabPermissionController As New Security.Permissions.TabPermissionController

            For Each objTab As TabInfo In tabs

                Dim objCurrentTabPermissions As Security.Permissions.TabPermissionCollection
                objCurrentTabPermissions = objTabPermissionController.GetTabPermissionsCollectionByTabID(objTab.TabID, objTab.PortalID)

                If Not objCurrentTabPermissions.CompareTo(newPermissions) Then
                    objTabPermissionController.DeleteTabPermissionsByTabID(objTab.TabID)

                    For Each objTabPermission As Security.Permissions.TabPermissionInfo In newPermissions
                        If objTabPermission.AllowAccess Then
                            objTabPermission.TabID = objTab.TabID
                            objTabPermissionController.AddTabPermission(objTabPermission)
                        End If
                    Next
                End If
            Next

            If tabs.Count > 0 Then
                DotNetNuke.Common.Utilities.DataCache.ClearTabsCache(CType(tabs(0), TabInfo).PortalID)
            End If

        End Sub

        Public Shared Sub AddTabPathDictionary(ByVal portalId As Integer, ByVal tabPath As String, ByVal tabId As Integer)
            Dim strKey As String = "//" & portalId.ToString & tabPath
            Dim tabpathDic As Dictionary(Of String, Integer) = GetTabPathDictionary()
            If Not tabpathDic.ContainsKey(strKey) Then
                tabpathDic(strKey) = tabId
            End If
        End Sub

        Public Shared Function GetTabPathDictionary() As Dictionary(Of String, Integer)
            'Dim tabpathKey As String = DataCache.TabPathDictionaryCacheKey
            Dim tabpathKey As String = "TabPathDictionary"

            Dim tabpathDic As Dictionary(Of String, Integer) = TryCast(DataCache.GetCache(tabpathKey), Dictionary(Of String, Integer))
            If tabpathDic Is Nothing Then
                tabpathDic = New Dictionary(Of String, Integer)
                DataCache.SetCache(tabpathKey, tabpathDic, False)
            End If

            Return tabpathDic
        End Function

        Public Shared Function GetTabByTabPath(ByVal portalId As Integer, ByVal tabPath As String) As Integer
            Dim strKey As String = "//" & portalId.ToString & tabPath
            Dim tabpathDic As Dictionary(Of String, Integer) = GetTabPathDictionary()
            If tabpathDic.ContainsKey(strKey) Then
                Return tabpathDic(strKey)
            Else
                Return -1
            End If
        End Function

#End Region

#Region "Obsolete"

        <Obsolete("This method is obsolete.  It has been replaced by GetTab(ByVal TabId As Integer, ByVal PortalId As Integer, ByVal ignoreCache As Boolean) ")> _
        Public Function GetTab(ByVal TabId As Integer) As TabInfo
            Dim dr As IDataReader = DataProvider.Instance().GetTab(TabId)
            Try
                Return FillTabInfo(dr)
            Finally
                If Not dr Is Nothing Then
                    dr.Close()
                End If
            End Try
        End Function

        <Obsolete("This method is obsolete.  It has been replaced by GetTabsByParentId(ByVal ParentId As Integer, ByVal PortalId As Integer) ")> _
        Public Function GetTabsByParentId(ByVal ParentId As Integer) As ArrayList
            Return FillTabInfoCollection(DataProvider.Instance().GetTabsByParentId(ParentId))
        End Function

        <Obsolete("This method is obsolete.  It has been replaced by UpdateTabOrder(ByVal objTab As TabInfo) ")> _
        Public Sub UpdateTabOrder(ByVal PortalID As Integer, ByVal TabId As Integer, ByVal TabOrder As Integer, ByVal Level As Integer, ByVal ParentId As Integer)
            Dim objTab As TabInfo = GetTab(TabId, PortalID, False)
            objTab.TabOrder = TabOrder
            objTab.Level = Level
            objTab.ParentId = ParentId
            UpdateTabOrder(objTab)
        End Sub


#End Region

    End Class


End Namespace

