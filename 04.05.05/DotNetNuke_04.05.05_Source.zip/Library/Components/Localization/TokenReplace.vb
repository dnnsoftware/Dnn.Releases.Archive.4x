'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2007 by DotNetNuke Corp. 
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports DotNetNuke
Imports DotNetNuke.Entities.Host.HostSettings
Imports DotNetNuke.Entities.Modules
Imports DotNetNuke.Entities.Portals
Imports DotNetNuke.Entities.Tabs
Imports DotNetNuke.Entities.Users
Imports DotNetNuke.Entities.Profile
Imports DotNetNuke.Services.Localization
Imports System.Globalization
Imports System.Web
Imports System.Text
Imports System.Text.RegularExpressions


Namespace DotNetNuke.Services.Localization

#Region " Type Definitions "
    Public Enum TokenAccessLevel
        NoSettings
        DefaultSettings
        FullSettings
    End Enum
#End Region

    ''' -----------------------------------------------------------------------------
    ''' Project:    DotNetNuke
    ''' Namespace:  DotNetNuke.Services.Localization
    ''' Class:      TokenReplace
    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' The TokenReplace class provides the option to replace tokens formatted 
    ''' [object:property] or [object:property|format] or [custom:no] within a string
    ''' with the appropriate current property/custom values.
    ''' Example for Newsletter: 'Dear [user:Displayname],' ==> 'Dear Superuser Account,'
    ''' </summary>
    ''' <history>
    '''     [sleupold]	12/30/2006  newly created based on method from DNN localization
    '''     [scullmann] 01/02/2007  refactored usingselect instead of reflection
    '''     [scullmann] 01/04/2007  refactored for performance
    '''     [sleupold]  05/16/2007  refactored user profile property access
    '''     [sleupold]  05/25/2007  documented
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Public Class TokenReplace

#Region " Private Fields "
        Private Shared _Tokenizer As Regex
        Private _Language As String
        Private _PortalSettings As PortalSettings
        Private _Hostsettings As Hashtable
        Private _ModuleInfo As Entities.Modules.ModuleInfo
        Private _User As Entities.Users.UserInfo
        Private _Tab As Entities.Tabs.TabInfo
        Private _ModuleId As Integer
        Private _formatProvider As IFormatProvider
        Private _AccessLevel As TokenAccessLevel
        Private _AccessingUser As Entities.Users.UserInfo
#End Region

#Region " Properties "

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets the Regular expression for the token to be replaced
        ''' </summary>
        ''' <value>A regular Expression</value>
        ''' <history>
        ''' 	[scullmann]	01/04/2007	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Shared ReadOnly Property TokenizerRegex() As Regex
            Get
                If _Tokenizer Is Nothing Then
                    Dim exp As String = "(?:\[((?<object>[^\]\[:]+):(?<property>[^\]\[\|]+))(?:\|(?<format>[^\]\[]+))*\])|(?<text>\[[^\]\[]+\])|(?<text>[^\]\[]+)"
                    _Tokenizer = New Regex(exp, RegexOptions.Compiled)
                End If
                Return _Tokenizer
            End Get
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets the Format provider as Culture info from stored language or current culture
        ''' </summary>
        ''' <value>An IFormatProvider</value>
        ''' <history>
        ''' 	[scullmann]	01/04/2007	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private ReadOnly Property FormatProvider() As IFormatProvider
            Get
                If _formatProvider Is Nothing Then
                    If Not Language Is Nothing Then
                        _formatProvider = New CultureInfo(Language)
                    Else
                        _formatProvider = System.Threading.Thread.CurrentThread.CurrentCulture
                    End If
                End If
                Return _formatProvider
            End Get
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets the Host settings from Portal
        ''' </summary>
        ''' <value>A hashtable with all settings</value>
        ''' <history>
        ''' 	[scullmann]	01/04/2007	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private ReadOnly Property HostSettings() As Hashtable
            Get
                If _Hostsettings Is Nothing Then
                    _Hostsettings = GetSecureHostSettings()
                End If
                Return _Hostsettings
            End Get
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets/sets the current Access Level controlling access to critical user settings
        ''' </summary>
        ''' <value>A TokenAccessLevel sa defined above</value>
        ''' <history>
        ''' 	[scullmann]	01/04/2007	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Property CurrentAccessLevel() As TokenAccessLevel
            Get
                Return _AccessLevel
            End Get
            Set(ByVal value As TokenAccessLevel)

                _AccessLevel = value
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets/sets the language to be used, e.g. for date format
        ''' </summary>
        ''' <value>A string, representing the locale</value>
        ''' <history>
        ''' 	[scullmann]	01/04/2007	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Property Language() As String
            Get
                Return _Language
            End Get
            Set(ByVal value As String)
                _Language = value
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets/sets the portal settings object to use for 'Portal:' token replacement
        ''' </summary>
        ''' <value>PortalSettings oject</value>
        ''' <history>
        ''' 	[scullmann]	01/04/2007	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Property PortalSettings() As PortalSettings
            Get
                Return _PortalSettings
            End Get
            Set(ByVal value As PortalSettings)
                _PortalSettings = value
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets/sets the module settings object to use for 'Module:' token replacement
        ''' </summary>
        ''' <value>ModuleInfo oject</value>
        ''' <history>
        ''' 	[scullmann]	01/04/2007	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Property ModuleInfo() As Entities.Modules.ModuleInfo
            Get
                If _ModuleInfo Is Nothing OrElse _ModuleInfo.ModuleID <> ModuleId Then
                    Dim mc As New DotNetNuke.Entities.Modules.ModuleController
                    _ModuleInfo = mc.GetModule(ModuleId, PortalSettings.ActiveTab.TabID)
                End If
                Return _ModuleInfo
            End Get
            Set(ByVal value As Entities.Modules.ModuleInfo)
                _ModuleInfo = value
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets/sets the user object to use for 'User:' token replacement
        ''' </summary>
        ''' <value>UserInfo oject</value>
        ''' <history>
        ''' 	[scullmann]	01/04/2007	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Property User() As Entities.Users.UserInfo
            Get
                Return _User
            End Get
            Set(ByVal value As Entities.Users.UserInfo)
                _User = value
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets/sets the user object representing the currently accessing user (permission)
        ''' </summary>
        ''' <value>UserInfo oject</value>
        ''' <history>
        ''' 	[scullmann]	01/04/2007	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Property AccessingUser() As Entities.Users.UserInfo
            Get
                Return _AccessingUser
            End Get
            Set(ByVal value As Entities.Users.UserInfo)
                _AccessingUser = value
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets/sets the current ModuleID to be used for 'User:' token replacement
        ''' </summary>
        ''' <value>ModuleID (Integer)</value>
        ''' <history>
        ''' 	[scullmann]	01/04/2007	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Property ModuleId() As Integer
            Get
                Return _ModuleId
            End Get
            Set(ByVal value As Integer)

                _ModuleId = value
            End Set
        End Property

#End Region

#Region " Constructor and fabric methods "
        Private Sub New()
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Create the object, basing on different passed objects. Missing object will be
        ''' replaced by objects created from current context
        ''' </summary>
        ''' <returns>TokenReplace Object</returns>
        ''' <param name="ModuleID">ID of the Module to use</param>
        ''' <history>
        ''' 	[scullmann]	01/04/2007	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function Create(ByVal ModuleID As Integer) As TokenReplace
            Dim tr As TokenReplace = Create(TokenAccessLevel.DefaultSettings)
            tr.ModuleId = ModuleID
            Return tr
        End Function

        Public Shared Function Create(ByVal objModuleInfo As ModuleInfo) As TokenReplace
            Dim tr As TokenReplace = Create(TokenAccessLevel.DefaultSettings)
            tr.ModuleId = objModuleInfo.ModuleID
            tr.ModuleInfo = objModuleInfo
            Return tr
        End Function

        Public Shared Function Create() As TokenReplace
            Return Create(TokenAccessLevel.DefaultSettings)
        End Function

        Public Shared Function Create(ByVal Language As String) As TokenReplace
            Return Create(TokenAccessLevel.DefaultSettings, Language, Nothing, Nothing)
        End Function

        Public Shared Function Create(ByVal AccessLevel As TokenAccessLevel) As TokenReplace
            Return Create(AccessLevel, Nothing, Nothing, Nothing)
        End Function

        Public Shared Function Create(ByVal AccessLevel As TokenAccessLevel, ByVal Language As String) As TokenReplace
            Return Create(AccessLevel, Language, Nothing, Nothing)
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Create the object, basing on different passed objects. Missing object will be
        ''' replaced by objects created from current context
        ''' </summary>
        ''' <returns>TokenReplace Object</returns>
        ''' <param name="AccessLevel">maximum Security Access level for private properties, limited by accessing user's permissions</param>
        ''' <param name="Language">Locale to be used for formatting</param>
        ''' <param name="PortalSettings">Portal to be queried for portal and admin settings</param>
        ''' <param name="User">User object to read user data and profile proerties from</param>
        ''' <history>
        ''' 	[scullmann]	01/04/2007	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function Create(ByVal AccessLevel As TokenAccessLevel, ByVal Language As String, ByVal PortalSettings As PortalSettings, ByVal User As UserInfo) As TokenReplace
            Dim tr As TokenReplace = New TokenReplace
            tr.CurrentAccessLevel = AccessLevel
            If AccessLevel <> TokenAccessLevel.NoSettings Then
                If PortalSettings Is Nothing Then
                    tr.PortalSettings = Entities.Portals.PortalController.GetCurrentPortalSettings
                Else
                    tr.PortalSettings = PortalSettings
                End If
                If User Is Nothing Then
                    tr.User = CType(HttpContext.Current.Items("UserInfo"), UserInfo)
                    tr.AccessingUser = tr.User
                Else
                    tr.User = User
                    tr.AccessingUser = CType(HttpContext.Current.Items("UserInfo"), UserInfo)
                End If
                If String.IsNullOrEmpty(Language) Then
                    tr.Language = New Localization().CurrentCulture
                Else
                    tr.Language = Language
                End If
            End If
            Return tr
        End Function

#End Region

#Region " Public Methods "

        Public Function ReplaceEnvironmentTokens(ByVal strSourceText As String) As String
            Return ReplaceEnvironmentTokens(strSourceText, Nothing, String.Empty, Nothing)
        End Function

        Public Function ReplaceEnvironmentTokens(ByVal strSourceText As String, ByVal row As DataRow) As String
            Return ReplaceEnvironmentTokens(strSourceText, Nothing, String.Empty, row)
        End Function

        Public Function ReplaceEnvironmentTokens(ByVal strSourceText As String, ByVal Custom As ArrayList, ByVal CustomCaption As String) As String
            Return ReplaceEnvironmentTokens(strSourceText, Custom, CustomCaption, Nothing)
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Replaces tokens in strSourceText parameter with the property values
        ''' </summary>
        ''' <returns>resulting string with token replaced by property values</returns>
        ''' <param name="strSourceText">Security Access level for private properties</param>
        ''' <param name="Custom">value list for replacing [custom:ID] tokens, where 'custom' is specified in next param and ID is index number in the string</param>
        ''' <param name="CustomCaption">Token name to be used for 'myCustom' (default), replacing [myCustom:ID] tokens with custom value from ArrayList Custom</param>
        ''' <param name="Row">Data Row, that can be used to replace tokens like [row:fieldName] or [field:fieldName] where fieldName is Name of a field in the row</param>
        ''' <history>
        ''' 	[scullmann]	01/04/2007	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function ReplaceEnvironmentTokens(ByVal strSourceText As String, ByVal Custom As ArrayList, ByVal CustomCaption As String, ByVal Row As System.Data.DataRow) As String

            If strSourceText Is Nothing Then Return String.Empty

            Dim Result As New System.Text.StringBuilder
            For Each m As Match In TokenizerRegex.Matches(strSourceText)
                Dim strObjectName As String = m.Result("${object}")
                If strObjectName.Length > 0 Then
                    Dim strPropertyName As String = m.Result("${property}")
                    Dim strFormat As String = m.Result("${format}")

                    Result.Append(replacedTokenValue(strObjectName, strPropertyName, strFormat, Custom, CustomCaption, Row))
                Else
                    Result.Append(m.Result("${text}"))
                End If
            Next

            Return Result.ToString()
        End Function

#End Region

#Region " Obsolete Methods "
        <Obsolete("This property has been deprecated, use overload with additional CustomCaption parameter")> _
        Public Function ReplaceEnvironmentTokens(ByVal strSourceText As String, ByVal Custom As ArrayList) As String
            Return ReplaceEnvironmentTokens(strSourceText, Custom, "Custom", Nothing)
        End Function

        <Obsolete("This property has been deprecated, use overload with additional CustomCaption parameter")> _
        Public Function ReplaceEnvironmentTokens(ByVal strSourceText As String, ByVal Custom As ArrayList, ByVal Row As System.Data.DataRow) As String
            Return ReplaceEnvironmentTokens(strSourceText, Custom, "Custom", Row)
        End Function
#End Region

#Region " Protected Methods "

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        '''     calculates the replaced string from source string containing tokens in form
        '''     [object:property] or [object:property|format]
        '''     property names need to be valid properties of the passed object or the index of a value in custom array list
        '''     format 
        ''' </summary>
        ''' <param name="strObjectName">name of the object, which property shall be replaced. valid objects are:
        '''     host: host user properties
        '''     portal: Portal settings
        '''     tab: tab settings
        '''     module: module settings
        '''     user: user settings
        '''     membership: user's settings from membership component
        '''     profile: user profile property (default and custom)
        '''     row, field: field value of passed row and fieldName, if available
        '''     datetime, date: current dateTime
        '''     ticks: current DateTime in Ticks or TicksPerDay
        '''     custom: replaces value from custom array 'custom' (overrides other objects, if similar name is used!)</param>
        ''' <param name="strPropertyName">name of the property to be replaced. Property names need to be valid properties 
        '''     of the passed object or the index of a value in custom array list.</param>
        ''' <param name="strFormat">format specification. Valid formats need to be able to be passed over to 'toString' method.</param>
        ''' <param name="Custom">value list for replacing [custom:ID] tokens, where 'custom' is specified in next param and ID is index number in the string</param>
        ''' <param name="CustomCaption">Token name to be used for 'myCustom' (default), replacing [myCustom:ID] tokens with custom value from ArrayList Custom</param>
        ''' <param name="Row">Data Row, that can be used to replace tokens like [row:fieldName] or [field:fieldName] where fieldName is Name of a field in the row</param>
        ''' <history>
        '''     [scullmann]    01/02/2007  newly created based on method from DNN localization
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Protected Function replacedTokenValue(ByVal strObjectName As String, ByVal strPropertyName As String, ByVal strFormat As String, _
                     ByVal Custom As ArrayList, ByVal CustomCaption As String, ByVal Row As System.Data.DataRow) As String

            Dim isSecure As Boolean = (CurrentAccessLevel = TokenAccessLevel.FullSettings)

            Select Case strObjectName.ToLower
                Case CustomCaption.ToLower
                    If IsNumeric(strPropertyName) Then
                        Dim intIndex As Integer = Integer.Parse(strPropertyName)
                        If Not Custom Is Nothing AndAlso Custom.Count > intIndex Then
                            Return Custom(intIndex).ToString()
                        End If
                    End If
                Case "host"
                    If HostSettings.ContainsKey(strPropertyName) Then Return HostSettings(strPropertyName).ToString()
                Case "portal"
                    If strPropertyName.ToLower = "url" Then
                        Return PortalSettings.PortalAlias.HTTPAlias()
                    Else
                        Return GetProperty(PortalSettings, strPropertyName, strFormat, FormatProvider)
                    End If
                Case "tab"
                    Return GetProperty(PortalSettings.ActiveTab, strPropertyName, strFormat, FormatProvider)
                Case "module"
                    Return GetProperty(ModuleInfo, strPropertyName, strFormat, FormatProvider)
                Case "user"
                    If strPropertyName.ToLower = "verificationcode" Then
                        Return PortalSettings.PortalId.ToString & "-" & User.UserID.ToString
                    Else
                        Return GetProperty(User, strPropertyName, strFormat, FormatProvider)
                    End If
                Case "membership"
                    If strPropertyName Like "Password*" Then
                        If Not isSecure OrElse User.IsSuperUser Then
                            Return "*******"
                        End If
                    End If
                    Return GetProperty(User.Membership, strPropertyName, strFormat, FormatProvider)
                Case "profile"
                    Dim accLevel As TokenAccessLevel = CurrentAccessLevel
                    If accLevel <> TokenAccessLevel.NoSettings AndAlso AccessingUser.UserID = Null.NullInteger Then
                        'unauthorized user access:
                        accLevel = TokenAccessLevel.NoSettings
                    ElseIf accLevel = TokenAccessLevel.FullSettings AndAlso AccessingUser.UserID <> User.UserID _
                      AndAlso Not AccessingUser.IsSuperUser AndAlso Not AccessingUser.IsInRole(GetPortalSettings.AdministratorRoleName) Then
                        'only Admins are allways allowed to view all properties and users of their own profile:
                        accLevel = TokenAccessLevel.DefaultSettings
                    End If
                    Return GetProperty(User.Profile, strPropertyName, strFormat, FormatProvider, accLevel)
                Case "row", "field"
                    If Not Row Is Nothing Then Return CStr(Row(strPropertyName))
                Case "datetime", "date"
                    If strFormat = String.Empty Then
                        If strPropertyName.ToLower = "current" Then Return DateTime.Now.ToString("D", FormatProvider)
                        If strPropertyName.ToLower = "now" Then Return DateTime.Now.ToString("g", FormatProvider)
                    Else
                        Return DateTime.Now.ToString(strFormat, FormatProvider)
                    End If
                Case "ticks"
                    Select Case strPropertyName.ToLower
                        Case "now"
                            Return DateTime.Now.Ticks.ToString()
                        Case "today"
                            Return DateTime.Today.Ticks.ToString()
                        Case "ticksperday"
                            Return TimeSpan.TicksPerDay.ToString()
                    End Select
            End Select
            If strFormat.Length > 0 Then
                Return String.Format("[{0}:{1}|{2}]", strObjectName, strPropertyName, strFormat)
            Else
                Return String.Format("[{0}:{1}]", strObjectName, strPropertyName)
            End If
        End Function

#End Region

#Region "Private Methods for Property Access"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        '''     Returns the localized property of the PortalSettings object as string
        ''' </summary>
        ''' <param name="objPortal">PortalSettings</param>
        ''' <param name="strPropertyName">Name of property</param>
        ''' <param name="strFormat">Format String</param>
        ''' <param name="formatProvider">IFormatProvider (e.g. CultureInfo)</param>
        ''' <returns>Localized Property</returns>
        ''' <history>
        '''     [Generator]    01/04/2007 Generated by a tool
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Shared Function GetProperty(ByVal objPortal As PortalSettings, ByVal strPropertyName As String, ByVal strFormat As String, ByVal formatProvider As IFormatProvider) As String
            If strFormat = String.Empty Then strFormat = "g"
            If Not objPortal Is Nothing Then
                Select Case strPropertyName.ToLower()
                    Case "portalid"
                        Return (objPortal.PortalId.ToString(strFormat, formatProvider))
                    Case "portalname"
                        Return (objPortal.PortalName)
                    Case "homedirectory"
                        Return (objPortal.HomeDirectory)
                    Case "homedirectorymappath"
                        Return (objPortal.HomeDirectoryMapPath)
                    Case "logofile"
                        Return (objPortal.LogoFile)
                    Case "footertext"
                        Return (objPortal.FooterText)
                    Case "expirydate"
                        Return (objPortal.ExpiryDate.ToString(strFormat, formatProvider))
                    Case "userregistration"
                        Return (objPortal.UserRegistration.ToString(strFormat, formatProvider))
                    Case "banneradvertising"
                        Return (objPortal.BannerAdvertising.ToString(strFormat, formatProvider))
                    Case "currency"
                        Return (objPortal.Currency)
                    Case "administratorid"
                        Return (objPortal.AdministratorId.ToString(strFormat, formatProvider))
                    Case "email"
                        Return (objPortal.Email)
                    Case "hostfee"
                        Return (objPortal.HostFee.ToString(strFormat, formatProvider))
                    Case "hostspace"
                        Return (objPortal.HostSpace.ToString(strFormat, formatProvider))
                    Case "administratorroleid"
                        Return (objPortal.AdministratorRoleId.ToString(strFormat, formatProvider))
                    Case "administratorrolename"
                        Return (objPortal.AdministratorRoleName)
                    Case "registeredroleid"
                        Return (objPortal.RegisteredRoleId.ToString(strFormat, formatProvider))
                    Case "registeredrolename"
                        Return (objPortal.RegisteredRoleName)
                    Case "description"
                        Return (objPortal.Description)
                    Case "keywords"
                        Return (objPortal.KeyWords)
                    Case "backgroundfile"
                        Return (objPortal.BackgroundFile)
                    Case "siteloghistory"
                        Return (objPortal.SiteLogHistory.ToString(strFormat, formatProvider))
                    Case "admintabid"
                        Return (objPortal.AdminTabId.ToString(strFormat, formatProvider))
                    Case "supertabid"
                        Return (objPortal.SuperTabId.ToString(strFormat, formatProvider))
                    Case "splashtabid"
                        Return (objPortal.SplashTabId.ToString(strFormat, formatProvider))
                    Case "hometabid"
                        Return (objPortal.HomeTabId.ToString(strFormat, formatProvider))
                    Case "logintabid"
                        Return (objPortal.LoginTabId.ToString(strFormat, formatProvider))
                    Case "usertabid"
                        Return (objPortal.UserTabId.ToString(strFormat, formatProvider))
                    Case "defaultlanguage"
                        Return (objPortal.DefaultLanguage)
                    Case "timezoneoffset"
                        Return (objPortal.TimeZoneOffset.ToString(strFormat, formatProvider))
                    Case "version"
                        Return (objPortal.Version)
                End Select
            End If
            Return "[Portal:" + strPropertyName + "]"
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        '''     Returns the localized property of the TabInfo object as string
        ''' </summary>
        ''' <param name="objTab"></param>
        ''' <param name="strPropertyName">Name of property</param>
        ''' <param name="strFormat">Format String</param>
        ''' <param name="formatProvider">IFormatProvider (e.g. CultureInfo)</param>
        ''' <returns>Localized Property</returns>
        ''' <history>
        '''     [Generator]    01/04/2007 Generated by a tool
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Shared Function GetProperty(ByVal objTab As TabInfo, ByVal strPropertyName As String, ByVal strFormat As String, ByVal formatProvider As IFormatProvider) As String
            If strFormat = String.Empty Then strFormat = "g"
            If Not objTab Is Nothing Then
                Select Case strPropertyName.ToLower()
                    Case "tabid"
                        Return (objTab.TabID.ToString(strFormat, formatProvider))
                    Case "taborder"
                        Return (objTab.TabOrder.ToString(strFormat, formatProvider))
                    Case "portalid"
                        Return (objTab.PortalID.ToString(strFormat, formatProvider))
                    Case "tabname"
                        Return (objTab.TabName)
                    Case "parentid"
                        Return (objTab.ParentId.ToString(strFormat, formatProvider))
                    Case "level"
                        Return (objTab.Level.ToString(strFormat, formatProvider))
                    Case "iconfile"
                        Return (objTab.IconFile)
                    Case "title"
                        Return (objTab.Title)
                    Case "description"
                        Return (objTab.Description)
                    Case "keywords"
                        Return (objTab.KeyWords)
                    Case "url"
                        Return (objTab.Url)
                    Case "skinsrc"
                        Return (objTab.SkinSrc)
                    Case "containersrc"
                        Return (objTab.ContainerSrc)
                    Case "tabpath"
                        Return (objTab.TabPath)
                    Case "startdate"
                        Return (objTab.StartDate.ToString(strFormat, formatProvider))
                    Case "enddate"
                        Return (objTab.EndDate.ToString(strFormat, formatProvider))
                    Case "skinpath"
                        Return (objTab.SkinPath)
                    Case "containerpath"
                        Return (objTab.ContainerPath)
                    Case "fullurl"
                        Return (objTab.FullUrl)
                    Case "refreshinterval"
                        Return (objTab.RefreshInterval.ToString(strFormat, formatProvider))
                    Case "pageheadtext"
                        Return (objTab.PageHeadText)
                    Case "authorizedroles"
                        Return (objTab.AuthorizedRoles)
                    Case "administratorroles"
                        Return (objTab.AdministratorRoles)
                End Select
            End If
            Return "[Tab:" + strPropertyName + "]"
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        '''     Returns the localized property of the ModuleInfo object as string
        ''' </summary>
        ''' <param name="objModule"></param>
        ''' <param name="strPropertyName">Name of property</param>
        ''' <param name="strFormat">Format String</param>
        ''' <param name="formatProvider">IFormatProvider (e.g. CultureInfo)</param>
        ''' <returns>Localized Property</returns>
        ''' <history>
        '''     [Generator]    01/04/2007 Generated by a tool
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Shared Function GetProperty(ByVal objModule As ModuleInfo, ByVal strPropertyName As String, ByVal strFormat As String, ByVal formatProvider As IFormatProvider) As String
            If strFormat = String.Empty Then strFormat = "g"
            If Not objModule Is Nothing Then
                Select Case strPropertyName.ToLower()
                    Case "portalid"
                        Return (objModule.PortalID.ToString(strFormat, formatProvider))
                    Case "tabid"
                        Return (objModule.TabID.ToString(strFormat, formatProvider))
                    Case "tabmoduleid"
                        Return (objModule.TabModuleID.ToString(strFormat, formatProvider))
                    Case "moduleid"
                        Return (objModule.ModuleID.ToString(strFormat, formatProvider))
                    Case "moduledefid"
                        Return (objModule.ModuleDefID.ToString(strFormat, formatProvider))
                    Case "moduleorder"
                        Return (objModule.ModuleOrder.ToString(strFormat, formatProvider))
                    Case "panename"
                        Return (objModule.PaneName)
                    Case "moduletitle"
                        Return (objModule.ModuleTitle)
                    Case "authorizededitroles"
                        Return (objModule.AuthorizedEditRoles)
                    Case "cachetime"
                        Return (objModule.CacheTime.ToString(strFormat, formatProvider))
                    Case "authorizedviewroles"
                        Return (objModule.AuthorizedViewRoles)
                    Case "alignment"
                        Return (objModule.Alignment)
                    Case "color"
                        Return (objModule.Color)
                    Case "border"
                        Return (objModule.Border)
                    Case "iconfile"
                        Return (objModule.IconFile)
                    Case "authorizedroles"
                        Return (objModule.AuthorizedRoles)
                    Case "header"
                        Return (objModule.Header)
                    Case "footer"
                        Return (objModule.Footer)
                    Case "startdate"
                        Return (objModule.StartDate.ToString(strFormat, formatProvider))
                    Case "enddate"
                        Return (objModule.EndDate.ToString(strFormat, formatProvider))
                    Case "containersrc"
                        Return (objModule.ContainerSrc)
                    Case "desktopmoduleid"
                        Return (objModule.DesktopModuleID.ToString(strFormat, formatProvider))
                    Case "friendlyname"
                        Return (objModule.FriendlyName)
                    Case "foldername"
                        Return (objModule.FolderName)
                    Case "description"
                        Return (objModule.Description)
                    Case "version"
                        Return (objModule.Version)
                    Case "businesscontrollerclass"
                        Return (objModule.BusinessControllerClass)
                    Case "modulename"
                        Return (objModule.ModuleName)
                    Case "supportedfeatures"
                        Return (objModule.SupportedFeatures.ToString(strFormat, formatProvider))
                    Case "defaultcachetime"
                        Return (objModule.DefaultCacheTime.ToString(strFormat, formatProvider))
                    Case "modulecontrolid"
                        Return (objModule.ModuleControlId.ToString(strFormat, formatProvider))
                    Case "controlsrc"
                        Return (objModule.ControlSrc)
                    Case "controltitle"
                        Return (objModule.ControlTitle)
                    Case "helpurl"
                        Return (objModule.HelpUrl)
                    Case "containerpath"
                        Return (objModule.ContainerPath)
                    Case "panemoduleindex"
                        Return (objModule.PaneModuleIndex.ToString(strFormat, formatProvider))
                    Case "panemodulecount"
                        Return (objModule.PaneModuleCount.ToString(strFormat, formatProvider))
                    Case "modulename"
                        Return objModule.ModuleName
                End Select
            End If
            Return "[Module:" + strPropertyName + "]"
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        '''     Returns the localized property of the UserInfo object as string
        ''' </summary>
        ''' <param name="objUser"></param>
        ''' <param name="strPropertyName">Name of property</param>
        ''' <param name="strFormat">Format String</param>
        ''' <param name="formatProvider">IFormatProvider (e.g. CultureInfo)</param>
        ''' <returns>Localized Property</returns>
        ''' <history>
        '''     [Generator]    01/04/2007 Generated by a tool
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Shared Function GetProperty(ByVal objUser As UserInfo, ByVal strPropertyName As String, ByVal strFormat As String, ByVal formatProvider As IFormatProvider) As String
            If strFormat = String.Empty Then strFormat = "g"
            If Not objUser Is Nothing Then
                Select Case strPropertyName.ToLower()
                    Case "affiliateid"
                        Return (objUser.AffiliateID.ToString(strFormat, formatProvider))
                    Case "displayname"
                        Return (objUser.DisplayName)
                    Case "email"
                        Return (objUser.Email)
                    Case "firstname"
                        Return (objUser.FirstName)
                    Case "lastname"
                        Return (objUser.LastName)
                    Case "portalid"
                        Return (objUser.PortalID.ToString(strFormat, formatProvider))
                    Case "userid"
                        Return (objUser.UserID.ToString(strFormat, formatProvider))
                    Case "username"
                        Return (objUser.Username)
                    Case "fullname"
                        Return (objUser.FullName)
                End Select
            End If
            Return "[User:" + strPropertyName + "]"
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        '''     Returns the localized property of the UserMembership object as string
        ''' </summary>
        ''' <param name="objMembership"></param>
        ''' <param name="strPropertyName">Name of property</param>
        ''' <param name="strFormat">Format String</param>
        ''' <param name="formatProvider">IFormatProvider (e.g. CultureInfo)</param>
        ''' <returns>Localized Property</returns>
        ''' <history>
        '''     [Generator]    01/04/2007 Generated by a tool
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Shared Function GetProperty(ByVal objMembership As UserMembership, ByVal strPropertyName As String, ByVal strFormat As String, ByVal formatProvider As IFormatProvider) As String
            If strFormat = String.Empty Then strFormat = "g"
            If Not objMembership Is Nothing Then
                Select Case strPropertyName.ToLower()
                    Case "createddate"
                        Return (objMembership.CreatedDate.ToString(strFormat, formatProvider))
                    Case "lastactivitydate"
                        Return (objMembership.LastActivityDate.ToString(strFormat, formatProvider))
                    Case "lastlockoutdate"
                        Return (objMembership.LastLockoutDate.ToString(strFormat, formatProvider))
                    Case "lastlogindate"
                        Return (objMembership.LastLoginDate.ToString(strFormat, formatProvider))
                    Case "lastpasswordchangedate"
                        Return (objMembership.LastPasswordChangeDate.ToString(strFormat, formatProvider))
                    Case "password"
                        Return (objMembership.Password)
                    Case "passwordanswer"
                        Return (objMembership.PasswordAnswer)
                    Case "passwordquestion"
                        Return (objMembership.PasswordQuestion)
                    Case "email"
                        Return (objMembership.Email)
                    Case "username"
                        Return (objMembership.Username)
                End Select
            End If
            Return "[Membership:" + strPropertyName + "]"
        End Function


        ''' -----------------------------------------------------------------------------
        ''' <summary>
        '''     Returns the localized property of the New UserProfile object as string
        ''' </summary>
        ''' <param name="objProfile"></param>
        ''' <param name="strPropertyName">Name of property</param>
        ''' <param name="strFormat">Format String</param>
        ''' <param name="formatProvider">IFormatProvider (e.g. CultureInfo)</param>
        ''' <returns>Localized Property</returns>
        ''' <history>
        '''     [sLeupold]    03/09/2007 converted to use new profile
        '''     [sleupold]    05/16/2007 visibility corrected
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Shared Function GetProperty(ByVal objProfile As DotNetNuke.Entities.Users.UserProfile, ByVal strPropertyName As String, ByVal strFormat As String, ByVal formatProvider As IFormatProvider, ByVal currentAccessLevel As TokenAccessLevel) As String
            If strFormat = String.Empty Then strFormat = "g"
            Dim prop As DotNetNuke.Entities.Profile.ProfilePropertyDefinition
            If Not objProfile Is Nothing Then
                For Each prop In objProfile.ProfileProperties
                    If prop.PropertyName.ToLower = strPropertyName.ToLower Then
                        If currentAccessLevel = TokenAccessLevel.FullSettings OrElse prop.Visibility = UserVisibilityMode.AllUsers OrElse (prop.Visibility = UserVisibilityMode.MembersOnly And currentAccessLevel <> TokenAccessLevel.NoSettings) Then
                            Return prop.PropertyValue
                        Else
                            Return String.Empty
                        End If
                        Exit For
                    End If
                Next prop
            End If
            Return "[Profile:" + strPropertyName + "]"
        End Function

#End Region

    End Class
End Namespace
