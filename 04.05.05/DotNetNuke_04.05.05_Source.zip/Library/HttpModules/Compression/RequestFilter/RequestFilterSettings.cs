using System;
using System.Collections.Generic;
using System.IO;
using System.Web.Caching;
using System.Xml.Serialization;
using System.Xml.XPath;
using DotNetNuke.Common;
using DotNetNuke.Common.Utilities;
using DotNetNuke.Entities.Host;
using System.Xml;
using System.Collections;

namespace DotNetNuke.HttpModules.Compression.RequestFilter
{
    [Serializable(), XmlRoot("RewriterConfig")]
    public class RequestFilterSettings
    {

#region Constants
        private const string c_RequestFilterConfig = "RequestFilter.Config";
        private const string c_DotNetNukeConfig = "DotNetNuke.config";
#endregion

#region Constructors

        public RequestFilterSettings()
        {
        }

#endregion

        private bool _Enabled;
        public bool Enabled
        {
            get
            {
                string EnableFilter = string.Empty;
                try
                {
                    EnableFilter = HostSettings.GetHostSetting("EnableRequestFilters");
                }
                catch
                { 
                    // We just want to trap the error so we know if we are installed or not 
                }

                return EnableFilter == "Y" ? true : false;
            }
        }

        private List<RequestFilterRule> _Rules = new List<RequestFilterRule>();
        public List<RequestFilterRule> Rules
        {
            get { return _Rules; }
            set { _Rules = value; }
        }

        /// <summary>
        /// Get the current settings from the xml config file
        /// </summary>
        public static RequestFilterSettings GetSettings()
        {
            RequestFilterSettings settings = (RequestFilterSettings)DataCache.GetCache(c_RequestFilterConfig);

            if (settings == null)
            {
                settings = new RequestFilterSettings();

                string filePath = String.Format("{0}\\{1}", Globals.ApplicationMapPath, c_DotNetNukeConfig);

                if (!File.Exists(filePath))
                {
                    //Copy from \Config
                    string defaultConfigFile = Globals.ApplicationMapPath + Globals.glbConfigFolder + c_DotNetNukeConfig;
                    if (File.Exists(defaultConfigFile))
                        File.Copy(defaultConfigFile, filePath, true);
                }

                //Create a FileStream for the Config file
                FileStream fileReader = new FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.Read);

                XPathDocument doc = new XPathDocument(fileReader);

                XPathNodeIterator ruleList = doc.CreateNavigator().Select("/configuration/blockrequests/rule");

                while (ruleList.MoveNext())
                {
                    try
                    {
                        string serverVar = ruleList.Current.GetAttribute("servervar", string.Empty);
                        string values = ruleList.Current.GetAttribute("values", string.Empty);
                        RequestFilterRuleType action = (RequestFilterRuleType)Enum.Parse(typeof(RequestFilterRuleType), ruleList.Current.GetAttribute("action", string.Empty));
                        RequestFilterOperatorType op = (RequestFilterOperatorType)Enum.Parse(typeof(RequestFilterOperatorType), ruleList.Current.GetAttribute("operator", string.Empty));
                        string location = ruleList.Current.GetAttribute("location", string.Empty);
                        RequestFilterRule rule = new RequestFilterRule(serverVar, values, op, action, location);
                        settings.Rules.Add(rule);
                    }
                    catch (Exception ex)
                    {
                        Exception rlException = new Exception(string.Format("Unable to read RequestFilter Rule: {0}:", ruleList.Current.OuterXml), ex);

                        DotNetNuke.Services.Exceptions.Exceptions.LogException(rlException);                        
                    }
                }
                
                if (File.Exists(filePath))
                {
                    //Create a dependancy on SiteUrls.config
                    CacheDependency dep = new CacheDependency(filePath);

                    //Set back into Cache
                    DataCache.SetCache(c_RequestFilterConfig, settings, dep);
                }
            }

            return settings;
        }

        public static void Save(List<RequestFilterRule> rules)
        {

            string filePath = String.Format("{0}\\{1}", Globals.ApplicationMapPath, c_DotNetNukeConfig);

            if (!File.Exists(filePath))
            {
                //Copy from \Config
                string defaultConfigFile = Globals.ApplicationMapPath + Globals.glbConfigFolder + c_DotNetNukeConfig;
                if (File.Exists(defaultConfigFile))
                    File.Copy(defaultConfigFile, filePath, true);
            }

            XmlDocument doc = new XmlDocument();
            doc.Load(filePath);

            XmlNode ruleRoot = doc.SelectSingleNode("/configuration/blockrequests");
            ruleRoot.RemoveAll();

            foreach (RequestFilterRule rule in rules)
            {
                XmlElement xmlRule = doc.CreateElement("rule");

                XmlAttribute var = doc.CreateAttribute("servervar");
                var.Value = rule.ServerVariable;
                xmlRule.Attributes.Append(var);

                XmlAttribute val = doc.CreateAttribute("values");
                val.Value = rule.RawValue;
                xmlRule.Attributes.Append(val);

                XmlAttribute op = doc.CreateAttribute("operator");
                op.Value = rule.Operator.ToString();
                xmlRule.Attributes.Append(op);

                XmlAttribute action = doc.CreateAttribute("action");
                action.Value = rule.Action.ToString();
                xmlRule.Attributes.Append(action);

                XmlAttribute location = doc.CreateAttribute("location");
                location.Value = rule.Location;
                xmlRule.Attributes.Append(location);

                ruleRoot.AppendChild(xmlRule);
            }

            XmlWriterSettings settings = new XmlWriterSettings();
            settings.Indent = true;

            using (XmlWriter writer = XmlWriter.Create(filePath, settings))
            {
                doc.WriteContentTo(writer);
            }
        }
    }
}
