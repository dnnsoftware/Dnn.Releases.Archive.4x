using System;
using System.Collections.Generic;
using System.Text;
using System.Web;

namespace DotNetNuke.HttpModules.Compression.RequestFilter
{
    public sealed class HttpModule : IHttpModule
    {

        const string INSTALLED_KEY = "httprequestfilter.attemptedinstall";



        #region IHttpModule Members

        public void Dispose() { }

        public void Init(HttpApplication context)
        {
            context.BeginRequest += new EventHandler(this.FilterRequest);
        }

        #endregion

        private void FilterRequest(object sender, EventArgs e)
        {
            HttpApplication app = (HttpApplication)sender;
            if ((app == null) || (app.Context == null) || (app.Context.Items == null))
                return;

            HttpRequest request = app.Context.Request;
            HttpResponse response = app.Context.Response;

            // only do this if we havn't already attempted an install.  This prevents PreSendRequestHeaders from
            // trying to add this item way to late.  We only want the first run through to do anything.
            // also, we use the context to store whether or not we've attempted an add, as it's thread-safe and
            // scoped to the request.  An instance of this module can service multiple requests at the same time,
            // so we cannot use a member variable.
            if (!app.Context.Items.Contains(INSTALLED_KEY))
            {

                // log the install attempt in the HttpContext
                // must do this first as several IF statements
                // below skip full processing of this method
                app.Context.Items.Add(INSTALLED_KEY, true);

                RequestFilterSettings settings = RequestFilterSettings.GetSettings();
                if (settings == null || settings.Rules.Count == 0 || !settings.Enabled )
                    return;

                foreach (RequestFilterRule rule in settings.Rules)
                {
                    string varVal = request.ServerVariables[rule.ServerVariable];
                    if (!string.IsNullOrEmpty(varVal))
                    {
                        if (rule.Matches(varVal))
                        {
                            rule.Execute();
                        }
                    }
                }
            }
        }
    }
}
