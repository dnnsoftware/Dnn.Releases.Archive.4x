'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2003
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'http://localhost/DNN_ADA/DesktopModules/Documents/Document.ascx.vb
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.IO

Namespace DotNetNuke

    Public MustInherit Class Document
        Inherits DotNetNuke.PortalModuleControl
Protected WithEvents pnlModuleContent As System.Web.UI.WebControls.Panel

        Protected WithEvents grdDocuments As System.Web.UI.WebControls.DataGrid

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            Dim documents As New DocumentDB()

            grdDocuments.DataSource = documents.GetDocuments(ModuleId, PortalId)
            grdDocuments.DataBind()

        End Sub


        Function FormatURL(ByVal Link As String, ByVal ID As Integer) As String

            Return IIf(Request.ApplicationPath = "/", Request.ApplicationPath, Request.ApplicationPath & "/") & "admin/Portal/LinkClick.aspx?tabid=" & TabId & "&table=Documents&field=ItemID&id=" & ID.ToString & "&link=" & Server.UrlEncode(Link)

        End Function


        Function FormatSize(ByVal Size As Object) As String

            If Not IsDBNull(Size) Then
                FormatSize = Format(Size / 1000, "#,##0.00")
            Else
                FormatSize = "Unknown"
            End If

        End Function

        Public Sub grdDocuments_ItemCreated(sender As Object, e As DataGridItemEventArgs) handles grdDocuments.ItemCreated 
            If e.Item.ItemType = ListItemType.Header then
                 e.Item.Cells(1).Attributes.Add("Scope","col")
                 e.Item.Cells(2).Attributes.Add("Scope","col")
                 e.Item.Cells(3).Attributes.Add("Scope","col")
                 e.Item.Cells(4).Attributes.Add("Scope","col")
                 e.Item.Cells(5).Attributes.Add("Scope","col")
            End If
        End Sub

        Public Sub grdDocuments_Edit(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles grdDocuments.EditCommand

            Dim ItemId As Integer = Integer.Parse(grdDocuments.DataKeys(e.Item.ItemIndex).ToString())

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            Dim objDocuments As New DocumentDB()
            Dim objAdmin As New AdminDB()

            Dim strLink As String = ""

            Dim dr As SqlDataReader = objDocuments.GetSingleDocument(ItemId, ModuleId)
            If dr.Read() Then
                strLink += IIf(Request.ApplicationPath = "/", Request.ApplicationPath, Request.ApplicationPath & "/") & "admin/Portal/LinkClick.aspx?tabid=" & TabId & "&table=Documents&field=ItemID&id=" & ItemId.ToString & "&link=" & Server.UrlEncode(dr("URL").ToString)
                If InStr(1, dr("URL").ToString, "://") = 0 Then
                    Dim drFile As SqlDataReader = objAdmin.GetSingleFile(dr("URL").ToString, PortalId)
                    If drFile.Read Then
                        strLink += "&contenttype=" & drFile("ContentType").ToString
                    End If
                    drFile.Close()
                End If
            End If
            dr.Close()

            If strLink <> "" Then
                Response.Redirect(strLink, True)
            End If
        End Sub

    End Class

End Namespace