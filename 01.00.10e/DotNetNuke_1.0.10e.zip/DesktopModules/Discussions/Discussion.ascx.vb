'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2003
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Namespace DotNetNuke

    Public MustInherit Class Discussion
        Inherits DotNetNuke.PortalModuleControl

        Protected WithEvents lstDiscussions As System.Web.UI.WebControls.DataList
        Protected WithEvents pnlModuleContent As System.Web.UI.WebControls.Panel

        Private itemIndex As Integer = -1

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load


            If Not (Request.Params("ItemIndex") Is Nothing) Then
                itemIndex = Int32.Parse(Request.Params("ItemIndex"))
            End If

            If Page.IsPostBack = False Then
                BindList()

                If itemIndex <> -1 Then
                    lstDiscussions.SelectedIndex = itemIndex
                    BindList()
                End If
            End If

        End Sub

        Sub BindList()

            ' Obtain a list of discussion messages for the module
            ' and bind to datalist
            Dim discuss As New DiscussionDB()

            lstDiscussions.DataSource = discuss.GetTopLevelMessages(ModuleId)
            lstDiscussions.DataBind()

        End Sub

        Function GetThreadMessages() As SqlDataReader

            ' Obtain a list of discussion messages for the module
            Dim discuss As New DiscussionDB()
            Dim dr As SqlDataReader = discuss.GetThreadMessages(lstDiscussions.DataKeys(lstDiscussions.SelectedIndex).ToString())

            ' Return the filtered DataView
            Return dr

            dr.Close()

        End Function

        Private Sub lstDiscussions_Select(ByVal Sender As Object, ByVal e As DataListCommandEventArgs) Handles lstDiscussions.ItemCommand

            ' Determine the command of the button (either "select" or "collapse")
            Dim command As String = CType(e.CommandSource, ImageButton).CommandName

            ' Update asp:datalist selection index depending upon the type of command
            ' and then rebind the asp:datalist with content
            If command = "collapse" Then
                lstDiscussions.SelectedIndex = -1
            Else
                lstDiscussions.SelectedIndex = e.Item.ItemIndex
            End If

            BindList()

        End Sub

        Function NodeImage(ByVal count As Integer) As String

            If count > 0 Then
                Return "~/images/plus.gif"
            Else
                Return "~/images/minus.gif"
            End If

        End Function

        Public Function FormatUser(ByVal UserName As Object) As String
            If Not IsDBNull(UserName) Then
                Return UserName.ToString
            Else
                Return "Anonymous"
            End If
        End Function

        Public Function FormatMultiLine(ByVal strValue As String) As String
            Return (New PortalSecurity()).InputFilter(strValue, PortalSecurity.FilterFlag.MultiLine)
        End Function

    End Class

End Namespace