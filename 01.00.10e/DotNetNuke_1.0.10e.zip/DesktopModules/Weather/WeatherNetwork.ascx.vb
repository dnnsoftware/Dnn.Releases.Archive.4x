'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2003
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Namespace DotNetNuke

    Public MustInherit Class WeatherNetwork
        Inherits DotNetNuke.PortalModuleControl

        Protected WithEvents lblScript As System.Web.UI.WebControls.Label

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            Dim strCity As String = CType(Settings("city"), String)
            Dim strRegion As String = CType(Settings("region"), String)
            Dim strCountry As String = CType(Settings("country"), String)

            If CType(Settings("personalize"), Boolean) = True And Request.IsAuthenticated = True Then
                ' Obtain PortalSettings from Current Context
                Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

                Dim objUser As New UsersDB()

                Dim dr As SqlDataReader = objUser.GetSingleUser(PortalId, Int32.Parse(Context.User.Identity.Name))
                If dr.Read Then
                    strCity = dr("City").ToString
                    strRegion = dr("Region").ToString
                    strCountry = dr("Country").ToString
                End If
                dr.Close()
            End If

            If strCity <> "" And strRegion <> "" And strCountry <> "" Then
                lblScript.Text = "<script language=javascript>var city = '" & LCase(Replace(strCity, " ", "_")) & "_" & strRegion & "';</script>"
                Select Case LCase(Replace(strCountry, ".", ""))
                    Case "canada", "can", "ca"
                        lblScript.Text += "<script language=javascript src='http://www.theweathernetwork.com/weatherbutton/test.js'></script>"
                    Case "united states", "usa", "us"
                        lblScript.Text += "<script language=javascript src='http://www.theweathernetwork.com/weatherbutton/usa.js'></script>"
                    Case Else ' does not work as TheWeatherNetwork uses custom codes for international cities
                        lblScript.Text += "<script language=javascript src='http://www.theweathernetwork.com/weatherbutton/intl.js'></script>"
                End Select
            End If

        End Sub

    End Class

End Namespace
