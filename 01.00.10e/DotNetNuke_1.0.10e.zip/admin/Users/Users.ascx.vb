'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2003
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Namespace DotNetNuke

    Public MustInherit Class Users

        Inherits DotNetNuke.PortalModuleControl

        Protected WithEvents grdUsers As System.Web.UI.WebControls.DataGrid
        Protected WithEvents cmdDelete As System.Web.UI.WebControls.LinkButton

        Dim strFilter As String

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        '*******************************************************
        '
        ' The Page_Load server event handler on this user control is used
        ' to populate the current roles settings from the configuration system
        '
        '*******************************************************

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            If Not Page.IsPostBack Then
                cmdDelete.Attributes.Add("onClick", "javascript:return confirm('Are You Sure You Wish To Delete These Items ?');")
            End If

            If Not Request.Params("filter") Is Nothing Then
                strFilter = Request.Params("filter")
            Else
                strFilter = " "
            End If

            BindData()

        End Sub

        '*******************************************************
        '
        ' The BindData helper method is used to bind the list of
        ' users for this portal to an asp:DropDownList server control
        '
        '*******************************************************

        Sub BindData()

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            ' Get the list of registered users from the database
            Dim objUser As New UsersDB()

            grdUsers.AllowPaging = True
            Dim ds As DataSet
            ds = ConvertDataReaderToDataSet(objUser.GetUsers(PortalId, strFilter))
            grdUsers.DataSource = ds
            grdUsers.PageSize = ds.Tables(0).Rows.Count + 1

            grdUsers.DataBind()

        End Sub

        Public Function FormatURL(ByVal strKeyName As String, ByVal strKeyValue As String)
            FormatURL = EditURL(strKeyName, strKeyValue) & IIf(strFilter <> "", "&filter=" & strFilter, "")
        End Function

        Public Function DisplayAddress(ByVal Unit As Object, ByVal Street As Object, ByVal City As Object, ByVal Region As Object, ByVal Country As Object, ByVal PostalCode As Object)
            DisplayAddress = FormatAddress(Unit, Street, City, Region, Country, PostalCode)
        End Function

        Public Function DisplayEmail(ByVal Email As Object)
            DisplayEmail = FormatEmail(Email)
        End Function

        Public Function DisplayLastLogin(ByVal LastLogin As Object)
            If Not IsDBNull(LastLogin) Then
                DisplayLastLogin = Format(LastLogin, "MM/dd/yyyy")
            Else
                DisplayLastLogin = ""
            End If
        End Function

        Private Sub grdUsers_ItemCreated(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles grdUsers.ItemCreated

            Dim intCounter As Integer
            Dim objLinkButton As LinkButton

            If e.Item.ItemType = ListItemType.Pager Then
                Dim objCell As TableCell = CType(e.Item.Controls(0), TableCell)
                objCell.Controls.Clear()

                For intCounter = Asc("A") To Asc("Z")
                    objLinkButton = New LinkButton()
                    objLinkButton.Text = Chr(intCounter)
                    objLinkButton.CssClass = "CommandButton"
                    objLinkButton.CommandName = "filter"
                    objLinkButton.CommandArgument = objLinkButton.Text
                    objCell.Controls.Add(objLinkButton)
                    objCell.Controls.Add(New LiteralControl("&nbsp;&nbsp;"))
                Next

                objLinkButton = New LinkButton()
                objLinkButton.Text = "(All)"
                objLinkButton.CssClass = "CommandButton"
                objLinkButton.CommandName = "filter"
                objLinkButton.CommandArgument = ""
                objCell.Controls.Add(objLinkButton)
                objCell.Controls.Add(New LiteralControl("&nbsp;&nbsp;"))

                objLinkButton = New LinkButton()
                objLinkButton.Text = "(Unauthorized)"
                objLinkButton.CssClass = "CommandButton"
                objLinkButton.CommandName = "filter"
                objLinkButton.CommandArgument = "-"
                objCell.Controls.Add(objLinkButton)
            End If

        End Sub

        Private Sub grdUsers_ItemCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles grdUsers.ItemCommand
            If e.CommandName = "filter" Then
                strFilter = e.CommandArgument
                BindData()
            End If
        End Sub

        Private Sub cmdDelete_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDelete.Click

            Dim objUser As New UsersDB()

            objUser.DeleteUsers(PortalId)

            BindData()

        End Sub

    End Class

End Namespace
