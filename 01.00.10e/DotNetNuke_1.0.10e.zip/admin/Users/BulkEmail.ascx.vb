'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2003
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Namespace DotNetNuke

    Public MustInherit Class BulkEmail
        Inherits DotNetNuke.PortalModuleControl

        Protected WithEvents cboRoles As System.Web.UI.WebControls.DropDownList
        Protected WithEvents txtEmail As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtSubject As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtMessage As System.Web.UI.WebControls.TextBox
        Protected WithEvents cboAttachment As System.Web.UI.WebControls.DropDownList
        Protected WithEvents cmdUpload As System.Web.UI.WebControls.HyperLink
        Protected WithEvents btnSend As System.Web.UI.WebControls.LinkButton

        Protected WithEvents pnlBasicTextBox As System.Web.UI.WebControls.Panel
        Protected WithEvents pnlRichTextBox As System.Web.UI.WebControls.Panel
        Protected WithEvents ftbDesktopText As FreeTextBoxControls.FreeTextBox
        Protected WithEvents optView As System.Web.UI.WebControls.RadioButtonList
#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            If Not Page.IsPostBack Then
                Dim objUser As New UsersDB()
                Dim dr As SqlDataReader = objUser.GetPortalRoles(PortalId)
                cboRoles.DataSource = dr
                cboRoles.DataBind()
                dr.Close()
                cboRoles.Items.Insert(0, New ListItem("<None Selected>", "-1"))

                cmdUpload.NavigateUrl = "~/EditModule.aspx?tabid=" & TabId & "&def=File Manager"
                Dim strDirectory As String
                Dim FileList As ArrayList
                FileList = GetFileList(PortalId, glbImageFileTypes)
                cboAttachment.DataSource = FileList
                cboAttachment.DataBind()
            Else
                If optView.SelectedItem.Value = "B" Then
                    pnlBasicTextBox.Visible = True
                    pnlRichTextBox.Visible = False
                Else
                    pnlBasicTextBox.Visible = False
                    pnlRichTextBox.Visible = True
                    ftbDesktopText.ImageGalleryPath = _portalSettings.UploadDirectory.Substring(_portalSettings.UploadDirectory.IndexOf("/Portals/"))
                    ftbDesktopText.HelperFilesPath = "controls/ftb/"
                    ftbDesktopText.HelperFilesParameters = "tabid=" & TabId
                    ftbDesktopText.ButtonPath = "controls/ftb/images/"
                End If
            End If
        End Sub

        Private Sub btnSend_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSend.Click
            Dim strBody As String

            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            ' send to role membership
            If cboRoles.SelectedIndex > 0 Then
                Dim objUser As New UsersDB()
                Dim dr As SqlDataReader = objUser.GetRoleMembership(PortalId, Integer.Parse(cboRoles.SelectedItem.Value))
                While dr.Read()

                    Dim sMimeType As String
                    If optView.SelectedItem.Value = "B" Then
                        sMimeType = "text"
                        strBody = "Dear " & dr("FullName") & "," & vbCrLf & vbCrLf
                        strBody = strBody & txtMessage.Text & vbCrLf & vbCrLf
                        strBody = strBody & "Thank you, we appreciate your support..." & vbCrLf & vbCrLf
                        strBody = strBody & _portalSettings.PortalName
                    Else
                        sMimeType = "html"
                        strBody = "Dear " & dr("FullName") & ",<p>"
                        strBody = strBody & ftbDesktopText.Text & "<p>"
                        strBody = strBody & "Thank you, we appreciate your support...<p>"
                        strBody = strBody & _portalSettings.PortalName
                    End If
                    SendNotification(_portalSettings.Email, dr("Email").ToString, "", txtSubject.Text, strBody, IIf(cboAttachment.SelectedItem.Value <> "", Request.MapPath(_portalSettings.UploadDirectory) & cboAttachment.SelectedItem.Value, ""), sMimeType)
                End While
                dr.Close()
            End If

            ' send to email distribution list
            If txtEmail.Text <> "" Then
                Dim arrEmail As Array = Split(txtEmail.Text, ";")
                Dim strEmail As String
                For Each strEmail In arrEmail

                    Dim sMimeType As String
                    If optView.SelectedItem.Value = "B" Then
                        sMimeType = "text"
                        strBody = "Dear " & strEmail & "," & vbCrLf & vbCrLf
                        strBody = strBody & txtMessage.Text & vbCrLf & vbCrLf
                        strBody = strBody & "Thank you, we appreciate your support..." & vbCrLf & vbCrLf
                        strBody = strBody & _portalSettings.PortalName
                    Else
                        sMimeType = "html"
                        strBody = "Dear " & strEmail & ",<p>"
                        strBody = strBody & ftbDesktopText.Text & "<p>"
                        strBody = strBody & "Thank you, we appreciate your support...<p>"
                        strBody = strBody & _portalSettings.PortalName
                    End If
                    SendNotification(_portalSettings.Email, strEmail, "", txtSubject.Text, strBody, IIf(cboAttachment.SelectedItem.Value <> "", Request.MapPath(_portalSettings.UploadDirectory) & cboAttachment.SelectedItem.Value, ""), sMimeType)
                Next
            End If

        End Sub

        Private Sub optView_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles optView.SelectedIndexChanged
            If optView.SelectedItem.Value = "B" Then
                txtMessage.Text = ftbDesktopText.Text
            Else
                ftbDesktopText.Text = txtMessage.Text
            End If
        End Sub
    End Class

End Namespace
