'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2003
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.Web.Security
Imports System.Data.SqlClient

Namespace DotNetNuke

    Public MustInherit Class Signin
        Inherits DotNetNuke.PortalModuleControl

        Protected WithEvents txtUsername As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtPassword As System.Web.UI.WebControls.TextBox
        Protected WithEvents rowVerification1 As System.Web.UI.HtmlControls.HtmlTableRow
        Protected WithEvents rowVerification2 As System.Web.UI.HtmlControls.HtmlTableRow
        Protected WithEvents txtVerification As System.Web.UI.WebControls.TextBox
        Protected WithEvents chkCookie As System.Web.UI.WebControls.CheckBox
        Protected WithEvents cmdLogin As System.Web.UI.WebControls.ImageButton
        Protected WithEvents cmdRegister As System.Web.UI.WebControls.ImageButton
        Protected WithEvents cmdSendPassword As System.Web.UI.WebControls.ImageButton
        Protected WithEvents lblMessage As System.Web.UI.WebControls.Label
        Protected WithEvents lblLogin As System.Web.UI.WebControls.Label

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            If _portalSettings.UserRegistration = 0 Then
                cmdRegister.Visible = False
            End If

            txtPassword.Attributes.Add("value", txtPassword.Text)

            If Page.IsPostBack = False Then
                Try
                    SetFormFocus(txtUsername)
                Catch
                    'control not there or error setting focus
                End Try
            End If

            Dim objAdmin As New AdminDB()

            Dim intModuleId As Integer = objAdmin.GetSiteModule("Site Settings", PortalId)
            Dim settings As Hashtable = _portalSettings.GetModuleSettings(intModuleId)
            lblLogin.Text = CType(settings("loginmessage"), String)
               
        End Sub

        Private Sub cmdLogin_Click(ByVal sender As Object, ByVal e As ImageClickEventArgs) Handles cmdLogin.Click

            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            Dim objUser As New UsersDB()
            Dim objSecurity As New PortalSecurity()

            Dim blnLogin As Boolean = True

            If _portalSettings.UserRegistration = 3 Then ' verified
                Dim dr As SqlDataReader = objUser.GetSingleUserByUsername(_portalSettings.PortalId, txtUsername.Text)
                If dr.Read() Then
                    If dr("LastLoginDate").ToString = "" And dr("IsSuperUser") = False Then
                        blnLogin = False
                        If rowVerification1.Visible Then
                            If txtVerification.Text <> "" Then
                                If txtVerification.Text = (_portalSettings.PortalId.ToString & "-" & dr("UserId").ToString) Then
                                    blnLogin = True
                                Else
                                    lblMessage.Text = "Invalid Verification Code"
                                End If
                            Else
                                lblMessage.Text = "Enter Your Verification Code"
                            End If
                        Else
                            rowVerification1.Visible = True
                            rowVerification2.Visible = True
                        End If
                    End If
                End If
                dr.Close()
            End If

            If blnLogin Then
                ' Attempt to Validate User Credentials
                Dim userId As Integer = objSecurity.UserLogin(txtUsername.Text, txtPassword.Text, _portalSettings.PortalId)

                If userId >= 0 Then
                    ' Use security system to set the UserID within a client-side Cookie
                    FormsAuthentication.SetAuthCookie(userId.ToString(), chkCookie.Checked)

                    ' Redirect browser back to home page
                    Response.Redirect(Request.RawUrl, True)
                Else
                    lblMessage.Text = "Login Failed"
                End If
            End If

        End Sub

        Private Sub cmdSendPassword_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles cmdSendPassword.Click

            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            If Trim(txtUsername.Text) <> "" Then
                Dim objUser As New UsersDB()
                Dim objSecurity As New PortalSecurity()

                Dim dr As SqlDataReader = objUser.GetSingleUserByUsername(_portalSettings.PortalId, txtUsername.Text)

                If dr.Read() Then
                    Dim strBody As String

                    strBody = "Dear " & dr("FullName") & "," & vbCrLf & vbCrLf
                    strBody = strBody & "You have requested a Password Reminder from our " & _portalSettings.PortalName & " website." & vbCrLf & vbCrLf
                    strBody = strBody & "Please login using the following information:" & vbCrLf & vbCrLf
                    strBody = strBody & "Portal Website Address: " & GetPortalDomainName(PortalAlias, Request) & vbCrLf
                    strBody = strBody & "Username:   " & dr("Username").ToString & vbCrLf
                    strBody = strBody & "Password: " & objSecurity.Decrypt(_portalSettings.HostSettings("EncryptionKey"), dr("Password").ToString) & vbCrLf
                    If _portalSettings.UserRegistration = 3 And dr("LastLoginDate").ToString = "" And dr("IsSuperUser") = False Then
                        strBody = strBody & "Verification Code: " & _portalSettings.PortalId.ToString & "-" & dr("UserId").ToString & vbCrLf
                    End If
                    If Not IsDBNull(dr("Authorized")) Then
                        If Not dr("Authorized") Then
                            strBody = strBody & "Status: Not Authorized" & vbCrLf
                        End If
                    End If
                    strBody = strBody & vbCrLf

                    strBody = strBody & vbCrLf & "Sincerely," & vbCrLf
                    strBody = strBody & "Portal Administrator" & vbCrLf & vbCrLf
                    strBody = strBody & "*Note: If you did not request a Password Reminder, please disregard this Message."

                    SendNotification(_portalSettings.Email, dr("Email").ToString, "", _portalSettings.PortalName & " Password Reminder", strBody)

                    lblMessage.Text = "Password Has Been Sent To<br>Your Email Address."
                Else
                    lblMessage.Text = "Username Does Not Exist"
                End If

                dr.Close()

            Else
                lblMessage.Text = "Please Enter Your Username"
            End If

        End Sub

        Private Sub cmdRegister_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles cmdRegister.Click
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)
            Response.Redirect("~/EditModule.aspx?tabid=" & _portalSettings.ActiveTab.TabId & "&def=Register", True)
        End Sub

    End Class

End Namespace
