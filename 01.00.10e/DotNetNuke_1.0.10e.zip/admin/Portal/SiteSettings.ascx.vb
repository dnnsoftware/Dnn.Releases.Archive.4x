'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2003
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.IO

Namespace DotNetNuke

    Public Class SiteSettings
        Inherits DotNetNuke.PortalModuleControl

        Protected WithEvents txtPortalName As System.Web.UI.WebControls.TextBox
        Protected WithEvents cboLogo As System.Web.UI.WebControls.DropDownList
        Protected WithEvents txtDescription As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtKeyWords As System.Web.UI.WebControls.TextBox
        Protected WithEvents cmdGoogle As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cboBackground As System.Web.UI.WebControls.DropDownList
        Protected WithEvents txtFooterText As System.Web.UI.WebControls.TextBox
        Protected WithEvents optUserRegistration As System.Web.UI.WebControls.RadioButtonList
        Protected WithEvents optBannerAdvertising As System.Web.UI.WebControls.RadioButtonList
        Protected WithEvents cboCurrency As System.Web.UI.WebControls.DropDownList
        Protected WithEvents cboAdministratorId As System.Web.UI.WebControls.DropDownList
        Protected WithEvents cboProcessor As System.Web.UI.WebControls.DropDownList
        Protected WithEvents cmdProcessor As System.Web.UI.WebControls.LinkButton
        Protected WithEvents txtUserId As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtPassword As System.Web.UI.WebControls.TextBox

        Protected WithEvents SiteRow1 As System.Web.UI.HtmlControls.HtmlTableRow
        Protected WithEvents txtPortalAlias As System.Web.UI.WebControls.TextBox
        Protected WithEvents SiteRow2 As System.Web.UI.HtmlControls.HtmlTableRow
        Protected WithEvents txtExpiryDate As System.Web.UI.WebControls.TextBox
        Protected WithEvents SiteRow3 As System.Web.UI.HtmlControls.HtmlTableRow
        Protected WithEvents txtHostSpace As System.Web.UI.WebControls.TextBox
        Protected WithEvents SiteRow4 As System.Web.UI.HtmlControls.HtmlTableRow
        Protected WithEvents txtHostFee As System.Web.UI.WebControls.TextBox
        Protected WithEvents SiteRow5 As System.Web.UI.HtmlControls.HtmlTableRow
        Protected WithEvents txtSiteLogHistory As System.Web.UI.WebControls.TextBox
        Protected WithEvents SiteRow6 As System.Web.UI.HtmlControls.HtmlTableRow

        Protected WithEvents txtLogin As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtRegistration As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtSignup As System.Web.UI.WebControls.TextBox

        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdDelete As System.Web.UI.WebControls.LinkButton

        Protected WithEvents chkStyleSheet As System.Web.UI.WebControls.CheckBox
        Protected WithEvents StyleRow1 As System.Web.UI.HtmlControls.HtmlTableRow
        Protected WithEvents txtStyleSheet As System.Web.UI.WebControls.TextBox
        Protected WithEvents StyleRow2 As System.Web.UI.HtmlControls.HtmlTableRow
        Protected WithEvents cmdSave As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdRestore As System.Web.UI.WebControls.LinkButton

        Protected WithEvents PortalRow1 As System.Web.UI.HtmlControls.HtmlTableRow
        Protected WithEvents PortalRow2 As System.Web.UI.HtmlControls.HtmlTableRow
        Protected WithEvents grdModuleDefinitions As System.Web.UI.WebControls.DataGrid
        Protected WithEvents PortalRow3 As System.Web.UI.HtmlControls.HtmlTableRow
        Protected WithEvents lblHostFee As System.Web.UI.WebControls.Label
        Protected WithEvents lblHostCurrency As System.Web.UI.WebControls.Label
        Protected WithEvents lblModuleFee As System.Web.UI.WebControls.Label
        Protected WithEvents lblModuleCurrency As System.Web.UI.WebControls.Label
        Protected WithEvents lblTotalFee As System.Web.UI.WebControls.Label
        Protected WithEvents lblTotalCurrency As System.Web.UI.WebControls.Label
        Protected WithEvents PortalRow4 As System.Web.UI.HtmlControls.HtmlTableRow
        Protected WithEvents PortalRow5 As System.Web.UI.HtmlControls.HtmlTableRow
        Protected WithEvents lblExpiryDate As System.Web.UI.WebControls.Label
        Protected WithEvents PortalRow6 As System.Web.UI.HtmlControls.HtmlTableRow
        Protected WithEvents PortalRow7 As System.Web.UI.HtmlControls.HtmlTableRow
        Protected WithEvents cmdRenew As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdExpiryCalendar As System.Web.UI.WebControls.HyperLink
        Protected WithEvents valExpiryDate As System.Web.UI.WebControls.CompareValidator

        Dim intPortalId As Integer = -1

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        '*******************************************************
        '
        ' The Page_Load server event handler on this user control is used
        ' to populate the current site settings from the config system
        '
        '*******************************************************

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            If Not (Request.QueryString("PortalID") Is Nothing) And _portalSettings.ActiveTab.ParentId = _portalSettings.SuperTabId Then
                intPortalId = Int32.Parse(Request.QueryString("PortalID"))
            Else
                intPortalId = PortalId
            End If

            ' If this is the first visit to the page, populate the site data
            If Page.IsPostBack = False Then

                cmdDelete.Attributes.Add("onClick", "javascript:return confirm('Are You Sure You Wish To Delete This Portal ?');")
                cmdExpiryCalendar.NavigateUrl = AdminDB.InvokePopupCal(txtExpiryDate)

                ' load the list of files found in the upload directory
                Dim ImageFileList As ArrayList = GetFileList(intPortalId, glbImageFileTypes)
                cboLogo.DataSource = ImageFileList
                cboLogo.DataBind()
                cboBackground.DataSource = ImageFileList
                cboBackground.DataBind()

                Dim objAdmin As New AdminDB()
                Dim objUser As New UsersDB()

                cboProcessor.DataSource = objAdmin.GetProcessorCodes
                cboProcessor.DataBind()

                Dim dr As SqlDataReader = objAdmin.GetSinglePortal(intPortalId)
                If dr.Read Then
                    txtPortalName.Text = dr("PortalName").ToString
                    If cboLogo.Items.Contains(New ListItem(dr("LogoFile").ToString)) Then
                        cboLogo.Items.FindByText(dr("LogoFile").ToString).Selected = True
                    End If
                    txtDescription.Text = dr("Description").ToString
                    txtKeyWords.Text = dr("KeyWords").ToString
                    If cboBackground.Items.Contains(New ListItem(dr("BackgroundFile").ToString)) Then
                        cboBackground.Items.FindByText(dr("BackgroundFile").ToString).Selected = True
                    End If
                    txtFooterText.Text = dr("FooterText").ToString
                    optUserRegistration.SelectedIndex = dr("UserRegistration")
                    optBannerAdvertising.SelectedIndex = dr("BannerAdvertising")

                    cboCurrency.DataSource = objAdmin.GetCurrencies()
                    cboCurrency.DataBind()
                    If dr("Currency").ToString = "" Then
                        cboCurrency.Items.FindByValue("USD").Selected = True
                    Else
                        cboCurrency.Items.FindByValue(dr("Currency").ToString).Selected = True
                    End If

                    Dim drUsers As SqlDataReader = objUser.GetRoleMembership(intPortalId, dr("AdministratorRoleId"))
                    While drUsers.Read()
                        cboAdministratorId.Items.Add(New ListItem(drUsers("FullName"), drUsers("UserId").ToString))
                    End While
                    drUsers.Close()
                    If Not cboAdministratorId.Items.FindByValue(dr("AdministratorId")) Is Nothing Then
                        cboAdministratorId.Items.FindByValue(dr("AdministratorId")).Selected = True
                    End If

                    txtPortalAlias.Text = dr("PortalAlias").ToString
                    txtExpiryDate.Text = GetMediumDate(dr("ExpiryDate").ToString)
                    lblExpiryDate.Text = txtExpiryDate.Text
                    txtHostFee.Text = dr("HostFee").ToString
                    If txtHostFee.Text <> "" Then
                        lblHostFee.Text = Format(Val(txtHostFee.Text), "#,##0.00")
                    Else
                        lblHostFee.Text = "0.00"
                    End If
                    lblHostCurrency.Text = _portalSettings.HostSettings("HostCurrency") & " / Month"
                    txtHostSpace.Text = dr("HostSpace").ToString
                    If Not IsDBNull(dr("SiteLogHistory")) Then
                        txtSiteLogHistory.Text = dr("SiteLogHistory").ToString
                    End If

                    If Not cboProcessor.Items.FindByText(dr("PaymentProcessor").ToString) Is Nothing Then
                        cboProcessor.Items.FindByText(dr("PaymentProcessor").ToString).Selected = True
                    Else ' default
                        cboProcessor.Items.FindByText("PayPal").Selected = True
                    End If
                    txtUserId.Text = dr("ProcessorUserId").ToString
                    txtPassword.Text = dr("ProcessorPassword").ToString
                End If
                dr.Close()

                Dim intModuleId As Integer = objAdmin.GetSiteModule("Site Settings", intPortalId)
                Dim settings As Hashtable = _portalSettings.GetModuleSettings(intModuleId)
                txtLogin.Text = CType(settings("loginmessage"), String)
                txtRegistration.Text = CType(settings("registrationmessage"), String)
                txtSignup.Text = CType(settings("signupmessage"), String)

                BindData()

                If Context.User.Identity.Name = _portalSettings.SuperUserId Then
                    SiteRow1.Visible = True
                    SiteRow2.Visible = True
                    SiteRow3.Visible = True
                    SiteRow4.Visible = True
                    SiteRow5.Visible = True
                    SiteRow6.Visible = True

                    cmdCancel.Visible = True
                    cmdDelete.Visible = True
                    cmdRenew.Visible = False
                End If

                If Not Request.UrlReferrer Is Nothing Then
                    ViewState("UrlReferrer") = Request.UrlReferrer.ToString()
                Else
                    ViewState("UrlReferrer") = ""
                End If
            End If

        End Sub

        Private Sub BindData()

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            Dim objAdmin As New AdminDB()

            grdModuleDefinitions.DataSource = objAdmin.GetPortalModuleDefinitions(intPortalId)
            grdModuleDefinitions.DataBind()

            If grdModuleDefinitions.Items.Count = 0 Then
                grdModuleDefinitions.Visible = False
            End If

            lblModuleFee.Text = "0.00"
            lblModuleCurrency.Text = _portalSettings.HostSettings("HostCurrency") & " / Month"

            lblModuleFee.Text = Format(objAdmin.GetPortalModuleDefinitionFee(intPortalId), "#,##0.00")

            lblTotalFee.Text = Format(Val(lblHostFee.Text) + Val(lblModuleFee.Text), "#,##0.00")
            lblTotalCurrency.Text = _portalSettings.HostSettings("HostCurrency") & " / Month"

        End Sub

        Private Sub Update_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click

            Dim strServerPath As String
            Dim strPortalName As String
            Dim strLogo As String
            Dim strBackground As String

            If Not cboLogo.SelectedItem Is Nothing Then
                strLogo = cboLogo.SelectedItem.Value
            End If
            If Not cboBackground.SelectedItem Is Nothing Then
                strBackground = cboBackground.SelectedItem.Value
            End If

            Dim dblHostFee As Double = 0
            If txtHostFee.Text <> "" Then
                dblHostFee = Double.Parse(txtHostFee.Text)
            End If

            Dim dblHostSpace As Double = 0
            If txtHostSpace.Text <> "" Then
                dblHostSpace = Double.Parse(txtHostSpace.Text)
            End If

            Dim intSiteLogHistory = -1
            If txtSiteLogHistory.Text <> "" Then
                intSiteLogHistory = Integer.Parse(txtSiteLogHistory.Text)
            End If

            ' update Portal info in the database
            Dim admin As New AdminDB()

            admin.UpdatePortalInfo(intPortalId, txtPortalName.Text, txtPortalAlias.Text, strLogo, txtFooterText.Text, optUserRegistration.SelectedIndex, optBannerAdvertising.SelectedIndex, cboCurrency.SelectedItem.Value, cboAdministratorId.SelectedItem.Value, GetMediumDate(txtExpiryDate.Text), dblHostFee, dblHostSpace, cboProcessor.SelectedItem.Text, txtUserId.Text, txtPassword.Text, txtDescription.Text, txtKeyWords.Text, strBackground, intSiteLogHistory)

            Dim intModuleId As Integer = admin.GetSiteModule("Site Settings", intPortalId)
            admin.UpdateModuleSetting(intModuleId, "loginmessage", txtLogin.Text)
            admin.UpdateModuleSetting(intModuleId, "registrationmessage", txtRegistration.Text)
            admin.UpdateModuleSetting(intModuleId, "signupmessage", txtSignup.Text)

            ' Redirect to this site to refresh
            Response.Redirect(Request.RawUrl, True)

        End Sub

        Private Sub Delete_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdDelete.Click

            Dim FileName As String
            Dim strServerPath As String
            Dim strPortalName As String

            strServerPath = GetAbsoluteServerPath(Request)

            Dim objAdmin As New AdminDB()

            Dim dr As SqlDataReader = objAdmin.GetSinglePortal(intPortalId)
            If dr.Read Then
                ' delete upload directory
                If System.IO.Directory.Exists(strServerPath & "Portals\" & dr("GUID").ToString) Then
                    Dim fileEntries As String() = System.IO.Directory.GetFiles(strServerPath & "Portals\" & dr("GUID").ToString)
                    For Each FileName In fileEntries
                        System.IO.File.Delete(FileName)
                    Next FileName
                    System.IO.Directory.Delete(strServerPath & "Portals\" & dr("GUID").ToString)
                End If

                ' delete child directory
                strPortalName = GetPortalDomainName(dr("PortalAlias").ToString)
                If InStr(1, dr("PortalAlias").ToString, "/") Then
                    strPortalName = Mid(dr("PortalAlias").ToString, InStrRev(dr("PortalAlias").ToString, "/") + 1)
                End If
                If System.IO.Directory.Exists(strServerPath & strPortalName) Then
                    Dim fileEntries As String() = System.IO.Directory.GetFiles(strServerPath & strPortalName)
                    For Each FileName In fileEntries
                        System.IO.File.Delete(FileName)
                    Next FileName
                    System.IO.Directory.Delete(strServerPath & strPortalName)
                End If

                ' remove database references
                objAdmin.DeletePortalInfo(intPortalId)
            End If
            dr.Close()

            ' Redirect to another site
            If intPortalId = PortalId Then
                Response.Redirect("~/default.aspx", True)
            Else
                Response.Redirect(CType(Viewstate("UrlReferrer"), String), True)
            End If

        End Sub

        Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
            Response.Redirect(CType(Viewstate("UrlReferrer"), String), True)
        End Sub

        Private Sub cmdRenew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdRenew.Click

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            Dim strProcessorURL As String = ""

            Dim objAdmin As New AdminDB()

            Dim strAdministratorRoleId As String
            Dim dr As SqlDataReader = objAdmin.GetSinglePortal(intPortalId)
            If dr.Read Then
                strAdministratorRoleId = dr("AdministratorRoleId").ToString
            End If
            dr.Close()

            If _portalSettings.HostSettings("PaymentProcessor") = "PayPal" Then
                strProcessorURL = "https://www.paypal.com/xclick/business=" & HTTPPOSTEncode(_portalSettings.HostSettings("ProcessorUserId"))
                strProcessorURL = strProcessorURL & "&item_name=" & HTTPPOSTEncode(txtPortalName.Text & " - Portal Subscription Renewal ( Basic Hosting Fee: " & lblHostFee.Text & " + Premium Modules: " & lblModuleFee.Text & " = Total Hosting Fee: " & lblTotalFee.Text & " )")
                strProcessorURL = strProcessorURL & "&item_number=" & HTTPPOSTEncode(strAdministratorRoleId)
                strProcessorURL = strProcessorURL & "&quantity=1" ' month by month only due to premium modules
                strProcessorURL = strProcessorURL & "&custom=" & HTTPPOSTEncode(Context.User.Identity.Name)
                strProcessorURL = strProcessorURL & "&amount=" & HTTPPOSTEncode(lblTotalFee.Text)
                strProcessorURL = strProcessorURL & "&currency_code=" & HTTPPOSTEncode(_portalSettings.HostSettings("HostCurrency"))
                strProcessorURL = strProcessorURL & "&return=" & HTTPPOSTEncode("http://" & GetDomainName(Request))
                strProcessorURL = strProcessorURL & "&cancel_return=" & HTTPPOSTEncode("http://" & GetDomainName(Request))
                strProcessorURL = strProcessorURL & "&notify_url=" & HTTPPOSTEncode("http://" & GetDomainName(Request) & "/admin/Sales/PayPalIPN.aspx")
                strProcessorURL = strProcessorURL & "&undefined_quantity=&no_note=1&no_shipping=1"
            End If

            ' redirect to payment processor
            If strProcessorURL <> "" Then
                Response.Redirect(strProcessorURL, True)
            End If

        End Sub

        Private Sub chkStyleSheet_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkStyleSheet.CheckedChanged
            If chkStyleSheet.Checked Then
                StyleRow1.Visible = True
                StyleRow2.Visible = True
                LoadStyleSheet()
            Else
                StyleRow1.Visible = False
                StyleRow2.Visible = False
            End If
        End Sub

        Private Sub LoadStyleSheet()

            Dim strUploadDirectory As String

            Dim objAdmin As New AdminDB()
            Dim dr As SqlDataReader = objAdmin.GetSinglePortal(intPortalId)
            If dr.Read Then
                strUploadDirectory = IIf(Request.ApplicationPath = "/", "", Request.ApplicationPath) & "/Portals/" & dr("GUID").ToString & "/"
            End If
            dr.Close()

            ' read CSS file
            Dim objStreamReader As StreamReader
            objStreamReader = File.OpenText(Server.MapPath(strUploadDirectory & "portal.css"))
            txtStyleSheet.Text = objStreamReader.ReadToEnd
            objStreamReader.Close()

        End Sub


        Private Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click

            Dim strUploadDirectory As String

            Dim objAdmin As New AdminDB()
            Dim dr As SqlDataReader = objAdmin.GetSinglePortal(intPortalId)
            If dr.Read Then
                strUploadDirectory = IIf(Request.ApplicationPath = "/", "", Request.ApplicationPath) & "/Portals/" & dr("GUID").ToString & "/"
            End If
            dr.Close()

            ' write CSS file
            Dim objStream As StreamWriter
            objStream = File.CreateText(Server.MapPath(strUploadDirectory & "portal.css"))
            objStream.WriteLine(txtStyleSheet.Text)
            objStream.Close()

        End Sub

        Private Sub cmdRestore_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRestore.Click

            Dim strServerPath As String = GetAbsoluteServerPath(Request)

            Dim objAdmin As New AdminDB()
            Dim dr As SqlDataReader = objAdmin.GetSinglePortal(intPortalId)
            If dr.Read Then
                If System.IO.File.Exists(strServerPath & "Portals\" & dr("GUID").ToString & "\portal.css") Then
                    ' delete existing style sheet
                    System.IO.File.Delete(strServerPath & "Portals\" & dr("GUID").ToString & "\portal.css")
                End If
                ' copy the default style sheet to the upload directory
                System.IO.File.Copy(strServerPath & "portal.css", strServerPath & "Portals\" & dr("GUID").ToString & "\portal.css")
            End If
            dr.Close()

            LoadStyleSheet()

        End Sub

        Private Sub cmdGoogle_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdGoogle.Click

            Dim strURL As String = ""
            Dim strComments As String = ""

            Dim objAdmin As New AdminDB()
            Dim dr As SqlDataReader = objAdmin.GetSinglePortal(intPortalId)
            If dr.Read Then
                strComments += dr("PortalName").ToString
                If dr("Description").ToString <> "" Then
                    strComments += " " & dr("Description").ToString
                End If
                If dr("KeyWords").ToString <> "" Then
                    strComments += " " & dr("KeyWords").ToString
                End If
            End If
            dr.Close()

            strURL += "http://www.google.com/addurl?q=" & HTTPPOSTEncode(AddHTTP(GetDomainName(Request)))
            strURL += "&dq=" & HTTPPOSTEncode(strComments)
            strURL += "&submit=Add+URL"

            Response.Redirect(strURL, True)

        End Sub

        Public Sub grdModuleDefinitions_CancelEdit(ByVal sender As Object, ByVal e As DataGridCommandEventArgs)
            grdModuleDefinitions.EditItemIndex = -1
            BindData()
        End Sub

        Public Sub grdModuleDefinitions_Edit(ByVal sender As Object, ByVal e As DataGridCommandEventArgs)
            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            If Context.User.Identity.Name = _portalSettings.SuperUserId Then
                grdModuleDefinitions.EditItemIndex = e.Item.ItemIndex
                grdModuleDefinitions.SelectedIndex = -1
            End If

            BindData()
        End Sub

        Public Sub grdModuleDefinitions_Update(ByVal sender As Object, ByVal e As DataGridCommandEventArgs)
            Dim chkSubscribed As CheckBox = CType(e.Item.FindControl("Checkbox2"), WebControls.CheckBox)
            Dim txtHostingFee As TextBox = CType(e.Item.FindControl("txtHostingFee"), WebControls.TextBox)

            Dim dblHostFee As Double = 0
            If txtHostingFee.Text <> "" Then
                dblHostFee = Double.Parse(txtHostingFee.Text)
            End If

            Dim objAdmin As New AdminDB()

            objAdmin.UpdatePortalModuleDefinition(intPortalId, Integer.Parse(grdModuleDefinitions.DataKeys(e.Item.ItemIndex).ToString()), chkSubscribed.Checked, dblHostFee)

            grdModuleDefinitions.EditItemIndex = -1
            BindData()
        End Sub

        Private Sub grdModuleDefinitions_ItemCreated(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles grdModuleDefinitions.ItemCreated
            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            Dim cmdEditModuleDefinitions As Control = e.Item.FindControl("cmdEditModuleDefinitions")

            If Not cmdEditModuleDefinitions Is Nothing Then
                If Context.User.Identity.Name <> _portalSettings.SuperUserId Then
                    CType(cmdEditModuleDefinitions, ImageButton).Attributes.Add("onClick", "javascript: return confirm('If You Wish To Add Premium Modules To Your Portal, Please Consult Your Hosting Provider')")
                End If
            End If

            Dim itemType As ListItemType
            itemType = CType(e.Item.ItemType, ListItemType)
            If (itemType = ListItemType.EditItem) Then
                Dim chkCheckbox2 As WebControls.CheckBox
                Dim txtHostingFee As WebControls.TextBox
                Dim lblCheckBox2, lblHostingFee As WebControls.Label
                chkCheckbox2 = CType(e.Item.FindControl("Checkbox2"), WebControls.CheckBox)
                lblCheckBox2 = CType(e.Item.FindControl("lblCheckBox2"), WebControls.Label)
                lblCheckBox2.Text = "<label class=""SubHead"" style=""display:none;"" for=""" & chkCheckbox2.ClientID.ToString & """>Subscribed</label>"
                txtHostingFee = CType(e.Item.FindControl("txtHostingFee"), WebControls.TextBox)
                lblHostingFee = CType(e.Item.FindControl("lblHostingFee"), WebControls.Label)
                lblHostingFee.Text = "<label class=""SubHead"" style=""display:none;"" for=""" & txtHostingFee.ClientID.ToString & """>Hosting Fee</label>"
            End If
        End Sub

        Public Function IsSuperUser() As String
            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            If Context.User.Identity.Name = _portalSettings.SuperUserId Then
                Return "True"
            Else
                Return "False"
            End If
        End Function

        Public Function FormatFee(ByVal objHostFee As Object) As String
            If Not IsDBNull(objHostFee) Then
                Return Format(objHostFee, "#,##0.00")
            Else
                Return 0
            End If
        End Function

        Public Function FormatCurrency() As String
            Return lblHostCurrency.Text
        End Function

        Private Sub cmdProcessor_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdProcessor.Click
            Response.Redirect(AddHTTP(cboProcessor.SelectedItem.Value), True)
        End Sub

    End Class

End Namespace

