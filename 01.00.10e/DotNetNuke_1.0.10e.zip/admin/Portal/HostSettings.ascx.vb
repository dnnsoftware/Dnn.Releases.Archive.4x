'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2003
' by Shaun Walker ( shaunw1@shaw.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.IO
Imports System.Runtime.Serialization.Formatters

Namespace DotNetNuke

    Public Class HostSettings
        Inherits DotNetNuke.PortalModuleControl

        Protected WithEvents txtHostTitle As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtHostURL As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtHostEmail As System.Web.UI.WebControls.TextBox
        Protected WithEvents cboProcessor As System.Web.UI.WebControls.DropDownList
        Protected WithEvents cmdProcessor As System.Web.UI.WebControls.LinkButton
        Protected WithEvents txtUserId As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtPassword As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtHostFee As System.Web.UI.WebControls.TextBox
        Protected WithEvents cboHostCurrency As System.Web.UI.WebControls.DropDownList
        Protected WithEvents txtHostSpace As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtSiteLogHistory As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtDemoPeriod As System.Web.UI.WebControls.TextBox
        Protected WithEvents chkDemoSignup As System.Web.UI.WebControls.CheckBox
        Protected WithEvents chkPageTitleVersion As System.Web.UI.WebControls.CheckBox
        Protected WithEvents chkEnableErrorReport As System.Web.UI.WebControls.CheckBox
        Protected WithEvents txtEncryptionKey As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtProxyServer As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtProxyPort As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtSMTPServer As System.Web.UI.WebControls.TextBox
        Protected WithEvents cmdEmail As System.Web.UI.WebControls.LinkButton
        Protected WithEvents lblEmail As System.Web.UI.WebControls.Label
        Protected WithEvents txtFileExtensions As System.Web.UI.WebControls.TextBox

        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton

        Protected WithEvents cboUpgrade As System.Web.UI.WebControls.DropDownList
        Protected WithEvents cmdUpgrade As System.Web.UI.WebControls.LinkButton
        Protected WithEvents lblUpgrade As System.Web.UI.WebControls.Label

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        '*******************************************************
        '
        ' The Page_Load server event handler on this user control is used
        ' to populate the current site settings from the config system
        '
        '*******************************************************

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            ' Verify that the current user has access to access this page
            If Context.User.Identity.Name <> _portalSettings.SuperUserId Then
                Response.Redirect("~/EditModule.aspx?tabid=" & TabId & "&def=Edit Access Denied", True)
            End If

            ' If this is the first visit to the page, populate the site data
            If Page.IsPostBack = False Then
                BindData()
            End If

        End Sub

        Private Sub BindData()
            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            Dim objAdmin As New AdminDB()

            txtHostTitle.Text = _portalSettings.HostSettings("HostTitle").ToString
            txtHostURL.Text = _portalSettings.HostSettings("HostURL").ToString
            txtHostEmail.Text = _portalSettings.HostSettings("HostEmail").ToString

            cboProcessor.DataSource = objAdmin.GetProcessorCodes
            cboProcessor.DataBind()

            If Not cboProcessor.Items.FindByText(_portalSettings.HostSettings("PaymentProcessor").ToString) Is Nothing Then
                cboProcessor.Items.FindByText(_portalSettings.HostSettings("PaymentProcessor").ToString).Selected = True
            End If
            txtUserId.Text = _portalSettings.HostSettings("ProcessorUserId").ToString
            txtPassword.Text = _portalSettings.HostSettings("ProcessorPassword").ToString

            txtHostFee.Text = _portalSettings.HostSettings("HostFee").ToString
            cboHostCurrency.DataSource = objAdmin.GetCurrencies()
            cboHostCurrency.DataBind()
            If Not cboHostCurrency.Items.FindByValue(_portalSettings.HostSettings("HostCurrency")) Is Nothing Then
                cboHostCurrency.Items.FindByValue(_portalSettings.HostSettings("HostCurrency").ToString).Selected = True
            Else
                cboHostCurrency.Items.FindByValue("USD").Selected = True
            End If
            txtHostSpace.Text = _portalSettings.HostSettings("HostSpace").ToString
            txtSiteLogHistory.Text = _portalSettings.HostSettings("SiteLogHistory").ToString
            txtDemoPeriod.Text = _portalSettings.HostSettings("DemoPeriod").ToString
            If _portalSettings.HostSettings("DemoSignup").ToString = "Y" Then
                chkDemoSignup.Checked = True
            Else
                chkDemoSignup.Checked = False
            End If
            If _portalSettings.HostSettings.ContainsKey("DisablePageTitleVersion") Then
                If _portalSettings.HostSettings("DisablePageTitleVersion").ToString = "Y" Then
                    chkPageTitleVersion.Checked = True
                Else
                    chkPageTitleVersion.Checked = False
                End If
            Else
                chkPageTitleVersion.Enabled = False
            End If

            If _portalSettings.HostSettings.ContainsKey("EnableErrorReporting") Then
                If _portalSettings.HostSettings("EnableErrorReporting").ToString = "Y" Then
                    chkEnableErrorReport.Checked = True
                Else
                    chkEnableErrorReport.Checked = False
                End If
            Else
                chkEnableErrorReport.Checked = False
            End If

            txtEncryptionKey.Text = _portalSettings.HostSettings("EncryptionKey").ToString
            txtProxyServer.Text = _portalSettings.HostSettings("ProxyServer").ToString
            txtProxyPort.Text = _portalSettings.HostSettings("ProxyPort").ToString
            txtSMTPServer.Text = _portalSettings.HostSettings("SMTPServer").ToString
            txtFileExtensions.Text = _portalSettings.HostSettings("FileExtensions").ToString

            Dim intVersion As Integer
            For intVersion = 0 To System.Diagnostics.FileVersionInfo.GetVersionInfo(System.Reflection.Assembly.GetExecutingAssembly.Location).ProductBuildPart()
                cboUpgrade.Items.Add("1.0." & intVersion.ToString)
            Next

        End Sub

        Private Sub Update_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            Dim objAdmin As New AdminDB()

            objAdmin.UpdateHostSetting("HostTitle", txtHostTitle.Text)
            objAdmin.UpdateHostSetting("HostURL", txtHostURL.Text)
            objAdmin.UpdateHostSetting("HostEmail", txtHostEmail.Text)
            objAdmin.UpdateHostSetting("PaymentProcessor", cboProcessor.SelectedItem.Text)
            objAdmin.UpdateHostSetting("ProcessorUserId", txtUserId.Text)
            objAdmin.UpdateHostSetting("ProcessorPassword", txtPassword.Text)
            objAdmin.UpdateHostSetting("HostFee", txtHostFee.Text)
            objAdmin.UpdateHostSetting("HostCurrency", cboHostCurrency.SelectedItem.Value)
            objAdmin.UpdateHostSetting("HostSpace", txtHostSpace.Text)
            objAdmin.UpdateHostSetting("SiteLogHistory", txtSiteLogHistory.Text)
            objAdmin.UpdateHostSetting("DemoPeriod", txtDemoPeriod.Text)
            objAdmin.UpdateHostSetting("DemoSignup", IIf(chkDemoSignup.Checked, "Y", "N"))
            objAdmin.UpdateHostSetting("DisablePageTitleVersion", IIf(chkPageTitleVersion.Checked, "Y", "N"))
            objAdmin.UpdateHostSetting("EnableErrorReporting", IIf(chkEnableErrorReport.Checked, "Y", "N"))
            objAdmin.UpdateHostSetting("ProxyServer", txtProxyServer.Text)
            objAdmin.UpdateHostSetting("ProxyPort", txtProxyPort.Text)
            objAdmin.UpdateHostSetting("SMTPServer", txtSMTPServer.Text)
            objAdmin.UpdateHostSetting("FileExtensions", txtFileExtensions.Text)

            ' re-encrypt user passwords if EncryptionKey has changed
            If txtEncryptionKey.Text <> _portalSettings.HostSettings("EncryptionKey").ToString Then
                Dim strBody As String

                Dim objSecurity As New PortalSecurity()
                Dim objUsers As New UsersDB()
                Dim strPassword As String
                Dim dr As SqlDataReader
                dr = objUsers.GetUsers()
                While dr.Read
                    strPassword = dr("Password").ToString
                    strPassword = objSecurity.Decrypt(_portalSettings.HostSettings("EncryptionKey").ToString, strPassword)
                    If strPassword = "" Then ' decryption error - reset password
                        strPassword = (dr("FirstName").ToString & dr("LastName").ToString).ToLower
                        strBody = "Dear " & dr("FullName") & "," & vbCrLf & vbCrLf
                        strBody = strBody & "Due to a website encryption problem your password has been reset." & vbCrLf & vbCrLf
                        strBody = strBody & "Please login using the following information:" & vbCrLf & vbCrLf
                        strBody = strBody & "Portal Website Address: " & GetPortalDomainName(PortalAlias, Request) & vbCrLf
                        strBody = strBody & "Username: " & dr("Username").ToString & vbCrLf
                        strBody = strBody & "Password: " & strPassword & vbCrLf
                        strBody = strBody & vbCrLf & "We apologize for the inconvenience." & vbCrLf
                        strBody = strBody & vbCrLf & "Sincerely," & vbCrLf
                        strBody = strBody & "Portal Administrator" & vbCrLf & vbCrLf
                        SendNotification(_portalSettings.Email, dr("Email").ToString, "", _portalSettings.PortalName & " Password Reset", strBody)
                    End If
                    strPassword = objSecurity.Encrypt(txtEncryptionKey.Text, strPassword)
                    objUsers.UpdateUser(-1, dr("UserId").ToString, dr("FirstName").ToString, dr("LastName").ToString, dr("Unit").ToString, dr("Street").ToString, dr("City").ToString, dr("Region").ToString, dr("PostalCode").ToString, dr("Country").ToString, dr("Telephone").ToString, dr("Email").ToString, dr("Username").ToString, strPassword)
                End While
                dr.Close()

                ' set the encryption key
                objAdmin.UpdateHostSetting("Encryptionkey", txtEncryptionKey.Text)
            End If

            ' Redirect to this site to refresh host settings
            Response.Redirect(Request.RawUrl, True)

        End Sub

        Private Sub cmdProcessor_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdProcessor.Click
            Response.Redirect(AddHTTP(cboProcessor.SelectedItem.Value), True)
        End Sub

        Private Sub cmdUpgrade_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdUpgrade.Click

            If File.Exists(Server.MapPath("Database\" & cboUpgrade.SelectedItem.Text & ".log")) Then
                Dim objStreamReader As StreamReader
                objStreamReader = File.OpenText(Server.MapPath("Database\" & cboUpgrade.SelectedItem.Text & ".log"))
                lblUpgrade.Text = Replace(objStreamReader.ReadToEnd, ControlChars.Lf, "<br>")
                objStreamReader.Close()
            Else
                lblUpgrade.Text = "Database script was not executed for specified version."
            End If

        End Sub

        Private Sub cmdEmail_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdEmail.Click
            If txtHostEmail.Text <> "" Then
                Dim strMessage As String = SendNotification(txtHostEmail.Text, txtHostEmail.Text, "", txtHostTitle.Text & " Email Configuration Test", "")
                If strMessage <> "" Then
                    lblEmail.Text = "<br>" & strMessage
                Else
                    lblEmail.Text = "<br>" & "Email Sent Successfully"
                End If
            Else
                lblEmail.Text = "<br>You Must Specify The Host Email Address"
            End If
        End Sub

    End Class

End Namespace

