'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2003
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.Xml
Imports System.IO

Namespace DotNetNuke

    Public Class ModuleDefinitions
        Inherits DotNetNuke.PortalModuleControl

        Protected WithEvents tabAddModule As System.Web.UI.HtmlControls.HtmlTable
        Protected WithEvents cboModule As System.Web.UI.WebControls.DropDownList
        Protected WithEvents cmdUpload As System.Web.UI.WebControls.HyperLink

        Protected WithEvents tabEditModule As System.Web.UI.HtmlControls.HtmlTable
        Protected WithEvents txtFriendlyName As System.Web.UI.WebControls.TextBox
        Protected WithEvents valFriendlyName As System.Web.UI.WebControls.RequiredFieldValidator
        Protected WithEvents txtDescription As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtDesktopSrc As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtEditSrc As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtMobileSrc As System.Web.UI.WebControls.TextBox
        Protected WithEvents cboEditModuleIcon As System.Web.UI.WebControls.DropDownList
        Protected WithEvents chkPremium As System.Web.UI.WebControls.CheckBox

        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdDelete As System.Web.UI.WebControls.LinkButton

        Private defId As Integer = -1

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        '*******************************************************
        '
        ' The Page_Load server event handler on this page is used
        ' to populate the role information for the page
        '
        '*******************************************************

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            ' Verify that the current user has access to this page
            If Context.User.Identity.Name <> _portalSettings.SuperUserId Then
                Response.Redirect("~/EditModule.aspx?tabid=" & TabId & "&def=Edit Access Denied", True)
            End If

            If Not (Request.Params("defid") Is Nothing) Then
                defId = Int32.Parse(Request.Params("defid"))
            End If

            If Page.IsPostBack = False Then

                cmdDelete.Attributes.Add("onClick", "javascript:return confirm('Are You Sure You Wish To Delete This Item ?');")

                cboEditModuleIcon.DataSource = GetFileList(, glbImageFileTypes)
                cboEditModuleIcon.DataBind()

                cmdUpload.NavigateUrl = "~/EditModule.aspx?tabid=" & TabId & "&def=File Manager"

                If defId = -1 Then

                    tabAddModule.Visible = True
                    tabEditModule.Visible = False
                    cmdUpdate.Text = "Install"
                    cmdDelete.Visible = False

                    ' load the modules to install
                    Dim strFolder As String = Request.MapPath(glbSiteDirectory)
                    If Directory.Exists(strFolder) Then
                        Dim fileEntries As String() = Directory.GetFiles(strFolder, "*.dnn")
                        Dim strModule As String
                        Dim strFileName As String
                        For Each strFileName In fileEntries
                            strModule = Mid(strFileName, InStrRev(strFileName, "\") + 1)
                            strModule = Left(strModule, InStr(1, strModule, ".dnn") - 1)
                            cboModule.Items.Add(New ListItem(strModule, strFileName))
                        Next
                    End If

                Else

                    tabAddModule.Visible = False
                    tabEditModule.Visible = True

                    ' Obtain the module definition to edit from the database
                    Dim objAdmin As New AdminDB()

                    Dim dr As SqlDataReader = objAdmin.GetSingleModuleDefinition(defId)

                    If dr.Read() Then
                        txtFriendlyName.Text = dr("FriendlyName").ToString
                        txtDescription.Text = dr("Description").ToString
                        txtDesktopSrc.Text = dr("DesktopSrc").ToString
                        txtEditSrc.Text = dr("EditSrc").ToString
                        txtMobileSrc.Text = dr("MobileSrc").ToString
                        If cboEditModuleIcon.Items.Contains(New ListItem(CType(dr("EditModuleIcon").ToString, String))) Then
                            cboEditModuleIcon.Items.FindByText(CType(dr("EditModuleIcon"), String)).Selected = True
                        End If
                        chkPremium.Checked = dr("IsPremium")
                    End If

                    dr.Close()

                End If

                ' Store URL Referrer to return to portal
                If Not Request.UrlReferrer Is Nothing Then
                    ViewState("UrlReferrer") = Request.UrlReferrer.ToString()
                Else
                    ViewState("UrlReferrer") = ""
                End If

            End If

        End Sub

        Private Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click

            Dim xmlDoc As New XmlDocument()
            Dim nodeModule As XmlNode
            Dim nodeFile As XmlNode

            If Page.IsValid = True Then

                Dim objAdmin As New AdminDB()
                Dim dr As SqlDataReader

                If defId <> -1 Then
                    Dim strEditModuleIcon As String = ""
                    If Not cboEditModuleIcon.SelectedItem Is Nothing Then
                        If cboEditModuleIcon.SelectedIndex <> 0 Then
                            strEditModuleIcon = cboEditModuleIcon.SelectedItem.Value
                        End If
                    End If

                    objAdmin.UpdateModuleDefinition(defId, txtFriendlyName.Text, txtDesktopSrc.Text, txtMobileSrc.Text, "", txtEditSrc.Text, True, txtDescription.Text, strEditModuleIcon, chkPremium.Checked)
                Else ' installing a new module

                    Dim strInstaller As String = cboModule.SelectedItem.Value

                    If File.Exists(strInstaller) Then
                        xmlDoc.Load(strInstaller)

                        nodeModule = xmlDoc.SelectSingleNode("module")

                        Dim strRelativePath As String = ""
                        Dim strAbsolutePath As String = ""

                        strRelativePath = nodeModule.Item("folder").InnerText()

                        If strRelativePath <> "" Then
                            strRelativePath += "/"
                            strAbsolutePath = Server.MapPath(strRelativePath)

                            If Not Directory.Exists(strAbsolutePath) Then
                                Directory.CreateDirectory(strAbsolutePath)
                            End If

                            ' check if development
                            Dim blnDelete As Boolean = True
                            If File.Exists(strAbsolutePath & nodeModule.Item("friendlyname").InnerText & ".vbproj") Then
                                blnDelete = False
                            End If
                        End If

                        ' move uninstall script to module folder
                        Dim strUninstallScript As String = nodeModule.Item("uninstall").InnerText
                        If strUninstallScript <> "" Then
                            If File.Exists(Request.MapPath(glbSiteDirectory) & strUninstallScript) Then
                                If File.Exists(strAbsolutePath & strUninstallScript) Then
                                    File.Delete(strAbsolutePath & strUninstallScript)
                                End If
                                File.Move(Request.MapPath(glbSiteDirectory) & strUninstallScript, strAbsolutePath & strUninstallScript)
                                objAdmin.DeleteFile(strUninstallScript)
                            End If
                        End If

                        ' install files
                        For Each nodeFile In xmlDoc.SelectNodes("//module/files/file")
                            Dim strFileName As String = nodeFile.Item("name").InnerText.ToLower
                            If File.Exists(Request.MapPath(glbSiteDirectory) & strFileName) Then
                                Dim strExtension As String = Mid(strFileName, InStrRev(strFileName, ".") + 1)
                                Select Case strExtension
                                    Case "dll"
                                        ' move DLL to application /bin/ folder
                                        If File.Exists(Request.MapPath("~/bin/") & strFileName) Then
                                            File.Delete(Request.MapPath("~/bin/") & strFileName)
                                        End If
                                        File.Move(Request.MapPath(glbSiteDirectory) & strFileName, Request.MapPath("~/bin/") & strFileName)
                                        objAdmin.DeleteFile(strFileName)
                                    Case "sql"
                                        ' read SQL installation script
                                        Dim objStreamReader As StreamReader
                                        objStreamReader = File.OpenText(Request.MapPath(glbSiteDirectory) & strFileName)
                                        Dim strScript As String = objStreamReader.ReadToEnd
                                        objStreamReader.Close()

                                        ' execute SQL installation script
                                        objAdmin.ExecuteSQLScript(strScript)

                                        ' delete script file once executed
                                        File.Delete(Request.MapPath(glbSiteDirectory) & strFileName)
                                        objAdmin.DeleteFile(strFileName)
                                    Case Else
                                        ' move user controls to module folder
                                        If File.Exists(strAbsolutePath & strFileName) Then
                                            File.Delete(strAbsolutePath & strFileName)
                                        End If
                                        File.Move(Request.MapPath(glbSiteDirectory) & strFileName, strAbsolutePath & strFileName)
                                        objAdmin.DeleteFile(strFileName)

                                        ' add supporting modules to database
                                        If strExtension = "ascx" Then
                                            If InStr(1, nodeModule.Item("desktopsrc").InnerText, strFileName, CompareMethod.Text) = 0 And _
                                              InStr(1, nodeModule.Item("mobilesrc").InnerText, strFileName, CompareMethod.Text) = 0 And _
                                              InStr(1, nodeModule.Item("editsrc").InnerText, strFileName, CompareMethod.Text) = 0 Then
                                                Dim strFriendlyName = Left(strFileName, InStrRev(strFileName, ".") - 1)
                                                dr = objAdmin.GetSingleModuleDefinitionByName(strFriendlyName)
                                                If dr.Read Then
                                                    ' upgrade
                                                    objAdmin.UpdateModuleDefinition(dr("ModuleDefID"), strFriendlyName, "", "", "", strRelativePath & "/" & strFileName, True, "", "", False)
                                                Else
                                                    ' new
                                                    objAdmin.AddModuleDefinition(strFriendlyName, "", "", "", strRelativePath & "/" & strFileName, True, "", "", False)
                                                End If
                                                dr.Close()

                                            End If
                                        End If
                                End Select
                            End If
                        Next

                        ' add new module definition to database
                        dr = objAdmin.GetSingleModuleDefinitionByName(nodeModule.Item("friendlyname").InnerText)
                        If dr.Read Then
                            ' upgrade
                            objAdmin.UpdateModuleDefinition(dr("ModuleDefID"), nodeModule.Item("friendlyname").InnerText, IIf(nodeModule.Item("desktopsrc").InnerText <> "", strRelativePath & nodeModule.Item("desktopsrc").InnerText, ""), IIf(nodeModule.Item("mobilesrc").InnerText <> "", strRelativePath & nodeModule.Item("mobilesrc").InnerText, ""), "", IIf(nodeModule.Item("editsrc").InnerText <> "", strRelativePath & nodeModule.Item("editsrc").InnerText, ""), True, nodeModule.Item("description").InnerText, nodeModule.Item("editmoduleicon").InnerText, False)
                        Else
                            ' new
                            objAdmin.AddModuleDefinition(nodeModule.Item("friendlyname").InnerText, IIf(nodeModule.Item("desktopsrc").InnerText <> "", strRelativePath & nodeModule.Item("desktopsrc").InnerText, ""), IIf(nodeModule.Item("mobilesrc").InnerText <> "", strRelativePath & nodeModule.Item("mobilesrc").InnerText, ""), "", IIf(nodeModule.Item("editsrc").InnerText <> "", strRelativePath & nodeModule.Item("editsrc").InnerText, ""), True, nodeModule.Item("description").InnerText, nodeModule.Item("editmoduleicon").InnerText, False)
                        End If
                        dr.Close()

                        ' move installation file to module folder ( for uninstall )
                        If cboModule.SelectedItem.Text <> "Template" Then
                            If File.Exists(strAbsolutePath & cboModule.SelectedItem.Text & ".dnn") Then
                                File.Delete(strAbsolutePath & cboModule.SelectedItem.Text & ".dnn")
                            End If
                            File.Move(strInstaller, strAbsolutePath & cboModule.SelectedItem.Text & ".dnn")
                            objAdmin.DeleteFile(cboModule.SelectedItem.Text & ".dnn")
                        End If
                    End If

                End If

                Response.Redirect(CType(Viewstate("UrlReferrer"), String), True)

            End If

        End Sub

        Private Sub cmdDelete_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdDelete.Click

            Dim xmlDoc As New XmlDocument()
            Dim nodeModule As XmlNode
            Dim nodeFile As XmlNode

            Dim objAdmin As New AdminDB()
            Dim dr As SqlDataReader

            Dim strRelativePath As String = ""
            Dim strAbsolutePath As String = ""

            If txtFriendlyName.Text <> "Template" Then
                strRelativePath = txtDesktopSrc.Text
                strRelativePath = Left(strRelativePath, InStrRev(strRelativePath, "/") - 1)
                strAbsolutePath = Server.MapPath(strRelativePath) & "\"
            End If

            ' read the installation file
            If File.Exists(strAbsolutePath & txtFriendlyName.Text & ".dnn") Then
                xmlDoc.Load(strAbsolutePath & txtFriendlyName.Text & ".dnn")

                nodeModule = xmlDoc.SelectSingleNode("module")

                ' check if development
                Dim blnDelete As Boolean = True
                If File.Exists(strAbsolutePath & nodeModule.Item("friendlyname").InnerText & ".vbproj") Then
                    blnDelete = False
                End If

                ' remove icon
                Dim strEditModuleIcon As String = nodeModule.Item("editmoduleicon").InnerText
                If strEditModuleIcon <> "" Then
                    If File.Exists(Request.MapPath(glbSiteDirectory) & strEditModuleIcon) Then
                        File.Delete(Request.MapPath(glbSiteDirectory) & strEditModuleIcon)
                    End If
                End If

                ' remove files
                For Each nodeFile In xmlDoc.SelectNodes("//module/files/file")
                    Dim strFileName As String = nodeFile.Item("name").InnerText.ToLower
                    Dim strExtension As String = Mid(strFileName, InStrRev(strFileName, ".") + 1)
                    Select Case strExtension
                        Case "dll"
                            ' delete DLL from application /bin/ folder
                            If File.Exists(Request.MapPath("~/bin/") & strFileName) Then
                                File.Delete(Request.MapPath("~/bin/") & strFileName)
                            End If
                        Case Else
                            ' delete files from module folder
                            If blnDelete Then
                                If File.Exists(strAbsolutePath & strFileName) Then
                                    File.Delete(strAbsolutePath & strFileName)
                                End If
                            End If

                            ' remove supporting modules from database
                            If strExtension = "ascx" Then
                                If InStr(1, nodeModule.Item("desktopsrc").InnerText, strFileName, CompareMethod.Text) = 0 And _
                                  InStr(1, nodeModule.Item("mobilesrc").InnerText, strFileName, CompareMethod.Text) = 0 And _
                                  InStr(1, nodeModule.Item("editsrc").InnerText, strFileName, CompareMethod.Text) = 0 Then
                                    Dim strFriendlyName = Left(strFileName, InStrRev(strFileName, ".") - 1)
                                    dr = objAdmin.GetSingleModuleDefinitionByName(strFriendlyName)
                                    If dr.Read Then
                                        ' delete
                                        objAdmin.DeleteModuleDefinition(dr("ModuleDefID"))
                                    End If
                                    dr.Close()
                                End If
                            End If
                    End Select
                Next

                ' execute uninstall script
                Dim strUninstallScript As String = nodeModule.Item("uninstall").InnerText
                If strUninstallScript <> "" Then
                    If File.Exists(strAbsolutePath & strUninstallScript) Then
                        ' read uninstall script
                        Dim objStreamReader As StreamReader
                        objStreamReader = File.OpenText(strAbsolutePath & strUninstallScript)
                        Dim strScript As String = objStreamReader.ReadToEnd
                        objStreamReader.Close()

                        ' execute SQL installation script
                        objAdmin.ExecuteSQLScript(strScript)

                        ' delete script file once executed
                        If blnDelete Then
                            File.Delete(strAbsolutePath & strUninstallScript)
                        End If
                    End If
                End If

                ' remove installation script and directory
                If blnDelete Then
                    File.Delete(strAbsolutePath & txtFriendlyName.Text & ".dnn")
                    Directory.Delete(strAbsolutePath)
                End If
            End If

            ' delete definition
            objAdmin.DeleteModuleDefinition(defId)

            Response.Redirect(CType(Viewstate("UrlReferrer"), String), True)

        End Sub


        Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click
            Response.Redirect(CType(Viewstate("UrlReferrer"), String), True)
        End Sub

    End Class

End Namespace
