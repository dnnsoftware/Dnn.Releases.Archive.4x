'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2003
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.Security
Imports System.Security.Principal
Imports System.Web.Security
Imports System.IO
Imports System.XML

Namespace DotNetNuke

   Public Class Global

        Inherits System.Web.HttpApplication
      
        '*********************************************************************
        '
        ' Application_BeginRequest Event
        '
        ' The Application_BeginRequest method is an ASP.NET event that executes 
        ' on each web request into the portal application.  The below method
        ' obtains the current TabId from the querystring of the 
        ' request -- and then obtains the configuration necessary to process
        ' and render the request.
        '
        ' This portal configuration is stored within the application's "Context"
        ' object -- which is available to all pages, controls and components
        ' during the processing of a single request.
        ' 
        '*********************************************************************

        Sub Application_BeginRequest(ByVal sender As Object, ByVal e As EventArgs)

            Dim tabId As Integer = 0
            Dim DomainName As String = Nothing
            Dim PortalAlias As String = Nothing

            Dim DatabaseVersion As Integer = PortalSettings.GetVersion
            Dim AssemblyVersion As Integer = System.Diagnostics.FileVersionInfo.GetVersionInfo(System.Reflection.Assembly.GetExecutingAssembly.Location).ProductBuildPart()

            If DatabaseVersion <> AssemblyVersion Then
                ' the database version is not synchronized with the assembly version
                If InStr(1, Request.Url.ToString.ToLower, "upgrade.aspx") = 0 Then
                    Dim strMessage As String = ""
                    If DatabaseVersion = -1 Then
                        strMessage = "The Application could not Connect to the Database using the Login details specified in the Web.Config file.<br><br>Please investigate the problem and then select the following link to continue."
                    Else
                        Dim intVersion As Integer
                        For intVersion = (DatabaseVersion + 1) To AssemblyVersion
                            If Not File.Exists(Server.MapPath("Database\1.0." & intVersion.ToString & ".sql")) Then
                                strMessage += "<li>1.0." & intVersion.ToString & ".sql"
                            End If
                        Next
                        If strMessage = "" Then
                            strMessage = "The required SQL Upgrade Scripts exist in the Database folder but have not been executed.<br><br>Please select the following link to continue."
                        Else
                            strMessage = "The following SQL Upgrade Scripts are missing from the Database folder:<br><br>" & strMessage & "<br><br>Please correct the problem and then select the following link to continue."
                        End If
                    End If

                    Dim objStreamReader As StreamReader
                    objStreamReader = File.OpenText(Server.MapPath("~/500.htm"))
                    Dim strHTML As String = objStreamReader.ReadToEnd
                    objStreamReader.Close()
                    strHTML = Replace(strHTML, "[ASSEMBLYVERSION]", "1.0." & AssemblyVersion.ToString)
                    strHTML = Replace(strHTML, "[DATABASEVERSION]", "1.0." & DatabaseVersion.ToString)
                    strHTML = Replace(strHTML, "[MESSAGE]", strMessage)

                    Response.Write(strHTML)
                    Response.End()
                Else ' execute the upgrade.aspx
                    Exit Sub
                End If
            End If

            ' get tabId from querystring
            If Not (Request.Params("tabid") Is Nothing) Then
                tabId = Int32.Parse(Request.Params("tabid"))
            End If

            ' parse the Request URL into a Domain Name token 
            DomainName = GetDomainName(Request)

            ' alias parameter can be used to switch portals
            If Not (Request.Params("alias") Is Nothing) Then
                If PortalSettings.GetPortalByAlias(Request.Params("alias")) <> -1 Then
                    If InStr(1, Request.Params("alias"), DomainName, CompareMethod.Text) = 0 Then
                        Response.Redirect(GetPortalDomainName(Request.Params("alias"), Request), True)
                    Else
                        PortalAlias = Request.Params("alias")
                    End If
                End If
            End If

            ' tabId uniquely identifies a Portal
            If PortalAlias Is Nothing Then
                If tabId <> 0 Then
                    PortalAlias = PortalSettings.GetPortalByTab(tabId, DomainName)
                End If
            End If

            ' else use the domainname
            If PortalAlias Is Nothing Then
                PortalAlias = DomainName
                tabId = 0 ' load the default tab 
            End If

            ' validate the alias
            If PortalSettings.GetPortalByAlias(PortalAlias) <> -1 Then
                ' load the PortalSettings into current context
                Context.Items.Add("PortalSettings", New PortalSettings(tabId, PortalAlias, Request.ApplicationPath))
            Else
                ' alias does not exist in database
                Dim objStreamReader As StreamReader
                objStreamReader = File.OpenText(Server.MapPath("~/404.htm"))
                Dim strHTML As String = objStreamReader.ReadToEnd
                objStreamReader.Close()
                strHTML = Replace(strHTML, "[DOMAINNAME]", DomainName)
                Response.Write(strHTML)
                Response.End()
            End If

        End Sub


        '*********************************************************************
        '
        ' Application_AuthenticateRequest Event
        '
        ' If the client is authenticated with the application, then determine
        ' which security roles he/she belongs to and replace the "User" intrinsic
        ' with a custom IPrincipal security object that permits "User.IsInRole"
        ' role checks within the application
        '
        ' Roles are cached in the browser in an in-memory encrypted cookie.  If the
        ' cookie doesn't exist yet for this session, create it.
        '
        '*********************************************************************

        Sub Application_AuthenticateRequest(ByVal sender As Object, ByVal e As EventArgs)

            ' Obtain PortalSettings from Current Context
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            If Request.IsAuthenticated = True Then
                If Not Request.Cookies("portalid") Is Nothing Then
                    Dim PortalCookie As FormsAuthenticationTicket = FormsAuthentication.Decrypt(Context.Request.Cookies("portalid").Value)

                    ' check if user has switched portals
                    If _portalSettings.PortalId <> Int32.Parse(PortalCookie.UserData) Then

                        ' expire cookies if portal has changed
                        Response.Cookies("portalid").Value = Nothing
                        Response.Cookies("portalid").Path = "/"
                        Response.Cookies("portalid").Expires = DateTime.Now.AddYears(-30)

                        Response.Cookies("portalroles").Value = Nothing
                        Response.Cookies("portalroles").Path = "/"
                        Response.Cookies("portalroles").Expires = DateTime.Now.AddYears(-30)

                        ' check if user is valid for new portal
                        Dim objUser As New UsersDB()
                        Dim dr As SqlDataReader = objUser.GetSingleUser(_portalSettings.PortalId, Int32.Parse(Context.User.Identity.Name))
                        If Not dr.Read Then
                            ' log user out
                            FormsAuthentication.SignOut()
                            ' Redirect browser back to home page
                            Response.Redirect(Request.RawUrl, True)
                            Exit Sub
                        End If

                        dr.close()

                    End If
                End If
            End If

            If Request.IsAuthenticated = True Then

                Dim arrPortalRoles() As String

                ' get UserId based on authentication method ( from web.config )
                Dim intUserId As Integer = -1
                Dim objUser As New UsersDB()
                Select Case User.Identity.AuthenticationType
                    Case "Forms"
                        If IsNumeric(Context.User.Identity.Name) Then
                            intUserId = Int32.Parse(Context.User.Identity.Name)
                        End If
                    Case "Windows"
                        Dim dr As SqlDataReader = objUser.GetSingleUserByUsername(_portalSettings.PortalId, Context.User.Identity.Name)
                        If dr.Read() Then
                            intUserId = dr("UserId")
                        End If
                        dr.Close()
                End Select

                ' authenticate user and set last login ( this is necessary for users who have a permanent Auth cookie set ) 
                If Not objUser.UpdateUserLogin(intUserId, _portalSettings.PortalId) Then

                    ' Log User Off from Cookie Authentication System
                    FormsAuthentication.SignOut()

                    ' expire cookies
                    Response.Cookies("portalid").Value = Nothing
                    Response.Cookies("portalid").Path = "/"
                    Response.Cookies("portalid").Expires = DateTime.Now.AddYears(-30)

                    Response.Cookies("portalroles").Value = Nothing
                    Response.Cookies("portalroles").Path = "/"
                    Response.Cookies("portalroles").Expires = DateTime.Now.AddYears(-30)

                Else ' valid Auth cookie

                    ' create cookies if they do not exist yet for this session.
                    If Request.Cookies("portalroles") Is Nothing Then

                        ' keep cookies in sync
                        Dim CurrentDateTime As Date = DateTime.Now

                        ' create a cookie authentication ticket ( version, user name, issue time, expires every hour, don't persist cookie, roles )
                        Dim PortalTicket As New FormsAuthenticationTicket(1, intUserId.ToString, CurrentDateTime, CurrentDateTime.AddHours(1), False, _portalSettings.PortalId.ToString)
                        ' encrypt the ticket
                        Dim strPortal As String = FormsAuthentication.Encrypt(PortalTicket)
                        ' send portal cookie to client
                        Response.Cookies("portalid").Value = strPortal
                        Response.Cookies("portalid").Path = "/"
                        Response.Cookies("portalid").Expires = CurrentDateTime.AddMinutes(1)

                        ' get roles from UserRoles table
                        arrPortalRoles = objUser.GetRolesByUser(intUserId, _portalSettings.PortalId)
                        ' create a string to persist the roles
                        Dim strPortalRoles As String = Join(arrPortalRoles, New Char() {";"c})

                        ' create a cookie authentication ticket ( version, user name, issue time, expires every hour, don't persist cookie, roles )
                        Dim RolesTicket As New FormsAuthenticationTicket(1, intUserId.ToString, CurrentDateTime, CurrentDateTime.AddHours(1), False, strPortalRoles)
                        ' encrypt the ticket
                        Dim strRoles As String = FormsAuthentication.Encrypt(RolesTicket)
                        ' send roles cookie to client
                        Response.Cookies("portalroles").Value = strRoles
                        Response.Cookies("portalroles").Path = "/"
                        Response.Cookies("portalroles").Expires = CurrentDateTime.AddMinutes(1)

                    Else
                        If Request.Cookies("portalroles").Value <> "" Then

                            ' get roles from roles cookie
                            Dim RoleTicket As FormsAuthenticationTicket = FormsAuthentication.Decrypt(Context.Request.Cookies("portalroles").Value)

                            ' convert the string representation of the role data into a string array
                            arrPortalRoles = Split(RoleTicket.UserData, New Char() {";"c})

                        End If

                    End If

                    ' add our own custom principal to the request containing the roles in the auth ticket
                    Dim objGenericIdentity As Principal.GenericIdentity = New Principal.GenericIdentity(intUserId.ToString)
                    Context.User = New GenericPrincipal(objGenericIdentity, arrPortalRoles)

                End If
            End If

        End Sub

        '*********************************************************************
        '
        ' Application_Start
        '
        ' Executes on the first web request into the portal application, 
        ' when a new DLL is deployed, or when web.config is modified.
        ' This procedure performs all version upgrade operations ( including database )
        '
        '*********************************************************************

        Sub Application_Start(ByVal Sender As Object, ByVal E As EventArgs)

            Dim strServerPath As String = Server.MapPath("")
            If Not strServerPath.EndsWith("\") Then
                strServerPath += "\"
            End If

            Dim objAdmin As New AdminDB()

            ' automatic upgrade
            Dim intBuild As Integer = PortalSettings.GetVersion

            ' for each build version up to the current version, perform the necessary upgrades
            While intBuild < System.Diagnostics.FileVersionInfo.GetVersionInfo(System.Reflection.Assembly.GetExecutingAssembly.Location).ProductBuildPart()
                intBuild += 1

                ' verify script has not already been run
                If Not PortalSettings.FindVersion(intBuild) Then
                    ' database upgrade 
                    If File.Exists(Server.MapPath("Database\1.0." & intBuild.ToString & ".sql")) Then
                        ' read script file for version
                        Dim objStreamReader As StreamReader
                        objStreamReader = File.OpenText(Server.MapPath("Database\1.0." & intBuild.ToString & ".sql"))
                        Dim strScript As String = objStreamReader.ReadToEnd
                        objStreamReader.Close()

                        ' execute SQL installation script
                        Dim strSQLExceptions As String = objAdmin.ExecuteSQLScript(strScript)

                        ' delete script file once executed
                        Try
                            If InStr(1, Request.Url.ToString.ToLower, "localhost") = 0 Then
                                File.Delete(Server.MapPath("Database\1.0." & intBuild.ToString & ".sql"))
                            End If
                        Catch
                            ' could not delete the script file
                        End Try

                        ' log the results
                        Try
                            Dim objStream As StreamWriter
                            objStream = File.CreateText(Server.MapPath("Database\1.0." & intBuild.ToString & ".log"))
                            objStream.WriteLine(strSQLExceptions)
                            objStream.Close()
                        Catch
                            ' does not have permission to create the log file
                        End Try
                    Else
                        ' script file does not exist for version ( this is mandatory for every version )
                        Try
                            Dim objStream As StreamWriter
                            objStream = File.CreateText(Server.MapPath("Database\1.0." & intBuild.ToString & ".log"))
                            objStream.WriteLine("Upgrade Error. Could Not Locate " & Server.MapPath("Database\1.0." & intBuild.ToString & ".sql") & " Database Upgrade Script.")
                            objStream.Close()
                        Catch
                            ' does not have permission to create the log file
                        End Try
                        Exit Sub
                    End If

                    ' application upgrade
                    Select Case intBuild
                        Case 5 ' move web.config settings to database ( upgrade only )
                            Upgrade_1_0_5()
                    End Select

                    PortalSettings.UpdateVersion(intBuild)
                End If

            End While

        End Sub

        Private Sub Upgrade_1_0_5()
            Dim objAdmin As New AdminDB()
            Dim dr As SqlDataReader

            dr = objAdmin.GetHostSetting("HostTitle")
            If Not dr.Read Then
                If ObjectToString(System.Configuration.ConfigurationSettings.AppSettings("siteHostTitle")) <> "" Then
                    objAdmin.UpdateHostSetting("HostTitle", ObjectToString(System.Configuration.ConfigurationSettings.AppSettings("siteHostTitle")))
                End If
                If ObjectToString(System.Configuration.ConfigurationSettings.AppSettings("siteHostURL")) <> "" Then
                    objAdmin.UpdateHostSetting("HostURL", ObjectToString(System.Configuration.ConfigurationSettings.AppSettings("siteHostURL")))
                End If
                If ObjectToString(System.Configuration.ConfigurationSettings.AppSettings("siteHostEmail")) <> "" Then
                    objAdmin.UpdateHostSetting("HostEmail", ObjectToString(System.Configuration.ConfigurationSettings.AppSettings("siteHostEmail")))
                End If
                objAdmin.UpdateHostSetting("PayPalId", ObjectToString(System.Configuration.ConfigurationSettings.AppSettings("sitePayPalId")))
                objAdmin.UpdateHostSetting("HostFee", ObjectToString(System.Configuration.ConfigurationSettings.AppSettings("siteHostFee")))
                objAdmin.UpdateHostSetting("HostCurrency", ObjectToString(System.Configuration.ConfigurationSettings.AppSettings("siteHostCurrency")))
                objAdmin.UpdateHostSetting("HostSpace", ObjectToString(System.Configuration.ConfigurationSettings.AppSettings("siteHostSpace")))
                objAdmin.UpdateHostSetting("DemoPeriod", ObjectToString(System.Configuration.ConfigurationSettings.AppSettings("siteDemoPeriod")))
                objAdmin.UpdateHostSetting("DemoSignup", ObjectToString(System.Configuration.ConfigurationSettings.AppSettings("siteDemoSignup")))
                Dim settings As Hashtable = PortalSettings.GetModuleSettings(objAdmin.GetSiteModule("Portals"))
                If CType(settings("encryptionkey"), String) Is Nothing Then
                    objAdmin.UpdateHostSetting("EncryptionKey", "")
                Else
                    objAdmin.UpdateHostSetting("EncryptionKey", CType(settings("encryptionkey"), String))
                End If
                objAdmin.UpdateHostSetting("ProxyServer", ObjectToString(System.Configuration.ConfigurationSettings.AppSettings("siteProxyServer")))
                objAdmin.UpdateHostSetting("ProxyPort", ObjectToString(System.Configuration.ConfigurationSettings.AppSettings("siteProxyPort")))
                objAdmin.UpdateHostSetting("SMTPServer", ObjectToString(System.Configuration.ConfigurationSettings.AppSettings("siteSMTPServer")))
                objAdmin.UpdateHostSetting("LoggingEnabled", "Y")
                objAdmin.UpdateHostSetting("PortalModule", "Y")
            End If

            dr.Close()

        End Sub

        Private Function ObjectToString(ByVal objObject As Object) As String
            If Not objObject Is Nothing Then
                Return objObject.ToString
            Else
                Return ""
            End If
        End Function

    End Class

End Namespace
