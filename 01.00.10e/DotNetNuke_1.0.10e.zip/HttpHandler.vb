Imports System
Imports System.Configuration
Imports System.Text
Imports System.Web

Namespace DotNetNuke

    Public Class HTTPHandler

        Implements IHttpModule

        Public Sub Init(ByVal app As HttpApplication) Implements IHttpModule.Init
            AddHandler app.BeginRequest, AddressOf Me.OnBeginRequest
        End Sub

        Public Sub Dispose() Implements IHttpModule.Dispose
        End Sub

        Public Delegate Sub MyEventHandler(ByVal s As Object, ByVal e As EventArgs)

        Public Event MyEvent As MyEventHandler

        Public Sub OnBeginRequest(ByVal s As Object, ByVal e As EventArgs)

            Dim objHttpApplication As HttpApplication = CType(s, HttpApplication)

            If InStr(1, objHttpApplication.Request.Url.ToString.ToLower, "/default.aspx") <> 0 Then

                Dim DomainName As String = GetDomainName(objHttpApplication.Request)

                If PortalSettings.GetPortalByAlias(DomainName) = -1 Then

                    ' request may include a tabname in the path
                    If InStr(1, DomainName, "/") <> 0 Then

                        Dim PortalAlias As String = Left(DomainName, InStrRev(DomainName, "/") - 1)

                        If PortalSettings.GetPortalByAlias(PortalAlias) <> -1 Then
                            Dim Tab As String = Mid(DomainName, InStrRev(DomainName, "/") + 1)

                            If IsNumeric(Tab) Then
                                objHttpApplication.Context.RewritePath("~/DesktopDefault.aspx?tabid=" & Tab & "&alias=" & PortalAlias)
                            Else
                                objHttpApplication.Context.RewritePath("~/DesktopDefault.aspx?tabname=" & Tab & "&alias=" & PortalAlias)
                            End If

                        End If

                    End If

                End If


            End If

        End Sub

    End Class

End Namespace
