'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2003
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.Configuration
Imports System.Web
Imports System.Data
Imports System.Data.SqlClient
Imports System.Collections
Imports System.Data.SqlTypes
Imports System.Reflection

Namespace DotNetNuke

    '*********************************************************************
    '
    ' TabStripDetails Class
    '
    ' Class that encapsulates the just the tabstrip details -- TabName, TabId and TabOrder 
    ' -- for a specific Tab in the Portal
    '
    '*********************************************************************

    Public Class TabStripDetails

        Public TabId As Integer
        Public TabName As String
        Public TabOrder As Integer
        Public AuthorizedRoles As String
        Public AdministratorRoles As String
        Public IsVisible As Boolean
        Public DisableLink As Boolean
        Public ParentId As Integer
        Public Level As Integer
        Public IconFile As String
        Public AdminTabIcon As String
        Public HasChildren As Boolean

    End Class


    '*********************************************************************
    '
    ' TabSettings Class
    '
    ' Class that encapsulates the detailed settings for a specific Tab 
    ' in the Portal
    '
    '*********************************************************************

    Public Class TabSettings

        Public TabId As Integer
        Public TabName As String
        Public TabOrder As Integer
        Public MobileTabName As String
        Public AuthorizedRoles As String
        Public AdministratorRoles As String
        Public ShowMobile As Boolean
        Public LeftPaneWidth As String
        Public RightPaneWidth As String
        Public IsVisible As Boolean
        Public DisableLink As Boolean
        Public ParentId As Integer
        Public Level As Integer
        Public IconFile As String
        Public AdminTabIcon As String
        Public HasChildren As Boolean
        Public Modules As New ArrayList()

    End Class


    '*********************************************************************
    '
    ' ModuleSettings Class
    '
    ' Class that encapsulates the detailed settings for a specific Tab 
    ' in the Portal
    '
    '*********************************************************************

    Public Class ModuleSettings

        Public ModuleId As Integer
        Public ModuleDefId As Integer
        Public TabId As Integer
        Public CacheTime As Integer
        Public ModuleOrder As Integer
        Public PaneName As String
        Public ModuleTitle As String
        Public AuthorizedEditRoles As String
        Public ShowMobile As Boolean
        Public DesktopSrc As String
        Public MobileSrc As String
        Public AuthorizedViewRoles As String
        Public Alignment As String
        Public Color As String
        Public Border As String
        Public EditSrc As String
        Public IconFile As String
        Public EditModuleIcon As String
        Public Secure As Boolean
        Public AllTabs As Boolean
        Public ShowTitle As Boolean
        Public Personalize As Integer
        Public Container As String
        Public FriendlyName As String

    End Class


    '*********************************************************************
    '
    ' PortalSettings Class
    '
    ' This class encapsulates all of the settings for the Portal, as well
    ' as the configuration settings required to execute the current tab
    ' view within the portal.
    '
    '*********************************************************************

    Public Class PortalSettings

        Public PortalId As Integer
        Public GUID As String
        Public PortalAlias As String
        Public PortalName As String
        Public UploadDirectory As String
        Public LogoFile As String
        Public FooterText As String
        Public ExpiryDate As String
        Public UserRegistration As Integer
        Public BannerAdvertising As Integer
        Public Currency As String
        Public AdministratorId As Integer
        Public Email As String
        Public HostFee As String
        Public HostSpace As Integer
        Public AdministratorRoleId As Integer
        Public RegisteredRoleId As Integer
        Public Description As String
        Public KeyWords As String
        Public BackgroundFile As String
        Public SiteLogHistory As Integer
        Public AdminTabId As Integer
        Public SuperUserId As Integer
        Public SuperTabId As Integer
        Public Version As String
        Public BreadCrumbs As New ArrayList()
        Public DesktopTabs As New ArrayList()
        Public MobileTabs As New ArrayList()
        Public ActiveTab As New TabSettings()
        Public HostSettings As New Hashtable()

        '*********************************************************************
        '
        ' PortalSettings Constructor
        '
        ' The PortalSettings Constructor encapsulates all of the logic
        ' necessary to obtain configuration settings necessary to render
        ' a Portal Tab view for a given request.
        '
        '*********************************************************************

        Public Sub New(ByVal tabId As Integer, ByVal PortalAlias As String, ByVal ApplicationPath As String)

            GetPortalSettings(tabId, PortalAlias)

            Me.UploadDirectory = IIf(ApplicationPath = "/", "", ApplicationPath) & "/Portals/" & Me.GUID.ToString & "/"
            GetBreadCrumbsRecursively(Me.ActiveTab.TabId)
            Me.Version = System.Diagnostics.FileVersionInfo.GetVersionInfo(System.Reflection.Assembly.GetExecutingAssembly.Location).ProductVersion.ToString
            Me.Version = Left(Me.Version, InStrRev(Me.Version, ".") - 1)

        End Sub

        Public Sub GetPortalSettings(ByVal tabId As Integer, ByVal PortalAlias As String)

            ' Create Instance of Connection and Command Object
            Dim myConnection As New SqlConnection(GetDBConnectionString)

            ' Generate Command Object based on Method
            Dim myCommand As SqlCommand = SqlCommandGenerator.GenerateCommand(myConnection, _
                CType(MethodBase.GetCurrentMethod(), MethodInfo), _
                New Object() {tabId, PortalAlias})

            ' Execute the command
            myConnection.Open()
            Dim result As SqlDataReader = myCommand.ExecuteReader(CommandBehavior.CloseConnection)

            If result.Read() Then
                ' portal settings
                Me.PortalId = Int32.Parse(result("PortalID").ToString)
                Me.GUID = result("GUID").ToString
                Me.PortalAlias = result("PortalAlias").ToString
                Me.PortalName = result("PortalName").ToString
                Me.LogoFile = result("LogoFile").ToString
                Me.FooterText = result("FooterText").ToString
                Me.ExpiryDate = result("ExpiryDate").ToString
                Me.UserRegistration = result("UserRegistration").ToString
                Me.BannerAdvertising = result("BannerAdvertising").ToString
                Me.Currency = result("Currency").ToString
                Me.AdministratorId = result("AdministratorId").ToString
                Me.Email = result("Email").ToString
                Me.HostFee = result("HostFee").ToString
                Me.HostSpace = IIf(IsDBNull(result("HostSpace")), 0, result("HostSpace"))
                Me.AdministratorRoleId = result("AdministratorRoleId").ToString
                Me.RegisteredRoleId = result("RegisteredRoleId").ToString
                Me.Description = result("Description").ToString
                Me.KeyWords = result("KeyWords").ToString
                Me.BackgroundFile = result("BackgroundFile").ToString
                Me.SiteLogHistory = IIf(IsDBNull(result("SiteLogHistory")), -1, result("SiteLogHistory"))
                Me.AdminTabId = result("AdminTabId").ToString
                Me.SuperUserId = result("SuperUserId").ToString
                Me.SuperTabId = result("SuperTabId").ToString

                '  tab settings
                Me.ActiveTab.TabId = Int32.Parse(result("TabId").ToString)
                Me.ActiveTab.TabOrder = IIf(IsDBNull(result("TabOrder")), -1, result("TabOrder"))
                Me.ActiveTab.MobileTabName = result("MobileTabName").ToString
                Me.ActiveTab.AuthorizedRoles = result("AuthorizedRoles").ToString
                Me.ActiveTab.AdministratorRoles = result("AdministratorRoles").ToString
                Me.ActiveTab.TabName = result("TabName").ToString
                Me.ActiveTab.ShowMobile = Boolean.Parse(result("ShowMobile").ToString)
                Me.ActiveTab.LeftPaneWidth = result("LeftPaneWidth").ToString
                Me.ActiveTab.RightPaneWidth = result("RightPaneWidth").ToString
                Me.ActiveTab.IsVisible = Boolean.Parse(result("IsVisible").ToString)
                Me.ActiveTab.DisableLink = Boolean.Parse(result("DisableLink").ToString)
                Me.ActiveTab.ParentId = result("ParentId")
                Me.ActiveTab.Level = result("Level")
                Me.ActiveTab.IconFile = result("IconFile").ToString
                Me.ActiveTab.AdminTabIcon = result("AdminTabIcon").ToString
                Me.ActiveTab.HasChildren = Boolean.Parse(result("HasChildren").ToString)
            End If

            ' Read the next result --  Desktop Tab Information
            result.NextResult()

            While result.Read()

                Dim tabDetails As New TabStripDetails()

                tabDetails.TabId = Int32.Parse(result("TabId").ToString)
                tabDetails.TabName = result("TabName").ToString
                tabDetails.TabOrder = IIf(IsDBNull(result("TabOrder")), -1, result("TabOrder"))
                tabDetails.AuthorizedRoles = result("AuthorizedRoles").ToString
                tabDetails.AdministratorRoles = result("AdministratorRoles").ToString
                tabDetails.IsVisible = Boolean.Parse(result("IsVisible").ToString)
                tabDetails.DisableLink = Boolean.Parse(result("DisableLink").ToString)
                tabDetails.ParentId = result("ParentId")
                tabDetails.Level = result("Level")
                tabDetails.IconFile = result("IconFile").ToString
                tabDetails.AdminTabIcon = result("AdminTabIcon").ToString
                tabDetails.HasChildren = Boolean.Parse(result("HasChildren").ToString)

                Me.DesktopTabs.Add(tabDetails)

            End While

            If Me.ActiveTab.TabId = 0 And Me.DesktopTabs.Count > 0 Then
                Me.ActiveTab.TabId = CType(Me.DesktopTabs(0), TabStripDetails).TabId
            End If

            ' Read the next result --  Mobile Tab Information
            result.NextResult()

            While result.Read()

                Dim tabDetails As New TabStripDetails()

                tabDetails.TabId = Int32.Parse(result("TabId").ToString)
                tabDetails.TabName = result("MobileTabName").ToString
                tabDetails.AuthorizedRoles = result("AuthorizedRoles").ToString
                tabDetails.AdministratorRoles = result("AdministratorRoles").ToString
                tabDetails.IsVisible = Boolean.Parse(result("IsVisible").ToString)
                tabDetails.DisableLink = Boolean.Parse(result("DisableLink").ToString)
                tabDetails.ParentId = result("ParentId")
                tabDetails.Level = result("Level")
                tabDetails.IconFile = result("IconFile").ToString
                tabDetails.AdminTabIcon = result("AdminTabIcon").ToString
                tabDetails.HasChildren = Boolean.Parse(result("HasChildren").ToString)

                Me.MobileTabs.Add(tabDetails)

            End While

            ' Read the next result --  Module Tab Information
            result.NextResult()

            While result.Read()

                Dim m As New ModuleSettings()

                m.ModuleId = Int32.Parse(result("ModuleID").ToString)
                m.ModuleDefId = Int32.Parse(result("ModuleDefID").ToString)
                m.TabId = Int32.Parse(result("TabID").ToString)
                m.PaneName = result("PaneName").ToString
                m.ModuleTitle = result("ModuleTitle").ToString
                m.AuthorizedEditRoles = result("AuthorizedEditRoles").ToString
                m.CacheTime = Int32.Parse(result("CacheTime").ToString)
                m.ModuleOrder = Int32.Parse(result("ModuleOrder").ToString)
                m.ShowMobile = Boolean.Parse(result("ShowMobile").ToString)
                m.DesktopSrc = result("DesktopSrc").ToString
                m.MobileSrc = result("MobileSrc").ToString
                m.AuthorizedViewRoles = result("AuthorizedViewRoles").ToString
                m.Alignment = result("Alignment").ToString
                m.Color = result("Color").ToString
                m.Border = result("Border").ToString
                m.EditSrc = result("EditSrc").ToString
                m.IconFile = result("IconFile").ToString
                m.EditModuleIcon = result("EditModuleIcon").ToString
                m.Secure = result("Secure")
                m.AllTabs = result("AllTabs")
                m.ShowTitle = result("ShowTitle")
                m.Personalize = result("Personalize")
                m.Container = result("Container").ToString
                m.FriendlyName = result("FriendlyName")

                Me.ActiveTab.Modules.Add(m)

            End While
            result.Close()

            Me.HostSettings = GetHostSettings()

        End Sub

        Public Shared Function GetEditModuleSettings(ByVal ModuleId As Integer) As ModuleSettings

            ' Get Settings for this module from the database
            Dim _moduleSettings As New ModuleSettings()

            ' Create Instance of Connection and Command Object
            Dim myConnection As New SqlConnection(GetDBConnectionString)

            ' Generate Command Object based on Method
            Dim myCommand As SqlCommand = SqlCommandGenerator.GenerateCommand(myConnection, _
                CType(MethodBase.GetCurrentMethod(), MethodInfo), _
                New Object() {ModuleId}, , "GetModule")

            ' Execute the command
            myConnection.Open()
            Dim result As SqlDataReader = myCommand.ExecuteReader(CommandBehavior.CloseConnection)

            If result.Read() Then
                _moduleSettings.ModuleId = Int32.Parse(result("ModuleID").ToString)
                _moduleSettings.ModuleDefId = Int32.Parse(result("ModuleDefID").ToString)
                _moduleSettings.TabId = Int32.Parse(result("TabID").ToString)
                _moduleSettings.PaneName = "Edit"
                _moduleSettings.ModuleTitle = result("ModuleTitle").ToString
                _moduleSettings.AuthorizedEditRoles = result("AuthorizedEditRoles").ToString
                _moduleSettings.EditSrc = result("EditSrc").ToString
                _moduleSettings.Secure = result("Secure")
                _moduleSettings.EditModuleIcon = result("EditModuleIcon").ToString
                _moduleSettings.ShowTitle = True
                _moduleSettings.Personalize = 2
                _moduleSettings.FriendlyName = result("FriendlyName").ToString
            End If
            result.Close()

            Return _moduleSettings

        End Function

        '*********************************************************************
        '
        ' GetModuleSettings Static Method
        '
        ' The PortalSettings.GetModuleSettings Method returns a hashtable of
        ' custom module specific settings from the database.  This method is
        ' used by some user control modules (Xml, Image, etc) to access misc
        ' settings.
        '
        '*********************************************************************

        Public Shared Function GetModuleSettings(ByVal ModuleId As Integer) As Hashtable

            ' Get Settings for this module from the database
            Dim _settings As New Hashtable()

            ' Create Instance of Connection and Command Object
            Dim myConnection As New SqlConnection(GetDBConnectionString)

            ' Generate Command Object based on Method
            Dim myCommand As SqlCommand = SqlCommandGenerator.GenerateCommand(myConnection, _
                CType(MethodBase.GetCurrentMethod(), MethodInfo), _
                New Object() {ModuleId})

            ' Execute the command
            myConnection.Open()
            Dim result As SqlDataReader = myCommand.ExecuteReader(CommandBehavior.CloseConnection)

            While result.Read()
                _settings(result.GetString(0)) = result.GetString(1)
            End While
            result.Close()

            Return _settings

        End Function


        Private Function GetHostSettings() As Hashtable

            ' Get Settings for this module from the database
            Dim _settings As New Hashtable()

            ' Create Instance of Connection and Command Object
            Dim myConnection As New SqlConnection(GetDBConnectionString)

            ' Generate Command Object based on Method
            Dim myCommand As SqlCommand = SqlCommandGenerator.GenerateCommand(myConnection, _
                CType(MethodBase.GetCurrentMethod(), MethodInfo), _
                New Object() {})

            ' Execute the command
            myConnection.Open()
            Dim result As SqlDataReader = myCommand.ExecuteReader(CommandBehavior.CloseConnection)

            While result.Read()
                _settings(result.GetString(0)) = result.GetString(1)
            End While
            result.Close()

            Return _settings

        End Function


        Public Shared Function GetPortalByAlias(ByVal PortalAlias As String) As Integer

            GetPortalByAlias = -1

            If PortalAlias <> "" Then

                ' Create Instance of Connection and Command Object
                Dim myConnection As New SqlConnection(GetDBConnectionString)

                ' Generate Command Object based on Method
                Dim myCommand As SqlCommand = SqlCommandGenerator.GenerateCommand(myConnection, _
                    CType(MethodBase.GetCurrentMethod(), MethodInfo), _
                    New Object() {PortalAlias})

                ' Execute the command
                myConnection.Open()
                Dim result As SqlDataReader = myCommand.ExecuteReader(CommandBehavior.CloseConnection)

                If result.Read() Then
                    If Not IsDBNull(result("PortalId")) Then
                        GetPortalByAlias = result("PortalID")
                    End If
                End If
                result.Close()

            End If

            Return GetPortalByAlias

        End Function

        Public Shared Function GetPortalByTab(ByVal TabID As Integer, ByVal PortalAlias As String) As String

            ' Create Instance of Connection and Command Object
            Dim myConnection As New SqlConnection(GetDBConnectionString)

            ' Generate Command Object based on Method
            Dim myCommand As SqlCommand = SqlCommandGenerator.GenerateCommand(myConnection, _
                CType(MethodBase.GetCurrentMethod(), MethodInfo), _
                New Object() {TabID, PortalAlias})

            ' Execute the command
            myConnection.Open()
            Dim result As SqlDataReader = myCommand.ExecuteReader(CommandBehavior.CloseConnection)

            GetPortalByTab = Nothing

            If result.Read() Then
                If Not IsDBNull(result("PortalAlias")) Then
                    GetPortalByTab = result("PortalAlias")
                End If
            End If
            result.Close()

            Return GetPortalByTab

        End Function


        Private Sub GetBreadCrumbsRecursively(ByVal intTabId As Integer)
            Dim objAdmin As New AdminDB()

            Dim dr As SqlDataReader = objAdmin.GetTabById(intTabId)
            While dr.Read
                If Not IsDBNull(dr("ParentId")) Then
                    Dim tabDetails As New TabStripDetails()

                    tabDetails.TabId = intTabId.ToString
                    tabDetails.TabName = dr("TabName").ToString

                    Me.BreadCrumbs.Insert(0, tabDetails)

                    GetBreadCrumbsRecursively(dr("ParentId"))
                Else ' root tabid
                    Dim tabDetails As New TabStripDetails()

                    tabDetails.TabId = intTabId.ToString
                    tabDetails.TabName = dr("TabName").ToString

                    Me.BreadCrumbs.Insert(0, tabDetails)
                End If
            End While
            dr.Close()

        End Sub

        Public Shared Function GetVersion() As Integer

            GetVersion = 0

            ' Create Instance of Connection and Command Object
            Dim myConnection As New SqlConnection(GetDBConnectionString)

            ' check if database exists
            Dim myCommand As SqlCommand = SqlCommandGenerator.GenerateCommand(myConnection, _
                CType(MethodBase.GetCurrentMethod(), MethodInfo), _
                New Object() {}, CommandType.Text, "select 1 from Portals")

            Try
                myConnection.Open()
                myCommand.ExecuteNonQuery()
                myConnection.Close()
            Catch
                ' database does not exist
                GetVersion = -1
            End Try

            If GetVersion = 0 Then
                ' Generate Command Object based on Method
                myCommand = SqlCommandGenerator.GenerateCommand(myConnection, _
                    CType(MethodBase.GetCurrentMethod(), MethodInfo), _
                    New Object() {}, CommandType.Text, "select 'Build' = max(Build) from Version")

                Try
                    ' Execute the command
                    myConnection.Open()
                    Dim result As SqlDataReader = myCommand.ExecuteReader(CommandBehavior.CloseConnection)
                    If result.Read Then
                        If Not IsDBNull(result("Build")) Then
                            GetVersion = result("Build")
                        End If
                    End If
                    result.Close()
                Catch
                    ' table does not exist - GetVersion = 0
                End Try
            End If

        End Function


        Public Shared Sub UpdateVersion(ByVal Build As Integer)

            ' Create Instance of Connection and Command Object
            Dim myConnection As New SqlConnection(GetDBConnectionString)

            ' Generate Command Object based on Method
            Dim myCommand As SqlCommand = SqlCommandGenerator.GenerateCommand(myConnection, _
                CType(MethodBase.GetCurrentMethod(), MethodInfo), _
                New Object() {Build})

            Try
                myConnection.Open()
                myCommand.ExecuteNonQuery()
                myConnection.Close()
            Catch
                ' stored procedure does not exist
            End Try
        End Sub


        Public Shared Function FindVersion(ByVal intVersion As Integer) As Boolean

            FindVersion = False

            ' Create Instance of Connection and Command Object
            Dim myConnection As New SqlConnection(GetDBConnectionString)

            ' Generate Command Object based on Method
            Dim myCommand As SqlCommand = SqlCommandGenerator.GenerateCommand(myConnection, _
                CType(MethodBase.GetCurrentMethod(), MethodInfo), _
                New Object() {}, CommandType.Text, "select 1 from Version where Build = " & intVersion.ToString)

            Try
                ' Execute the command
                myConnection.Open()
                Dim result As SqlDataReader = myCommand.ExecuteReader(CommandBehavior.CloseConnection)
                If result.Read Then
                    FindVersion = True
                End If
                result.Close()
            Catch
                ' table does not exist
            End Try

        End Function

    End Class

End Namespace