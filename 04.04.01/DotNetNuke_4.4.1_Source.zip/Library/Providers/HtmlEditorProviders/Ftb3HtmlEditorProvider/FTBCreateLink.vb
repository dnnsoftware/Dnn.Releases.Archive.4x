'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2007
' by DotNetNuke Corporation
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.Web.UI
Imports DotNetNuke.Common
Imports DotNetNuke.Common.Utilities
Imports DotNetNuke.Entities.Portals
Imports DotNetNuke.Security

Namespace DotNetNuke.HtmlEditor

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' The FTBCreateLink Class provides the DNN Link control for the FTB Provider
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[jobrien]	20051101  created
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Public Class FTBCreateLink
        Inherits DotNetNuke.Framework.PageBase

        Protected WithEvents ctlURL As UI.UserControls.UrlControl
        Protected WithEvents phHidden As System.Web.UI.WebControls.PlaceHolder

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            ' set page title
            Dim strTitle As String = PortalSettings.PortalName & " > Insert Link"

            ' show copyright credits?
            If GetHashValue(Common.Globals.HostSettings("Copyright"), "Y") = "Y" Then
                strTitle += " ( DNN " & PortalSettings.Version & " )"
            End If
            Title = strTitle

            Dim htmlhidden As New HtmlControls.HtmlInputHidden
            Dim _portalSettings As PortalSettings = PortalController.GetCurrentPortalSettings

            htmlhidden.ID = "TargetFreeTextBox"
            htmlhidden.Value = Request.Params("ftb")
            phHidden.Controls.Add(htmlhidden)

            htmlhidden = New HtmlControls.HtmlInputHidden
            htmlhidden.ID = "DNNDomainNameTabid"
            htmlhidden.Value = "http://" & DotNetNuke.Common.GetDomainName(Request) & "/" & glbDefaultPage & "?tabid="
            phHidden.Controls.Add(htmlhidden)

            htmlhidden = New HtmlControls.HtmlInputHidden
            htmlhidden.ID = "DNNDomainNameFilePath"
            Dim homePath As String = _portalSettings.HomeDirectory
            If Request.ApplicationPath <> "/" Then homePath = Replace(_portalSettings.HomeDirectory, Request.ApplicationPath, "")
            htmlhidden.Value = "http://" & DotNetNuke.Common.GetDomainName(Request) & homePath

            phHidden.Controls.Add(htmlhidden)

        End Sub

    End Class

End Namespace

