'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2007
' by DotNetNuke Corporation
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports System.Collections.Specialized
Imports System.Text
Imports System.Xml
Imports System.IO

Namespace DotNetNuke.Services.EventQueue
    Public Enum MessagePriority
        High
        Medium
        Low
    End Enum

    Public Class EventMessage

        Private _id As String
        Private _processorType As String
        Private _body As String
        Private _priority As MessagePriority
        Private _attributes As NameValueCollection
        Private _sender As String
        Private _subscribers As String
        Private _authorizedRoles As String
        Private _expirationDate As DateTime
        Private _exceptionMessage As String
        Private _sentDate As DateTime

        Public Sub New()
            _id = Guid.NewGuid.ToString()
            _processorType = ""
            _body = ""
            _priority = MessagePriority.Low
            _attributes = New NameValueCollection
            _sender = ""
            _subscribers = ""
            _authorizedRoles = ""
            _exceptionMessage = ""
        End Sub
        Public ReadOnly Property ID() As String
            Get
                Return _id
            End Get
        End Property

        Public Property ProcessorType() As String
            Get
                Return _processorType
            End Get
            Set(ByVal Value As String)
                _processorType = Value
            End Set
        End Property
        Public Property Body() As String
            Get
                Return _body
            End Get
            Set(ByVal Value As String)
                _body = Value
            End Set
        End Property

        Public Property Sender() As String
            Get
                Return _sender
            End Get
            Set(ByVal Value As String)
                _sender = Value
            End Set
        End Property
        Public Property Subscribers() As String
            Get
                Return _subscribers
            End Get
            Set(ByVal Value As String)
                _subscribers = Value
            End Set
        End Property
        Public Property AuthorizedRoles() As String
            Get
                Return _authorizedRoles
            End Get
            Set(ByVal Value As String)
                _authorizedRoles = Value
            End Set
        End Property
        Public Property Priority() As MessagePriority
            Get
                Return _priority
            End Get
            Set(ByVal Value As MessagePriority)
                _priority = Value
            End Set
        End Property

        Public Property ExceptionMessage() As String
            Get
                Return _exceptionMessage
            End Get
            Set(ByVal Value As String)
                _exceptionMessage = Value
            End Set
        End Property
        Public Property SentDate() As DateTime
            Get
                Return _sentDate.ToLocalTime
            End Get
            Set(ByVal Value As DateTime)
                _sentDate = Value.ToUniversalTime
            End Set
        End Property
        Public Property ExpirationDate() As DateTime
            Get
                Return _expirationDate.ToLocalTime
            End Get
            Set(ByVal Value As DateTime)
                _expirationDate = Value.ToUniversalTime
            End Set
        End Property
        Public Property Attributes() As NameValueCollection
            Get
                Return _attributes
            End Get
            Set(ByVal Value As NameValueCollection)
                _attributes = Value
            End Set
        End Property


        Public Function Serialize() As String
            Dim configXML As New StringBuilder("<?xml version=""1.0"" encoding=""utf-8""?>")
            configXML.Append(ControlChars.CrLf)
            configXML.Append("<EventMessage>")
            configXML.Append(ControlChars.CrLf)
            configXML.Append(ControlChars.Tab)
            configXML.Append(GetXMLNodeString("ID", _id))
            configXML.Append(ControlChars.CrLf)
            configXML.Append(ControlChars.Tab)
            configXML.Append(GetXMLNodeString("Priority", _priority.ToString()))
            configXML.Append(ControlChars.CrLf)
            configXML.Append(ControlChars.Tab)
            configXML.Append(GetXMLNodeString("ProcessorType", _processorType))
            configXML.Append(ControlChars.CrLf)
            configXML.Append(ControlChars.Tab)
            configXML.Append(GetXMLNodeString("Body", _body))
            configXML.Append(ControlChars.CrLf)
            configXML.Append(ControlChars.Tab)
            configXML.Append(GetXMLNodeString("Sender", _sender))
            configXML.Append(ControlChars.CrLf)
            configXML.Append(ControlChars.Tab)
            configXML.Append(GetXMLNodeString("Subscribers", _subscribers))
            configXML.Append(ControlChars.CrLf)
            configXML.Append(ControlChars.Tab)
            configXML.Append(GetXMLNodeString("AuthorizedRoles", _authorizedRoles))
            configXML.Append(ControlChars.CrLf)
            configXML.Append(ControlChars.Tab)
            configXML.Append(GetXMLNodeString("ExceptionMessage", _exceptionMessage))
            configXML.Append(ControlChars.CrLf)
            configXML.Append(ControlChars.Tab)
            configXML.Append(GetXMLNodeString("SentDate", _sentDate.ToString("yyyy-MM-ddTHH:mm:ss.fffffffZ", CultureInfo.InvariantCulture)))
            configXML.Append(ControlChars.CrLf)
            configXML.Append(ControlChars.Tab)
            configXML.Append(GetXMLNodeString("ExpirationDate", _expirationDate.ToString("yyyy-MM-ddTHH:mm:ss.fffffffZ", CultureInfo.InvariantCulture)))
            configXML.Append(ControlChars.CrLf)
            configXML.Append(ControlChars.Tab)
            configXML.Append("<Attributes>")
            For Each key As String In Me.Attributes.Keys
                configXML.Append(ControlChars.CrLf)
                configXML.Append(ControlChars.Tab, 2)
                configXML.Append("<Attribute>")
                configXML.Append(ControlChars.CrLf)
                configXML.Append(ControlChars.Tab, 3)
                configXML.Append(GetXMLNodeString("Name", key))
                configXML.Append(ControlChars.CrLf)
                configXML.Append(ControlChars.Tab, 3)
                configXML.Append(GetXMLNodeString("Value", Me.Attributes(key)))
                configXML.Append(ControlChars.CrLf)
                configXML.Append(ControlChars.Tab, 2)
                configXML.Append("</Attribute>")
            Next
            configXML.Append(ControlChars.CrLf)
            configXML.Append(ControlChars.Tab)
            configXML.Append("</Attributes>")
            configXML.Append(ControlChars.CrLf)
            configXML.Append("</EventMessage>")
            Return configXML.ToString()
        End Function
        Private Function GetXMLNodeString(ByVal xmlNodeName As String, ByVal xmlNodeValue As String) As String
            Dim xmlNodeString As New StringBuilder("<")
            xmlNodeString.Append(xmlNodeName)
            If xmlNodeValue = "" Then
                xmlNodeString.Append("/>")
            ElseIf xmlNodeValue.IndexOfAny("<'>""&".ToCharArray) > -1 Then
                xmlNodeString.Append(">")
                xmlNodeString.Append("<![CDATA[")
                xmlNodeString.Append(xmlNodeValue)
                xmlNodeString.Append("]]></")
                xmlNodeString.Append(xmlNodeName)
                xmlNodeString.Append(">")
            Else
                xmlNodeString.Append(">")
                xmlNodeString.Append(xmlNodeValue)
                xmlNodeString.Append("</")
                xmlNodeString.Append(xmlNodeName)
                xmlNodeString.Append(">")
            End If
            Return xmlNodeString.ToString
        End Function
        Public Sub Deserialize(ByVal configXml As String)
            Dim oXMLTextReader As New XmlTextReader(New StringReader(configXml))
            oXMLTextReader.MoveToContent()
            While oXMLTextReader.Read
                If oXMLTextReader.NodeType = XmlNodeType.Element Then
                    Select Case oXMLTextReader.Name.ToUpper
                        Case "ID"
                            oXMLTextReader.Read()
                            _id = oXMLTextReader.Value
                        Case "PRIORITY"
                            oXMLTextReader.Read()
                            _priority = CType([Enum].Parse(GetType(MessagePriority), oXMLTextReader.Value), MessagePriority)
                        Case "PROCESSORTYPE"
                            oXMLTextReader.Read()
                            _processorType = oXMLTextReader.Value
                        Case "BODY"
                            oXMLTextReader.Read()
                            _body = oXMLTextReader.Value
                        Case "SENDER"
                            oXMLTextReader.Read()
                            _sender = oXMLTextReader.Value
                        Case "SUBSCRIBERS"
                            oXMLTextReader.Read()
                            _subscribers = oXMLTextReader.Value
                        Case "AUTHORIZEDROLES"
                            oXMLTextReader.Read()
                            _authorizedRoles = oXMLTextReader.Value
                        Case "EXCEPTIONMESSAGE"
                            oXMLTextReader.Read()
                            _exceptionMessage = oXMLTextReader.Value
                        Case "EXPIRATIONDATE"
                            oXMLTextReader.Read()
                            _expirationDate = DateTime.Parse(oXMLTextReader.Value, CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.AdjustToUniversal)
                        Case "SENTDATE"
                            oXMLTextReader.Read()
                            _sentDate = DateTime.Parse(oXMLTextReader.Value, CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.AdjustToUniversal)
                        Case "ATTRIBUTES"
                            'move to the first Attribute node of the EventMessage
                            ReadToFollowing(oXMLTextReader, "Attribute")
                            _attributes = New NameValueCollection
                            While oXMLTextReader.Name.ToUpper <> "ATTRIBUTES"
                                If oXMLTextReader.NodeType = XmlNodeType.Element And _
                                    oXMLTextReader.Name.ToUpper = "ATTRIBUTE" Then
                                    'move to the Name node of the Message Attribute
                                    ReadToFollowing(oXMLTextReader, "Name")
                                    Dim attName As String = oXMLTextReader.ReadString
                                    'move to the Value node of the Message Attribute
                                    ReadToFollowing(oXMLTextReader, "Value")
                                    _attributes.Add(attName, oXMLTextReader.ReadString)
                                End If
                                'move to the Next Element
                                oXMLTextReader.Read()
                            End While
                    End Select
                End If
            End While

        End Sub
        'This Private sub is here so that ReadToFollowing can be used in ASP.Net 1.1 and ASP.Net 2.0 with the same code
        Private Sub ReadToFollowing(ByRef oXMLTextReader As XmlTextReader, ByVal NodeName As String)
            While oXMLTextReader.Read
                If oXMLTextReader.NodeType = XmlNodeType.Element And oXMLTextReader.Name.ToUpper = NodeName.ToUpper Then
                    Return
                End If
            End While

        End Sub
    End Class
End Namespace

