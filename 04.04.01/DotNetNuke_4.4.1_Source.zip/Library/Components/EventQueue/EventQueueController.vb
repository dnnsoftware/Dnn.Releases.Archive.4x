'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2007
' by DotNetNuke Corporation
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.IO
Imports System.Web
Imports System.Xml
Imports System.Xml.XPath
Imports DotNetNuke
Imports DotNetNuke.Common
Imports DotNetNuke.Common.Utilities
Imports DotNetNuke.Services.EventQueue.Config
Imports DotNetNuke.Security

Namespace DotNetNuke.Services.EventQueue

    Public Class EventQueueController
        Private m_messagePath As String
        Public Sub New()
            m_messagePath = HostMapPath & "EventQueue\"
        End Sub

        Public Function GetMessage(ByVal eventName As String, ByVal subscriberId As String, ByVal messageId As String) As EventMessage
            Return DeserializeMessage(m_messagePath & MessageName(eventName, subscriberId, messageId), subscriberId)
        End Function

        Public Function GetMessages(ByVal eventName As String) As EventMessageCollection
            Dim oEventMessageCollection As New EventMessageCollection
            Dim EventMessageFiles() As String
            Dim EventMessageFile As String
            Dim subscribers(-1) As String
            If Not IsNothing(Config.EventQueueConfiguration.GetConfig().PublishedEvents(eventName)) Then
                subscribers = Config.EventQueueConfiguration.GetConfig().PublishedEvents(eventName).Subscribers().Split(";".ToCharArray())
            Else
                subscribers(0) = ""
            End If
            For indx As Integer = 0 To subscribers.Length - 1
                EventMessageFiles = Directory.GetFiles(m_messagePath, MessageName(eventName, subscribers(indx), "*"))
                For Each EventMessageFile In EventMessageFiles
                    oEventMessageCollection.Add(DeserializeMessage(EventMessageFile, subscribers(indx)))
                Next
            Next
            Return oEventMessageCollection
        End Function
        Public Function GetMessages(ByVal eventName As String, ByVal subscriberId As String) As EventMessageCollection
            Dim oEventMessageCollection As New EventMessageCollection
            Dim EventMessageFiles() As String
            Dim EventMessageFile As String
            EventMessageFiles = Directory.GetFiles(m_messagePath, MessageName(eventName, subscriberId, "*"))
            For Each EventMessageFile In EventMessageFiles
                oEventMessageCollection.Add(DeserializeMessage(EventMessageFile, subscriberId))
            Next
            Return oEventMessageCollection
        End Function
        Public Function ProcessMessages(ByVal eventName As String) As Boolean
            Return ProcessMessages(GetMessages(eventName))
        End Function
        Public Function ProcessMessages(ByVal eventName As String, ByVal subscriberId As String) As Boolean
            Return ProcessMessages(GetMessages(eventName, subscriberId))
        End Function

        Public Function ProcessMessages(ByVal eventMessages As EventMessageCollection) As Boolean

            Dim message As EventMessage
            For Each message In eventMessages
                Try
                    Dim oMessageProcessor As Object = Framework.Reflection.CreateObject(message.ProcessorType, message.ProcessorType)
                    If Not CType(oMessageProcessor, EventMessageProcessorBase).ProcessMessage(message) Then
                        Throw New Exception
                    End If
                Catch
                    'log if message could not be processed
                    Dim objEventLog As New Services.Log.EventLog.EventLogController
                    Dim objEventLogInfo As New Services.Log.EventLog.LogInfo
                    objEventLogInfo.AddProperty("EventQueue.ProcessMessage", "Message Processing Failed")
                    objEventLogInfo.AddProperty("ProcessorType", message.ProcessorType)
                    objEventLogInfo.AddProperty("Body", message.Body)
                    objEventLogInfo.AddProperty("Sender", message.Sender)
                    For Each key As String In message.Attributes.Keys
                        objEventLogInfo.AddProperty(key, message.Attributes(key))
                    Next
                    If message.ExceptionMessage.Length > 0 Then
                        objEventLogInfo.AddProperty("ExceptionMessage", message.ExceptionMessage)
                    End If
                    objEventLogInfo.LogTypeKey = Services.Log.EventLog.EventLogController.EventLogType.HOST_ALERT.ToString
                    objEventLog.AddLog(objEventLogInfo)

                End Try
            Next
        End Function
        Public Function SendMessage(ByVal message As EventMessage, ByVal eventName As String) As Boolean
            SendMessage(message, eventName, False)
        End Function
        Public Function SendMessage(ByVal message As EventMessage, ByVal eventName As String, ByVal encryptMessage As Boolean) As Boolean

            'set the sent date if it wasn't set by the sender
            If IsNothing(message.SentDate) Then
                message.SentDate = DateTime.Now
            End If

            Dim subscribers(-1) As String
            If Not IsNothing(Config.EventQueueConfiguration.GetConfig().PublishedEvents(eventName)) Then
                subscribers = Config.EventQueueConfiguration.GetConfig().PublishedEvents(eventName).Subscribers().Split(";".ToCharArray())
            Else
                subscribers(0) = ""
            End If
            'send a message for each subscriber of the specified event
            For indx As Integer = 0 To subscribers.Length - 1
                Dim oStream As StreamWriter = File.CreateText(m_messagePath & MessageName(eventName, subscribers(indx), message.ID))
                Dim messageString As String = message.Serialize()
                If encryptMessage Then
                    Dim oPortalSecurity As New PortalSecurity
                    messageString = oPortalSecurity.Encrypt(Config.EventQueueConfiguration.GetConfig().EventQueueSubscribers(subscribers(indx)).PrivateKey, messageString)
                End If
                oStream.WriteLine(messageString)
                oStream.Close()
            Next

            Return True

        End Function

        Private Function DeserializeMessage(ByVal filePath As String, ByVal subscriberId As String) As EventMessage

            Dim message As New EventMessage
            Dim oStreamReader As StreamReader = File.OpenText(filePath)
            Dim messageString As String = oStreamReader.ReadToEnd
            If messageString.IndexOf("EventMessage") < 0 Then
                Dim oPortalSecurity As New PortalSecurity
                messageString = oPortalSecurity.Decrypt(Config.EventQueueConfiguration.GetConfig().EventQueueSubscribers(subscriberId).PrivateKey, messageString)
            End If
            message.Deserialize(messageString)
            oStreamReader.Close()

            'remove the persisted message from the queue if it has expired
            If message.ExpirationDate < System.DateTime.Now Then
                File.Delete(filePath)
            End If

            Return message

        End Function
        Private Function MessageName(ByVal eventName As String, ByVal subscriberId As String, ByVal messageId As String) As String
            Return eventName & "-" & subscriberId & "-" & messageId & ".config"
        End Function
    End Class

End Namespace
