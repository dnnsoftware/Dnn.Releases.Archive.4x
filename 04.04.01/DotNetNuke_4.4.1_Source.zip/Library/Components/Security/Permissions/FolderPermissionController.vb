'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2007
' by DotNetNuke Corporation
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports System
Imports System.Data
Imports DotNetNuke

Namespace DotNetNuke.Security.Permissions

#Region "FolderPermissionController"
    Public Class FolderPermissionController

#Region "Private Members"

        Private Function FillFolderPermissionCollection(ByVal dr As IDataReader) As FolderPermissionCollection
            Dim arr As New FolderPermissionCollection()
            Try
                Dim obj As FolderPermissionInfo
                While dr.Read
                    ' fill business object
                    obj = FillFolderPermissionInfo(dr, False)
                    ' add to collection
                    arr.Add(obj)
                End While
            Catch exc As Exception
                LogException(exc)
            Finally
                ' close datareader
                If Not dr Is Nothing Then
                    dr.Close()
                End If
            End Try
            Return arr
        End Function

        Private Function FillFolderPermissionInfoList(ByVal dr As IDataReader) As ArrayList
            Dim arr As New ArrayList
            Try
                Dim obj As FolderPermissionInfo
                While dr.Read
                    ' fill business object
                    obj = FillFolderPermissionInfo(dr, False)
                    ' add to collection
                    arr.Add(obj)
                End While
            Catch exc As Exception
                LogException(exc)
            Finally
                ' close datareader
                If Not dr Is Nothing Then
                    dr.Close()
                End If
            End Try
            Return arr
        End Function

        Private Function FillFolderPermissionInfo(ByVal dr As IDataReader) As FolderPermissionInfo
            Return FillFolderPermissionInfo(dr, True)
        End Function

        Private Function FillFolderPermissionInfo(ByVal dr As IDataReader, ByVal CheckForOpenDataReader As Boolean) As FolderPermissionInfo
            Dim permissionInfo As FolderPermissionInfo

            ' read datareader
            Dim canContinue As Boolean = True
            If CheckForOpenDataReader Then
                canContinue = False
                If dr.Read Then
                    canContinue = True
                End If
            End If

            If canContinue Then
                permissionInfo = New FolderPermissionInfo()
                permissionInfo.FolderPermissionID = Convert.ToInt32(Null.SetNull(dr("FolderPermissionID"), permissionInfo.FolderPermissionID))
                permissionInfo.FolderID = Convert.ToInt32(Null.SetNull(dr("FolderID"), permissionInfo.FolderID))
                permissionInfo.FolderPath = Convert.ToString(Null.SetNull(dr("FolderPath"), permissionInfo.FolderPath))
                permissionInfo.PermissionID = Convert.ToInt32(Null.SetNull(dr("PermissionID"), permissionInfo.PermissionID))
                permissionInfo.RoleID = Convert.ToInt32(Null.SetNull(dr("RoleID"), permissionInfo.RoleID))
                permissionInfo.RoleName = Convert.ToString(Null.SetNull(dr("RoleName"), permissionInfo.RoleName))
                permissionInfo.AllowAccess = Convert.ToBoolean(Null.SetNull(dr("AllowAccess"), permissionInfo.AllowAccess))
                permissionInfo.PermissionCode = Convert.ToString(Null.SetNull(dr("PermissionCode"), permissionInfo.PermissionCode))
                permissionInfo.PermissionKey = Convert.ToString(Null.SetNull(dr("PermissionKey"), permissionInfo.PermissionKey))
                permissionInfo.PermissionName = Convert.ToString(Null.SetNull(dr("PermissionName"), permissionInfo.PermissionName))
            Else
                permissionInfo = Nothing
            End If

            Return permissionInfo

        End Function

#End Region

        Public Function AddFolderPermission(ByVal objFolderPermission As FolderPermissionInfo) As Integer
            Return CType(DataProvider.Instance().AddFolderPermission(objFolderPermission.FolderID, objFolderPermission.PermissionID, objFolderPermission.RoleID, objFolderPermission.AllowAccess), Integer)
        End Function

        Public Sub DeleteFolderPermission(ByVal FolderPermissionID As Integer)
            DataProvider.Instance().DeleteFolderPermission(FolderPermissionID)
        End Sub

        Public Sub DeleteFolderPermissionsByFolder(ByVal PortalID As Integer, ByVal FolderPath As String)
            DataProvider.Instance().DeleteFolderPermissionsByFolderPath(PortalID, FolderPath)
        End Sub

        Public Function GetFolderPermission(ByVal FolderPermissionID As Integer) As FolderPermissionInfo
            Dim permission As FolderPermissionInfo

            'Get permission from Database
            Dim dr As IDataReader = DataProvider.Instance().GetFolderPermission(FolderPermissionID)
            Try
                permission = FillFolderPermissionInfo(dr)
            Finally
                If Not dr Is Nothing Then
                    dr.Close()
                End If
            End Try

            Return permission
        End Function

        Public Function GetFolderPermissionsByFolder(ByVal PortalID As Integer, ByVal Folder As String) As ArrayList
            Return FillFolderPermissionInfoList(DataProvider.Instance().GetFolderPermissionsByFolderPath(PortalID, Folder, -1))
        End Function

        Public Function GetFolderPermissionsByFolder(ByVal arrFolderPermissions As ArrayList, ByVal FolderPath As String) As Security.Permissions.FolderPermissionCollection
            Dim p As New Security.Permissions.FolderPermissionCollection

            Dim i As Integer
            For i = 0 To arrFolderPermissions.Count - 1
                Dim objFolderPermission As Security.Permissions.FolderPermissionInfo = CType(arrFolderPermissions(i), Security.Permissions.FolderPermissionInfo)
                If objFolderPermission.FolderPath = FolderPath Then
                    p.Add(objFolderPermission)
                End If
            Next
            Return p
        End Function

        Public Function GetFolderPermissionsByFolderPath(ByVal arrFolderPermissions As ArrayList, ByVal FolderPath As String, ByVal PermissionKey As String) As String
            Dim strRoles As String = ";"
            Dim i As Integer
            For i = 0 To arrFolderPermissions.Count - 1
                Dim objFolderPermission As Security.Permissions.FolderPermissionInfo = CType(arrFolderPermissions(i), Security.Permissions.FolderPermissionInfo)
                If objFolderPermission.FolderPath = FolderPath AndAlso objFolderPermission.AllowAccess = True AndAlso objFolderPermission.PermissionKey = PermissionKey Then
                    strRoles += objFolderPermission.RoleName + ";"
                End If
            Next
            Return strRoles
        End Function

        Public Function GetFolderPermissionsCollectionByFolderPath(ByVal PortalID As Integer, ByVal FolderPath As String) As Security.Permissions.FolderPermissionCollection
            Return FillFolderPermissionCollection(DataProvider.Instance().GetFolderPermissionsByFolderPath(PortalID, FolderPath, -1))
        End Function

        Public Function GetFolderPermissionsCollectionByFolderPath(ByVal arrFolderPermissions As ArrayList, ByVal FolderPath As String) As Security.Permissions.FolderPermissionCollection
            Dim objFolderPermissionCollection As New Security.Permissions.FolderPermissionCollection(arrFolderPermissions, FolderPath)
            Return objFolderPermissionCollection
        End Function

        Public Shared Function HasFolderPermission(ByVal objFolderPermissions As Security.Permissions.FolderPermissionCollection, ByVal PermissionKey As String) As Boolean
            Dim m As Security.Permissions.FolderPermissionCollection = objFolderPermissions
            Dim i As Integer
            For i = 0 To m.Count - 1
                Dim mp As Security.Permissions.FolderPermissionInfo
                mp = m(i)
                If mp.PermissionKey = PermissionKey AndAlso PortalSecurity.IsInRoles(mp.RoleName) Then
                    Return True
                End If
            Next
            Return False
        End Function

        Public Sub UpdateFolderPermission(ByVal objFolderPermission As FolderPermissionInfo)
            DataProvider.Instance().UpdateFolderPermission(objFolderPermission.FolderPermissionID, objFolderPermission.FolderID, objFolderPermission.PermissionID, objFolderPermission.RoleID, objFolderPermission.AllowAccess)
        End Sub

    End Class
#End Region


End Namespace
