'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2006
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports ICSharpCode.SharpZipLib.Zip
Imports ICSharpCode.SharpZipLib.Checksums
Imports ICSharpCode.SharpZipLib.GZip
Imports System.IO
Imports System.Xml
Imports System.Xml.Serialization
Imports DotNetNuke.Modules.Admin.ResourceInstaller
Imports DotNetNuke.Entities.Modules.Definitions
Imports DotNetNuke.Services.Localization
Imports DotNetNuke.Framework.Providers

Namespace DotNetNuke.Entities.Modules

    ''' -----------------------------------------------------------------------------
    ''' Project  : DotNetNuke
    ''' Class  : PaWriter
    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' The PaWriter class packages a Module as a Private Assembly.
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    '''  [cnurse] 01/13/2005 created
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Public Class PaWriter

#Region "Private Members"

        Private _ProgressLog As New PaLogger
        Private _IncludeSource As Boolean = False
        Private _ZipFile As String

        'Source Folder of PA
        Private _Folder As String
        Private _AppCodeFolder As String

        'Name of PA
        Private _Name As String

        'List of Files to include in PA
        Private _Files As New ArrayList


#End Region

#Region "Constructors"

        Public Sub New()
            Me.New(False, "")
        End Sub

        Public Sub New(ByVal IncludeSource As Boolean, ByVal ZipFile As String)
            _IncludeSource = IncludeSource
            _ZipFile = ZipFile
        End Sub

#End Region

#Region "Public Properties"

        Public Property IncludeSource() As Boolean
            Get
                Return _IncludeSource
            End Get
            Set(ByVal Value As Boolean)
                _IncludeSource = Value
            End Set
        End Property

        Public ReadOnly Property ProgressLog() As PaLogger
            Get
                Return _ProgressLog
            End Get
        End Property

        Public Property ZipFile() As String
            Get
                Return _ZipFile
            End Get
            Set(ByVal Value As String)
                _ZipFile = Value
            End Set
        End Property

#End Region

#Region "Private Methods"

        Private Sub AddFile(ByVal File As PaFileInfo, ByVal AllowUnsafeExtensions As Boolean)
            Dim objPaFileInfo As PaFileInfo
            Dim blnAdd As Boolean = True
            For Each objPaFileInfo In _Files
                If objPaFileInfo.FullName = File.FullName Then
                    blnAdd = False
                    Exit For
                End If
            Next
            If Not AllowUnsafeExtensions Then
                If Right(File.FullName, 3).ToLower = "dnn" Then blnAdd = False
            End If

            If blnAdd Then
                _Files.Add(File)
            End If

        End Sub

        Private Sub AddFile(ByVal File As PaFileInfo)
            AddFile(File, False)
        End Sub

        Private Sub CreateDnnManifest(ByVal objDesktopModule As DesktopModuleInfo)

            Dim filename As String = ""
            _Name = objDesktopModule.ModuleName
            _Folder = Common.Globals.ApplicationMapPath & "\DesktopModules\" & objDesktopModule.FolderName
            _AppCodeFolder = Common.Globals.ApplicationMapPath & "\App_Code\" & objDesktopModule.FolderName

            'Create Manifest Document
            Dim xmlManifest As New XmlDocument

            'Root Element
            Dim nodeRoot As XmlNode = xmlManifest.CreateElement("dotnetnuke")
            nodeRoot.Attributes.Append(XmlUtils.CreateAttribute(xmlManifest, "version", "3.0"))
            nodeRoot.Attributes.Append(XmlUtils.CreateAttribute(xmlManifest, "type", "Module"))

            'Folders Element
            Dim nodeFolders As XmlNode = xmlManifest.CreateElement("folders")
            nodeRoot.AppendChild(nodeFolders)

            'Folder Element
            Dim nodeFolder As XmlNode = xmlManifest.CreateElement("folder")
            nodeFolders.AppendChild(nodeFolder)

            'Desktop Module Info
            nodeFolder.AppendChild(XmlUtils.CreateElement(xmlManifest, "name", _Name))
            nodeFolder.AppendChild(XmlUtils.CreateElement(xmlManifest, "friendlyname", objDesktopModule.FriendlyName))
            nodeFolder.AppendChild(XmlUtils.CreateElement(xmlManifest, "foldername", objDesktopModule.FolderName))
            nodeFolder.AppendChild(XmlUtils.CreateElement(xmlManifest, "modulename", _Name))
            nodeFolder.AppendChild(XmlUtils.CreateElement(xmlManifest, "description", objDesktopModule.Description))
            If objDesktopModule.Version = Null.NullString Then
                objDesktopModule.Version = "01.00.00"
            End If
            nodeFolder.AppendChild(XmlUtils.CreateElement(xmlManifest, "version", objDesktopModule.Version))
            nodeFolder.AppendChild(XmlUtils.CreateElement(xmlManifest, "businesscontrollerclass", objDesktopModule.BusinessControllerClass))

            'Add Source files
            'If _IncludeSource Then
            '    Dim resourcesFile As String = objDesktopModule.ModuleName & "_Source.zip"
            '    CreateResourceFile(_Folder & "\" & resourcesFile)
            '    nodeFolder.AppendChild(XmlUtils.CreateElement(xmlManifest, "resourcefile", resourcesFile))
            'End If

            'Modules Element
            Dim nodeModules As XmlNode = xmlManifest.CreateElement("modules")
            nodeFolder.AppendChild(nodeModules)

            'Get the Module Definitions for this Module
            Dim objModuleDefinitionController As New ModuleDefinitionController
            Dim arrModuleDefinitions As ArrayList = objModuleDefinitionController.GetModuleDefinitions(objDesktopModule.DesktopModuleID)

            'Iterate through Module Definitions
            For Each objModuleInfo As ModuleDefinitionInfo In arrModuleDefinitions
                Dim nodeModule As XmlNode = xmlManifest.CreateElement("module")

                'Add module definition properties
                nodeModule.AppendChild(XmlUtils.CreateElement(xmlManifest, "friendlyname", objModuleInfo.FriendlyName))

                'Add Cache properties
                nodeModule.AppendChild(XmlUtils.CreateElement(xmlManifest, "cachetime", objModuleInfo.DefaultCacheTime.ToString))


                'Get the Module Controls for this Module Definition
                Dim objModuleControlController As New ModuleControlController
                Dim arrModuleControls As ArrayList = objModuleControlController.GetModuleControls(objModuleInfo.ModuleDefID)

                'Controls Element
                Dim nodeControls As XmlNode = xmlManifest.CreateElement("controls")
                nodeModule.AppendChild(nodeControls)

                'Iterate through Module Controls
                For Each objModuleControl As ModuleControlInfo In arrModuleControls
                    Dim nodeControl As XmlNode = xmlManifest.CreateElement("control")

                    'Dim src As String = objModuleControl.ControlSrc.Replace("DesktopModules/" & _Name & "/", "")

                    'Add module control properties
                    XmlUtils.AppendElement(xmlManifest, nodeControl, "key", objModuleControl.ControlKey, False)
                    XmlUtils.AppendElement(xmlManifest, nodeControl, "title", objModuleControl.ControlTitle, False)

                    XmlUtils.AppendElement(xmlManifest, nodeControl, "src", objModuleControl.ControlSrc, True)
                    XmlUtils.AppendElement(xmlManifest, nodeControl, "iconfile", objModuleControl.IconFile, False)
                    XmlUtils.AppendElement(xmlManifest, nodeControl, "type", objModuleControl.ControlType.ToString, True)
                    XmlUtils.AppendElement(xmlManifest, nodeControl, "helpurl", objModuleControl.HelpURL, False)

                    'Add control Node to controls
                    nodeControls.AppendChild(nodeControl)

                    'Determine the filename for the Manifest file (It should be saved with the other Module files)
                    If filename = "" Then
                        filename = _Folder & "\" & objDesktopModule.ModuleName + ".dnn"
                    End If
                Next

                'Add module Node to modules
                nodeModules.AppendChild(nodeModule)
            Next

            'Create File List
            CreateFileList()

            'Files Element
            Dim nodeFiles As XmlNode = xmlManifest.CreateElement("files")
            nodeFolder.AppendChild(nodeFiles)

            'Add the files
            For Each file As PaFileInfo In _Files
                Dim nodeFile As XmlNode = xmlManifest.CreateElement("file")

                'Add file properties
                XmlUtils.AppendElement(xmlManifest, nodeFile, "path", file.Path, False)
                XmlUtils.AppendElement(xmlManifest, nodeFile, "name", file.Name, False)

                'Add file Node to files
                nodeFiles.AppendChild(nodeFile)
            Next

            'Add Root element to document
            xmlManifest.AppendChild(nodeRoot)

            'Save Manifest file
            xmlManifest.Save(filename)

            'Add Manifest file to file list
            AddFile(New PaFileInfo(objDesktopModule.ModuleName & ".dnn", "", _Folder), True)

        End Sub

        Private Sub CreateFileList()

            'Add the files in the DesktopModules Folder
            ParseFolder(_Folder, _Folder)

            'Add the files in the AppCode Folder
            ParseFolder(_AppCodeFolder, _AppCodeFolder)

        End Sub

        Private Function CreateZipFile() As String
            Dim CompressionLevel As Integer = 9
            Dim ZipFileShortName As String = _Name
            Dim ZipFileName As String = _ZipFile
            If ZipFileName = "" Then
                ZipFileName = ZipFileShortName & ".zip"
            End If
            ZipFileName = Common.Globals.HostMapPath & ZipFileName

            Dim strmZipFile As FileStream = Nothing
            Try
                ProgressLog.AddInfo(String.Format(Localization.GetString("LOG.PAWriter.CreateArchive"), ZipFileShortName))
                strmZipFile = File.Create(ZipFileName)
                Dim strmZipStream As ZipOutputStream = Nothing
                Try
                    strmZipStream = New ZipOutputStream(strmZipFile)
                    strmZipStream.SetLevel(CompressionLevel)
                    For Each PaFile As PaFileInfo In _Files
                        FileSystemUtils.AddToZip(strmZipStream, PaFile.FullName, PaFile.Name, "")
                        ProgressLog.AddInfo(String.Format(Localization.GetString("LOG.PAWriter.SavedFile"), PaFile.Name))
                    Next
                Catch ex As Exception
                    LogException(ex)
                    ProgressLog.AddFailure(String.Format(Localization.GetString("LOG.PAWriter.ERROR.SavingFile"), ex))
                Finally
                    If Not strmZipStream Is Nothing Then
                        strmZipStream.Finish()
                        strmZipStream.Close()
                    End If
                End Try
            Catch ex As Exception
                LogException(ex)
                ProgressLog.AddFailure(String.Format(Localization.GetString("LOG.PAWriter.ERROR.SavingFile"), ex))
            Finally
                If Not strmZipFile Is Nothing Then
                    strmZipFile.Close()
                End If
            End Try

            Return ZipFileName
        End Function

        Private Sub ParseFolder(ByVal folderName As String, ByVal rootPath As String)

            Dim folder As DirectoryInfo = New DirectoryInfo(folderName)

            'Recursively parse the subFolders
            Dim subFolders As DirectoryInfo() = folder.GetDirectories()
            For Each subFolder As DirectoryInfo In subFolders
                ParseFolder(subFolder.FullName, rootPath)
            Next

            'Add the Files in the Folder
            Dim files As FileInfo() = folder.GetFiles()
            For Each file As FileInfo In files
                Dim path As String = folder.FullName.Replace(rootPath, "")
                If path.StartsWith("\") Then
                    path = path.Substring(1)
                End If
                If folder.FullName.ToLower.Contains("app_code") Then
                    path = "[app_code]" + path
                End If
                AddFile(New PaFileInfo(file.Name, path, folder.FullName))
            Next

        End Sub

#End Region

#Region "Public Methods"

        Public Function CreatePrivateAssembly(ByVal DesktopModuleId As Integer) As String

            Dim Result As String = ""

            'Get the Module Definition File for this Module
            Dim objDesktopModuleController As New DesktopModuleController
            Dim objModule As DesktopModuleInfo = objDesktopModuleController.GetDesktopModule(DesktopModuleId)

            ProgressLog.StartJob(String.Format(Localization.GetString("LOG.PAWriter.CreateManifest"), objModule.FriendlyName))
            CreateDnnManifest(objModule)
            ProgressLog.EndJob((String.Format(Localization.GetString("LOG.PAWriter.CreateManifest"), objModule.FriendlyName)))

            ProgressLog.StartJob(String.Format(Localization.GetString("LOG.PAWriter.CreateZipFile"), objModule.FriendlyName))
            CreateZipFile()
            ProgressLog.EndJob((String.Format(Localization.GetString("LOG.PAWriter.CreateZipFile"), objModule.FriendlyName)))

            Return Result
        End Function

#End Region

    End Class
End Namespace